/// <reference types="next" />
/// <reference types="next/image-types/global" />
/// <reference path="./.next-tooling-build-october/types/routes.d.ts" />

// NOTE: This file should not be edited
// see https://nextjs.org/docs/app/api-reference/config/typescript for more information.
