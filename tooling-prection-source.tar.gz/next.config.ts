import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  distDir: process.env.NEXT_BUILD_DIR || ".next-tooling-build-october",
  images: { remotePatterns: [{ protocol: "https", hostname: "toolingprection.com" }] },
};

export default nextConfig;
