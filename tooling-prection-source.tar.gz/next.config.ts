import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  distDir: ".next-tooling-build-october",
  images: { remotePatterns: [{ protocol: "https", hostname: "toolingprection.com" }] },
};

export default nextConfig;
