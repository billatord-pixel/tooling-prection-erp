import path from "node:path";
import { defineConfig } from "vitest/config";

export default defineConfig({
  esbuild: { jsx: "automatic" },
  test: { include: ["src/**/*.test.ts"], testTimeout: 15000 },
  resolve: { alias: { "@": path.resolve(__dirname, "src") } },
});
