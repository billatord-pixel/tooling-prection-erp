-- AlterTable
ALTER TABLE "SalesInvoice" ADD COLUMN     "archivedAt" TIMESTAMP(3);

-- CreateTable
CREATE TABLE "customer_orders" (
    "id" TEXT NOT NULL,
    "customer_id" TEXT NOT NULL,
    "folio" VARCHAR(100) NOT NULL,
    "normalized_folio" VARCHAR(100) NOT NULL,
    "revision" VARCHAR(40) NOT NULL DEFAULT '',
    "order_date" DATE NOT NULL,
    "due_date" DATE,
    "deadline_text" VARCHAR(500),
    "currency" CHAR(3) NOT NULL DEFAULT 'USD',
    "declared_total" DECIMAL(19,4),
    "contact_name" VARCHAR(200),
    "delivery_address" TEXT,
    "notes_text" TEXT,
    "status" VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    "source_checksum" CHAR(64),
    "company_snapshot" JSONB,
    "created_by_id" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "customer_orders_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "customer_order_items" (
    "id" TEXT NOT NULL,
    "order_id" TEXT NOT NULL,
    "line_number" INTEGER NOT NULL,
    "customer_code" VARCHAR(200),
    "description" TEXT NOT NULL,
    "product_id" TEXT,
    "quantity" DECIMAL(19,4) NOT NULL,
    "unit" VARCHAR(20) NOT NULL DEFAULT 'PZA',
    "unit_price" DECIMAL(19,4),
    "due_date" DATE,
    "notes_text" TEXT,

    CONSTRAINT "customer_order_items_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "CustomerOrderAttachment" (
    "id" TEXT NOT NULL,
    "orderId" TEXT NOT NULL,
    "fileName" TEXT NOT NULL,
    "checksum" TEXT NOT NULL,
    "data" BYTEA NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "CustomerOrderAttachment_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "customer_order_allocations" (
    "id" TEXT NOT NULL,
    "order_item_id" TEXT NOT NULL,
    "purchase_order_item_id" TEXT NOT NULL,
    "quantity" DECIMAL(19,4) NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "customer_order_allocations_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "customer_order_deliveries" (
    "id" TEXT NOT NULL,
    "order_item_id" TEXT NOT NULL,
    "quantity" DECIMAL(19,4) NOT NULL,
    "delivery_date" DATE NOT NULL,
    "delivery_note_item_id" TEXT,
    "notes_text" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),
    "invoice_link_id" TEXT,

    CONSTRAINT "customer_order_deliveries_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "customer_order_invoice_links" (
    "id" TEXT NOT NULL,
    "order_id" TEXT NOT NULL,
    "sales_invoice_id" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "customer_order_invoice_links_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "customer_orders_source_checksum_key" ON "customer_orders"("source_checksum");

-- CreateIndex
CREATE INDEX "customer_orders_status_due_date_idx" ON "customer_orders"("status", "due_date");

-- CreateIndex
CREATE INDEX "customer_orders_customer_id_order_date_idx" ON "customer_orders"("customer_id", "order_date");

-- CreateIndex
CREATE UNIQUE INDEX "customer_orders_customer_id_normalized_folio_revision_key" ON "customer_orders"("customer_id", "normalized_folio", "revision");

-- CreateIndex
CREATE INDEX "customer_order_items_product_id_idx" ON "customer_order_items"("product_id");

-- CreateIndex
CREATE UNIQUE INDEX "customer_order_items_order_id_line_number_key" ON "customer_order_items"("order_id", "line_number");

-- CreateIndex
CREATE UNIQUE INDEX "CustomerOrderAttachment_checksum_key" ON "CustomerOrderAttachment"("checksum");

-- CreateIndex
CREATE INDEX "CustomerOrderAttachment_orderId_createdAt_idx" ON "CustomerOrderAttachment"("orderId", "createdAt");

-- CreateIndex
CREATE INDEX "customer_order_allocations_purchase_order_item_id_idx" ON "customer_order_allocations"("purchase_order_item_id");

-- CreateIndex
CREATE UNIQUE INDEX "customer_order_allocations_order_item_id_purchase_order_ite_key" ON "customer_order_allocations"("order_item_id", "purchase_order_item_id");

-- CreateIndex
CREATE INDEX "customer_order_deliveries_order_item_id_idx" ON "customer_order_deliveries"("order_item_id");

-- CreateIndex
CREATE INDEX "customer_order_deliveries_delivery_note_item_id_idx" ON "customer_order_deliveries"("delivery_note_item_id");

-- CreateIndex
CREATE INDEX "customer_order_deliveries_invoice_link_id_idx" ON "customer_order_deliveries"("invoice_link_id");

-- CreateIndex
CREATE INDEX "customer_order_invoice_links_sales_invoice_id_idx" ON "customer_order_invoice_links"("sales_invoice_id");

-- CreateIndex
CREATE UNIQUE INDEX "customer_order_invoice_links_order_id_sales_invoice_id_key" ON "customer_order_invoice_links"("order_id", "sales_invoice_id");

-- AddForeignKey
ALTER TABLE "customer_orders" ADD CONSTRAINT "customer_orders_customer_id_fkey" FOREIGN KEY ("customer_id") REFERENCES "Party"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "customer_orders" ADD CONSTRAINT "customer_orders_created_by_id_fkey" FOREIGN KEY ("created_by_id") REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "customer_order_items" ADD CONSTRAINT "customer_order_items_order_id_fkey" FOREIGN KEY ("order_id") REFERENCES "customer_orders"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "customer_order_items" ADD CONSTRAINT "customer_order_items_product_id_fkey" FOREIGN KEY ("product_id") REFERENCES "Product"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CustomerOrderAttachment" ADD CONSTRAINT "CustomerOrderAttachment_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES "customer_orders"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "customer_order_allocations" ADD CONSTRAINT "customer_order_allocations_order_item_id_fkey" FOREIGN KEY ("order_item_id") REFERENCES "customer_order_items"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "customer_order_allocations" ADD CONSTRAINT "customer_order_allocations_purchase_order_item_id_fkey" FOREIGN KEY ("purchase_order_item_id") REFERENCES "PurchaseOrderLine"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "customer_order_deliveries" ADD CONSTRAINT "customer_order_deliveries_order_item_id_fkey" FOREIGN KEY ("order_item_id") REFERENCES "customer_order_items"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "customer_order_deliveries" ADD CONSTRAINT "customer_order_deliveries_delivery_note_item_id_fkey" FOREIGN KEY ("delivery_note_item_id") REFERENCES "DeliveryLine"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "customer_order_deliveries" ADD CONSTRAINT "customer_order_deliveries_invoice_link_id_fkey" FOREIGN KEY ("invoice_link_id") REFERENCES "customer_order_invoice_links"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "customer_order_invoice_links" ADD CONSTRAINT "customer_order_invoice_links_order_id_fkey" FOREIGN KEY ("order_id") REFERENCES "customer_orders"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "customer_order_invoice_links" ADD CONSTRAINT "customer_order_invoice_links_sales_invoice_id_fkey" FOREIGN KEY ("sales_invoice_id") REFERENCES "SalesInvoice"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
