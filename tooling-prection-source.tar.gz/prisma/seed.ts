import { PrismaClient, Role } from "@prisma/client";
import bcrypt from "bcryptjs";

const db = new PrismaClient();

async function main() {
  // Keep only the two supported application roles. Existing non-admin users
  // become Sellers without changing their accounts or historical records.
  await db.user.updateMany({ where: { role: { in: [Role.PURCHASES, Role.INVENTORY, Role.READONLY] } }, data: { role: Role.SALES } });
  await db.companySettings.upsert({
    where: { id: "tooling-prection-company" },
    update: {},
    create: {
      id: "tooling-prection-company", legalName: "Tooling Prection", tradeName: "Tooling Prection",
      logoUrl: "/brand/tooling-prection-logo.jpg", phone: "221-300-31-16", email: "tooling.prection@yahoo.com", currency: "USD",
      address: "Cjon. Agustín Delgado 11B, Tránsito, Cuauhtémoc", city: "Ciudad de México", state: "CDMX", postalCode: "06820",
    },
  });
  const email = process.env.INITIAL_ADMIN_EMAIL;
  const password = process.env.INITIAL_ADMIN_PASSWORD;
  if (email && password) await db.user.upsert({ where: { email }, update: { role: Role.ADMIN, isActive: true }, create: { email, name: "Administrador Tooling Prection", passwordHash: await bcrypt.hash(password, 12), role: Role.ADMIN } });
  for (const name of ["Mitsubishi", "Boehlerit", "Moldino", "NTK Cutting Tools", "M.A. Ford", "Hoffmann", "Aurelion"]) await db.brand.upsert({ where: { name }, update: {}, create: { name } });
  for (const name of ["Paquetería", "Recolección", "Transporte del cliente", "Su transporte", "Entrega local"]) await db.shippingMethod.upsert({ where: { name }, update: {}, create: { name } });
}

main().finally(() => db.$disconnect());
