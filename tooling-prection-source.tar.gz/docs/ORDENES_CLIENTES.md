# Órdenes de clientes — Tooling Prection

Referencia de lectura: Gerat-Tool-ERP, commit 3ce073af2332dd651268dbca4692dd20164953a8.
No se copiaron clientes, órdenes, acuerdos de plazo, credenciales ni documentos.

## Operación

Menú Comercial → Órdenes de clientes. Captura manual o PDF opcional con propuesta
editable y confirmación de revisión. Folio original + cliente + revisión únicos;
partidas independientes, producto opcional y vencimiento propio que prevalece
sobre el general. Moneda inicial USD. Sin fecha identificada no se inventa plazo.

Los filtros de vencimiento se calculan por partida pendiente, con días de Ciudad
de México. Búsqueda por cliente, folio y descripción; filtros, paginación y retorno
conservados en la URL. El PDF individual no hereda filtros del listado; el general
respeta filtros explícitos y sólo imprime saldos pendientes. Todas las partidas se
agrupan por orden y los encabezados se repiten en continuaciones.

Las asignaciones manuales validan unidad y capacidad de ambas partes considerando
otras órdenes. Cancelar libera capacidad comercial, archivar no. Reactivar valida
de nuevo. Pedidos cancelados/archivados no cubren. En Tooling, un pedido PENDING es
material solicitado; no se introduce una segunda lógica de pedidos o inventario.

Entregas manuales por partida o referencia a remisión DELIVERED del mismo cliente,
sin volver a despachar. Folios de factura deben ser inequívocos, vigentes y del
mismo cliente. Vincular no entrega; cerrar todo exige confirmación explícita de
surtido y facturación. Sólo se registran los saldos restantes. Varias facturas,
idempotencia y retiro de referencias con motivo. Anular factura no elimina
silenciosamente entregas comerciales: se advierte en el detalle.

## Seguridad y datos

Administrador: lectura, creación, edición, entrega y vínculos separados.
Vendedor: lectura e impresión, respetando la política previa de Tooling.
No se amplían permisos financieros. Los contextos de proveedor no retornan costos.
PDF original en PostgreSQL BYTEA privado, descarga autenticada, SHA-256 único,
duplicados incluidos archivados y originales anteriores. Reemplazo confirmado;
anteriores conservados. Respaldo PostgreSQL diario ya incluye las nuevas tablas.
Exportación lógica v3 también las incluye; no sustituye el respaldo restaurable.

Edición conserva IDs y números originales de partida. No elimina actividad ni
reduce bajo entregas/asignaciones. Operaciones transaccionales con bloqueo
comercial PostgreSQL y control optimista updatedAt. Auditoría incluye usuario,
fecha, operación/motivo e inventoryAffected:false.

Migración aditiva documentada en prisma/additive/customer-orders-20261014.sql:
seis tablas nuevas y un campo nullable de archivo en SalesInvoice. El mecanismo
actual de inicio Railway aplica prisma db push; no se usa accept-data-loss.
La referencia SQL no debe ejecutarse nuevamente después del arranque.

## Limitaciones

La extracción genérica sólo reconoce texto y estructuras confiables; no promete
OCR ni lectura universal. Formatos desconocidos continúan manualmente conservando
el PDF. No se trasladan acuerdos comerciales particulares de Gerat.
No hay carga inicial de órdenes reales: el módulo productivo comienza vacío.

## Verificación

Pruebas unitarias de estados, calendario, capacidad decimal, permisos, lectura
real PDF y reporte multipágina. Pruebas integradas en PostgreSQL restaurado y
aislado: edición/IDs/concurrencia, parciales/idempotencia/cierre, múltiples facturas,
folios inválidos, capacidad entre órdenes, archivo/reactivación, remisiones,
duplicados SHA-256 y permisos. Huellas de existencias y movimientos idénticas antes
y después del módulo. Pruebas del circuito de compras/ventas existente también.
Los datos ficticios se mantienen sólo en la base local efímera, nunca Railway.
