# Productos comprados por mes

En Facturas de compra, seleccionar mes y consultar productos. Una fila por código y descripción del catálogo (o del CFDI si no está vinculado), con folios de compra relacionados y cantidad total. No se agrupa por proveedor ni por factura. Las unidades incompatibles se mantienen separadas.

GET /api/reports/purchased-products?month=AAAA-MM&format=json|pdf. Requiere sesión, permite consulta e impresión a vendedores, sin permisos de escritura. El intervalo usa la fecha fiscal desde el inicio del mes inclusive hasta el siguiente mes exclusivo. Excluye canceladas y borradores; compras no dispone de archivado. El PDF comparte el diseño y paginación del reporte mensual de ventas con títulos propios de compras.

No modifica facturas, productos, inventario ni costos. No requiere migraciones.

La columna Proveedor muestra las razones sociales de los proveedores de las facturas relacionadas, sin duplicar un mismo proveedor por herramienta. Si una herramienta se compró a varios proveedores, todos aparecen en la misma fila, en pantalla y PDF, conservando su cantidad total y folios.

Cada folio muestra su fecha de facturación (issueDate) en DD/MM/AAAA, tanto en pantalla como en PDF. La fecha fiscal no se desplaza por zona horaria. Varias fechas no generan filas separadas por herramienta.
