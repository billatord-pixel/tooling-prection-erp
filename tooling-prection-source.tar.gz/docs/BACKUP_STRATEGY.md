# Estrategia de respaldos independiente

1. Railway PostgreSQL `tooling-prection-postgres`: backup automático diario, retención mínima de 30 días y exportación cifrada semanal a almacenamiento propio.
2. Archivos XML/PDF: bucket exclusivo `tooling-prection-files`, versionado y replicación diaria. No se permite montar ni compartir un volumen de Gerat Tool.
3. Secretos: `BACKUP_ENCRYPTION_KEY` almacenada en un gestor separado; guarda una copia de recuperación fuera de Railway con acceso limitado a administradores.
4. Restauración: cada mes restaura el último backup a una base temporal independiente, ejecuta el checklist de login, productos, facturas y archivos, y documenta el resultado.
5. Alertas: `/api/health` no saludable, errores HTTP 500–599, fallos de backup y más de cinco intentos de inicio de sesión fallidos en 15 minutos.

Nunca se restaura un backup de Gerat Tool en este proyecto ni viceversa.
