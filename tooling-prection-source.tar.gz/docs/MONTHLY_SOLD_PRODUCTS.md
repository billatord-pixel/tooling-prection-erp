# Productos vendidos por mes

Cada folio incluye su fecha de facturación (issueDate) en DD/MM/AAAA en pantalla y PDF, sin desplazar el día fiscal por zona horaria. Se conserva una fila por herramienta aunque incluya varias facturas con fechas diferentes.

Ventas → Productos vendidos por mes → seleccionar mes → Consultar productos.
Una fila por código técnico y descripción, no por folio. Muestra los folios
relacionados sin repetir una referencia y suma todas sus partidas. Los folios
abren la factura correspondiente. La descarga PDF incluye el reporte completo.

Identidad de herramienta del catálogo vinculado: código + descripción técnica.
Si falta catálogo, conserva descripción fiscal y utiliza código del XML sólo si
la coincidencia descripción/cantidad es inequívoca. Nunca omite una línea sin
catálogo; se identifica como Sin código cuando no existe identificación confiable.
Se normalizan espacios y mayúsculas de agrupación, no ceros ni signos del código.
Unidades pieza/H87/PCS se unifican; unidades incompatibles no se suman entre sí.

Mes de la fecha fiscal almacenada, desde día 1 inclusive hasta siguiente mes
exclusivo, sin desplazar la fecha local de CFDI. Excluye canceladas, borradores y
archivadas. Incluye tanto pagadas como pendientes, también históricas del mes.
No mezcla importes o monedas: es un reporte de herramientas y cantidades, sin precios.

Consulta y PDF autenticados para administradores/vendedores; no modifica permisos
de escritura ni el reporte general. Endpoint GET /api/reports/sold-products,
month=AAAA-MM y format=json|pdf. Sin cambios de esquema, saldos, documentos o ledger.
Formato Tooling Prection, encabezados repetidos y filas extensas continuadas
sin truncar descripciones ni omitir folios.
