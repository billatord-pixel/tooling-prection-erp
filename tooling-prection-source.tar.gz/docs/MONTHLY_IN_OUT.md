# Entradas y salidas

Reporte operativo mensual en Reportes (administrador y vendedor), con consulta y PDF privado en /api/reports/in-out?month=AAAA-MM&format=json|pdf. Combina exactamente los reportes mensuales de productos comprados y vendidos: una fila por código, descripción y unidad compatible. Orden natural por código. Incluye herramientas que sólo aparecen en compras o sólo en ventas, proveedores y folios con fecha fiscal.

Compras en verde, ventas en rojo, con encabezados explícitos y cantidades separadas. Mantiene las exclusiones de los reportes originales. No es un kardex ni calcula existencia, saldo inicial o diferencias; incluye las ventas históricas que integran el reporte de ventas. No modifica inventario ni facturas. Unidades incompatibles conservan filas y totales separados. El mes aplicado determina la descarga aunque se cambie el selector después de consultar.
