# Monedas y valoración solicitada — 29/10/2026

Los importes de facturas de venta/compra, vistas previas, cuentas por cobrar,
dashboard y reportes muestran el código ISO (MXN, USD o EUR), también en pesos.
No se modifican los PDF fiscales originales adjuntos.

Valoración comercial personalizada sobre existencias actuales:

1. Producto con factura de venta vigente: precio unitario de su última venta,
   ordenada por fecha de factura, después fecha de registro e identificador.
2. Sin venta vigente: precio de su última factura de compra vigente.
3. Sin documentos: costo de catálogo, identificado expresamente.

Se excluyen ventas canceladas, borrador y archivadas; compras canceladas/borrador.
Las líneas deben tener cantidad positiva. Se utiliza precio unitario sin IVA.
No se modifica stock, pedidos, precios de catálogo, ledger ni documentos fiscales.
Las existencias negativas mantienen su signo y requieren conciliación documental.
Un precio cero documentado se conserva; no se sustituye por otro.

Inventario y resumen de productos muestran valores separados por moneda original
del precio elegido. El reporte general en MXN convierte cada precio extranjero
con el TipoCambio de su propia factura, recuperándolo del XML si es necesario.
No se usa una tasa actual o ajena. Si no hay conversión documental válida, el valor
seleccionado se marca parcial y se conserva el desglose nativo en Inventario.
La selección USD/EUR no mezcla inventario denominado en otras monedas.

El periodo del reporte filtra ventas/compras, no la valoración del stock actual:
para esta última se busca la última factura vigente de toda la historia.
Se comparte la misma función en /api/inventory, /api/reports y el PDF de productos.

Pruebas: formato MXN/USD/EUR, precio de venta/compra/catálogo, ceros y negativos,
conversión por factura, falta de cambio, suma decimal, selección de documentos,
PDF de ventas/compras y consulta Prisma sobre restauración PostgreSQL aislada.
