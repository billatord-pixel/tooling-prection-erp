# Checklist de pruebas de aceptación

- [ ] Crear cliente y proveedor.
- [ ] Crear producto y confirmar bloqueo por código técnico duplicado.
- [ ] Crear pedido de compra y producto desde pedido.
- [ ] Importar factura de compra XML con PDF opcional; comprobar proveedor por RFC, vínculo de pedido y entrada única.
- [ ] Crear remisión y comprobar salida cuando corresponda.
- [ ] Importar factura de venta XML; confirmar cliente por RFC, UUID único y salida única.
- [ ] Generar PDFs de cotización, pedido, remisión, facturas y reportes.
- [ ] Aplicar descuento y crear producto desde cotización.
- [ ] Probar permisos por rol y auditoría.
- [ ] Probar drawer móvil a 320, 375, 390, 430 y 768 px, en ambas orientaciones.
- [ ] Recargar y comprobar persistencia.
- [ ] Ejecutar backup y restaurar en base temporal independiente.
- [ ] Verificar que variables, base, bucket y dominio no correspondan a Gerat Tool.
