# Respaldos de Tooling Prection

El respaldo completo usa `pg_dump` de la base independiente de Tooling Prection mediante el acceso existente de Railway. No conecta ni modifica Gerat Tool y no crea un puerto público de PostgreSQL.

Los archivos se guardan en `OneDrive/Documentos/ChatGPT/Tooling Prection - Respaldos`, cifrados con AES-256-GCM. La etiqueta de autenticación y los hashes se comprueban antes de publicar el archivo final. El último estado e historial quedan en `backup-status.json` y `backup-history.jsonl`; los archivos `.partial` no se consideran respaldos válidos.

La tarea de Windows está programada a las 14:00 en Ciudad de México. Requiere PC encendida, sesión iniciada, Internet y OneDrive sincronizando. Si no está disponible en el horario programado, Windows intenta ejecutarla al volver a estar disponible. No se borran respaldos anteriores automáticamente.

## Llave de recuperación

La ruta física de la llave está registrada en `backup-status.json` (`recoveryKeyLocation`), fuera de OneDrive y del repositorio. La carpeta tiene acceso local restringido al usuario de Windows y SYSTEM. Es indispensable conservar una copia de esta llave en un medio privado separado para poder recuperar los respaldos en otro equipo. No publicar ni enviar la llave junto con los respaldos. Si se pierde esta llave, los respaldos cifrados no se pueden recuperar.

El acceso de Railway/SSH existente también debe mantenerse vigente para las siguientes ejecuciones. Un fallo se registra como fallo, nunca como respaldo exitoso. El indicador de Railway confirma la creación local del archivo, no la finalización de la sincronización remota de OneDrive.

## Prueba de restauración

`node scripts/verify-backup-restore.mjs RUTA_DEL_ARCHIVO.tpbackup` descifra el archivo únicamente en una carpeta temporal restringida, levanta PostgreSQL local en 127.0.0.1:54987, restaura todas las tablas y comprueba los adjuntos. No modifica la base de producción. La base temporal se detiene y elimina después de la prueba. El resultado queda en `restore-verification.json` dentro de la carpeta de respaldos.

Una restauración real de producción requiere planificar la interrupción, comprobar la fecha elegida y conservar el estado actual antes de sustituir datos. El script de prueba no realiza esa operación.
