# Arranque operativo — octubre de 2026

El ERP se entrega sin XML, PDF, clientes, proveedores, pedidos, existencias ni historial. Esta decisión conserva la independencia respecto a Gerat Tool y permite iniciar los datos nuevos desde octubre.

Antes del primer despliegue, configura valores nuevos en Railway: `DATABASE_URL`, `AUTH_SECRET`, `INITIAL_ADMIN_EMAIL` e `INITIAL_ADMIN_PASSWORD`. Usa un PostgreSQL, dominio, bucket, SMTP y respaldo propios de Tooling Prection.

El primer arranque ejecuta `pnpm db:bootstrap`, que crea el esquema de la base nueva y aplica una semilla idempotente: identidad de Tooling Prection, logo oficial, marcas de referencia y el administrador indicado en las variables. No inserta operaciones ni archivos.

Secuencia de uso al iniciar:

1. Inicia sesión con el administrador y registra los usuarios con su rol.
2. Completa o ajusta productos, proveedores y clientes desde sus catálogos.
3. Registra pedidos de compra. La cantidad se refleja en **En pedido**, sin aumentar la existencia.
4. Al registrar y confirmar una factura de compra, la existencia aumenta y se reduce **En pedido**; reintentar el procesamiento no duplica el movimiento.
5. Crea remisiones y confirma la salida sólo al entregar. No se permiten existencias negativas.
6. Usa ajustes exclusivamente con un motivo; cada ajuste deja movimiento y evento de auditoría.

Para empezar a guardar CFDI en octubre, deja configurados un bucket independiente y credenciales SMTP propias. Hasta que se conecte ese almacenamiento, el módulo de facturas conserva el XML procesado en la base de datos y no requiere archivos históricos.
