import fs from "node:fs";
import path from "node:path";
import PDFDocument from "pdfkit";

const output = path.resolve("output/pdf");
fs.mkdirSync(output, { recursive: true });
const logo = path.resolve("public/brand/tooling-prection-logo.jpg");
const blue = "#075FA9", navy = "#163B5B", ink = "#243447", muted = "#536A82", pale = "#F0F6FC", cyan = "#5BBCE5";
const money = value => new Intl.NumberFormat("es-MX", { style: "currency", currency: "MXN" }).format(value);
const date = "26/09/2026";
const save = (doc, filename) => new Promise(resolve => { const stream = fs.createWriteStream(path.join(output, filename)); doc.pipe(stream); doc.end(); stream.on("finish", resolve); });

{
  const doc = new PDFDocument({ size: "LETTER", margins: { top: 38, left: 42, right: 42, bottom: 46 }, info: { Title: "Ejemplo pedido de compra Tooling Prection", Author: "Tooling Prection ERP" } });
  const left = 42, right = 570, width = right - left; let y = 38;
  doc.rect(0, 0, 68 * 4.25, 7).fill(navy); doc.rect(68 * 4.25, 0, 22 * 4.25, 7).fill(blue); doc.rect(90 * 4.25, 0, 10 * 4.25, 7).fill(cyan);
  try { doc.image(logo, left, y, { fit: [106, 48] }); } catch {}
  doc.font("Helvetica-Bold").fontSize(16).fillColor(navy).text("Tooling Prection", left + 118, y + 2);
  doc.font("Helvetica").fontSize(8).fillColor(muted).text("ERP · COMPRAS\nEJEMPLO · DATOS FICTICIOS", left + 118, y + 24, { lineGap: 2 });
  doc.roundedRect(right - 180, y, 180, 66, 7).fill(pale);
  doc.font("Helvetica-Bold").fontSize(8).fillColor(blue).text("PEDIDO / PURCHASE ORDER", right - 168, y + 9, { width: 156, align: "right" });
  doc.fontSize(15).fillColor(navy).text("OC-TP-EJ-0001", right - 168, y + 24, { width: 156, align: "right" });
  doc.font("Helvetica").fontSize(8).fillColor(muted).text(`FECHA / DATE  ${date}`, right - 168, y + 47, { width: 156, align: "right" });
  y += 82; doc.moveTo(left, y).lineTo(right, y).lineWidth(2).strokeColor(blue).stroke(); y += 13;
  const boxes = [["ENTREGA ESTIMADA", "10/10/2026"], ["SOLICITADO POR", "Equipo de Compras"], ["MODO DE ENVÍO", "Transportista"], ["CONDICIONES DE PAGO", "Crédito a 30 días"], ["MONEDA", "MXN"], ["TIPO DE CAMBIO", "1.000000"]];
  const bw = width / 3, bh = 44;
  boxes.forEach(([label, value], i) => { const x = left + (i % 3) * bw, by = y + Math.floor(i / 3) * bh; doc.rect(x, by, bw, bh).lineWidth(.6).strokeColor("#D5E5F2").stroke(); doc.font("Helvetica-Bold").fontSize(7).fillColor(muted).text(label, x + 9, by + 8, { width: bw - 18 }); doc.font("Helvetica").fontSize(8.5).fillColor(ink).text(value, x + 9, by + 23, { width: bw - 18 }); });
  y += bh * 2 + 13;
  doc.roundedRect(left, y, width, 72, 6).fill("#F3F7FA"); doc.rect(left, y, 5, 72).fill(blue);
  doc.font("Helvetica-Bold").fontSize(7.5).fillColor(blue).text("PROVEEDOR / SUPPLIER", left + 14, y + 10);
  doc.font("Helvetica-Bold").fontSize(11).fillColor(ink).text("Proveedor de Muestra, S.A. de C.V.", left + 14, y + 24);
  doc.font("Helvetica").fontSize(8).fillColor(muted).text("RFC: PMS260101AB1 · Ciudad de México · compras@proveedor-ejemplo.mx", left + 14, y + 45, { width: 300 });
  doc.font("Helvetica-Bold").fontSize(7.5).fillColor(muted).text("CONTACTO", left + 350, y + 12);
  doc.font("Helvetica").fontSize(8).fillColor(ink).text("Contacto de muestra · 55 0000 0000", left + 350, y + 28, { width: 165 });
  y += 87;
  const xs = [left, left + 108, left + 346, left + 398, left + 462, right];
  const heads = ["CÓDIGO / ITEM", "DESCRIPCIÓN / DESCRIPTION", "CANT. / QTY", "PRECIO / PRICE", "IMPORTE / AMOUNT"];
  doc.roundedRect(left, y, width, 25, 4).fill(pale); doc.font("Helvetica-Bold").fontSize(7).fillColor(navy);
  heads.forEach((h, i) => doc.text(h, xs[i] + 5, y + 8, { width: xs[i + 1] - xs[i] - 10, align: i > 1 ? "right" : "left", lineBreak: false })); y += 31;
  doc.rect(left, y - 3, width, 50).fill("#F5F9FD");
  ["TP-MUESTRA-01", "Inserto de carburo para mecanizado industrial · PZA", "5", money(124.4), money(622)].forEach((v, i) => doc.font(i === 0 ? "Helvetica-Bold" : "Helvetica").fontSize(8).fillColor(ink).text(v, xs[i] + 5, y + 5, { width: xs[i + 1] - xs[i] - 10, height: 40, align: i > 1 ? "right" : "left", ellipsis: true }));
  y += 68; const tx = right - 202;
  [["Subtotal", 622], ["Descuento", 0], ["Flete", 80], ["IVA 16%", 112.32]].forEach(([label, amount], i) => { doc.font("Helvetica").fontSize(8).fillColor(muted).text(label, tx, y + i * 17, { width: 90 }); doc.fillColor(ink).text(money(amount), tx + 90, y + i * 17, { width: 112, align: "right" }); });
  doc.moveTo(tx, y + 72).lineTo(right, y + 72).lineWidth(1).strokeColor(blue).stroke(); doc.font("Helvetica-Bold").fontSize(11).fillColor(navy).text("TOTAL", tx, y + 81); doc.text(money(814.32), tx + 90, y + 81, { width: 112, align: "right" });
  doc.font("Helvetica").fontSize(8).fillColor(muted).text("Observaciones: ejemplo visual con valores ilustrativos; no corresponde a una compra real.", left, 632, { width });
  doc.moveTo(left, 722).lineTo(right, 722).lineWidth(.5).strokeColor("#D8E6F1").stroke(); doc.font("Helvetica").fontSize(7).fillColor(muted).text("Documento de compra · Tooling Prection", left, 731); doc.text("Página 1 de 1", right - 90, 731, { width: 90, align: "right" });
  await save(doc, "ejemplo-pedido-compra-tooling-prection.pdf");
}

{
  const doc = new PDFDocument({ size: "LETTER", margins: { top: 44, left: 48, right: 48, bottom: 48 }, info: { Title: "Ejemplo reporte operativo Tooling Prection", Author: "Tooling Prection ERP" } });
  const left = 48, right = 564; let y = 40;
  try { doc.image(logo, left, y, { fit: [98, 44] }); } catch {}
  doc.font("Helvetica-Bold").fontSize(18).fillColor(navy).text("Tooling Prection", left + 112, y + 2);
  doc.font("Helvetica").fontSize(8).fillColor(muted).text("REPORTE OPERATIVO · EJEMPLO CON DATOS FICTICIOS", left + 112, y + 25);
  doc.fontSize(8).text("Periodo: septiembre 2026 · Moneda: MXN", right - 210, y + 26, { width: 210, align: "right" });
  y += 64; doc.moveTo(left, y).lineTo(right, y).lineWidth(2).strokeColor(blue).stroke(); y += 20;
  const metrics = [["Productos activos", "128"], ["Valor inventario", "$842,600.00"], ["Ventas del periodo", "$286,450.00"], ["Compras del periodo", "$174,820.00"]];
  metrics.forEach(([label, value], i) => { const x = left + (i % 2) * 258, by = y + Math.floor(i / 2) * 78; doc.roundedRect(x, by, 246, 64, 7).lineWidth(.8).strokeColor("#C9DEEF").stroke(); doc.font("Helvetica").fontSize(8).fillColor(muted).text(label, x + 13, by + 12); doc.font("Helvetica-Bold").fontSize(15).fillColor(navy).text(value, x + 13, by + 32, { width: 218 }); });
  y += 186; doc.font("Helvetica-Bold").fontSize(12).fillColor(navy).text("Ventas y compras por mes", left, y); y += 24;
  const bars = [{ m: "JUN", s: 208000, p: 157000 }, { m: "JUL", s: 242000, p: 181000 }, { m: "AGO", s: 198000, p: 143000 }, { m: "SEP", s: 286450, p: 174820 }], max = 300000;
  bars.forEach(row => { doc.font("Helvetica").fontSize(8).fillColor(muted).text(row.m, left, y + 1, { width: 34 }); const bx = left + 40, barMax = 284; doc.roundedRect(bx, y, barMax * row.s / max, 10, 4).fill(blue); doc.roundedRect(bx, y + 14, barMax * row.p / max, 10, 4).fill(cyan); doc.fontSize(7).fillColor(ink).text(`V ${money(row.s)} · C ${money(row.p)}`, bx + barMax + 10, y + 5, { width: 155, ellipsis: true }); y += 41; });
  y += 10; doc.font("Helvetica-Bold").fontSize(11).fillColor(navy).text("Saldos y operación", left, y); y += 21;
  [["Cuentas por cobrar", "$96,250.00"], ["Cuentas por pagar", "$72,100.00"], ["Pedidos pendientes", "7"], ["Movimientos de inventario", "42"]].forEach(([label, value]) => { doc.font("Helvetica").fontSize(9).fillColor(muted).text(label, left, y, { width: 250 }); doc.font("Helvetica-Bold").fillColor(ink).text(value, left + 270, y, { width: right - left - 270, align: "right" }); doc.moveTo(left, y + 16).lineTo(right, y + 16).lineWidth(.4).strokeColor("#E2ECF4").stroke(); y += 24; });
  doc.font("Helvetica").fontSize(8).fillColor(muted).text("Vista ilustrativa. Los importes de monedas distintas se reportan por separado y no se mezclan.", left, 730, { width: right - left });
  await save(doc, "ejemplo-reporte-tooling-prection.pdf");
}
