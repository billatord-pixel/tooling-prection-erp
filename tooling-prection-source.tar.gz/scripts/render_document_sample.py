from pathlib import Path
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import Image, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "output" / "pdf" / "tooling-prection-document-example.pdf"
LOGO = ROOT / "public" / "brand" / "tooling-prection-logo.jpg"

NAVY = colors.HexColor("#163B5B")
BLUE = colors.HexColor("#075FA9")
SKY = colors.HexColor("#5BBCE5")
INK = colors.HexColor("#243447")

def main():
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    doc = SimpleDocTemplate(str(OUTPUT), pagesize=A4, leftMargin=18*mm, rightMargin=18*mm, topMargin=15*mm, bottomMargin=15*mm)
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="TitleBrand", parent=styles["Title"], textColor=NAVY, fontName="Helvetica-Bold", fontSize=19, leading=23, spaceAfter=3*mm))
    styles.add(ParagraphStyle(name="Small", parent=styles["Normal"], textColor=colors.HexColor("#536A82"), fontSize=8, leading=11))
    styles.add(ParagraphStyle(name="BodyBrand", parent=styles["Normal"], textColor=INK, fontSize=9, leading=12))
    story = []
    logo = Image(str(LOGO), width=34*mm, height=24*mm, kind="proportional")
    heading = [logo, [Paragraph("<b>TOOLING PRECTION</b>", styles["TitleBrand"]), Paragraph("Documento de ejemplo - ERP independiente", styles["BodyBrand"]), Paragraph("Cjon. Agustin Delgado 11B, CDMX | 221-300-31-16 | tooling.prection@yahoo.com", styles["Small"])]]
    header = Table([heading], colWidths=[38*mm, 136*mm])
    header.setStyle(TableStyle([("VALIGN", (0,0), (-1,-1), "TOP"), ("LINEBELOW", (0,0), (-1,-1), 1.2, BLUE), ("BOTTOMPADDING", (0,0), (-1,-1), 6*mm)]))
    story += [header, Spacer(1, 7*mm), Paragraph("COTIZACION COT-000001", styles["TitleBrand"]), Paragraph("Fecha: 01/10/2026 &nbsp;&nbsp;&nbsp; Vigencia: 15 dias &nbsp;&nbsp;&nbsp; Moneda: MXN", styles["BodyBrand"]), Spacer(1, 5*mm)]
    data = [["CODIGO", "DESCRIPCION", "CANT.", "P. UNITARIO", "IMPORTE"], ["TP-001", "Inserto de carburo para mecanizado industrial", "10", "$1,250.00", "$12,500.00"], ["TP-002", "Fresa de alto rendimiento", "2", "$3,800.00", "$7,600.00"]]
    table = Table(data, colWidths=[24*mm, 80*mm, 18*mm, 28*mm, 28*mm], repeatRows=1)
    table.setStyle(TableStyle([("BACKGROUND", (0,0), (-1,0), NAVY), ("TEXTCOLOR", (0,0), (-1,0), colors.white), ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"), ("FONTSIZE", (0,0), (-1,-1), 8), ("LEADING", (0,0), (-1,-1), 10), ("GRID", (0,0), (-1,-1), .25, colors.HexColor("#D5E5F2")), ("VALIGN", (0,0), (-1,-1), "MIDDLE"), ("ALIGN", (2,0), (-1,-1), "RIGHT"), ("BACKGROUND", (0,1), (-1,-1), colors.white), ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, colors.HexColor("#F5F9FD")]), ("TOPPADDING", (0,0), (-1,-1), 3*mm), ("BOTTOMPADDING", (0,0), (-1,-1), 3*mm)]))
    story += [table, Spacer(1, 6*mm)]
    totals = Table([["Subtotal", "$20,100.00"], ["IVA", "$3,216.00"], ["TOTAL", "$23,316.00"]], colWidths=[30*mm, 30*mm], hAlign="RIGHT")
    totals.setStyle(TableStyle([("FONTNAME", (0,0), (-1,-1), "Helvetica"), ("FONTSIZE", (0,0), (-1,-1), 9), ("ALIGN", (0,0), (-1,-1), "RIGHT"), ("LINEABOVE", (0,2), (-1,2), 1, NAVY), ("FONTNAME", (0,2), (-1,2), "Helvetica-Bold"), ("TEXTCOLOR", (0,2), (-1,2), NAVY), ("TOPPADDING", (0,0), (-1,-1), 2*mm), ("BOTTOMPADDING", (0,0), (-1,-1), 2*mm)]))
    story += [totals, Spacer(1, 10*mm), Paragraph("Condiciones comerciales", styles["BodyBrand"]), Paragraph("Precios sujetos a disponibilidad. Tiempo de entrega conforme a cada partida. Este documento utiliza la identidad corporativa oficial y datos configurables de Tooling Prection.", styles["Small"])]
    doc.build(story)

if __name__ == "__main__": main()
