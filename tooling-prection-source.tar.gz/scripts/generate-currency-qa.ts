import { readFile,writeFile,mkdir } from "node:fs/promises";
import { resolve } from "node:path";
import { createInvoiceReportPdf } from "../src/lib/invoice-report-pdf";
async function main(){
 const folder=resolve("../../tmp/pdfs/currency-valuation-20261029");await mkdir(folder,{recursive:true});
 const logo=await readFile("public/brand/tooling-prection-logo.jpg");
 for(const kind of ["sales","purchases"] as const){
   const bytes=await createInvoiceReportPdf({kind,currency:"MXN",title:kind==="sales"?"Reporte de ventas":"Reporte de compras",period:"Ejemplo de verificación - datos ficticios",logo,invoices:[
    {issueDate:new Date("2026-10-29T12:00:00Z"),folio:"EJ-MXN-1",counterparty:"EMPRESA DE EJEMPLO EN PESOS",currency:"MXN",reportTotal:123456.78,status:"PAID",lineCount:2},
    {issueDate:new Date("2026-10-29T12:00:00Z"),folio:"EJ-USD-2",counterparty:"EMPRESA DE EJEMPLO EN DÓLARES CON NOMBRE LARGO PARA VERIFICAR LA DISTRIBUCIÓN DE COLUMNAS",currency:"USD",reportTotal:18000,status:"PENDING",lineCount:12},
    {issueDate:new Date("2026-10-29T12:00:00Z"),folio:"EJ-MXN-3",counterparty:"EMPRESA DE EJEMPLO CANCELADA",currency:"MXN",reportTotal:999,status:"CANCELLED",lineCount:1}
   ]});await writeFile(resolve(folder,kind+".pdf"),bytes);
 }
 console.log(folder);
}
main().catch(e=>{console.error(e);process.exitCode=1;});
