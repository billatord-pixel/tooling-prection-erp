import { mkdir,readFile,writeFile } from "node:fs/promises";
import { resolve } from "node:path";
import { groupMonthlySoldProducts } from "../src/lib/monthly-sold-products";
import { createMonthlySoldProductsPdf } from "../src/lib/monthly-sold-products-pdf";
async function main(){
 const lines=Array.from({length:70},(_,i)=>({code:"EDP "+(410755+Math.floor(i/3)),description:i<3?"RCMX2507M0-RR UH6400":"Herramienta de precisión "+Math.floor(i/3)+" - "+("Descripción técnica completa de herramienta. ".repeat(Math.floor(i/3)%7===0?9:2)),quantity:i<3?[5,8,12][i]:2+i%4,unit:"PZA",invoiceId:"invoice-"+i,folio:"F-EJ-"+(100+i)}));
 const report=groupMonthlySoldProducts("2026-10",lines);
 const target=resolve(process.argv[2]||"../../output/pdf/ejemplo-productos-vendidos-mensual-tooling-prection.pdf");await mkdir(resolve(target,".."),{recursive:true});
 await writeFile(target,await createMonthlySoldProductsPdf(report,{tradeName:"Tooling Prection",email:"tooling.prection@yahoo.com"},await readFile("public/brand/tooling-prection-logo.jpg")));console.log(target);
}
main().catch(e=>{console.error(e);process.exitCode=1;});
