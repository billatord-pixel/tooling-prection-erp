import { writeFile,readFile,mkdir } from "node:fs/promises";
import { resolve } from "node:path";
import { buildCustomerOrdersPendingPdf } from "../src/lib/customer-orders-pdf";
const rows=Array.from({length:24},(_,i)=>({orderId:i<3?"oc-uno":"oc-dos",lineNumber:i<3?i+1:i-2,customer:"Cliente de ejemplo (datos ficticios)",folio:i<3?"OC-TP-001":"OC-TP-002",description:i<3?"Inserto de precisión para mecanizado - entrega programada independiente":"Herramienta de corte con recubrimiento de alto rendimiento. "+("Descripción completa de la partida, sin recortes ni omisiones. ".repeat(3)),quantity:2+i%4,unit:"PZA",dueDate:"2026-10-"+(18+i%10),suppliers:i%3===0?"OC-TP-PROV-001 (2 PZA)":"Sin vincular",notes:"Ejemplo sin efectos sobre inventario"}));
const target=resolve(process.argv[2]||"../../output/pdf/ejemplo-ordenes-clientes-tooling-prection.pdf");
async function main() {
await mkdir(resolve(target,".."),{recursive:true});
await writeFile(target,await buildCustomerOrdersPendingPdf({company:{legalName:"Tooling Prection",tradeName:"Tooling Prection",email:"tooling.prection@yahoo.com"},rows,filterLabel:"Ejemplo ilustrativo - datos ficticios",today:"2026-10-14",logoBytes:await readFile("public/brand/tooling-prection-logo.jpg")}));
console.log(target);
}
main().catch(error=>{console.error(error);process.exitCode=1;});
