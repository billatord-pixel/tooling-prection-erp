import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import { spawn } from 'node:child_process';

export const scope = {
  project: '9fad48a4-01ef-4c86-9169-6b7f04ce1328',
  service: 'afd55a29-237f-42f9-b3ab-4738c2deb79a',
  environment: '678a5269-2b8b-4210-9205-1b07aa114e27',
};
export const backupRoot = path.join(os.homedir(), 'OneDrive/Documentos/ChatGPT/Tooling Prection - Respaldos');
export const privateRoot = process.env.TP_BACKUP_PRIVATE_ROOT || await fs.realpath(path.join(os.homedir(), 'AppData/Local/ToolingPrectionBackup')).catch(() => path.join(os.homedir(), 'AppData/Local/ToolingPrectionBackup'));
export const keyRoot = path.join(os.homedir(), '.tooling-prection-backup-private');
const sourceRoot = path.join(os.homedir(), 'OneDrive/Documentos/ChatGPT/Tooling Prection');
const cli = process.env.TP_RAILWAY_EXE;
export function run(executable, args, options = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(executable, args, { windowsHide: true, ...options });
    const output = [], errors = [];
    const timer = setTimeout(() => { child.kill(); reject(new Error('La operación excedió el tiempo permitido.')); }, 900_000);
    child.stdout?.on('data', data => output.push(data));
    child.stderr?.on('data', data => errors.push(data));
    child.on('error', error => { clearTimeout(timer); reject(error); });
    child.on('close', code => {
      clearTimeout(timer);
      if (code !== 0) return reject(new Error(`La operación falló (código ${code}). ${Buffer.concat(errors).toString().slice(-700)}`));
      resolve(Buffer.concat(output));
    });
  });
}
export async function decryptBackup(file) {
  const bytes = await fs.readFile(file);
  if (bytes.subarray(0, 8).toString() !== 'TPBAK001') throw new Error('Formato de respaldo inválido.');
  const key = await fs.readFile(path.join(keyRoot, 'recovery.key'));
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, bytes.subarray(8, 20));
  decipher.setAuthTag(bytes.subarray(20, 36));
  return Buffer.concat([decipher.update(bytes.subarray(36)), decipher.final()]);
}
export async function reportBackupStatus(status) {
  if (!cli) throw new Error('No hay cliente Railway disponible para registrar el respaldo.');
  const event = { status: status.status, completedAt: status.completedAt, file: status.file, bytes: status.bytes, encryption: status.encryption, restoreVerifiedAt: status.restoreVerifiedAt };
  const payload = Buffer.from(JSON.stringify(event)).toString('base64');
  const code = `const {PrismaClient}=require('@prisma/client');const db=new PrismaClient();db.auditEvent.create({data:{entity:'DatabaseBackup',action:'BACKUP_${status.status === 'success' ? 'SUCCESS' : 'FAILED'}',after:JSON.parse(Buffer.from('${payload}','base64').toString())}}).then(()=>db.$disconnect()).catch(()=>process.exit(1));`;
  await run(cli, ['ssh', '--project', scope.project, '--service', '5aec5d84-2e39-4d20-833d-28200a3b1a21', '--environment', scope.environment, '--', 'node', '-e', code]);
}
async function main() {
  await fs.mkdir(backupRoot, { recursive: true });
  await fs.mkdir(privateRoot, { recursive: true });
  await fs.mkdir(keyRoot, { recursive: true });
  const statusPath = path.join(backupRoot, 'backup-status.json');
  const startedAt = new Date().toISOString();
  const status = { scope, startedAt, status: 'running', completedAt: null };
  // A local exclusive lock avoids simultaneous manual and scheduled runs.
  const lockFile = path.join(privateRoot, 'backup.lock');
  let lock;
  try { lock = await fs.open(lockFile, 'wx'); }
  catch (error) {
    if (error.code !== 'EEXIST') throw error;
    let stale = false;
    try {
      const previous = JSON.parse(await fs.readFile(lockFile, 'utf8'));
      try { process.kill(previous.pid, 0); } catch (error) { stale = error.code === 'ESRCH'; }
    } catch { stale = Date.now() - (await fs.stat(lockFile)).mtimeMs > 20 * 60_000; }
    if (!stale) throw new Error('Ya hay un respaldo en ejecución.');
    await fs.unlink(lockFile);
    lock = await fs.open(lockFile, 'wx');
  }
  await lock.writeFile(JSON.stringify({ pid: process.pid, startedAt }));
  try {
    if (!cli) throw new Error('Falta la ruta del cliente Railway.');
    await fs.writeFile(statusPath, JSON.stringify(status, null, 2));
    const args = ['ssh', '--project', scope.project, '--service', scope.service, '--environment', scope.environment, '--', 'bash', '-lc',
      'set -o pipefail; pg_dump -U postgres -d railway --format=custom --no-owner --no-acl | base64 -w0'];
    const raw = await run(cli, args);
    const lines = raw.toString('utf8').split(/\r?\n/).map(line => line.trim());
    const payload = lines.find(line => line.length > 100 && /^[A-Za-z0-9+/=]+$/.test(line));
    if (!payload) throw new Error('Railway no devolvió un archivo de base de datos válido.');
    const dump = Buffer.from(payload, 'base64');
    if (dump.subarray(0, 5).toString() !== 'PGDMP') throw new Error('El respaldo PostgreSQL no pasó la validación de formato.');
    const stamp = new Intl.DateTimeFormat('sv-SE', { timeZone: 'America/Mexico_City', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }).format(new Date()).replace(/[ :]/g, '-');
    const destination = path.join(backupRoot, `Tooling-Prection-datos-${stamp}.tpbackup`);
    let key;
    try { key = await fs.readFile(path.join(keyRoot, 'recovery.key')); }
    catch (error) {
      if (error.code !== 'ENOENT') throw error;
      key = crypto.randomBytes(32);
      await fs.writeFile(path.join(keyRoot, 'recovery.key'), key, { flag: 'wx', mode: 0o600 });
    }
    if (key.length !== 32) throw new Error('La llave de recuperación no es válida.');
    const iv = crypto.randomBytes(12);
    const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
    const encrypted = Buffer.concat([cipher.update(dump), cipher.final()]);
    const bytes = Buffer.concat([Buffer.from('TPBAK001'), iv, cipher.getAuthTag(), encrypted]);
    await fs.writeFile(`${destination}.partial`, bytes, { flag: 'wx' });
    const decoded = await decryptBackup(`${destination}.partial`);
    const sha256 = value => crypto.createHash('sha256').update(value).digest('hex');
    if (sha256(decoded) !== sha256(dump)) throw new Error('El archivo cifrado no pasó la comprobación de integridad.');
    await fs.rename(`${destination}.partial`, destination);
    // Preserve the exact source archive deployed by this project's repository.
    const releaseArchive = path.join(sourceRoot, 'tmp/tooling-prection-deploy-clone-20260928/tooling-prection-source.tar.gz');
    await fs.copyFile(releaseArchive, path.join(backupRoot, `Tooling-Prection-codigo-${stamp}.tar.gz`));
    Object.assign(status, { status: 'success', completedAt: new Date().toISOString(), file: path.basename(destination), bytes: bytes.length,
      plaintextSha256: sha256(dump), encryptedSha256: sha256(bytes), includes: ['Base PostgreSQL completa', 'Clientes y proveedores', 'Productos y movimientos', 'Usuarios y permisos', 'XML originales', 'PDF de venta y compra', 'Adjuntos de remisiones'],
      encryption: 'AES-256-GCM', recoveryKeyLocation: path.join(keyRoot, 'recovery.key'), cloudSyncVerified: false });
    try { await reportBackupStatus(status); status.productionStatusRecorded = true; }
    catch { status.productionStatusRecorded = false; }
    await fs.writeFile(statusPath, JSON.stringify(status, null, 2));
    await fs.appendFile(path.join(backupRoot, 'backup-history.jsonl'), JSON.stringify(status) + '\n');
    console.log(JSON.stringify({ status: 'success', file: destination, bytes: bytes.length, completedAt: status.completedAt }));
  } catch (error) {
    Object.assign(status, { status: 'failed', completedAt: new Date().toISOString(), error: error.message });
    await fs.writeFile(statusPath, JSON.stringify(status, null, 2));
    await fs.appendFile(path.join(backupRoot, 'backup-history.jsonl'), JSON.stringify(status) + '\n');
    try { await reportBackupStatus(status); } catch {}
    throw error;
  } finally { await lock.close(); await fs.unlink(lockFile); }
}
if (process.argv[1] && path.resolve(process.argv[1]) === path.resolve(new URL(import.meta.url).pathname.replace(/^\/(?=[A-Za-z]:)/, '').replaceAll('%20', ' '))) {
  main().catch(error => { console.error(error.message); process.exitCode = 1; });
}
