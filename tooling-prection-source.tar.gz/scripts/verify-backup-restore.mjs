import fs from 'node:fs/promises';
import path from 'node:path';
import { createRequire } from 'node:module';
import { decryptBackup, run, backupRoot, privateRoot } from './onedrive-backup.mjs';
const require = createRequire(path.join(privateRoot, 'tools/package.json'));
const { Client } = require('pg');
const bin = path.join(privateRoot, 'postgresql/pgsql/bin');
const sandbox = await fs.mkdtemp(path.join(privateRoot, 'restore-check-'));
const dumpPath = path.join(sandbox, 'restoration.dump');
const dataPath = path.join(sandbox, 'data');
const backupFile = process.argv[2];
let started = false;
let client;
try {
  const dump = await decryptBackup(backupFile);
  await fs.writeFile(dumpPath, dump);
  const listing = await run(path.join(bin, 'pg_restore.exe'), ['--list', dumpPath]);
  if (!listing.toString().includes('TABLE DATA public')) throw new Error('El archivo no contiene tablas de datos.');
  await run(path.join(bin, 'initdb.exe'), ['-D', dataPath, '-U', 'postgres', '-A', 'trust', '--encoding=UTF8', '--no-locale']);
  await run(path.join(bin, 'pg_ctl.exe'), ['-D', dataPath, '-l', path.join(sandbox, 'server.log'), '-o', '-h 127.0.0.1 -p 54987', '-w', 'start'], { stdio: 'ignore' });
  started = true;
  const connectionString = 'postgresql://postgres@127.0.0.1:54987/postgres';
  await run(path.join(bin, 'pg_restore.exe'), ['--dbname', connectionString, '--no-owner', '--no-privileges', '--exit-on-error', '--single-transaction', dumpPath]);
  client = new Client({ connectionString });
  await client.connect();
  const counts = {};
  const tables = (await client.query("SELECT tablename FROM pg_tables WHERE schemaname='public' ORDER BY tablename")).rows;
  for (const { tablename } of tables) counts[tablename] = Number((await client.query(`SELECT count(*) AS count FROM "${tablename.replaceAll('"', '""')}"`)).rows[0].count);
  for (const table of ['CompanySettings', 'User', 'Product', 'SalesInvoice', 'PurchaseInvoice', 'SalesInvoiceAttachment', 'PurchaseInvoiceAttachment']) {
    if (!Object.hasOwn(counts, table)) throw new Error(`Falta la tabla ${table}.`);
  }
  const binaryChecks = [];
  for (const table of ['SalesInvoiceAttachment', 'PurchaseInvoiceAttachment', 'DeliveryAttachment']) {
    const result = await client.query(`SELECT count(*)::int AS files, count(*) FILTER (WHERE octet_length(data) = "fileSize")::int AS valid FROM "${table}"`);
    if (result.rows[0].files !== result.rows[0].valid) throw new Error(`Adjuntos inválidos en ${table}.`);
    binaryChecks.push({ table, ...result.rows[0] });
  }
  const report = { status: 'success', verifiedAt: new Date().toISOString(), backup: path.basename(backupFile), restoredTo: 'PostgreSQL aislado en 127.0.0.1; nunca producción', counts, binaryChecks, postgres: '18.6', scope: 'Tooling Prection' };
  await fs.writeFile(path.join(backupRoot, 'restore-verification.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report));
} finally {
  await client?.end();
  if (started) { try { await run(path.join(bin, 'pg_ctl.exe'), ['-D', dataPath, '-m', 'fast', '-w', 'stop'], { stdio: 'ignore' }); } catch {} }
  const resolved = await fs.realpath(sandbox);
  if (!resolved.toLowerCase().startsWith((path.resolve(privateRoot) + path.sep).toLowerCase()) || !path.basename(resolved).startsWith('restore-check-')) throw new Error('No se permite limpiar una ruta fuera de la prueba aislada.');
  await fs.rm(resolved, { recursive: true });
}
