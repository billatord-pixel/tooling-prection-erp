"use client";
import { useEffect,useRef,useState } from "react";
import Link from "next/link";
import { Download,Search } from "lucide-react";
import { mexicoToday } from "@/lib/customer-order-calendar";
import type { MonthlySoldProductsReport } from "@/lib/monthly-sold-products";
import "./monthly-sold-products-report.css";
const quantity=(n:number)=>n.toLocaleString("es-MX",{maximumFractionDigits:3});
export function MonthlyPurchasedProductsReportPanel(){
  const [month,setMonth]=useState(()=>mexicoToday().slice(0,7)),[report,setReport]=useState<MonthlySoldProductsReport|null>(null),[busy,setBusy]=useState(false),[error,setError]=useState("");
  const controller=useRef<AbortController|null>(null);
  useEffect(()=>()=>controller.current?.abort(),[]);
  async function load(event:React.FormEvent){
    event.preventDefault();controller.current?.abort();const request=new AbortController();controller.current=request;setBusy(true);setError("");
    try{const response=await fetch("/api/reports/purchased-products?month="+encodeURIComponent(month),{signal:request.signal});const data=await response.json();if(!response.ok)throw Error(data.error||"No se pudo generar el reporte.");if(!request.signal.aborted)setReport(data);}catch(e){if(!request.signal.aborted)setError(e instanceof Error?e.message:"No se pudo consultar.");}finally{if(!request.signal.aborted)setBusy(false);}
  }
  return <section className="panel sold-products-report" aria-label="Reporte mensual de productos comprados">
    <div className="panel-head"><div><h2>Productos comprados por mes</h2><span className="record-count">Agrupados por código y descripción de herramienta, no por factura.</span></div></div>
    <form className="sold-products-controls" onSubmit={load}><label>Mes de compra<input type="month" required value={month} onChange={e=>setMonth(e.target.value)} onInput={e=>setMonth(e.currentTarget.value)}/></label><button className="secondary" disabled={busy||!month}><Search size={16}/>{busy?"Consultando…":"Consultar productos"}</button>{report&&<a className="secondary" href={"/api/reports/purchased-products?format=pdf&month="+encodeURIComponent(report.month)}><Download size={16}/> Descargar PDF · {report.month}</a>}</form>
    {error&&<p role="alert" className="error sold-products-note">{error}</p>}
    {report&&<><div className="sold-products-summary" role="status"><strong>{report.month}: {report.productCount} herramientas · {report.invoiceCount} facturas vigentes</strong><span>Total comprado: {report.totalsByUnit.map(t=>quantity(t.quantity)+" "+t.unit).join(" · ")||"0 PZA"}</span><small>Se usa la identificación del catálogo cuando está vinculada. Las unidades incompatibles se mantienen separadas. No incluye facturas canceladas ni en borrador.</small></div><div className="table-wrap sold-products-table-wrap"><table className="table sold-products-table"><thead><tr><th>Código de herramienta</th><th>Descripción de herramienta</th><th>Facturas relacionadas</th><th>Cantidad total comprada</th></tr></thead><tbody>{report.rows.map((row,i)=><tr key={i}><td><b>{row.code}</b></td><td>{row.description}</td><td><div className="sold-products-folios">{row.invoices.map(invoice=><Link href={"/facturas-compra/"+invoice.id} key={invoice.id}>{invoice.folio}</Link>)}</div></td><td><b>{quantity(row.quantity)} {row.unit}</b></td></tr>)}{!report.rows.length&&<tr><td colSpan={4} className="empty">No hay productos comprados en el mes seleccionado.</td></tr>}</tbody></table></div></>}
  </section>;
}
