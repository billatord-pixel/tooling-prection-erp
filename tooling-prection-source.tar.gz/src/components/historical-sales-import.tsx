"use client";

import { useMemo, useState } from "react";
import { unzipSync } from "fflate";
import { FileArchive, FileCheck2, LoaderCircle } from "lucide-react";
import { parseCfdi } from "@/lib/cfdi";
import "./historical-sales-import.css";

type HistoricalRecord = {
  uuid: string;
  folio: string;
  date: string;
  customer: string;
  currency: string;
  total: number;
  codes: string[];
  xmlName: string;
  pdfName: string;
  xml: Blob;
  pdf: Blob;
};

const knownCodeOverrides: Record<string, string[]> = {
  // El CFDI F-3794 no incluye NoIdentificacion; la clave se leyó del campo “Clave” de su PDF.
  "E95123B0-89ED-4C3D-AA7C-14E913360A5F": ["EDP 208119"],
};

function baseName(path: string) {
  return path.replace(/\\/g, "/").replace(/\.(xml|pdf)$/i, "").toLocaleLowerCase("es-MX");
}

export function HistoricalSalesImport({ canEdit }: { canEdit: boolean }) {
  const [records, setRecords] = useState<HistoricalRecord[]>([]);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState(0);
  const [excluded, setExcluded] = useState(0);
  const [duplicates, setDuplicates] = useState(0);
  const [missingPair, setMissingPair] = useState(0);
  const summary = useMemo(() => ({
    customers: new Set(records.map(record => record.customer)).size,
    products: new Set(records.flatMap(record => record.codes)).size,
    currencies: [...new Set(records.map(record => record.currency))].join(", "),
  }), [records]);

  async function readZip(file?: File) {
    setError(""); setMessage(""); setRecords([]); setProgress(0);
    if (!file) return;
    if (!file.name.toLowerCase().endsWith(".zip")) return setError("Selecciona un archivo .zip.");
    if (file.size > 500 * 1024 * 1024) return setError("El ZIP supera el límite de 500 MB.");
    setBusy(true);
    try {
      const archive = unzipSync(new Uint8Array(await file.arrayBuffer()));
      const pairs = new Map<string, { xml?: Uint8Array; pdf?: Uint8Array; xmlName?: string; pdfName?: string }>();
      for (const [path, bytes] of Object.entries(archive)) {
        if (path.endsWith("/")) continue;
        const extension = path.toLowerCase().split(".").pop();
        if (extension !== "xml" && extension !== "pdf") continue;
        const key = baseName(path);
        const pair = pairs.get(key) || {};
        if (extension === "xml") { pair.xml = bytes; pair.xmlName = path.split(/[\\/]/).pop() || "factura.xml"; }
        else { pair.pdf = bytes; pair.pdfName = path.split(/[\\/]/).pop() || "factura.pdf"; }
        pairs.set(key, pair);
      }
      const found: HistoricalRecord[] = [];
      const seen = new Set<string>();
      let ignored = 0; let repeated = 0; let unpaired = 0;
      for (const pair of pairs.values()) {
        if (!pair.xml || !pair.pdf) { unpaired++; continue; }
        try {
          const xml = new TextDecoder().decode(pair.xml);
          const cfdi = parseCfdi(xml);
          if (!cfdi.uuid || !cfdi.concepts.length || !cfdi.issuer.rfc || !cfdi.receiver.rfc) { ignored++; continue; }
          // Solo facturas de ingreso del emisor Tooling Prection; excluye complementos, acuses y terceros.
          if (cfdi.issuer.rfc.replace(/[^a-z0-9]/gi, "").toUpperCase() !== "TPR090119AKA") { ignored++; continue; }
          const root = new DOMParser().parseFromString(xml, "application/xml").documentElement;
          if (root.localName !== "Comprobante" || root.getAttribute("TipoDeComprobante") !== "I") { ignored++; continue; }
          if (seen.has(cfdi.uuid.toUpperCase())) { repeated++; continue; }
          seen.add(cfdi.uuid.toUpperCase());
          const overrides = knownCodeOverrides[cfdi.uuid.toUpperCase()] || [];
          const codes = cfdi.concepts.map((line, index) => (overrides[index] || line.code || "").trim());
          if (cfdi.concepts.some((line, index) => !(overrides[index] || line.code || "").trim())) {
            throw new Error(`La factura ${cfdi.series || ""}-${cfdi.folio || cfdi.uuid} tiene una partida sin EDP en el XML y requiere revisión.`);
          }
          found.push({
            uuid: cfdi.uuid, folio: `${cfdi.series ? `${cfdi.series}-` : ""}${cfdi.folio || "(sin folio)"}`,
            date: cfdi.issueDate.toISOString().slice(0, 10), customer: cfdi.receiver.rfc,
            currency: cfdi.currency, total: cfdi.total, codes,
            xmlName: pair.xmlName || "factura.xml", pdfName: pair.pdfName || "factura.pdf",
            xml: new Blob([Uint8Array.from(pair.xml).buffer as ArrayBuffer]), pdf: new Blob([Uint8Array.from(pair.pdf).buffer as ArrayBuffer], { type: "application/pdf" }),
          });
        } catch (cause) {
          if (cause instanceof Error && cause.message.includes("requiere revisión")) throw cause;
          ignored++;
        }
      }
      found.sort((a, b) => a.date.localeCompare(b.date) || a.folio.localeCompare(b.folio));
      setRecords(found); setExcluded(ignored); setDuplicates(repeated); setMissingPair(unpaired);
      setMessage(`Vista previa lista: ${found.length} facturas únicas. Se excluyen ${ignored} documentos no facturables y ${repeated} copias repetidas.`);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "No se pudo procesar el ZIP.");
    } finally { setBusy(false); }
  }

  async function importInvoices() {
    if (!canEdit || !records.length || busy) return;
    setBusy(true); setError(""); setMessage(""); setProgress(0);
    let created = 0; let skipped = 0; const failures: string[] = [];
    for (let index = 0; index < records.length; index++) {
      const record = records[index];
      try {
        const form = new FormData();
        form.append("xml", new File([record.xml], record.xmlName, { type: "application/xml" }));
        form.append("pdf", new File([record.pdf], record.pdfName, { type: "application/pdf" }));
        form.append("productCodes", JSON.stringify(record.codes));
        const response = await fetch("/api/invoices/sales/historical-import", { method: "POST", body: form });
        const result = await response.json();
        if (!response.ok) throw new Error(result.error || `Error HTTP ${response.status}`);
        if (result.skipped) skipped++; else created++;
      } catch (cause) {
        failures.push(`${record.folio}: ${cause instanceof Error ? cause.message : "error desconocido"}`);
      }
      setProgress(index + 1);
      if (index % 10 === 0) setMessage(`Importando ${index + 1} de ${records.length}… ${created} nuevas, ${skipped} ya existentes.`);
    }
    setBusy(false);
    setMessage(`Carga concluida: ${created} facturas agregadas, ${skipped} UUID ya existentes, ${failures.length} errores.`);
    if (failures.length) setError(`Primeros errores: ${failures.slice(0, 8).join(" · ")}`);
    if (!failures.length) setRecords([]);
  }

  return <section className="panel import-panel historical-import">
    <div className="panel-head"><div><h2>Importar facturas de venta históricas</h2><p>Sube el ZIP de XML y PDF. Los documentos se vinculan al cliente y a los productos por RFC y EDP, sin descontar existencias.</p></div><span className="record-count">Solo administrador</span></div>
    <label className="import-drop"><FileArchive size={27}/><b>Selecciona el ZIP de facturas</b><span>Se emparejan XML/PDF por nombre, se excluyen complementos y acuses, y se detectan UUID duplicados.</span><input type="file" accept=".zip,application/zip" disabled={!canEdit || busy} onChange={event => void readZip(event.target.files?.[0])}/></label>
    <div className="historical-warning"><FileCheck2 size={18}/><span>Estas facturas quedan marcadas como históricas: se conservan para consulta, cobranza y reportes, pero no generan salidas de inventario.</span></div>
    {message && <p className="import-hint" role="status">{message}</p>}{error && <p className="historical-error" role="alert">{error}</p>}
    {records.length > 0 && <><div className="historical-summary"><article><b>{records.length}</b><span>facturas válidas</span></article><article><b>{summary.customers}</b><span>RFC de clientes</span></article><article><b>{summary.products}</b><span>EDP distintos</span></article><article><b>{summary.currencies || "—"}</b><span>monedas</span></article></div>
      <p className="import-hint">Omitidas: {excluded} complemento/acuse u otros · repetidas dentro del ZIP: {duplicates} · sin pareja XML/PDF: {missingPair}. Se conservan los nombres originales de los archivos adjuntos.</p>
      {busy && <div className="historical-progress"><span style={{ width: `${records.length ? progress / records.length * 100 : 0}%` }}/></div>}
      <button className="primary import-submit" disabled={!canEdit || busy} onClick={() => void importInvoices()}>{busy ? <><LoaderCircle size={16} className="spin"/> {progress} / {records.length}</> : `Importar ${records.length} facturas históricas`}</button>
    </>}
  </section>;
}
