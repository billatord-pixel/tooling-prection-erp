"use client";
import { useEffect,useRef,useState } from "react";
import Link from "next/link";
import { Download,Search } from "lucide-react";
import { mexicoToday } from "@/lib/customer-order-calendar";
import { monthlyInvoiceDateLabel } from "@/lib/monthly-invoice-date";
import type { MonthlySoldProductsReport } from "@/lib/monthly-sold-products";
import "./monthly-sold-products-report.css";
const quantity=(n:number)=>n.toLocaleString("es-MX",{maximumFractionDigits:3});
export function MonthlySoldProductsReportPanel(){
  const [month,setMonth]=useState(()=>mexicoToday().slice(0,7)),[endMonth,setEndMonth]=useState(month),[report,setReport]=useState<MonthlySoldProductsReport|null>(null),[busy,setBusy]=useState(false),[error,setError]=useState("");
  const invalid = Boolean(month && endMonth && month > endMonth);
  const period = report?.endMonth ? `${report.month} al ${report.endMonth}` : report?.month;
  const controller=useRef<AbortController|null>(null);
  useEffect(()=>()=>controller.current?.abort(),[]);
  async function load(event:React.FormEvent){
    event.preventDefault();if(invalid||!month||!endMonth)return;controller.current?.abort();const request=new AbortController();controller.current=request;setBusy(true);setError("");
    try{const response=await fetch("/api/reports/sold-products?"+new URLSearchParams({month,endMonth}),{signal:request.signal});const data=await response.json();if(!response.ok)throw Error(data.error||"No se pudo generar el reporte.");if(!request.signal.aborted)setReport(data);}catch(e){if(!request.signal.aborted)setError(e instanceof Error?e.message:"No se pudo consultar.");}finally{if(!request.signal.aborted)setBusy(false);}
  }
  return <section className="panel sold-products-report" aria-label="Reporte mensual de productos vendidos">
    <div className="panel-head"><div><h2>Productos vendidos por mes</h2><span className="record-count">Agrupados por código y descripción de herramienta, no por factura.</span></div></div>
    <form className="sold-products-controls" onSubmit={load}>
      <label>Mes inicial<input type="month" required value={month} onChange={e=>setMonth(e.target.value)}/></label>
      <label>Mes final<input type="month" required value={endMonth} onChange={e=>setEndMonth(e.target.value)}/></label>
      <button className="secondary" disabled={busy||!month||!endMonth||invalid}><Search size={16}/>{busy?"Consultando…":"Consultar productos"}</button>
      {report && <a className="secondary" href={"/api/reports/sold-products?"+new URLSearchParams({format:"pdf",month:report.month,endMonth:report.endMonth??report.month})}><Download size={16}/> Descargar PDF · {period}</a>}
    </form>
    {invalid && <p role="alert" className="error sold-products-note">El mes inicial no puede ser posterior al mes final.</p>}
    {error&&<p role="alert" className="error sold-products-note">{error}</p>}
    {report&&<><div className="sold-products-summary" role="status"><strong>{period}: {report.productCount} herramientas · {report.invoiceCount} facturas vigentes</strong><span>Total vendido: {report.totalsByUnit.map(t=>quantity(t.quantity)+" "+t.unit).join(" · ")||"0 PZA"}</span><small>Se usa la identificación del catálogo cuando está vinculada. Las unidades incompatibles se mantienen separadas. No incluye facturas canceladas, en borrador ni archivadas.</small></div><div className="table-wrap sold-products-table-wrap"><table className="table sold-products-table"><thead><tr><th>Código de herramienta</th><th>Descripción de herramienta</th><th>Folio y fecha de facturación</th><th>Cantidad total vendida</th></tr></thead><tbody>{report.rows.map((row,i)=><tr key={i}><td><b>{row.code}</b></td><td>{row.description}</td><td><div className="sold-products-folios">{row.invoices.map(invoice=><Link href={"/facturas-venta/"+invoice.id} key={invoice.id}><span>{invoice.folio}</span><time dateTime={invoice.issueDate}>{monthlyInvoiceDateLabel(invoice.issueDate)}</time></Link>)}</div></td><td><b>{quantity(row.quantity)} {row.unit}</b></td></tr>)}{!report.rows.length&&<tr><td colSpan={4} className="empty">No hay productos vendidos en el periodo seleccionado.</td></tr>}</tbody></table></div></>}
  </section>;
}
