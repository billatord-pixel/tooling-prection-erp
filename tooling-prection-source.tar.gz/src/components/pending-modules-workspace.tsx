"use client";
import {MonthlyInOutReportPanel} from "./monthly-in-out-report";
import { formatMoney } from "@/lib/money-format";
import type { summarizeInventoryValuation } from "@/lib/inventory-valuation";
import type { summarizePhysicalInventory } from "@/lib/physical-inventory-valuation";
import type { BanxicoInventoryRate } from "@/lib/banxico-fix";
import { displayOrderDate } from "@/lib/customer-order-calendar";


import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Download, FileText, FileUp, RefreshCw, Search, ShieldCheck } from "lucide-react";
import { HistoricalSalesImport } from "@/components/historical-sales-import";
import { BackupStatusPanel } from "@/components/backup-status-panel";
import "./pending-modules-workspace.css";
import "./technical-review.css";
import "./reports-workspace.css";
import "./reports-currency.css";

type ModuleKey = "conciliacion" | "revision-tecnica" | "importaciones" | "respaldos" | "reportes";
type Product = { id: string; technicalCode: string; description: string; stock: string | number; baseCost: string | number; currency: string; brand?: { name: string } | null };
type TechnicalProduct = Product & { fiscalDescription?: string | null; unit: string; salePrice: string | number; category?: { name: string } | null; mainSupplier?: { legalName: string } | null; status: string };
type Pair = { id: string; productA: Product; productB: Product; similarity: string; reasons: string[]; status: string; officialProductId: string | null };
type Reports = { inventoryValuation: ReturnType<typeof summarizeInventoryValuation> | null; physicalInventory: ReturnType<typeof summarizePhysicalInventory> | null; products: number; stockValue: number; stockCurrency: string; stockExchangeRate: BanxicoInventoryRate | null; lowStock: number; sales: { currency: string; count: number; total: number }[]; nativeSales: { currency: string; count: number; total: number }[]; usdInvoices: Array<{id:string;folio:string;uuid:string|null;customer:string;issueDate:string;status:string;totalUsd:number;exchangeRate:number|null;totalMxn:number|null}>; missingSalesConversion:number; missingPurchaseConversion:number; purchases: { currency: string; count: number; total: number }[]; receivables: { currency: string; total: number }[]; payables: { currency: string; total: number }[]; movements: number; openOrders:number; monthly:Array<{month:string;sales:Record<string,number>;purchases:Record<string,number>}> };
const titles: Record<ModuleKey, [string, string, string]> = {
  conciliacion: ["PRODUCTOS", "Conciliación de productos", "Revisa sugerencias de posibles duplicados; confirmar no fusiona ni elimina productos."],
  "revision-tecnica": ["PRODUCTOS", "Revisión técnica", "Compara códigos y descripciones del catálogo para detectar coincidencias que requieren criterio humano."],
  importaciones: ["ADMINISTRACIÓN", "Importaciones", "Carga controlada del catálogo y de facturas históricas de venta."],
  respaldos: ["ADMINISTRACIÓN", "Respaldos y exportación", "Revisa el último respaldo completo en OneDrive o descarga una exportación de los datos del ERP."],
  reportes: ["CONTROL", "Reportes", "Resumen operativo real de inventario, ventas, compras y saldos pendientes."],
};
const num = (value: unknown) => Number(value || 0).toLocaleString("es-MX", { maximumFractionDigits: 2 });
const money = formatMoney;
function parseCsv(text: string) {
  const input = text.replace(/^\uFEFF/, ""); let delimiter = ",", quoted = false;
  for (const char of input) { if (char === '"') quoted = !quoted; else if (!quoted && (char === "," || char === ";")) { delimiter = char; break; } else if (!quoted && char === "\n") break; }
  const rows: string[][] = []; let row: string[] = [], field = ""; quoted = false;
  for (let i = 0; i < input.length; i++) { const char = input[i];
    if (char === '"' && quoted && input[i + 1] === '"') { field += '"'; i++; }
    else if (char === '"') quoted = !quoted;
    else if (!quoted && char === delimiter) { row.push(field.trim()); field = ""; }
    else if (!quoted && (char === "\n" || char === "\r")) { if (char === "\r" && input[i + 1] === "\n") i++; row.push(field.trim()); if (row.some(Boolean)) rows.push(row); row = []; field = ""; }
    else field += char;
  }
  row.push(field.trim()); if (row.some(Boolean)) rows.push(row); return rows;
}

export function PendingModulesWorkspace({ module, role }: { module: string; role: string }) {
  const key = module as ModuleKey;
  const [pairs, setPairs] = useState<Pair[]>([]); const [technicalProducts, setTechnicalProducts] = useState<TechnicalProduct[]>([]); const [reports, setReports] = useState<Reports | null>(null); const [reportFrom,setReportFrom]=useState("");const [reportTo,setReportTo]=useState("");const [appliedRange,setAppliedRange]=useState({from:"",to:"",currency:"MXN"});
  const [loading, setLoading] = useState(true); const [busy, setBusy] = useState(false); const [message, setMessage] = useState(""); const [filter, setFilter] = useState(""); const [csvRows, setCsvRows] = useState<Record<string, string>[]>([]);
  const canEdit = role === "ADMIN";
  const valuation = reports?.inventoryValuation;
  const physical = reports?.physicalInventory;
  const stockFx = reports?.stockExchangeRate;
  const reportRequest = useRef<AbortController | null>(null);
  const load = useCallback(async () => {
    const request = key === "reportes" ? new AbortController() : null;
    if (request) {
      reportRequest.current?.abort();
      reportRequest.current = request;
      setReports(null);
      setMessage("");
    }
    setLoading(true);
    try {
      if (key === "conciliacion") { const res = await fetch("/api/reconciliation", { cache: "no-store" }); if (!res.ok) throw new Error("No se pudieron cargar las revisiones."); const data = await res.json(); setPairs(data.pairs); }
      if (key === "revision-tecnica") { const res = await fetch("/api/products", { cache: "no-store" }); if (!res.ok) throw new Error("No se pudo cargar el catálogo técnico."); setTechnicalProducts(await res.json()); }
      if (request) {
        const query = new URLSearchParams({ currency: appliedRange.currency });
        if (appliedRange.from) query.set("from", appliedRange.from);
        if (appliedRange.to) query.set("to", appliedRange.to);
        const res = await fetch(`/api/reports?${query}`, { cache: "no-store", signal: request.signal });
        if (!res.ok) throw new Error("No se pudieron cargar los reportes.");
        const report = await res.json();
        if (!request.signal.aborted) setReports(report);
      }
    } catch (error) {
      if (!request?.signal.aborted) setMessage(error instanceof Error ? error.message : "Error al cargar.");
    } finally {
      if (!request?.signal.aborted) setLoading(false);
    }
  }, [key,appliedRange]);
  useEffect(() => {
    void load();
    return () => reportRequest.current?.abort();
  }, [load]);
  const { 0: eyebrow, 1: title, 2: description } = titles[key];
  const visiblePairs = useMemo(() => pairs.filter(p => `${p.productA.technicalCode} ${p.productA.description} ${p.productB.technicalCode} ${p.productB.description} ${p.status}`.toLowerCase().includes(filter.toLowerCase())), [pairs, filter]);
  const visibleTechnical = useMemo(() => technicalProducts.filter(p => `${p.technicalCode} ${p.description} ${p.fiscalDescription || ""} ${p.brand?.name || ""} ${p.category?.name || ""}`.toLowerCase().includes(filter.toLowerCase())), [technicalProducts, filter]);
  async function action(id: string, status: string, officialProductId?: string) { setBusy(true); setMessage(""); try { const res = await fetch(`/api/reconciliation/${id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status, officialProductId }) }); const data = await res.json(); if (!res.ok) throw new Error(data.error || "No se pudo guardar la decisión."); setMessage("Decisión registrada con trazabilidad. No se alteraron existencias ni se borraron registros."); await load(); } catch (error) { setMessage(error instanceof Error ? error.message : "Error."); } finally { setBusy(false); } }
  async function makeSuggestions() { setBusy(true); setMessage(""); try { const res = await fetch("/api/reconciliation", { method: "POST" }); const data = await res.json(); if (!res.ok) throw new Error(data.error || "No se pudieron analizar los productos."); setMessage(`Análisis completado: ${data.created} sugerencias nuevas.`); await load(); } catch (error) { setMessage(error instanceof Error ? error.message : "Error."); } finally { setBusy(false); } }
  async function importRows() { setBusy(true); setMessage(""); try { const res = await fetch("/api/imports/products", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ rows: csvRows }) }); const data = await res.json(); if (!res.ok) throw new Error(data.error || "La importación falló."); setMessage(`Importación terminada: ${data.created} productos creados; ${data.skipped} omitidos. ${data.errors?.length ? `Errores: ${data.errors.slice(0, 4).join("; ")}` : ""}`); setCsvRows([]); } catch (error) { setMessage(error instanceof Error ? error.message : "Error."); } finally { setBusy(false); } }
  async function readCsv(file?: File) { if (!file) return; const matrix = parseCsv(await file.text()); if (matrix.length < 2) return setMessage("El CSV debe tener encabezados y al menos una fila de datos."); const headers = matrix[0].map(s => s.trim().toLowerCase().replace(/[á]/g,"a").replace(/[ó]/g,"o").replace(/\s+/g,"_")); if (!headers.includes("technicalcode") || !headers.includes("description")) return setMessage("Faltan columnas obligatorias: technicalCode y description."); const rows = matrix.slice(1, 501).map(values => Object.fromEntries(headers.map((h,i) => [h, (values[i] || "").trim()]))); setCsvRows(rows); setMessage(`Vista previa: ${rows.length} filas. Encabezados opcionales: fiscalDescription, unit, baseCost, salePrice, brand, category.`); }
  return <section className="content pending-workspace"><div className="title-row"><div><span className="module-eyebrow">{eyebrow}</span><h1>{title}</h1><p>{description}</p></div><div className="pending-actions"><button className="secondary" onClick={() => void load()}><RefreshCw size={16}/> Actualizar</button>{(key === "conciliacion" || key === "revision-tecnica") && canEdit && <button className="primary" disabled={busy} onClick={() => void makeSuggestions()}>Analizar catálogo</button>}</div></div>
    {message && <div className="pending-message" role="status">{message}</div>}
    {key === "respaldos" && role === "ADMIN" && <BackupStatusPanel/>}
    {key === "conciliacion" && <><div className="module-tools"><label className="pending-search"><Search size={16}/><input value={filter} onChange={e => setFilter(e.target.value)} placeholder="Buscar código, descripción o estado…"/></label><span className="record-count">{visiblePairs.length} revisiones</span></div>{loading ? <div className="panel pending-empty">Cargando revisiones…</div> : <div className="pending-list">{visiblePairs.map(pair => <article className="panel pending-pair" key={pair.id}><div className="pair-products">{[pair.productA, pair.productB].map(p => <div className="pair-product" key={p.id}><span className="pair-code">{p.technicalCode}</span><b>{p.description}</b><small>Existencia {num(p.stock)} · Costo {money(p.baseCost,p.currency)} · {p.brand?.name || "Sin marca"}</small></div>)}<div className="pair-score"><b>{num(pair.similarity)}%</b><small>similitud</small><span className={`status-chip ${pair.status.toLowerCase()}`}>{pair.status}</span></div></div><div className="pair-footer"><span>{pair.reasons.join(" · ") || "Coincidencia sugerida por código y descripción"}</span>{pair.status === "SUGGESTED" && canEdit && <div className="pair-buttons"><select aria-label="Producto oficial" defaultValue={pair.productA.id} id={`official-${pair.id}`}><option value={pair.productA.id}>{pair.productA.technicalCode} — A</option><option value={pair.productB.id}>{pair.productB.technicalCode} — B</option></select><button className="secondary" disabled={busy} onClick={() => void action(pair.id, "REJECTED")}>Descartar</button><button className="primary" disabled={busy} onClick={() => void action(pair.id, "CONFIRMED", (document.getElementById(`official-${pair.id}`) as HTMLSelectElement)?.value)}>Confirmar equivalencia</button></div>}</div></article>)}{!visiblePairs.length && <div className="panel pending-empty">{pairs.length ? "No hay coincidencias con ese filtro." : "Aún no hay revisiones. Ejecuta Analizar catálogo para proponer productos similares."}</div>}</div>}</>}
    {key === "revision-tecnica" && <><div className="module-tools"><label className="pending-search"><Search size={16}/><input value={filter} onChange={e => setFilter(e.target.value)} placeholder="Buscar código, descripción, marca o categoría…"/></label><span className="record-count">{visibleTechnical.length} productos</span></div><div className="panel table-wrap">{loading ? <div className="pending-empty">Cargando catálogo técnico…</div> : <table className="pending-table technical-table"><thead><tr><th>Código</th><th>Descripción técnica</th><th>Descripción fiscal</th><th>Marca / categoría</th><th>Unidad</th><th>Existencia</th><th>Costo</th><th>Precio venta</th><th>Proveedor principal</th></tr></thead><tbody>{visibleTechnical.map(p=><tr key={p.id}><td><b>{p.technicalCode}</b></td><td>{p.description}</td><td>{p.fiscalDescription || "—"}</td><td>{[p.brand?.name,p.category?.name].filter(Boolean).join(" / ") || "—"}</td><td>{p.unit}</td><td>{num(p.stock)}</td><td>{money(p.baseCost,p.currency)}</td><td>{money(p.salePrice,p.currency)}</td><td>{p.mainSupplier?.legalName || "—"}</td></tr>)}</tbody></table>}{!loading && !visibleTechnical.length && <div className="pending-empty">No hay productos que coincidan con la búsqueda.</div>}</div></>}
    {key === "importaciones" && <div className="panel import-panel"><div className="panel-head"><h2>Importar catálogo de productos (CSV)</h2><span className="record-count">Hasta 500 filas por carga</span></div><div className="import-drop"><FileUp size={27}/><b>Selecciona un archivo .csv</b><span>Se validan código técnico y descripción; los duplicados no se sobrescriben.</span><input type="file" accept=".csv,text/csv" onChange={e => void readCsv(e.target.files?.[0])}/></div><p className="import-hint">Columnas obligatorias: <code>technicalCode</code>, <code>description</code>. Opcionales: <code>fiscalDescription</code>, <code>unit</code>, <code>baseCost</code>, <code>salePrice</code>, <code>brand</code>, <code>category</code>.</p>{csvRows.length > 0 && <><div className="table-wrap"><table className="pending-table"><thead><tr>{Object.keys(csvRows[0]).slice(0,6).map(h=><th key={h}>{h}</th>)}</tr></thead><tbody>{csvRows.slice(0,8).map((r,i)=><tr key={i}>{Object.keys(csvRows[0]).slice(0,6).map(h=><td key={h}>{r[h]}</td>)}</tr>)}</tbody></table></div><button className="primary import-submit" disabled={busy || !canEdit} onClick={() => void importRows()}>{busy ? "Procesando…" : `Crear ${csvRows.length} productos`}</button></>}</div>}
    {key === "importaciones" && <HistoricalSalesImport canEdit={role === "ADMIN"}/>}
    {key === "reportes" && <>
      <MonthlyInOutReportPanel/>
      <form className="report-filters" onSubmit={e=>{e.preventDefault();setAppliedRange({from:reportFrom,to:reportTo,currency:(e.currentTarget.elements.namedItem("currency") as HTMLSelectElement).value});}}>
        <label>Desde<input type="date" value={reportFrom} onChange={e=>setReportFrom(e.target.value)}/></label>
        <label>Hasta<input type="date" value={reportTo} onChange={e=>setReportTo(e.target.value)}/></label>
        <label>Moneda del reporte<select name="currency" defaultValue="MXN"><option>MXN</option><option>USD</option><option>EUR</option></select></label>
        <button className="primary">Aplicar filtros</button>
      </form>
      {loading ? <div className="panel pending-empty">Cargando indicadores…</div> : reports && <>
        {physical && <div className="panel" style={{padding:"14px 18px",marginBottom:16}}>
          <b>Valoración al corte de inventario físico</b>
          <p>{physical.title} · {num(physical.lines)} partidas. Existencias del PDF multiplicadas por su precio unitario en {physical.currency}.</p>
          {physical.roundingAdjustment !== 0 && <p>Cálculo de {money(physical.calculatedTotal,physical.currency)} más una diferencia de {money(physical.roundingAdjustment,physical.currency)} para coincidir con el importe impreso.</p>}
          {stockFx?.quote ? <p>
            Base {money(physical.total,physical.currency)} × {stockFx.quote.rate} MXN por USD. FIX del {displayOrderDate(stockFx.quote.date)}{stockFx.quote.date !== stockFx.requestedDate ? " (último disponible)" : ""}.{" "}
            <a className="report-fix-source" href={stockFx.quote.sourceUrl} target="_blank" rel="noreferrer">Consultar en Banxico</a>
          </p> : stockFx && <p className="report-warning" role="status">El inventario se muestra en USD porque Banxico no devolvió un FIX disponible.</p>}
          <p>El periodo filtra las operaciones. La valuación del inventario corresponde al corte físico.</p>
        </div>}
        {valuation && <div className="panel" style={{padding:"14px 18px",marginBottom:16}}>
          <b>Valoración de las existencias actuales</b>
          <p>{valuation.method} El periodo del reporte solo filtra las operaciones.</p>
          <p>{num(valuation.valuedProducts)} productos valuados.</p>
          {valuation.missingPrice > 0 && <p className="report-warning">{num(valuation.missingPrice)} productos con saldo siguen pendientes de valuación por falta de precio registrado.</p>}
          {valuation.missingConversion > 0 && <p className="report-warning">{num(valuation.missingConversion)} productos con precio quedaron fuera del subtotal por falta de conversión a {appliedRange.currency}.</p>}
        </div>}
        <div className="report-grid">{[["Productos activos",num(reports.products)], [physical ? "Valor del inventario al corte" : valuation?.isPartial ? "Subtotal valuado del inventario" : "Valor del inventario",money(reports.stockValue,reports.stockCurrency)], ["Productos bajo mínimo",num(reports.lowStock)], ["Ventas del periodo",reports.sales.length ? reports.sales.map(x => `${num(x.count)} docs · ${money(x.total, x.currency)}`).join(" / ") : money(0,appliedRange.currency)], ["Compras del periodo",reports.purchases.length ? reports.purchases.map(x => `${num(x.count)} docs · ${money(x.total, x.currency)}`).join(" / ") : money(0,appliedRange.currency)], ["Cuentas por cobrar",reports.receivables.length ? reports.receivables.map(x => money(x.total, x.currency)).join(" / ") : money(0,appliedRange.currency)], ["Cuentas por pagar",reports.payables.length ? reports.payables.map(x => money(x.total, x.currency)).join(" / ") : money(0,appliedRange.currency)], ["Pedidos pendientes",num(reports.openOrders)], ["Movimientos inventario",num(reports.movements)]].map(([label,value])=><article className="panel report-card" key={label}><span>{label}</span><b>{value}</b></article>)}</div>
        {appliedRange.currency === "MXN" && <section className="panel report-currency-breakdown"><div className="panel-head"><div><h2>Ventas por moneda de facturación</h2><span className="record-count">Montos originales de los CFDI incluidos en el periodo</span></div></div><div className="report-currency-cards">{reports.nativeSales.map(row=><article key={row.currency}><span>{row.currency} · {num(row.count)} facturas</span><b>{money(row.total,row.currency)}</b></article>)}<article className="report-mxn-total"><span>Total consolidado en MXN</span><b>{money(reports.sales.find(row=>row.currency==="MXN")?.total||0,"MXN")}</b></article></div>{reports.missingSalesConversion>0&&<p className="report-warning">Hay {reports.missingSalesConversion} factura(s) sin un tipo de cambio válido; no se sumaron al total convertido.</p>}</section>}
        {appliedRange.currency === "MXN" && reports.usdInvoices.length > 0 && <section className="panel report-usd-invoices"><div className="panel-head"><div><h2>Relación de facturas emitidas en USD</h2><span className="record-count">{num(reports.usdInvoices.length)} facturas · tipo de cambio de cada CFDI</span></div><a className="secondary report-download" href={`/api/reports?format=usd-invoices-csv&currency=MXN${appliedRange.from?`&from=${appliedRange.from}`:""}${appliedRange.to?`&to=${appliedRange.to}`:""}`}><Download size={15}/> Descargar relación CSV</a></div><div className="table-wrap report-usd-table-wrap"><table className="table"><thead><tr><th>Folio</th><th>Cliente</th><th>Fecha</th><th className="numeric">Total USD</th><th className="numeric">Tipo de cambio</th><th className="numeric">Equivalente MXN</th></tr></thead><tbody>{reports.usdInvoices.map(row=><tr key={row.id}><td><b>{row.folio}</b></td><td>{row.customer}</td><td>{new Intl.DateTimeFormat("es-MX",{dateStyle:"medium",timeZone:"America/Mexico_City"}).format(new Date(row.issueDate))}</td><td className="numeric">{money(row.totalUsd,"USD")}</td><td className="numeric">{row.exchangeRate?.toLocaleString("es-MX",{minimumFractionDigits:2,maximumFractionDigits:6})||"Sin dato"}</td><td className="numeric"><b>{row.totalMxn===null?"No convertido":money(row.totalMxn,"MXN")}</b></td></tr>)}</tbody></table></div></section>}
        <section className="panel report-trend"><div className="panel-head"><div><h2>Compras y ventas por mes</h2><span className="record-count">Moneda {appliedRange.currency} · {appliedRange.currency==="MXN"?"USD convertido por tipo de cambio de cada factura":"importes en moneda seleccionada"}</span></div></div><div className="trend-list">{reports.monthly.map(item=>{const sales=item.sales[appliedRange.currency]||0,purchases=item.purchases[appliedRange.currency]||0,max=Math.max(1,...reports.monthly.flatMap(m=>[m.sales[appliedRange.currency]||0,m.purchases[appliedRange.currency]||0]));return <div className="trend-row" key={item.month}><span>{item.month}</span><div className="trend-bars"><div className="trend-bar sales-bar" style={{width:`${Math.max(sales?2:0,sales/max*100)}%`}} title={`Ventas ${money(sales,appliedRange.currency)}`}/><div className="trend-bar purchases-bar" style={{width:`${Math.max(purchases?2:0,purchases/max*100)}%`}} title={`Compras ${money(purchases,appliedRange.currency)}`}/></div><small>V {money(sales,appliedRange.currency)} · C {money(purchases,appliedRange.currency)}</small></div>})}{!reports.monthly.length&&<div className="pending-empty">No hay documentos en el periodo y moneda elegidos.</div>}<div className="trend-legend"><span><i className="sales-dot"/> Ventas</span><span><i className="purchases-dot"/> Compras</span></div></div></section>
      </>}
      <section className="panel report-export-panel"><div className="panel-head"><div><h2>Exportar reportes</h2><span className="record-count">PDF por módulo o reporte ejecutivo completo · periodo y moneda aplicados</span></div></div><div className="report-export"><a className="secondary report-download" href={`/api/reports/invoices/sales?currency=MXN${appliedRange.from?`&from=${appliedRange.from}`:""}${appliedRange.to?`&to=${appliedRange.to}`:""}`} target="_blank" rel="noreferrer"><FileText size={16}/> Reporte de ventas PDF · MXN</a><a className="secondary report-download" href={`/api/reports/invoices/purchases?currency=${appliedRange.currency}${appliedRange.from?`&from=${appliedRange.from}`:""}${appliedRange.to?`&to=${appliedRange.to}`:""}`} target="_blank" rel="noreferrer"><FileText size={16}/> Reporte de compras PDF</a><a className="secondary report-download" href={`/api/reports/pdf?currency=${appliedRange.currency}${appliedRange.from?`&from=${appliedRange.from}`:""}${appliedRange.to?`&to=${appliedRange.to}`:""}`} target="_blank" rel="noreferrer"><Download size={16}/> Reporte ejecutivo completo PDF</a><button type="button" className="secondary report-download" onClick={() => { const q=new URLSearchParams({format:"csv",currency:appliedRange.currency});if(appliedRange.from)q.set("from",appliedRange.from);if(appliedRange.to)q.set("to",appliedRange.to);window.location.href=`/api/reports?${q}`; }}><Download size={16}/> Descargar CSV</button></div></section>
    </>}
    {key === "respaldos" && <div className="panel backup-panel"><div className="backup-icon"><ShieldCheck/></div><div><h2>Exportación de datos del ERP</h2><p>Descarga tablas de operación y auditoría en JSON para resguardo. El archivo contiene información confidencial: guárdalo en almacenamiento seguro y con acceso restringido.</p><p className="backup-caveat"><b>Importante:</b> esta exportación no sustituye un backup nativo/restaurable de PostgreSQL y no incluye archivos cargados en almacenamiento externo. Configura snapshots automáticos de PostgreSQL desde Railway para recuperación ante incidentes.</p>{role === "ADMIN" ? <button className="primary backup-download" onClick={() => { window.location.href = "/api/backups/export"; }}><Download size={16}/> Descargar exportación protegida</button> : <small>Solo administradores pueden exportar datos completos.</small>}</div></div>}
  </section>;
}
