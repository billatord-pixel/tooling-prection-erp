"use client";
import { formatMoney } from "@/lib/money-format";
import { MonthlySoldProductsReportPanel } from "@/components/monthly-sold-products-report";

import { ChangeEvent, FormEvent, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft, ChartNoAxesColumn, CheckCircle2, ChevronDown, ChevronRight, Download, FileText, ListFilter, LoaderCircle, Plus, Printer, Search } from "lucide-react";
import "./sales-invoices-workspace.css";

type View = "list" | "new" | "detail";
type InvoiceRow = { id: string; folio: string; uuid?: string | null; customer: string; issueDate: string; status: string; items: number; currency: string; total: number; balance: number };
type Customer = { id: string; legalName: string; taxId?: string | null };
type Preview = { cfdi: { uuid?: string; series?: string; folio?: string; issueDate: string; currency: string; exchangeRate?: number | null; subtotal: number; tax: number; total: number; issuer: { rfc: string; name: string }; receiver: { rfc: string; name: string }; concepts: Array<{ description: string; quantity: number; unit?: string; unitPrice: number; amount: number }> }; party: Customer | null; needsPartyConfirmation: boolean; lines: Array<{ description: string; quantity: number; unit?: string; amount: number }> };
type InvoiceDetail = { id: string; folio: string; uuid?: string | null; series?: string | null; issueDate: string; status: string; currency: string; subtotal: number | string; tax: number | string; total: number | string; paymentForm?: string | null; paymentMethod?: string | null; processedAt?: string | null; inventoryDisposition?: "APPLIED" | "HISTORICAL"; customer: Customer; lines: Array<{ id: string; description: string; unit?: string | null; quantity: number | string; unitPrice: number | string; amount: number | string; product?: { technicalCode: string } | null }>; attachments: Array<{ id: string; fileName: string; contentType: string; fileSize: number; createdAt: string }>; balance: number };

const money = formatMoney;
const date = (value: string) => new Intl.DateTimeFormat("es-MX", { day: "2-digit", month: "short", year: "numeric", timeZone: "America/Mexico_City" }).format(new Date(value));
const fileSize = (value: number) => value < 1024 * 1024 ? `${Math.max(1, Math.round(value / 1024))} KB` : `${(value / 1024 / 1024).toFixed(1)} MB`;

function SalesReportPanel() {
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const invalid = Boolean(from && to && from > to);
  const filters = new URLSearchParams({ currency: "MXN" });
  if (from) filters.set("from", from);
  if (to) filters.set("to", to);
  return <details className="sales-monthly">
    <summary><FileText size={17} aria-hidden="true"/> Reporte de ventas en MXN <ChevronDown size={15} className="sales-monthly-chevron" aria-hidden="true"/></summary>
    <div className="sold-products-controls">
      <label>Desde<input type="date" value={from} onChange={event => setFrom(event.target.value)}/></label>
      <label>Hasta<input type="date" value={to} onChange={event => setTo(event.target.value)}/></label>
      {invalid ? <span className="error" role="alert">La fecha inicial debe ser anterior o igual a la final.</span> :
        <a className="secondary" href={`/api/reports/invoices/sales?${filters}`} target="_blank" rel="noreferrer"><Download size={16}/> Abrir reporte de ventas PDF</a>}
    </div>
    <p className="field-hint sold-products-note">Incluye el importe en MXN por partida. Las facturas en USD se convierten con el FIX de Banxico según su fecha de facturación. Deja las fechas vacías para consultar todo el historial.</p>
  </details>;
}

export function SalesInvoicesWorkspace({ view, invoiceId }: { view: View; invoiceId?: string }) {
  const router = useRouter();
  const [rows, setRows] = useState<InvoiceRow[]>([]); const [customers, setCustomers] = useState<Customer[]>([]);
  const [query, setQuery] = useState(""); const [status, setStatus] = useState("ALL"); const [invoice, setInvoice] = useState<InvoiceDetail | null>(null);
  const [xmlFile, setXmlFile] = useState<File | null>(null); const [pdfFile, setPdfFile] = useState<File | null>(null); const [preview, setPreview] = useState<Preview | null>(null); const [customerId, setCustomerId] = useState("");
  const [edit, setEdit] = useState(false); const [editCustomer, setEditCustomer] = useState(""); const [editDate, setEditDate] = useState(""); const [editLines, setEditLines] = useState<Array<{ id: string; description: string }>>([]);
  const [busy, setBusy] = useState(false); const [error, setError] = useState(""); const [notice, setNotice] = useState("");

  useEffect(() => { if (view !== "list") return; const timer = window.setTimeout(() => { const params = new URLSearchParams({ status }); if (query.trim()) params.set("q", query.trim()); void fetch(`/api/invoices/sales?${params}`).then(async r => { const data = await r.json(); if (!r.ok) throw new Error(data.error || "No se pudieron cargar las facturas."); setRows(data); }).catch(e => setError(e.message)); }, 180); return () => window.clearTimeout(timer); }, [view, query, status]);
  useEffect(() => { if (view !== "new" && !(view === "detail" && edit)) return; void fetch("/api/parties?kind=CUSTOMER").then(r => r.json()).then(data => setCustomers(data)); }, [view, edit]);
  useEffect(() => { if (view !== "detail" || !invoiceId) return; void fetch(`/api/invoices/sales/${invoiceId}`).then(async r => { const data = await r.json(); if (!r.ok) throw new Error(data.error || "No se encontró la factura."); setInvoice(data); setEditCustomer(data.customer.id); setEditDate(String(data.issueDate).slice(0, 10)); setEditLines(data.lines.map((line: InvoiceDetail["lines"][number]) => ({ id: line.id, description: line.description }))); }).catch(e => setError(e.message)); }, [view, invoiceId]);

  const filteredRows = useMemo(() => rows, [rows]);
  async function loadPreview(event: FormEvent) { event.preventDefault(); if (!xmlFile) { setError("Selecciona el XML CFDI."); return; } setBusy(true); setError(""); setNotice(""); try { const response = await fetch("/api/invoices/preview", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ kind: "sales", xml: await xmlFile.text() }) }); const data = await response.json(); if (!response.ok) throw new Error(data.error || "No se pudo leer el XML."); setPreview(data); setCustomerId(data.party?.id || "AUTO"); } catch (e) { setError(e instanceof Error ? e.message : "No se pudo validar el XML."); } finally { setBusy(false); } }
  async function createCustomer() { if (!preview) return; setBusy(true); setError(""); try { const response = await fetch("/api/parties", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ kind: "CUSTOMER", taxId: preview.cfdi.receiver.rfc, legalName: preview.cfdi.receiver.name || preview.cfdi.receiver.rfc }) }); const data = await response.json(); if (!response.ok) throw new Error(data.error || "No se pudo crear el cliente."); setCustomers(current => [...current, data]); setCustomerId(data.id); setPreview({ ...preview, party: data, needsPartyConfirmation: false }); } catch (e) { setError(e instanceof Error ? e.message : "No se pudo vincular el cliente."); } finally { setBusy(false); } }
  async function saveInvoice() { if (!xmlFile) { setError("Selecciona el XML CFDI antes de guardar."); return; } setBusy(true); setError(""); try { const form = new FormData(); form.set("xml", xmlFile); if (customerId && customerId !== "AUTO") form.set("customerId", customerId); if (pdfFile) form.set("pdf", pdfFile); const response = await fetch("/api/invoices/sales", { method: "POST", body: form }); const data = await response.json(); if (!response.ok) throw new Error(data.error || "No se pudo registrar la factura."); router.push(`/facturas-venta/${data.id}`); } catch (e) { setError(e instanceof Error ? e.message : "No se pudo guardar la factura."); } finally { setBusy(false); } }
  async function updateInvoice(values: Record<string, unknown>) { if (!invoice) return; setBusy(true); setError(""); setNotice(""); try { const response = await fetch(`/api/invoices/sales/${invoice.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(values) }); const data = await response.json(); if (!response.ok) throw new Error(data.error || "No se pudo actualizar la factura."); setInvoice(data); setEdit(false); setNotice("Los cambios se guardaron."); } catch (e) { setError(e instanceof Error ? e.message : "No se pudo actualizar la factura."); } finally { setBusy(false); } }
  async function processInventory() { if (!invoice) return; setBusy(true); setError(""); setNotice(""); try { const response = await fetch(`/api/invoices/sales/${invoice.id}/process`, { method: "POST" }); const data = await response.json(); if (!response.ok) throw new Error(data.error || "No se pudo confirmar la salida de inventario."); const refreshed = await fetch(`/api/invoices/sales/${invoice.id}`); const detail = await refreshed.json(); if (!refreshed.ok) throw new Error(detail.error || "No se pudo actualizar el detalle."); setInvoice(detail); setNotice("Salida de inventario confirmada."); } catch (e) { setError(e instanceof Error ? e.message : "No se pudo procesar el inventario."); } finally { setBusy(false); } }

  if (view === "list") return <section className="content sales-invoices sales-invoices-list">
    <div className="title-row">
      <div>
        <span className="module-eyebrow"><FileText size={14} aria-hidden="true"/> Comercial / Ventas</span>
        <h1>Facturas de venta</h1>
        <p>Consulta facturas emitidas y da seguimiento a tus saldos.</p>
      </div>
      <Link className="primary page-action" href="/facturas-venta/nueva"><Plus size={18}/> Nueva factura</Link>
    </div>
    <div className="sales-toolbar">
      <section className="panel sales-filter-card" aria-labelledby="sales-filter-heading">
        <h2 id="sales-filter-heading">Buscar y filtrar</h2>
        <div className="sales-filter-controls">
          <label className="sales-search"><Search size={17} aria-hidden="true"/><input type="search" aria-label="Buscar factura" placeholder="Folio, UUID o cliente" value={query} onChange={event => setQuery(event.target.value)}/></label>
          <div className="sales-tabs" role="group" aria-label="Estado de pago">
            {[["ALL", "Todas"], ["PAID", "Pagadas"], ["PENDING", "Pendientes de pago"]].map(([value, label]) =>
              <button type="button" key={value} aria-pressed={status === value} className={status === value ? "selected" : ""} onClick={() => setStatus(value)}>{label}</button>,
            )}
          </div>
        </div>
      </section>
      <section className="panel sales-export-card" aria-labelledby="sales-export-heading">
        <div><h2 id="sales-export-heading"><FileText size={17} aria-hidden="true"/> Cuentas por cobrar</h2><p>Consulta el saldo pendiente en el reporte.</p></div>
        <a className="secondary sales-export" href="/api/invoices/sales/export" target="_blank" rel="noreferrer"><Printer size={17}/> Exportar PDF</a>
      </section>
    </div>
    <details className="sales-monthly">
      <summary><ChartNoAxesColumn size={17} aria-hidden="true"/> Productos vendidos por mes <ChevronDown size={15} className="sales-monthly-chevron" aria-hidden="true"/></summary>
      <MonthlySoldProductsReportPanel/>
    </details>
    <SalesReportPanel/>
    {error && <div className="error" role="alert">{error}</div>}
    <section className="panel sales-table-panel" aria-labelledby="sales-table-heading">
      <div className="panel-head">
        <div className="sales-table-title"><h2 id="sales-table-heading">Facturas registradas</h2><span className="record-count" aria-live="polite">{filteredRows.length.toLocaleString("es-MX")} {filteredRows.length === 1 ? "factura" : "facturas"}</span></div>
        <span className="sales-sort"><ListFilter size={15} aria-hidden="true"/> Más recientes</span>
      </div>
      <div className="table-wrap sales-invoice-table-wrap">
        <table className="table sales-invoice-table" role="table" aria-labelledby="sales-table-heading">
          <thead role="rowgroup"><tr role="row">{["Folio", "Cliente", "Fecha", "Estado", "Partidas", "Total", "Saldo"].map((label, index) => <th key={label} role="columnheader" scope="col" className={index > 4 ? "numeric" : index === 4 ? "sales-items-cell" : undefined}>{label}</th>)}</tr></thead>
          <tbody role="rowgroup">
            {filteredRows.map(row => {
              const tone = row.status === "PAID" ? "paid" : row.status === "CANCELLED" ? "cancelled" : "pending";
              const label = tone === "paid" ? "Pagada" : tone === "cancelled" ? "Cancelada" : "Pendiente";
              return <tr key={row.id} role="row">
                <td role="cell" className="sales-folio-cell"><Link className="sales-folio" href={`/facturas-venta/${row.id}`}>{row.folio}<ChevronRight size={14} aria-hidden="true"/></Link><small className="sales-uuid" title={row.uuid ?? undefined}>{row.uuid || "UUID no disponible"}</small></td>
                <td role="cell" className="sales-client-cell">{row.customer}</td>
                <td role="cell" className="date-cell"><time dateTime={row.issueDate}>{date(row.issueDate)}</time></td>
                <td role="cell" className="sales-status-cell"><span className={`status ${tone}`}>{label}</span></td>
                <td role="cell" className="sales-items-cell">{row.items}<span className="sales-mobile-label"> {row.items === 1 ? "partida" : "partidas"}</span></td>
                <td role="cell" className="numeric money-cell sales-total-cell"><span className="sales-mobile-label">Total</span>{money(row.total, row.currency)}</td>
                <td role="cell" className={`numeric money-cell sales-balance-cell${row.balance ? "" : " is-zero"}`}><span className="sales-mobile-label">Saldo</span>{money(row.balance, row.currency)}</td>
              </tr>;
            })}
            {!filteredRows.length && <tr role="row"><td role="cell" colSpan={7} className="empty">No hay facturas que coincidan con la búsqueda y el filtro.</td></tr>}
          </tbody>
        </table>
      </div>
    </section>
  </section>;

  if (view === "new") return <section className="content sales-invoices"><div className="title-row"><div><Link className="sales-back" href="/facturas-venta"><ArrowLeft size={16}/> Facturas de venta</Link><span className="module-eyebrow">COMERCIAL · ALTA</span><h1>Nueva factura de venta</h1><p>El XML es la fuente fiscal; el PDF se conserva como documento visual adjunto.</p></div></div>{error && <div className="error">{error}</div>}<section className="panel sales-upload-panel"><div className="panel-head"><h2><span className="sales-step">1</span> Adjuntar documentos</h2><span className="record-count">XML obligatorio · PDF opcional · Máximo 20 MB por archivo</span></div><div className="sales-file-grid"><label className="sales-file-card"><input type="file" accept=".xml,text/xml,application/xml" onChange={(e: ChangeEvent<HTMLInputElement>) => { setXmlFile(e.target.files?.[0] || null); setPreview(null); }}/><span className="sales-file-icon"><FileText/></span><b>Archivo XML CFDI *</b><small>{xmlFile ? `${xmlFile.name} · ${fileSize(xmlFile.size)}` : "Selecciona o arrastra el XML de la factura"}</small></label><label className="sales-file-card"><input type="file" accept=".pdf,application/pdf" onChange={(e: ChangeEvent<HTMLInputElement>) => setPdfFile(e.target.files?.[0] || null)}/><span className="sales-file-icon"><FileText/></span><b>Representación impresa PDF</b><small>{pdfFile ? `${pdfFile.name} · ${fileSize(pdfFile.size)}` : "Opcional: adjunta el PDF correspondiente"}</small></label></div><div className="sales-upload-actions"><button className="primary" onClick={loadPreview} disabled={!xmlFile || busy}>{busy ? <LoaderCircle className="spin"/> : <CheckCircle2 size={16}/>} Validar XML</button></div></section>{preview && <><section className="panel"><div className="panel-head"><h2><span className="sales-step">2</span> Revisar datos del CFDI</h2><span className="status paid">XML válido</span></div><div className="invoice-summary"><div><small>UUID fiscal</small><b>{preview.cfdi.uuid || "Sin UUID"}</b></div><div><small>Folio</small><b>{[preview.cfdi.series, preview.cfdi.folio].filter(Boolean).join("-") || "Sin serie/folio"}</b></div><div><small>Cliente del XML</small><b>{preview.cfdi.receiver.name}</b><span>{preview.cfdi.receiver.rfc}</span></div><div><small>Total</small><b>{money(preview.cfdi.total, preview.cfdi.currency)}</b></div><div><small>Emisor</small><b>{preview.cfdi.issuer.name}</b><span>{preview.cfdi.issuer.rfc}</span></div><div><small>Fecha</small><b>{date(preview.cfdi.issueDate)}</b></div><div><small>Moneda</small><b>{preview.cfdi.currency}</b></div><div><small>Partidas detectadas</small><b>{preview.lines.length}</b></div></div>{preview.needsPartyConfirmation ? <div className="confirmation"><div><b>No existe un cliente vinculado al RFC del XML.</b><span>Comprueba los datos fiscales antes de crear el registro.</span></div><button className="secondary" onClick={createCustomer} disabled={busy}>Crear y vincular cliente</button></div> : <div className="confirmation confirmed"><CheckCircle2/><span>Cliente vinculado: {preview.party?.legalName}</span></div>}</section><section className="panel"><div className="panel-head"><h2>Partidas incluidas</h2><span className="record-count">{preview.lines.length} partidas</span></div><div className="table-wrap"><table className="table sales-lines-table"><thead><tr><th>Descripción</th><th>Cantidad</th><th>Precio unitario</th><th className="numeric">Importe</th></tr></thead><tbody>{preview.lines.map((line, i) => <tr key={`${line.description}-${i}`}><td>{line.description}</td><td>{line.quantity} {line.unit || ""}</td><td>{money(preview.cfdi.concepts[i]?.unitPrice || 0, preview.cfdi.currency)}</td><td className="numeric">{money(line.amount, preview.cfdi.currency)}</td></tr>)}</tbody></table></div></section><div className="invoice-actions"><button className="primary" onClick={saveInvoice} disabled={busy || !customerId}>{busy ? "Guardando…" : "Guardar factura"}</button></div></>}</section>;

  if (!invoice) return <section className="content"><div className="empty">Cargando factura…</div></section>;
  const paid = invoice.status === "PAID", cancelled = invoice.status === "CANCELLED";
  return <section className="content sales-invoices"><div className="title-row"><div><Link className="sales-back" href="/facturas-venta"><ArrowLeft size={16}/> Facturas de venta</Link><span className="module-eyebrow">FACTURA DE VENTA</span><h1>{invoice.folio}</h1><p>{date(invoice.issueDate)} · {paid ? "Pagada" : cancelled ? "Cancelada" : "Pendiente de pago"}</p></div><div className="sales-detail-actions">{!cancelled && <button className="secondary" onClick={() => setEdit(value => !value)}>{edit ? "Cerrar edición" : "Editar"}</button>}{!cancelled && !invoice.processedAt && invoice.inventoryDisposition !== "HISTORICAL" && <button className="secondary" onClick={() => void processInventory()} disabled={busy}>Confirmar salida de inventario</button>}{!paid && !cancelled && <button className="primary" onClick={() => void updateInvoice({ status: "PAID" })} disabled={busy}><CheckCircle2 size={16}/> Marcar como pagada</button>}{!cancelled && <button className="sales-danger" onClick={() => { if (window.confirm(`¿Cancelar la factura ${invoice.folio}?`)) void updateInvoice({ status: "CANCELLED" }); }} disabled={busy}>Cancelar</button>}</div></div>{error && <div className="error">{error}</div>}{notice && <div className="success-message"><CheckCircle2/>{notice}</div>}{edit && <section className="panel sales-edit-panel"><div className="panel-head"><h2>Editar información de factura</h2><span className="record-count">El XML fiscal original se conserva sin alteraciones.</span></div><div className="sales-edit-grid"><label className="field"><span>Cliente</span><select value={editCustomer} onChange={e => setEditCustomer(e.target.value)}>{customers.map(customer => <option key={customer.id} value={customer.id}>{customer.legalName}</option>)}</select></label><label className="field"><span>Fecha</span><input type="date" value={editDate} onChange={e => setEditDate(e.target.value)}/></label></div><div className="sales-edit-lines">{editLines.map((line, index) => <label className="field" key={line.id}><span>Descripción partida {index + 1}</span><input value={line.description} onChange={e => setEditLines(old => old.map(item => item.id === line.id ? { ...item, description: e.target.value } : item))}/></label>)}</div><footer className="sales-edit-footer"><button className="primary" onClick={() => void updateInvoice({ customerId: editCustomer, issueDate: new Date(`${editDate}T12:00:00.000Z`).toISOString(), lines: editLines })} disabled={busy}>Guardar cambios</button></footer></section>}{!edit && <><section className="sales-detail-grid"><article className="panel sales-detail-card"><span>CLIENTE</span><h2>{invoice.customer.legalName}</h2><p>{invoice.customer.taxId || "RFC sin registrar"}</p></article><article className="panel sales-detail-card"><span>DOCUMENTOS FISCALES</span><dl><div><dt>UUID</dt><dd>{invoice.uuid || "Sin UUID"}</dd></div><div><dt>Moneda</dt><dd>{invoice.currency}</dd></div><div><dt>Forma de pago</dt><dd>{invoice.paymentForm || "—"}</dd></div><div><dt>Método de pago</dt><dd>{invoice.paymentMethod || "—"}</dd></div></dl></article></section>{invoice.inventoryDisposition === "HISTORICAL" ? <div className="field-hint sales-stock-hint">Documento histórico previo al arranque; se conserva sin movimientos de inventario.</div> : !invoice.processedAt && !cancelled && <div className="field-hint sales-stock-hint">La salida de inventario aún no se ha confirmado. Hazlo solo después de validar las partidas y existencias.</div>}<section className="panel"><div className="panel-head"><h2>Partidas</h2><span className="record-count">{invoice.lines.length} partidas</span></div><div className="table-wrap"><table className="table sales-lines-table"><thead><tr><th>#</th><th>Producto</th><th>Cantidad</th><th>Precio</th><th className="numeric">Importe</th></tr></thead><tbody>{invoice.lines.map((line, i) => <tr key={line.id}><td>{i + 1}</td><td>{line.description}<small>{line.product?.technicalCode || "Sin código relacionado"}</small></td><td>{Number(line.quantity).toLocaleString("es-MX")} {line.unit || ""}</td><td>{money(Number(line.unitPrice), invoice.currency)}</td><td className="numeric">{money(Number(line.amount), invoice.currency)}</td></tr>)}</tbody></table></div><div className="sales-totals"><div><span>Subtotal</span><b>{money(Number(invoice.subtotal), invoice.currency)}</b></div><div><span>IVA</span><b>{money(Number(invoice.tax), invoice.currency)}</b></div><div><span>Total</span><b>{money(Number(invoice.total), invoice.currency)}</b></div><div className="sales-balance"><span>Saldo</span><b>{money(invoice.balance, invoice.currency)}</b></div></div></section><section className="panel sales-attachments"><div className="panel-head"><h2>Documentos adjuntos</h2><span className="record-count">XML y PDF originales vinculados a esta factura</span></div>{invoice.attachments.length ? <ul>{invoice.attachments.map(file => <li key={file.id}><span className="sales-file-icon"><FileText/></span><div><b>{file.fileName}</b><small>{fileSize(file.fileSize)} · {date(file.createdAt)}</small></div><a className="secondary" href={`/api/invoices/sales/${invoice.id}/attachments/${file.id}`}><Download size={15}/> Descargar</a></li>)}</ul> : <div className="empty">Esta factura no tiene archivos adjuntos almacenados.</div>}</section></>}</section>;
}
