"use client";

import { FormEvent, useEffect, useState } from "react";
import { CheckCircle2, FileText, LoaderCircle, Upload } from "lucide-react";
import "./catalog-workspace.css";

type Kind = "purchase" | "sales";
type PurchaseOrderOption = { id: string; folio: string; supplierId: string; status: string };
type ProductOption = { id: string; technicalCode: string; description: string };
type Preview = {
  cfdi: {
    uuid?: string; series?: string; folio?: string; issueDate: string; currency: string; subtotal: number; tax: number; total: number;
    issuer: { rfc: string; name: string }; receiver: { rfc: string; name: string };
    concepts: Array<{ description: string; quantity: number; unit?: string; unitPrice: number; amount: number; code?: string }>;
  };
  party: { id: string; legalName: string; taxId?: string } | null;
  needsPartyConfirmation: boolean;
  lines: Array<{ description: string; quantity: number; unit?: string; amount: number; product?: ProductOption | null }>;
};

const labels = {
  purchase: { eyebrow: "COMPRAS", title: "Facturas de compra", subtitle: "Importa XML, revisa el CFDI y registra la recepción en inventario.", party: "proveedor", partyKind: "SUPPLIER", endpoint: "/api/invoices/purchase" },
  sales: { eyebrow: "COMERCIAL", title: "Facturas de venta", subtitle: "Importa XML, relaciona al cliente y registra la salida de inventario.", party: "cliente", partyKind: "CUSTOMER", endpoint: "/api/invoices/sales" },
} as const;

export function InvoiceImportWorkspace({ kind }: { kind: Kind }) {
  const meta = labels[kind];
  const [xml, setXml] = useState("");
  const [preview, setPreview] = useState<Preview | null>(null);
  const [partyId, setPartyId] = useState("");
  const [products, setProducts] = useState<ProductOption[]>([]);
  const [lineProducts, setLineProducts] = useState<Record<number, string>>({});
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrderOption[]>([]);
  const [purchaseOrderId, setPurchaseOrderId] = useState("");
  const [savedId, setSavedId] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    const requests = kind === "purchase" ? [fetch("/api/purchase-orders"), fetch("/api/products")] : [Promise.resolve(null), fetch("/api/products")];
    void Promise.all(requests).then(async ([ordersResponse, productsResponse]) => {
      if (!productsResponse?.ok || (ordersResponse && !ordersResponse.ok)) throw new Error("No se pudieron cargar pedidos y productos para relacionar la factura.");
      if (ordersResponse) setPurchaseOrders(await ordersResponse.json());
      setProducts(await productsResponse.json());
    }).catch(cause => setError(cause instanceof Error ? cause.message : "No se pudieron cargar los datos para relacionar la factura."));
  }, [kind]);

  async function previewXml(event: FormEvent) {
    event.preventDefault(); setBusy(true); setError(""); setMessage(""); setSavedId(""); setPurchaseOrderId(""); setLineProducts({});
    try {
      const response = await fetch("/api/invoices/preview", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ kind, xml }) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? "No se pudo leer el XML.");
      setPreview(result);
      setLineProducts(Object.fromEntries(result.lines.map((line: Preview["lines"][number], index: number) => [index, line.product?.id ?? ""])));
      setPartyId(result.party?.id ?? "");
    } catch (cause) { setError(cause instanceof Error ? cause.message : "No se pudo leer el XML."); }
    finally { setBusy(false); }
  }

  async function createParty() {
    if (!preview) return;
    setBusy(true); setError("");
    const source = kind === "purchase" ? preview.cfdi.issuer : preview.cfdi.receiver;
    try {
      const response = await fetch("/api/parties", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ kind: meta.partyKind, taxId: source.rfc, legalName: source.name || source.rfc }) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? `No se pudo crear el ${meta.party}.`);
      setPartyId(result.id); setPreview({ ...preview, party: result, needsPartyConfirmation: false });
    } catch (cause) { setError(cause instanceof Error ? cause.message : `No se pudo crear el ${meta.party}.`); }
    finally { setBusy(false); }
  }

  async function saveInvoice() {
    if (!partyId) { setError(`Confirma o crea el ${meta.party} antes de registrar la factura.`); return; }
    setBusy(true); setError("");
    const partyField = kind === "purchase" ? "supplierId" : "customerId";
    const productIds = preview?.lines.map((line, index) => lineProducts[index] || line.product?.id || "") ?? [];
    try {
      const response = await fetch(meta.endpoint, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ xml, [partyField]: partyId, productIds, ...(kind === "purchase" && purchaseOrderId ? { purchaseOrderId } : {}) }) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? "No se pudo registrar la factura ni aplicar inventario.");
      setSavedId(result.id);
      setMessage(kind === "purchase" ? "Factura guardada; la existencia aumentó y el saldo del pedido se actualizó." : "Factura guardada; las existencias se descontaron.");
    } catch (cause) { setError(cause instanceof Error ? cause.message : "No se pudo registrar la factura."); }
    finally { setBusy(false); }
  }

  const allLinesMapped = preview?.lines.every((line, index) => Boolean(lineProducts[index] || line.product?.id)) ?? false;
  const money = new Intl.NumberFormat("es-MX", { style: "currency", currency: preview?.cfdi.currency || "MXN" });

  return <section className="content">
    <div className="title-row"><div><span className="module-eyebrow">{meta.eyebrow}</span><h1>{meta.title}</h1><p>{meta.subtitle}</p></div></div>
    <section className="panel importer"><div className="panel-head"><h2><Upload size={18}/> 1. Importar XML</h2><span className="record-count">Revisa y relaciona cada partida antes de contabilizar</span></div><form onSubmit={previewXml} className="xml-form"><label className="field"><span>Contenido XML CFDI *</span><textarea value={xml} onChange={event => setXml(event.target.value)} rows={9} placeholder="Pega el XML CFDI aquí para procesarlo y revisar los datos extraídos." required/></label><button className="primary page-action" disabled={busy}>{busy ? <><LoaderCircle className="spin"/> Procesando…</> : <><FileText size={17}/> Procesar XML</>}</button></form></section>
    {error && <div className="error" role="alert">{error}</div>}
    {preview && <>
      <section className="panel"><div className="panel-head"><h2>2. Revisar información fiscal</h2><span className="status paid">XML válido</span></div><div className="invoice-summary"><div><small>UUID</small><b>{preview.cfdi.uuid ?? "Sin UUID"}</b></div><div><small>Folio fiscal</small><b>{[preview.cfdi.series, preview.cfdi.folio].filter(Boolean).join("-") || "Sin serie/folio"}</b></div><div><small>{kind === "purchase" ? "Proveedor" : "Cliente"}</small><b>{kind === "purchase" ? preview.cfdi.issuer.name : preview.cfdi.receiver.name}</b><span>{kind === "purchase" ? preview.cfdi.issuer.rfc : preview.cfdi.receiver.rfc}</span></div><div><small>Total</small><b>{money.format(preview.cfdi.total)}</b></div></div>
        {kind === "purchase" && <label className="field invoice-order-link"><span>Pedido de compra relacionado (opcional)</span><select value={purchaseOrderId} onChange={event => setPurchaseOrderId(event.target.value)} disabled={!partyId}><option value="">Sin pedido relacionado</option>{purchaseOrders.filter(order => order.supplierId === partyId && order.status !== "CANCELLED").map(order => <option key={order.id} value={order.id}>{order.folio} · {order.status === "DELIVERED" ? "Recibido" : "Pendiente"}</option>)}</select><small>La factura sumará la recepción y descontará del pedido solo la cantidad recibida.</small></label>}
        {preview.needsPartyConfirmation ? <div className="confirmation"><div><b>No existe un {meta.party} con ese RFC.</b><span>El XML no creará duplicados silenciosamente.</span></div><button type="button" className="secondary" onClick={createParty} disabled={busy}>Crear y vincular {meta.party}</button></div> : <div className="confirmation confirmed"><CheckCircle2/><span>{meta.party[0].toUpperCase() + meta.party.slice(1)} vinculado: {preview.party?.legalName}</span></div>}
      </section>
      <section className="panel"><div className="panel-head"><h2>Partidas detectadas</h2><span className="record-count">Verifica o asocia cada producto antes de actualizar inventario</span></div><div className="table-wrap"><table className="table"><thead><tr><th>Descripción XML</th><th>Cantidad</th><th>Unidad</th><th>Producto de inventario</th><th>Importe</th></tr></thead><tbody>{preview.lines.map((line, index) => <tr key={`${line.description}-${index}`}><td>{line.description}</td><td>{line.quantity}</td><td>{line.unit ?? "—"}</td><td><select className="invoice-product-select" aria-label={`Producto para partida ${index + 1}`} value={lineProducts[index] || line.product?.id || ""} onChange={event => setLineProducts(current => ({ ...current, [index]: event.target.value }))}><option value="">Selecciona producto…</option>{products.map(product => <option key={product.id} value={product.id}>{product.technicalCode} · {product.description}</option>)}</select></td><td>{money.format(line.amount)}</td></tr>)}</tbody></table></div></section>
      <div className="invoice-actions"><button className="primary page-action" onClick={saveInvoice} disabled={busy || !partyId || !allLinesMapped || Boolean(savedId)}>{savedId ? "Factura registrada" : "3. Registrar factura y actualizar inventario"}</button></div>
      {!allLinesMapped && <div className="field-hint">Asocia cada partida con un producto activo. No se registrará la factura mientras falte alguna asociación.</div>}
      {message && <div className="success-message"><CheckCircle2/> {message}</div>}
    </>}
  </section>;
}
