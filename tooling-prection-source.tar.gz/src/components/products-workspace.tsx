"use client";

import Link from "next/link";
import { FormEvent, useCallback, useEffect, useMemo, useState } from "react";
import { Archive, ArrowLeft, ArrowUpRight, Check, Download, LoaderCircle, Package, Pencil, Plus, Search, RotateCcw, X } from "lucide-react";
import "./products-workspace.css";

type ProductOption = { id: string; name?: string; legalName?: string };
type ProductOptions = { brands: ProductOption[]; categories: ProductOption[]; suppliers: ProductOption[] };
type Product = {
  id: string; internalReference: number; technicalCode: string; description: string; fiscalDescription?: string | null; unit: string;
  stock: string | number; onOrder: string | number; baseCost: string | number; salePrice: string | number; minimumStock: string | number; leadTimeDays?: number | null;
  status: "ACTIVE" | "ARCHIVED"; createdAt?: string; updatedAt?: string;
  brandId?: string | null; categoryId?: string | null; mainSupplierId?: string | null;
  brand?: { name: string } | null; category?: { name: string } | null; mainSupplier?: { legalName: string } | null;
};
type ProductDetail = Product & {
  inventoryMovements: Array<{ id: string; type: string; quantity: string | number; balanceAfter: string | number; notes?: string | null; createdAt: string }>;
  purchaseLines: Array<{ id: string; quantity: string | number; receivedQuantity: string | number; unitPrice: string | number; purchaseOrder: { folio: string; issueDate: string; status: string; supplier: { legalName: string } } }>;
  purchaseInvoiceLines: Array<{ id: string; quantity: string | number; unitPrice: string | number; purchaseInvoice: { folio: string; issueDate: string; supplier: { legalName: string } } }>;
  salesInvoiceLines: Array<{ id: string; quantity: string | number; unitPrice: string | number; salesInvoice: { folio: string; issueDate: string; customer: { legalName: string } } }>;
  quoteLines: Array<{ id: string; quantity: string | number; unitPrice: string | number; quote: { folio: string; issueDate: string; customer?: { legalName: string } | null } }>;
  deliveryLines: Array<{ id: string; quantity: string | number; unitPrice: string | number; delivery: { folio: string; issueDate: string; customer?: { legalName: string } | null } }>;
  reconciliationLeft: Array<{ id: string; status: string; similarity: string | number; productB: Product }>;
  reconciliationRight: Array<{ id: string; status: string; similarity: string | number; productA: Product }>;
};

const fmtDate = (value?: string) => value ? new Intl.DateTimeFormat("es-MX", { dateStyle: "medium", timeZone: "America/Mexico_City" }).format(new Date(value)) : "—";
const qty = (value: string | number) => Number(value).toLocaleString("es-MX", { maximumFractionDigits: 3 });
const money = (value: string | number) => new Intl.NumberFormat("es-MX", { style: "currency", currency: "MXN" }).format(Number(value));

export function ProductsWorkspace({ canCreate = false, canArchive = false, canManageCatalogs = false }: { canCreate?: boolean; canArchive?: boolean; canManageCatalogs?: boolean }) {
  const [products, setProducts] = useState<Product[]>([]);
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState<"ACTIVE" | "ARCHIVED">("ACTIVE");
  const [open, setOpen] = useState(false);
  const [options, setOptions] = useState<ProductOptions>({ brands: [], categories: [], suppliers: [] });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [productResponse, optionsResponse] = await Promise.all([fetch(`/api/products?status=${status}`), fetch("/api/products/options")]);
      const productData = await productResponse.json();
      const optionData = await optionsResponse.json();
      if (!productResponse.ok) throw new Error(productData.error ?? "No fue posible cargar los productos.");
      if (!optionsResponse.ok) throw new Error(optionData.error ?? "No fue posible cargar marcas, categorías y proveedores.");
      setProducts(productData); setOptions(optionData); setError("");
    } catch (cause) { setError(cause instanceof Error ? cause.message : "No fue posible cargar los productos."); }
    finally { setLoading(false); }
  }, [status]);
  useEffect(() => { void load(); }, [load]);

  const filtered = useMemo(() => {
    const needle = query.trim().toLocaleLowerCase("es-MX");
    if (!needle) return products;
    return products.filter(product => [product.technicalCode, String(product.internalReference), `TP-${String(product.internalReference).padStart(5, "0")}`, product.description, product.fiscalDescription, product.mainSupplier?.legalName, product.brand?.name, product.category?.name].some(value => value?.toLocaleLowerCase("es-MX").includes(needle)));
  }, [products, query]);

  async function createProduct(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setSaving(true); setError(""); setNotice("");
    const form = new FormData(event.currentTarget);
    const body = Object.fromEntries(form.entries());
    for (const key of ["brandId", "categoryId", "mainSupplierId", "leadTimeDays", "fiscalDescription"]) if (!body[key]) delete body[key];
    try {
      const response = await fetch("/api/products", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? "No fue posible crear el producto.");
      setOpen(false); setNotice("Producto registrado correctamente."); await load();
    } catch (cause) { setError(cause instanceof Error ? cause.message : "No fue posible crear el producto."); }
    finally { setSaving(false); }
  }

  async function setProductStatus(product: Product) {
    const next = product.status === "ACTIVE" ? "ARCHIVED" : "ACTIVE";
    setError(""); setNotice("");
    try {
      const response = await fetch(`/api/products/${product.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status: next }) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? "No fue posible actualizar el estado.");
      setNotice(next === "ARCHIVED" ? "Producto archivado; se conservan los movimientos y documentos." : "Producto restaurado y activo."); await load();
    } catch (cause) { setError(cause instanceof Error ? cause.message : "No fue posible actualizar el estado."); }
  }

  return <section className="content products-workspace">
    <div className="title-row"><div><span className="module-eyebrow">CATÁLOGO TÉCNICO</span><h1>Productos</h1><p>Catálogo, existencias, pedidos pendientes y datos comerciales de Tooling Prection.</p></div><div className="products-page-actions"><a className="secondary products-summary-button" href={`/api/products/summary?status=${status}`} target="_blank" rel="noreferrer"><Download size={16}/> Resumen PDF</a>{canCreate && <button className="primary page-action" onClick={() => { setError(""); setOpen(true); }}><Plus size={17}/> Registrar producto</button>}</div></div>
    <div className="products-toolbar"><label className="local-search products-search"><Search size={16}/><input value={query} onChange={event => setQuery(event.target.value)} placeholder="Código técnico, descripción, marca…" aria-label="Buscar productos"/></label><div className="products-tabs" role="tablist" aria-label="Estado de producto"><button type="button" role="tab" aria-selected={status === "ACTIVE"} className={status === "ACTIVE" ? "selected" : ""} onClick={() => { setStatus("ACTIVE"); setNotice(""); }}>Activos</button><button type="button" role="tab" aria-selected={status === "ARCHIVED"} className={status === "ARCHIVED" ? "selected" : ""} onClick={() => { setStatus("ARCHIVED"); setNotice(""); }}>Archivados</button></div></div>
    {error && !open && <div className="error" role="alert">{error}</div>}{notice && <div className="success-notice" role="status"><Check size={16}/>{notice}</div>}
    <section className="panel products-panel"><div className="panel-head"><h2>{loading ? "Cargando…" : `${filtered.length} ${filtered.length === 1 ? "producto" : "productos"}`}</h2><span className="record-count">{status === "ACTIVE" ? "Activos" : "Archivados"} · los cambios de stock conservan su trazabilidad</span></div>{loading ? <div className="empty"><LoaderCircle className="spin"/> Cargando catálogo…</div> : <div className="table-wrap products-table-wrap"><table className="table products-table"><thead><tr><th>Código técnico</th><th>Producto</th><th>Marca / categoría</th><th>Proveedor principal</th><th>Existencia</th><th>En pedido</th><th>Estado</th><th>Costo</th><th>Precio</th><th>Acciones</th></tr></thead><tbody>{filtered.map(product => <tr key={product.id}>
      <td><Link className="product-code" href={`/productos/${product.id}`}>{product.technicalCode || "Sin código"}<ArrowUpRight size={13}/></Link><small>Ref. interna: TP-{String(product.internalReference).padStart(5, "0")}</small></td>
      <td className="product-description">{product.description}</td><td>{product.brand?.name ?? "—"}<small>{product.category?.name ?? "Sin categoría"}</small></td><td>{product.mainSupplier?.legalName ?? "—"}</td><td className="numeric">{qty(product.stock)} <small>{product.unit}</small></td><td className="numeric">{qty(product.onOrder)} <small>{product.unit}</small></td><td><span className={`status ${product.status === "ACTIVE" ? "paid" : "archived-status"}`}>{product.status === "ACTIVE" ? "Activo" : "Archivado"}</span></td><td className="money-cell">{money(product.baseCost)}</td><td className="money-cell">{money(product.salePrice)}</td><td><div className="product-actions"><Link className="product-action" href={`/productos/${product.id}`} title="Ver resumen" aria-label={`Ver resumen de ${product.technicalCode}`}><Package size={15}/></Link>{canArchive && <button type="button" className="product-action" onClick={() => void setProductStatus(product)} title={product.status === "ACTIVE" ? "Archivar" : "Restaurar"} aria-label={product.status === "ACTIVE" ? `Archivar ${product.technicalCode}` : `Restaurar ${product.technicalCode}`}>{product.status === "ACTIVE" ? <Archive size={15}/> : <RotateCcw size={15}/>}</button>}</div></td>
    </tr>)}{!filtered.length && <tr><td colSpan={10} className="empty">{query ? "No hay productos que coincidan con la búsqueda." : status === "ACTIVE" ? "Aún no hay productos activos." : "No hay productos archivados."}</td></tr>}</tbody></table></div>}</section>
    {open && <div className="dialog-backdrop" role="presentation" onMouseDown={() => setOpen(false)}><form className="dialog product-dialog" onSubmit={createProduct} onMouseDown={event => event.stopPropagation()}><header><div><span className="module-eyebrow">CATÁLOGO TÉCNICO</span><h2>Registrar producto</h2></div><button type="button" className="icon-button" onClick={() => setOpen(false)} aria-label="Cerrar"><X/></button></header>{error && <div className="error" role="alert">{error}</div>}<ProductFields options={options} canManageCatalogs={canManageCatalogs}/><footer><button type="button" className="secondary" onClick={() => setOpen(false)}>Cancelar</button><button className="primary" disabled={saving}>{saving ? "Guardando…" : "Guardar producto"}</button></footer></form></div>}
  </section>;
}

function ProductFields({ product, options, onSave, saving, error, canManageCatalogs = false }: { product?: Product; options: ProductOptions; onSave?: (event: FormEvent<HTMLFormElement>) => void; saving?: boolean; error?: string; canManageCatalogs?: boolean }) {
  const [brands, setBrands] = useState(options.brands); const [categories, setCategories] = useState(options.categories);
  const [brandId, setBrandId] = useState(product?.brandId ?? ""); const [categoryId, setCategoryId] = useState(product?.categoryId ?? "");
  const body = <><div className="form-section-title">Identificación</div><div className="field"><label>Código técnico *</label><input name="technicalCode" required maxLength={100} defaultValue={product?.technicalCode ?? ""}/></div><div className="field"><label>Referencia interna</label><input value={product ? `TP-${String(product.internalReference).padStart(5, "0")}` : "Se asigna automáticamente"} readOnly/></div><div className="field form-span"><label>Descripción *</label><textarea name="description" required rows={3} defaultValue={product?.description ?? ""}/></div><div className="field form-span"><label>Descripción fiscal</label><textarea name="fiscalDescription" rows={2} defaultValue={product?.fiscalDescription ?? ""}/></div><div className="field"><label>Marca</label><select name="brandId" value={brandId} onChange={event => setBrandId(event.target.value)}><option value="">Sin marca</option>{brands.map(item => <option key={item.id} value={item.id}>{item.name}</option>)}</select>{canManageCatalogs && <InlineCatalogCreate type="brands" items={brands} onCreated={item => { setBrands(current => [...current, item].sort((a,b) => (a.name || "").localeCompare(b.name || ""))); setBrandId(item.id); }}/>}</div><div className="field"><label>Categoría</label><select name="categoryId" value={categoryId} onChange={event => setCategoryId(event.target.value)}><option value="">Sin categoría</option>{categories.map(item => <option key={item.id} value={item.id}>{item.name}</option>)}</select>{canManageCatalogs && <InlineCatalogCreate type="categories" items={categories} onCreated={item => { setCategories(current => [...current, item].sort((a,b) => (a.name || "").localeCompare(b.name || ""))); setCategoryId(item.id); }}/>}</div><div className="field"><label>Proveedor principal</label><select name="mainSupplierId" defaultValue={product?.mainSupplierId ?? ""}><option value="">Sin asignar</option>{options.suppliers.map(item => <option key={item.id} value={item.id}>{item.legalName}</option>)}</select></div><div className="field"><label>Unidad *</label><input name="unit" required maxLength={20} defaultValue={product?.unit ?? "PZA"}/></div><div className="form-section-title">Información comercial e inventario</div><div className="field"><label>Costo base (MXN) *</label><input name="baseCost" type="number" min="0" step="0.01" required defaultValue={product?.baseCost ?? 0}/></div><div className="field"><label>Precio de venta (MXN) *</label><input name="salePrice" type="number" min="0" step="0.01" required defaultValue={product?.salePrice ?? 0}/></div><div className="field"><label>Existencia mínima</label><input name="minimumStock" type="number" min="0" step="0.001" defaultValue={product?.minimumStock ?? 0}/><small className="field-hint">Se utiliza para identificar inventario crítico en reportes.</small></div><div className="field"><label>Lead time (días)</label><input name="leadTimeDays" type="number" min="0" step="1" defaultValue={product?.leadTimeDays ?? ""}/></div>{product && <div className="field product-readonly"><label>Existencia</label><input value={`${qty(product.stock)} ${product.unit} · se actualiza con movimientos`} readOnly/></div>}</>;
  if (!onSave) return <div className="form-grid product-form-grid">{body}</div>;
  return <form className="product-edit-form" onSubmit={onSave}><div className="form-grid product-form-grid">{body}</div>{error && <div className="error" role="alert">{error}</div>}<footer><button className="primary" disabled={saving}>{saving ? "Guardando…" : "Guardar cambios"}</button></footer></form>;
}

function InlineCatalogCreate({ type, items, onCreated }: { type: "brands" | "categories"; items: ProductOption[]; onCreated: (item: ProductOption) => void }) {
  const [open, setOpen] = useState(false); const [name, setName] = useState(""); const [saving, setSaving] = useState(false); const [error, setError] = useState("");
  async function create() {
    const cleaned = name.trim(); if (cleaned.length < 2) { setError("Escribe al menos 2 caracteres."); return; }
    const normalized = (value: string) => value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim().replace(/\s+/g, " ").toLocaleUpperCase("es-MX");
    const existing = items.find(item => normalized(item.name || "") === normalized(cleaned));
    if (existing) { onCreated(existing); setName(""); setOpen(false); setError(""); return; }
    setSaving(true); setError("");
    try { const response = await fetch("/api/catalogs", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ type, name: cleaned }) }); const result = await response.json(); if (!response.ok) throw new Error(result.error || "No se pudo guardar el catálogo."); onCreated(result); setName(""); setOpen(false); }
    catch (cause) { setError(cause instanceof Error ? cause.message : "No se pudo guardar el catálogo."); }
    finally { setSaving(false); }
  }
  return <div className="inline-catalog-create"><button type="button" className="inline-catalog-toggle" onClick={() => { setOpen(value => !value); setError(""); }}>{open ? "Cancelar" : `+ Agregar ${type === "brands" ? "marca" : "categoría"}`}</button>{open && <div className="inline-catalog-entry"><input aria-label={`Nombre de ${type === "brands" ? "marca" : "categoría"}`} value={name} maxLength={100} placeholder={`Nombre de ${type === "brands" ? "marca" : "categoría"}`} onChange={event => setName(event.target.value)} onKeyDown={event => { if (event.key === "Enter") { event.preventDefault(); void create(); } }}/><button type="button" className="secondary" disabled={saving} onClick={() => void create()}>{saving ? "Guardando…" : "Guardar"}</button>{error && <small className="error" role="alert">{error}</small>}</div>}</div>;
}

export function ProductDetailWorkspace({ productId, canUpdate = false, canArchive = false, canManageCatalogs = false }: { productId: string; canUpdate?: boolean; canArchive?: boolean; canManageCatalogs?: boolean }) {
  const [product, setProduct] = useState<ProductDetail | null>(null);
  const [options, setOptions] = useState<ProductOptions>({ brands: [], categories: [], suppliers: [] });
  const [editing, setEditing] = useState(false); const [loading, setLoading] = useState(true); const [saving, setSaving] = useState(false); const [error, setError] = useState(""); const [notice, setNotice] = useState("");
  const load = useCallback(async () => { setLoading(true); setError(""); try { const [productResponse, optionsResponse] = await Promise.all([fetch(`/api/products/${productId}`), fetch("/api/products/options")]); const data = await productResponse.json(); const optionData = await optionsResponse.json(); if (!productResponse.ok) throw new Error(data.error ?? "No fue posible cargar el producto."); if (!optionsResponse.ok) throw new Error(optionData.error ?? "No fue posible cargar las opciones."); setProduct(data); setOptions(optionData); } catch (cause) { setError(cause instanceof Error ? cause.message : "No fue posible cargar el producto."); } finally { setLoading(false); } }, [productId]);
  useEffect(() => { void load(); }, [load]);
  async function save(event: FormEvent<HTMLFormElement>) { event.preventDefault(); if (!product) return; setSaving(true); setError(""); const form = new FormData(event.currentTarget); const body = Object.fromEntries(form.entries()); for (const key of ["brandId", "categoryId", "mainSupplierId", "leadTimeDays", "fiscalDescription"]) if (!body[key]) delete body[key]; try { const response = await fetch(`/api/products/${product.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }); const result = await response.json(); if (!response.ok) throw new Error(result.error ?? "No fue posible guardar los cambios."); setEditing(false); setNotice("Los datos del producto se actualizaron."); await load(); } catch (cause) { setError(cause instanceof Error ? cause.message : "No fue posible guardar los cambios."); } finally { setSaving(false); } }
  async function changeStatus() { if (!product) return; const next = product.status === "ACTIVE" ? "ARCHIVED" : "ACTIVE"; const response = await fetch(`/api/products/${product.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status: next }) }); const result = await response.json(); if (!response.ok) { setError(result.error ?? "No fue posible cambiar el estado."); return; } setNotice(next === "ARCHIVED" ? "Producto archivado; el historial permanece disponible." : "Producto restaurado."); await load(); }
  if (loading) return <section className="content"><div className="empty"><LoaderCircle className="spin"/> Cargando producto…</div></section>;
  if (!product) return <section className="content"><div className="error" role="alert">{error || "Producto no encontrado."}</div><Link className="secondary" href="/productos"><ArrowLeft size={16}/> Volver a productos</Link></section>;
  const histories = [
    { title: "Pedidos de compra", rows: product.purchaseLines.map(line => ({ key: line.id, folio: line.purchaseOrder.folio, who: line.purchaseOrder.supplier.legalName, date: line.purchaseOrder.issueDate, quantity: line.quantity, extra: `${qty(line.receivedQuantity)} recibidas · ${line.purchaseOrder.status === "PENDING" ? "Pendiente" : line.purchaseOrder.status}` })) },
    { title: "Facturas de compra", rows: product.purchaseInvoiceLines.map(line => ({ key: line.id, folio: line.purchaseInvoice.folio, who: line.purchaseInvoice.supplier.legalName, date: line.purchaseInvoice.issueDate, quantity: line.quantity, extra: money(line.unitPrice) })) },
    { title: "Facturas de venta", rows: product.salesInvoiceLines.map(line => ({ key: line.id, folio: line.salesInvoice.folio, who: line.salesInvoice.customer.legalName, date: line.salesInvoice.issueDate, quantity: line.quantity, extra: money(line.unitPrice) })) },
    { title: "Cotizaciones", rows: product.quoteLines.map(line => ({ key: line.id, folio: line.quote.folio, who: line.quote.customer?.legalName ?? "Cliente manual", date: line.quote.issueDate, quantity: line.quantity, extra: money(line.unitPrice) })) },
    { title: "Remisiones", rows: product.deliveryLines.map(line => ({ key: line.id, folio: line.delivery.folio, who: line.delivery.customer?.legalName ?? "Cliente no indicado", date: line.delivery.issueDate, quantity: line.quantity, extra: money(line.unitPrice) })) },
  ];
  return <section className="content products-workspace product-detail"><div className="product-detail-back"><Link href="/productos"><ArrowLeft size={16}/> Volver a productos</Link></div>{error && <div className="error" role="alert">{error}</div>}{notice && <div className="success-notice" role="status"><Check size={16}/>{notice}</div>}
    <section className="product-detail-hero"><div className="product-detail-title"><span className="module-eyebrow">CATÁLOGO TÉCNICO · TP-{String(product.internalReference).padStart(5, "0")}</span><h1>{product.description}</h1><p>Código técnico <strong>{product.technicalCode}</strong> · {product.brand?.name ?? "Sin marca"} · {product.category?.name ?? "Sin categoría"}</p><span className={`status ${product.status === "ACTIVE" ? "paid" : "archived-status"}`}>{product.status === "ACTIVE" ? "Activo" : "Archivado"}</span></div><div className="product-detail-actions"><a className="secondary" href={`/api/products/summary?status=${product.status}`} target="_blank" rel="noreferrer"><Download size={16}/> Resumen PDF</a>{canUpdate && <button className="secondary" onClick={() => { setEditing(!editing); setError(""); }}><Pencil size={16}/> {editing ? "Cerrar edición" : "Editar producto"}</button>}{canArchive && <button className="secondary" onClick={() => void changeStatus()}>{product.status === "ACTIVE" ? <><Archive size={16}/> Archivar</> : <><RotateCcw size={16}/> Restaurar</>}</button>}</div></section>
    <div className="product-metrics"><Metric label="Existencia" value={`${qty(product.stock)} ${product.unit}`} detail="Stock disponible"/><Metric label="En pedido" value={`${qty(product.onOrder)} ${product.unit}`} detail="Recepciones pendientes"/><Metric label="Costo base" value={money(product.baseCost)} detail="Costo de referencia · MXN"/><Metric label="Precio de venta" value={money(product.salePrice)} detail="Precio actual · MXN"/></div>
    {editing && <section className="panel product-detail-edit"><div className="panel-head"><h2>Editar producto</h2><span className="record-count">Los cambios no alteran existencias ni historial de documentos</span></div><ProductFields product={product} options={options} onSave={save} saving={saving} error={error} canManageCatalogs={canManageCatalogs}/></section>}
    <div className="product-detail-grid"><section className="panel"><div className="panel-head"><h2>Información del producto</h2></div><dl className="product-facts"><Fact label="Referencia interna" value={`TP-${String(product.internalReference).padStart(5, "0")}`}/><Fact label="Código técnico" value={product.technicalCode}/><Fact label="Descripción fiscal" value={product.fiscalDescription || "—"}/><Fact label="Unidad" value={product.unit}/><Fact label="Marca" value={product.brand?.name ?? "Sin marca"}/><Fact label="Categoría" value={product.category?.name ?? "Sin categoría"}/><Fact label="Proveedor principal" value={product.mainSupplier?.legalName ?? "Sin asignar"}/><Fact label="Tiempo de entrega" value={product.leadTimeDays != null ? `${product.leadTimeDays} días` : "Sin definir"}/><Fact label="Última actualización" value={fmtDate(product.updatedAt)}/></dl></section><section className="panel"><div className="panel-head"><h2>Movimientos de inventario</h2><span className="record-count">Últimos 30 movimientos</span></div><div className="table-wrap"><table className="table product-history-table"><thead><tr><th>Fecha</th><th>Tipo</th><th>Cantidad</th><th>Saldo</th><th>Nota</th></tr></thead><tbody>{product.inventoryMovements.length ? product.inventoryMovements.map(row => <tr key={row.id}><td>{fmtDate(row.createdAt)}</td><td>{movementName(row.type)}</td><td>{qty(row.quantity)} {product.unit}</td><td>{qty(row.balanceAfter)} {product.unit}</td><td>{row.notes || "—"}</td></tr>) : <tr><td className="empty" colSpan={5}>Aún no hay movimientos de inventario.</td></tr>}</tbody></table></div></section></div>
    <section className="panel product-equivalents"><div className="panel-head"><h2>Equivalencias y revisión técnica</h2><span className="record-count">{product.reconciliationLeft.length + product.reconciliationRight.length} relaciones</span></div>{product.reconciliationLeft.length + product.reconciliationRight.length ? <div className="product-equivalent-list">{[...product.reconciliationLeft.map(item => ({ ...item, other: item.productB })), ...product.reconciliationRight.map(item => ({ ...item, other: item.productA }))].map(item => <div className="product-equivalent-row" key={item.id}><div><Link href={`/productos/${item.other.id}`}>{item.other.technicalCode}</Link><span>{item.other.description}</span></div><strong>{qty(item.similarity)}% coincidencia</strong><span className={`status ${item.status === "CONFIRMED" ? "paid" : item.status === "REJECTED" ? "archived-status" : "pending"}`}>{item.status === "CONFIRMED" ? "Confirmada" : item.status === "REJECTED" ? "Rechazada" : item.status === "SUGGESTED" ? "Por revisar" : item.status}</span></div>)}</div> : <div className="empty">Sin equivalencias técnicas registradas.</div>}</section>
    <div className="product-doc-history">{histories.map(history => <section className="panel" key={history.title}><div className="panel-head"><h2>{history.title}</h2><span className="record-count">{history.rows.length} registros</span></div><div className="table-wrap"><table className="table product-history-table"><thead><tr><th>Folio</th><th>{history.title.includes("compra") ? "Proveedor" : "Cliente"}</th><th>Fecha</th><th>Cantidad</th><th>Detalle</th></tr></thead><tbody>{history.rows.length ? history.rows.map(row => <tr key={row.key}><td><b>{row.folio}</b></td><td>{row.who}</td><td>{fmtDate(row.date)}</td><td>{qty(row.quantity)} {product.unit}</td><td>{row.extra}</td></tr>) : <tr><td className="empty" colSpan={5}>Sin historial registrado.</td></tr>}</tbody></table></div></section>)}</div>
  </section>;
}

function Metric({ label, value, detail }: { label: string; value: string; detail: string }) { return <section className="product-metric"><span>{label}</span><strong>{value}</strong><small>{detail}</small></section>; }
function Fact({ label, value }: { label: string; value: string }) { return <div><dt>{label}</dt><dd>{value}</dd></div>; }
function movementName(type: string) { return ({ PURCHASE_RECEIPT: "Recepción de compra", SALE: "Factura de venta", DELIVERY: "Remisión", ADJUSTMENT: "Ajuste", REVERSAL: "Reversión", MERGE: "Conciliación" } as Record<string, string>)[type] ?? type; }
