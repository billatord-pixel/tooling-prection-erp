"use client";

import { useEffect, useState } from "react";
import { LoaderCircle, ShieldCheck } from "lucide-react";
import "./catalog-workspace.css";
import "./audit-workspace.css";

type Event = { id: string; action: string; entity: string; entityId?: string | null; createdAt: string; user?: { name: string; email: string } | null };
const label: Record<string, string> = { CREATE: "Creación", UPDATE: "Actualización", PROCESS: "Procesamiento", ADJUST: "Ajuste", LOGIN: "Inicio de sesión" };
const entity: Record<string, string> = { Product: "Producto", Party: "Contacto", PurchaseOrder: "Pedido de compra", PurchaseInvoice: "Factura de compra", SalesInvoice: "Factura de venta", Delivery: "Remisión", Inventory: "Inventario", User: "Usuario", Brand: "Marca", Category: "Categoría", CompanySettings: "Configuración" };

export function AuditWorkspace() {
  const [events, setEvents] = useState<Event[]>([]); const [loading, setLoading] = useState(true); const [error, setError] = useState("");
  useEffect(() => { void (async () => { const response = await fetch("/api/audit"); const data = await response.json(); if (response.ok) setEvents(data); else setError(data.error ?? "No fue posible cargar la auditoría."); setLoading(false); })(); }, []);
  return <section className="content"><div className="title-row"><div><span className="module-eyebrow">CONTROL</span><h1>Auditoría</h1><p>Eventos críticos de la operación nueva de Tooling Prection.</p></div></div>{error && <div className="error">{error}</div>}<section className="panel"><div className="panel-head"><h2>{loading ? "Cargando…" : "Actividad reciente"}</h2><span className="record-count">Últimos {events.length} eventos</span></div>{loading ? <div className="empty"><LoaderCircle className="spin"/> Cargando auditoría…</div> : <div className="table-wrap"><table className="table"><thead><tr><th>Fecha y hora</th><th>Acción</th><th>Entidad</th><th>Usuario</th><th>Referencia</th></tr></thead><tbody>{events.length ? events.map(event => <tr key={event.id}><td>{new Intl.DateTimeFormat("es-MX", { dateStyle: "medium", timeStyle: "short" }).format(new Date(event.createdAt))}</td><td><span className="role-chip"><ShieldCheck size={14}/>{label[event.action] ?? event.action}</span></td><td>{entity[event.entity] ?? event.entity}</td><td>{event.user?.name ?? "Sistema"}<small>{event.user?.email ?? ""}</small></td><td><code>{event.entityId ?? "—"}</code></td></tr>) : <tr><td className="empty" colSpan={5}>Aún no hay eventos para mostrar.</td></tr>}</tbody></table></div>}</section></section>;
}
