"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { LoaderCircle, Search } from "lucide-react";
import "./global-search-workspace.css";

type Result = { id: string; type: string; title: string; subtitle: string; href: string; date: string };

export function GlobalSearchWorkspace() {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<Result[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    const value = query.trim();
    if (value.length < 2) { setResults([]); setBusy(false); setError(""); return; }
    const controller = new AbortController();
    const timer = window.setTimeout(async () => {
      setBusy(true); setError("");
      try {
        const response = await fetch(`/api/search?q=${encodeURIComponent(value)}`, { signal: controller.signal });
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || "No se pudo completar la búsqueda.");
        setResults(data.results);
      } catch (cause) {
        if (!controller.signal.aborted) setError(cause instanceof Error ? cause.message : "No se pudo completar la búsqueda.");
      } finally { if (!controller.signal.aborted) setBusy(false); }
    }, 220);
    return () => { window.clearTimeout(timer); controller.abort(); };
  }, [query]);

  return <section className="content global-search-workspace">
    <div className="title-row"><div><span className="module-eyebrow">BÚSQUEDA GLOBAL</span><h1>Buscar en el sistema</h1><p>Encuentra productos, clientes, proveedores y documentos de Tooling Prection.</p></div></div>
    <label className="global-search-field"><Search size={20}/><input autoFocus value={query} onChange={event => setQuery(event.target.value)} placeholder="Código, razón social, RFC, folio o UUID…" aria-label="Búsqueda global"/><span>{busy && <LoaderCircle className="spin" size={18}/>}</span></label>
    <section className="panel global-search-results"><div className="panel-head"><h2>{query.trim().length < 2 ? "Empieza escribiendo" : busy ? "Buscando…" : `${results.length} resultados`}</h2><span className="record-count">Búsqueda en registros activos</span></div>
      {error ? <div className="error" role="alert">{error}</div> : query.trim().length < 2 ? <div className="empty">Escribe al menos dos caracteres para buscar en tus catálogos y documentos.</div> : !busy && results.length === 0 ? <div className="empty">No encontramos coincidencias para “{query.trim()}”.</div> : <div className="global-search-list">{results.map(result => <Link href={result.href} key={`${result.type}-${result.id}`} className="global-search-result"><span className="global-search-type">{result.type}</span><span className="global-search-copy"><b>{result.title}</b><small>{result.subtitle}</small></span><time dateTime={result.date}>{new Intl.DateTimeFormat("es-MX", { dateStyle: "medium" }).format(new Date(result.date))}</time></Link>)}</div>}
    </section>
  </section>;
}
