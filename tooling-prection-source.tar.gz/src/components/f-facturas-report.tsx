"use client";
import { useState } from "react";
import { ChevronDown, Download, FileText } from "lucide-react";

export function FFacturasReportPanel() {
  const [from,setFrom] = useState("");
  const [to,setTo] = useState("");
  const [status,setStatus] = useState("ALL");
  const invalid = Boolean(from && to && from > to);
  const filters = new URLSearchParams({status});
  if (from) filters.set("from",from);
  if (to) filters.set("to",to);
  return <details className="sales-monthly">
    <summary><FileText size={17} aria-hidden="true"/> F-Facturas <ChevronDown size={15} className="sales-monthly-chevron" aria-hidden="true"/></summary>
    <div className="sold-products-controls">
      <label>Desde<input type="date" value={from} onChange={e=>setFrom(e.target.value)}/></label>
      <label>Hasta<input type="date" value={to} onChange={e=>setTo(e.target.value)}/></label>
      <label>Estado<select value={status} onChange={e=>setStatus(e.target.value)}><option value="ALL">Todas</option><option value="PAID">Pagadas</option><option value="PENDING">Pendientes de pago</option><option value="CANCELLED">Canceladas</option></select></label>
      {invalid ? <span className="error" role="alert">La fecha inicial debe ser anterior o igual a la final.</span> : <a className="secondary" href={`/api/reports/f-facturas?${filters}`} target="_blank" rel="noreferrer"><Download size={16}/> Abrir F-Facturas PDF</a>}
    </div>
    <p className="field-hint sold-products-note">Dos tablas por hoja: Folio, Monto USD y Monto MXN. El importe en USD se convierte a MXN con el FIX de Banxico de la fecha de facturación o el último anterior disponible. Las facturas emitidas en MXN muestran un guion en USD. Deja las fechas vacías para incluir todo el historial.</p>
  </details>;
}
