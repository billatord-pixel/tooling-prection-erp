"use client";

import { FormEvent, useCallback, useEffect, useMemo, useState } from "react";
import { Archive, Check, LoaderCircle, Pencil, Plus, Search, Trash2, X } from "lucide-react";
import "./catalog-workspace.css";

type WorkspaceKind = "products" | "customers" | "suppliers";
type Product = { id: string; internalReference: number; technicalCode: string; description: string; unit: string; stock: string | number; onOrder: string | number; baseCost: string | number; salePrice: string | number; currency?: string; status: string; brand?: { name: string } | null; category?: { name: string } | null; mainSupplier?: { legalName: string } | null };
type Party = { id: string; customerCode?: string | null; taxId?: string | null; legalName: string; tradeName?: string | null; email?: string | null; phone?: string | null; contactName?: string | null; address?: string | null; city?: string | null; state?: string | null; postalCode?: string | null; commercialTerms?: string | null; country?: string | null; currency?: string; _count?: {supplierProducts:number}; status: string; createdAt?: string };

const copy = {
  products: { eyebrow: "CATÁLOGO TÉCNICO", title: "Productos", description: "Herramientas, costos, precios y disponibilidad.", singular: "producto", search: "Código técnico o descripción…" },
  customers: { eyebrow: "COMERCIAL", title: "Clientes", description: "Datos fiscales, condiciones comerciales e historial.", singular: "cliente", search: "Código, razón social o RFC…" },
  suppliers: { eyebrow: "COMPRAS", title: "Proveedores", description: "RFC, condiciones y vínculo fiscal con facturas.", singular: "proveedor", search: "RFC, razón social o contacto…" },
} as const;

function money(value: string | number, currency = "USD") { return new Intl.NumberFormat("es-MX", { style: "currency", currency }).format(Number(value)); }

export function CatalogWorkspace({ kind, canEdit = false, canArchive = false, canDelete = false }: { kind: WorkspaceKind; canEdit?: boolean; canArchive?: boolean; canDelete?: boolean }) {
  const [records, setRecords] = useState<(Product | Party)[]>([]);
  const [query, setQuery] = useState("");
  const [archivedView, setArchivedView] = useState(false);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Party | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Party | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const text = copy[kind];
  const endpoint = kind === "products" ? "/api/products" : `/api/parties?kind=${kind === "customers" ? "CUSTOMER" : "SUPPLIER"}&status=${archivedView ? "ARCHIVED" : "ACTIVE"}`;

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const response = await fetch(endpoint);
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? "No fue posible cargar los registros.");
      setRecords(result);
      setError("");
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "No fue posible cargar los registros.");
    } finally { setLoading(false); }
  }, [endpoint]);

  useEffect(() => { void load(); }, [load]);

  const filtered = useMemo(() => records.filter(record => {
    const needle = query.trim().toLocaleLowerCase("es-MX");
    if (!needle) return true;
    if (kind === "customers") {
      const party = record as Party;
      return [party.customerCode, party.legalName, party.taxId].some(value => value?.toLocaleLowerCase("es-MX").includes(needle));
    }
    return JSON.stringify(record).toLocaleLowerCase("es-MX").includes(needle);
  }), [records, query, kind]);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setSaving(true); setError("");
    const form = new FormData(event.currentTarget);
    const body = kind === "products" ? {
      technicalCode: form.get("technicalCode"), description: form.get("description"), fiscalDescription: form.get("fiscalDescription") || undefined,
      unit: form.get("unit") || "PZA", baseCost: form.get("baseCost") || 0, salePrice: form.get("salePrice") || 0, leadTimeDays: form.get("leadTimeDays") || undefined,
    } : kind === "customers" ? {
      kind: "CUSTOMER", taxId: form.get("taxId") || undefined, legalName: form.get("legalName"), tradeName: form.get("tradeName") || undefined,
      email: form.get("email") || undefined, phone: form.get("phone") || undefined, contactName: form.get("contactName") || undefined,
      postalCode: form.get("postalCode") || undefined, city: form.get("city") || undefined, state: form.get("state") || undefined,
      commercialTerms: form.get("commercialTerms") || undefined, country: editing?.country || "México",
    } : {
      kind: "SUPPLIER", taxId: form.get("taxId") || undefined, legalName: form.get("legalName"), tradeName: form.get("tradeName") || undefined,
      email: form.get("email") || undefined, phone: form.get("phone") || undefined, contactName: form.get("contactName") || undefined,
      address: form.get("address") || undefined, city: form.get("city") || undefined, state: form.get("state") || undefined, postalCode: form.get("postalCode") || undefined, commercialTerms: form.get("commercialTerms") || undefined, country: form.get("country") || "México", currency: form.get("currency") || "USD",
    };
    try {
      const response = await fetch(kind === "products" ? "/api/products" : editing ? `/api/parties/${editing.id}` : "/api/parties", {
        method: editing ? "PATCH" : "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? "No fue posible guardar.");
      setOpen(false); setEditing(null); setNotice(editing ? "Los datos del cliente se actualizaron." : kind === "customers" ? `Cliente ${result.customerCode} creado correctamente.` : "Registro creado correctamente.");
      await load();
    } catch (cause) { setError(cause instanceof Error ? cause.message : "No fue posible guardar."); }
    finally { setSaving(false); }
  }

  async function changeStatus(party: Party, status: "ACTIVE" | "ARCHIVED") {
    setError("");
    try {
      const response = await fetch(`/api/parties/${party.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status }) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? "No fue posible actualizar el estado.");
      setNotice(status === "ARCHIVED" ? "Registro archivado; su historial se conserva." : "Registro restaurado y activo.");
      await load();
    } catch (cause) { setError(cause instanceof Error ? cause.message : "No fue posible actualizar el estado."); }
  }

  async function permanentlyDelete() {
    if (!deleteTarget) return;
    setSaving(true); setError("");
    try {
      const response = await fetch(`/api/parties/${deleteTarget.id}`, { method: "DELETE" });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? "No fue posible eliminar el cliente.");
      setDeleteTarget(null); setNotice("El cliente se eliminó permanentemente."); await load();
    } catch (cause) { setError(cause instanceof Error ? cause.message : "No fue posible eliminar el cliente."); }
    finally { setSaving(false); }
  }

  function startNew() { setEditing(null); setError(""); setNotice(""); setOpen(true); }
  function startEdit(party: Party) { setEditing(party); setError(""); setNotice(""); setOpen(true); }

  return <section className="content">
    <div className="title-row"><div><span className="module-eyebrow">{text.eyebrow}</span><h1>{text.title}</h1><p>{text.description}</p></div><button className="primary page-action" onClick={startNew}><Plus size={17}/>{kind === "customers" ? "Nuevo cliente" : `Registrar ${text.singular}`}</button></div>
    <div className={`module-tools ${kind === "customers" ? "customers-toolbar" : ""}`}>
      <label className="local-search"><Search size={16}/><input aria-label={`Buscar ${text.title}`} value={query} onChange={event => setQuery(event.target.value)} placeholder={text.search}/></label>
      {(kind === "customers" || kind === "suppliers") && <div className="module-tabs customer-tabs" role="tablist" aria-label={`Estado de ${kind === "customers" ? "clientes" : "proveedores"}`}>
        <button type="button" role="tab" aria-selected={!archivedView} className={!archivedView ? "selected" : ""} onClick={() => { setArchivedView(false); setNotice(""); }}>Activos</button>
        <button type="button" role="tab" aria-selected={archivedView} className={archivedView ? "selected" : ""} onClick={() => { setArchivedView(true); setNotice(""); }}>Archivados</button>
      </div>}
    </div>
    {error && !open && !deleteTarget && <div className="error" role="alert">{error}</div>}{notice && <div className="success-notice" role="status"><Check size={16}/>{notice}</div>}
    <section className="panel"><div className="panel-head"><h2>{loading ? "Cargando…" : `${filtered.length} ${filtered.length === 1 ? "resultado" : "resultados"}`}</h2><span className="record-count">{kind === "customers" ? archivedView ? "Clientes archivados" : "Clientes activos" : kind === "suppliers" ? archivedView ? "Proveedores archivados" : "Proveedores activos" : "Inicio independiente octubre 2026"}</span></div>
      {loading ? <div className="empty"><LoaderCircle className="spin"/> Cargando catálogo…</div> : kind === "products" ? <ProductTable rows={filtered as Product[]}/> : kind === "customers" ? <CustomerTable rows={filtered as Party[]} canEdit={canEdit} canArchive={canArchive} canDelete={canDelete} archivedView={archivedView} onEdit={startEdit} onStatus={changeStatus} onDelete={setDeleteTarget}/> : <PartyTable rows={filtered as Party[]} canEdit={canEdit} canArchive={canArchive} canDelete={canDelete} archivedView={archivedView} onEdit={startEdit} onStatus={changeStatus} onDelete={setDeleteTarget}/>}
    </section>
    {open && <div className="dialog-backdrop" role="presentation" onMouseDown={() => { setOpen(false); setEditing(null); }}><form className="dialog customer-dialog" onSubmit={submit} onMouseDown={event => event.stopPropagation()}>
      <header><div><span className="module-eyebrow">{editing ? "ACTUALIZAR INFORMACIÓN" : "NUEVO REGISTRO"}</span><h2>{editing ? "Editar cliente" : kind === "customers" ? "Registrar cliente" : `Registrar ${text.singular}`}</h2></div><button type="button" className="icon-button" onClick={() => { setOpen(false); setEditing(null); }} aria-label="Cerrar"><X/></button></header>
      {error && <div className="error" role="alert">{error}</div>}
      {kind === "products" ? <ProductFields/> : kind === "customers" ? <CustomerFields party={editing}/> : <PartyFields party={editing}/>}
      <footer><button type="button" className="secondary" onClick={() => { setOpen(false); setEditing(null); }}>Cancelar</button><button className="primary" disabled={saving}>{saving ? "Guardando…" : editing ? "Guardar cambios" : `Guardar ${text.singular}`}</button></footer>
    </form></div>}
    {deleteTarget && <div className="dialog-backdrop" role="presentation" onMouseDown={() => !saving && setDeleteTarget(null)}><section className="dialog delete-dialog" role="alertdialog" aria-modal="true" aria-labelledby="delete-title" onMouseDown={event => event.stopPropagation()}>
      <header><div><span className="module-eyebrow">ACCIÓN PERMANENTE</span><h2 id="delete-title">Eliminar cliente</h2></div><button type="button" className="icon-button" onClick={() => setDeleteTarget(null)} aria-label="Cerrar"><X/></button></header>
      <p>¿Eliminar permanentemente a <strong>{deleteTarget.legalName}</strong>? Esta acción no se puede deshacer. Si existen documentos vinculados, el sistema impedirá la eliminación para conservar el historial.</p>{error && <div className="error" role="alert">{error}</div>}
      <footer><button type="button" className="secondary" onClick={() => { setDeleteTarget(null); setError(""); }}>Cancelar</button><button type="button" className="danger-button" disabled={saving} onClick={() => void permanentlyDelete()}><Trash2 size={16}/>{saving ? "Eliminando…" : "Eliminar permanentemente"}</button></footer>
    </section></div>}
  </section>;
}

function ProductTable({ rows }: { rows: Product[] }) { return <div className="table-wrap"><table className="table catalog-table"><thead><tr><th>Código técnico</th><th>Producto</th><th>Marca / categoría</th><th>Proveedor principal</th><th>Existencia</th><th>En pedido</th><th>Estado</th><th>Costo</th><th>Precio</th><th>Acciones</th></tr></thead><tbody>{rows.length ? rows.map(product => <tr key={product.id}><td><b>{product.technicalCode}</b><small>Ref. interna: TP-{String(product.internalReference).padStart(5, "0")}</small></td><td>{product.description}</td><td>{product.brand?.name ?? "—"}<small>{product.category?.name ?? "Sin categoría"}</small></td><td>{product.mainSupplier?.legalName ?? "—"}</td><td>{Number(product.stock)}</td><td>{Number(product.onOrder)}</td><td><span className="status paid">{product.status === "ACTIVE" ? "Activo" : "Archivado"}</span></td><td>{money(product.baseCost)}</td><td>{money(product.salePrice)}</td><td>—</td></tr>) : <tr><td colSpan={10} className="empty">Aún no hay productos. Registra el primero para comenzar.</td></tr>}</tbody></table></div>; }

function CustomerTable({ rows, canEdit, canArchive, canDelete, archivedView, onEdit, onStatus, onDelete }: { rows: Party[]; canEdit: boolean; canArchive: boolean; canDelete: boolean; archivedView: boolean; onEdit: (party: Party) => void; onStatus: (party: Party, status: "ACTIVE" | "ARCHIVED") => void; onDelete: (party: Party) => void }) {
  return <div className="table-wrap customer-table-wrap"><table className="table customer-table"><thead><tr><th>Código</th><th>Cliente <span>(Razón social)</span></th><th>RFC</th><th>Contacto</th><th>Estado</th><th>Acciones</th></tr></thead><tbody>{rows.length ? rows.map(party => <tr key={party.id}>
    <td><span className="customer-code-value">{party.customerCode ?? "—"}</span></td><td><b>{party.legalName}</b>{party.tradeName && <small>{party.tradeName}</small>}</td><td>{party.taxId || "—"}</td><td>{party.contactName && <b>{party.contactName}</b>}{party.email && <small>{party.email}</small>}{party.phone && <small>{party.phone}</small>}{!party.contactName && !party.email && !party.phone && "—"}</td>
    <td><span className={`status ${party.status === "ACTIVE" ? "paid" : "archived-status"}`}>{party.status === "ACTIVE" ? "Activo" : "Inactivo"}</span></td>
    <td><div className="customer-actions">{canEdit && <button type="button" className="customer-action" onClick={() => onEdit(party)} aria-label={`Editar ${party.legalName}`} title="Editar cliente"><Pencil size={15}/><span>Editar</span></button>}{canArchive && <button type="button" className="customer-action" onClick={() => void onStatus(party, archivedView ? "ACTIVE" : "ARCHIVED")} aria-label={archivedView ? `Restaurar ${party.legalName}` : `Archivar ${party.legalName}`} title={archivedView ? "Restaurar cliente" : "Archivar cliente"}><Archive size={15}/><span>{archivedView ? "Restaurar" : "Archivar"}</span></button>}{canDelete && <button type="button" className="customer-action customer-action--danger" onClick={() => onDelete(party)} aria-label={`Eliminar permanentemente ${party.legalName}`} title="Eliminar permanentemente"><Trash2 size={15}/><span>Eliminar</span></button>}{!canEdit && !canArchive && !canDelete && <span aria-label="Sin acciones disponibles">—</span>}</div></td>
  </tr>) : <tr><td colSpan={6} className="empty">{archivedView ? "No hay clientes archivados." : "Aún no hay clientes. Registra el primero para comenzar."}</td></tr>}</tbody></table></div>;
}

function PartyTable({ rows, canEdit, canArchive, canDelete, archivedView, onEdit, onStatus, onDelete }: { rows: Party[]; canEdit:boolean; canArchive:boolean; canDelete:boolean; archivedView:boolean; onEdit:(party:Party)=>void; onStatus:(party:Party,status:"ACTIVE"|"ARCHIVED")=>void; onDelete:(party:Party)=>void }) { return <div className="table-wrap customer-table-wrap"><table className="table supplier-table"><thead><tr><th>Código</th><th>Proveedor</th><th>País / moneda</th><th>Productos</th><th>Estado</th><th>Acciones</th></tr></thead><tbody>{rows.length ? rows.map(party => <tr key={party.id}><td><b>{party.taxId ?? "—"}</b></td><td><b>{party.tradeName || party.legalName}</b><small>{party.email || "Sin correo"} · {party.phone || "Sin teléfono"}</small></td><td>{party.country || "México"}<small>{party.currency||"MXN"}</small></td><td>{party._count?.supplierProducts??0}</td><td><span className={`status ${party.status === "ACTIVE" ? "paid" : "archived-status"}`}>{party.status === "ACTIVE" ? "Activo" : "Archivado"}</span></td><td><div className="customer-actions">{canEdit&&<button type="button" className="customer-action" onClick={()=>onEdit(party)}><Pencil size={15}/><span>Editar</span></button>}{canArchive&&<button type="button" className="customer-action" onClick={()=>void onStatus(party,archivedView?"ACTIVE":"ARCHIVED")}><Archive size={15}/><span>{archivedView?"Restaurar":"Archivar"}</span></button>}{canDelete&&<button type="button" className="customer-action customer-action--danger" onClick={()=>onDelete(party)}><Trash2 size={15}/><span>Eliminar</span></button>}{!canEdit&&!canArchive&&!canDelete&&"—"}</div></td></tr>) : <tr><td colSpan={6} className="empty">{archivedView?"No hay proveedores archivados.":"Aún no hay proveedores. Registra el primero para comenzar."}</td></tr>}</tbody></table></div>; }

function ProductFields() { return <div className="form-grid"><div className="field"><label>Código técnico *</label><input name="technicalCode" required/></div><div className="field"><label>Unidad</label><input name="unit" defaultValue="PZA"/></div><div className="field form-span"><label>Descripción general *</label><textarea name="description" required rows={3}/></div><div className="field form-span"><label>Descripción fiscal</label><textarea name="fiscalDescription" rows={2}/></div><div className="field"><label>Costo base</label><input name="baseCost" type="number" min="0" step="0.01" defaultValue="0"/></div><div className="field"><label>Precio de venta</label><input name="salePrice" type="number" min="0" step="0.01" defaultValue="0"/></div><div className="field"><label>Lead time (días)</label><input name="leadTimeDays" type="number" min="0"/></div></div>; }

function CustomerFields({ party }: { party: Party | null }) { return <div className="form-grid customer-form-grid">
  <div className="form-section-title">Información general</div>
  <div className="field"><label htmlFor="customer-code">Código de cliente</label><input id="customer-code" value={party?.customerCode ?? "Asignado automáticamente al guardar"} readOnly aria-readonly="true"/></div>
  <div className="field"><label htmlFor="customer-legal-name">Razón social *</label><input id="customer-legal-name" name="legalName" required maxLength={180} defaultValue={party?.legalName ?? ""}/></div>
  <div className="field"><label htmlFor="customer-trade-name">Nombre comercial</label><input id="customer-trade-name" name="tradeName" maxLength={180} defaultValue={party?.tradeName ?? ""}/></div>
  <div className="field"><label htmlFor="customer-tax-id">RFC</label><input id="customer-tax-id" name="taxId" maxLength={13} autoCapitalize="characters" placeholder="12 o 13 caracteres" defaultValue={party?.taxId ?? ""}/></div>
  <div className="form-section-title">Información de contacto</div>
  <div className="field"><label htmlFor="customer-contact">Nombre de contacto</label><input id="customer-contact" name="contactName" maxLength={120} defaultValue={party?.contactName ?? ""}/></div>
  <div className="field"><label htmlFor="customer-email">Correo electrónico</label><input id="customer-email" name="email" type="email" autoComplete="email" maxLength={254} defaultValue={party?.email ?? ""}/></div>
  <div className="field"><label htmlFor="customer-phone">Teléfono</label><input id="customer-phone" name="phone" type="tel" inputMode="tel" maxLength={30} defaultValue={party?.phone ?? ""}/></div>
  <div className="form-section-title">Dirección</div>
  <div className="field"><label htmlFor="customer-postal">Código postal</label><input id="customer-postal" name="postalCode" inputMode="numeric" maxLength={5} pattern="\d{5}" title="Ingresa 5 dígitos" defaultValue={party?.postalCode ?? ""}/></div>
  <div className="field"><label htmlFor="customer-city">Ciudad</label><input id="customer-city" name="city" maxLength={100} defaultValue={party?.city ?? ""}/></div>
  <div className="field"><label htmlFor="customer-state">Estado</label><input id="customer-state" name="state" maxLength={100} defaultValue={party?.state ?? ""}/></div>
  <div className="form-section-title">Información comercial</div>
  <div className="field form-span"><label htmlFor="customer-terms">Condiciones de pago</label><textarea id="customer-terms" name="commercialTerms" rows={3} maxLength={1000} placeholder="Ej. Crédito a 30 días" defaultValue={party?.commercialTerms ?? ""}/></div>
</div>; }

function PartyFields({party}:{party:Party|null}) { return <div className="form-grid"><div className="field"><label>RFC</label><input name="taxId" maxLength={13} defaultValue={party?.taxId||""}/></div><div className="field"><label>Nombre comercial</label><input name="tradeName" defaultValue={party?.tradeName||""}/></div><div className="field form-span"><label>Razón social *</label><input name="legalName" required defaultValue={party?.legalName||""}/></div><div className="field"><label>Contacto</label><input name="contactName" defaultValue={party?.contactName||""}/></div><div className="field"><label>Teléfono</label><input name="phone" inputMode="tel" defaultValue={party?.phone||""}/></div><div className="field form-span"><label>Correo</label><input name="email" type="email" defaultValue={party?.email||""}/></div><div className="form-section-title">Dirección y condiciones</div><div className="field form-span"><label>Domicilio</label><input name="address" defaultValue={party?.address||""}/></div><div className="field"><label>Ciudad</label><input name="city" defaultValue={party?.city||""}/></div><div className="field"><label>Estado</label><input name="state" defaultValue={party?.state||""}/></div><div className="field"><label>Código postal</label><input name="postalCode" inputMode="numeric" maxLength={5} defaultValue={party?.postalCode||""}/></div><div className="field"><label>País</label><input name="country" defaultValue={party?.country||"México"}/></div><div className="field"><label>Moneda de proveedor</label><select name="currency" defaultValue={party?.currency||"USD"}><option>USD</option><option>MXN</option><option>EUR</option></select></div><div className="field form-span"><label>Condiciones comerciales</label><textarea name="commercialTerms" rows={2} defaultValue={party?.commercialTerms||""}/></div></div>; }
