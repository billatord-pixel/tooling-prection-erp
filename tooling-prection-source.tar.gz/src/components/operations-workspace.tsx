"use client";

import { FormEvent, useEffect, useMemo, useState, type ReactNode } from "react";
import { CheckCircle2, ClipboardList, LoaderCircle, Package, Plus, Truck, Wrench, X } from "lucide-react";
import "./catalog-workspace.css";
import "./operations-workspace.css";

type Product = { id: string; technicalCode: string; description: string; stock: string | number; onOrder: string | number; inventoryMovements?: Movement[] };
type Party = { id: string; legalName: string; taxId?: string | null };
type Line = { id: string; description: string; quantity: string | number; unitPrice: string | number; receivedQuantity?: string | number; product: Product };
type PurchaseOrder = { id: string; folio: string; issueDate: string; expectedDate?: string | null; status: string; total: string | number; supplier: Party; lines: Line[] };
type Delivery = { id: string; folio: string; issueDate: string; total: string | number; processedAt?: string | null; customer?: Party | null; lines: Line[] };
type Movement = { id: string; type: string; quantity: string | number; balanceAfter: string | number; notes?: string | null; createdAt: string };
type Kind = "purchase-orders" | "deliveries" | "inventory";

const numeric = (value: string | number) => Number(value);
const money = (value: string | number) => new Intl.NumberFormat("es-MX", { style: "currency", currency: "MXN" }).format(numeric(value));
const date = (value: string) => new Intl.DateTimeFormat("es-MX", { dateStyle: "medium" }).format(new Date(value));

export function OperationsWorkspace({ kind }: { kind: Kind }) {
  const [products, setProducts] = useState<Product[]>([]); const [parties, setParties] = useState<Party[]>([]); const [records, setRecords] = useState<(PurchaseOrder | Delivery)[]>([]); const [open, setOpen] = useState(false); const [loading, setLoading] = useState(true); const [saving, setSaving] = useState(false); const [error, setError] = useState(""); const [notice, setNotice] = useState("");
  const config = kind === "purchase-orders" ? { eyebrow: "COMPRAS", title: "Pedidos de compra", description: "Solicitudes, partidas y recepción controlada mediante factura de compra.", action: "Nuevo pedido", endpoint: "/api/purchase-orders", party: "SUPPLIER" } : kind === "deliveries" ? { eyebrow: "COMERCIAL", title: "Remisiones", description: "Entregas controladas que descuentan existencia sólo al confirmarse.", action: "Nueva remisión", endpoint: "/api/deliveries", party: "CUSTOMER" } : { eyebrow: "PRODUCTOS", title: "Inventario", description: "Existencias y ajustes con trazabilidad; los documentos fiscales se cargarán a partir de octubre.", action: "Registrar ajuste", endpoint: "/api/inventory", party: "" };
  async function load() { setLoading(true); setError(""); const requests: Promise<Response>[] = [fetch(config.endpoint), fetch("/api/products")]; if (config.party) requests.push(fetch(`/api/parties?kind=${config.party}`)); const answers = await Promise.all(requests); if (!answers.every(answer => answer.ok)) { setError("No fue posible cargar la información operativa."); setLoading(false); return; } const [current, productData, partyData] = await Promise.all(answers.map(answer => answer.json())); if (kind === "inventory") setProducts(current); else { setRecords(current); setProducts(productData); setParties(partyData ?? []); } setLoading(false); }
  useEffect(() => { void load(); }, [kind]);
  async function create(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSaving(true); setError(""); setNotice("");
    const form = new FormData(event.currentTarget);
    let lines: Array<{ productId: string; quantity: string; unitPrice: string; deliveryDays?: string }> = [];
    if (kind !== "inventory") {
      try { lines = JSON.parse(String(form.get("linesJson") || "[]")); }
      catch { setError("Revisa las partidas del documento e inténtalo de nuevo."); setSaving(false); return; }
      if (!lines.length || lines.some(line => !line.productId || Number(line.quantity) <= 0 || Number(line.unitPrice) < 0)) {
        setError("Completa el producto, la cantidad y el precio de cada partida."); setSaving(false); return;
      }
    }
    const body = kind === "inventory"
      ? { productId: form.get("productId"), quantity: form.get("quantity"), notes: form.get("notes") }
      : kind === "purchase-orders"
        ? { supplierId: form.get("partyId"), expectedDate: form.get("expectedDate") || undefined, conditions: form.get("conditions") || undefined, notes: form.get("notes") || undefined, lines: lines.map(line => ({ ...line, deliveryDays: line.deliveryDays || undefined })) }
        : { customerId: form.get("partyId") || undefined, notes: form.get("notes") || undefined, lines };
    try {
      const response = await fetch(config.endpoint, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? "No fue posible guardar el movimiento.");
      event.currentTarget.reset(); setOpen(false);
      setNotice(kind === "inventory" ? "Ajuste registrado con su nota de auditoría." : "Documento creado. Confirma la salida sólo cuando corresponda.");
      await load();
    } catch (cause) { setError(cause instanceof Error ? cause.message : "No fue posible guardar el movimiento."); }
    finally { setSaving(false); }
  }
  async function processDelivery(id: string) { if (!confirm("¿Confirmar la salida de inventario de esta remisión? Esta acción quedará auditada.")) return; setSaving(true); setError(""); const response = await fetch(`/api/deliveries/${id}/process`, { method: "POST" }); const result = await response.json(); setSaving(false); if (!response.ok) { setError(result.error ?? "No fue posible confirmar la salida."); return; } setNotice("Salida confirmada y existencia actualizada."); await load(); }
  const availableProducts = useMemo(() => products.filter(product => kind !== "deliveries" || numeric(product.stock) > 0), [kind, products]);
  return <section className="content"><div className="title-row"><div><span className="module-eyebrow">{config.eyebrow}</span><h1>{config.title}</h1><p>{config.description}</p></div><button className="primary page-action" onClick={() => { setOpen(true); setError(""); }}><Plus size={17}/>{config.action}</button></div>{notice && <div className="success-message"><CheckCircle2/>{notice}</div>}{error && !open && <div className="error">{error}</div>}{loading ? <section className="panel"><div className="empty"><LoaderCircle className="spin"/> Cargando operación…</div></section> : kind === "inventory" ? <InventoryTable rows={products}/> : kind === "purchase-orders" ? <OrdersTable rows={records as PurchaseOrder[]}/> : <DeliveriesTable rows={records as Delivery[]} onProcess={processDelivery} processing={saving}/>} {open && <div className="dialog-backdrop" role="presentation" onMouseDown={() => setOpen(false)}><form className="dialog" onSubmit={create} onMouseDown={event => event.stopPropagation()}><header><div><span className="module-eyebrow">OPERACIÓN NUEVA</span><h2>{config.action}</h2></div><button type="button" className="icon-button" onClick={() => setOpen(false)} aria-label="Cerrar"><X/></button></header>{error && <div className="error">{error}</div>}{kind === "inventory" ? <AdjustmentFields products={products}/> : <DocumentFields kind={kind} products={availableProducts} parties={parties}/>}<footer><button type="button" className="secondary" onClick={() => setOpen(false)}>Cancelar</button><button className="primary" disabled={saving}>{saving ? "Guardando…" : "Guardar"}</button></footer></form></div>}</section>;
}

function OrdersTable({ rows }: { rows: PurchaseOrder[] }) { return <section className="panel"><div className="panel-head"><h2>Pedidos registrados</h2><span className="record-count">{rows.length} resultados</span></div><div className="table-wrap"><table className="table"><thead><tr><th>Folio</th><th>Proveedor</th><th>Partidas</th><th>Recepción esperada</th><th>Total</th><th>Estado</th></tr></thead><tbody>{rows.length ? rows.map(order => <tr key={order.id}><td><b>{order.folio}</b><small>{date(order.issueDate)}</small></td><td>{order.supplier.legalName}<small>{order.supplier.taxId ?? "Sin RFC"}</small></td><td>{order.lines.map(line => <span className="line-summary" key={line.id}>{line.description} · {numeric(line.quantity)} {numeric(line.receivedQuantity ?? 0) ? `(rec. ${numeric(line.receivedQuantity ?? 0)})` : ""}</span>)}</td><td>{order.expectedDate ? date(order.expectedDate) : "Por definir"}</td><td>{money(order.total)}</td><td><span className="status pending">{order.status === "DELIVERED" ? "Recibido" : "Pendiente"}</span></td></tr>) : <Empty colSpan={6} icon={<ClipboardList/>} text="Aún no hay pedidos. Registra el primero cuando exista una compra nueva."/>}</tbody></table></div></section>; }
function DeliveriesTable({ rows, onProcess, processing }: { rows: Delivery[]; onProcess: (id: string) => void; processing: boolean }) { return <section className="panel"><div className="panel-head"><h2>Remisiones registradas</h2><span className="record-count">{rows.length} resultados</span></div><div className="table-wrap"><table className="table"><thead><tr><th>Folio</th><th>Cliente</th><th>Partidas</th><th>Total</th><th>Estado</th><th>Acción</th></tr></thead><tbody>{rows.length ? rows.map(delivery => <tr key={delivery.id}><td><b>{delivery.folio}</b><small>{date(delivery.issueDate)}</small></td><td>{delivery.customer?.legalName ?? "Entrega sin cliente asignado"}</td><td>{delivery.lines.map(line => <span className="line-summary" key={line.id}>{line.description} · {numeric(line.quantity)}</span>)}</td><td>{money(delivery.total)}</td><td><span className={`status ${delivery.processedAt ? "paid" : "pending"}`}>{delivery.processedAt ? "Salida confirmada" : "Pendiente"}</span></td><td>{delivery.processedAt ? "—" : <button className="row-action" disabled={processing} onClick={() => onProcess(delivery.id)}><Truck size={16}/> Confirmar salida</button>}</td></tr>) : <Empty colSpan={6} icon={<Truck/>} text="Aún no hay remisiones. La existencia se descuenta sólo después de confirmarlas."/>}</tbody></table></div></section>; }
function InventoryTable({ rows }: { rows: Product[] }) { return <section className="panel"><div className="panel-head"><h2>Existencias actuales</h2><span className="record-count">{rows.length} productos activos</span></div><div className="table-wrap"><table className="table"><thead><tr><th>Producto</th><th>Existencia</th><th>En pedido</th><th>Último movimiento</th><th>Saldo resultante</th></tr></thead><tbody>{rows.length ? rows.map(product => { const last = product.inventoryMovements?.[0]; return <tr key={product.id}><td><b>{product.technicalCode}</b><small>{product.description}</small></td><td>{numeric(product.stock)}</td><td>{numeric(product.onOrder)}</td><td>{last ? <>{last.type}<small>{date(last.createdAt)} · {numeric(last.quantity) > 0 ? "+" : ""}{numeric(last.quantity)} {last.notes ? `· ${last.notes}` : ""}</small></> : "Sin movimientos"}</td><td>{last ? numeric(last.balanceAfter) : numeric(product.stock)}</td></tr>; }) : <Empty colSpan={5} icon={<Package/>} text="Registra productos para empezar a controlar existencia en octubre."/>}</tbody></table></div></section>; }
function Empty({ colSpan, icon, text }: { colSpan: number; icon: ReactNode; text: string }) { return <tr><td colSpan={colSpan} className="empty">{icon} {text}</td></tr>; }
function DocumentFields({ kind, products, parties }: { kind: "purchase-orders" | "deliveries"; products: Product[]; parties: Party[] }) {
  const purchase = kind === "purchase-orders";
  const [lines, setLines] = useState([{ key: crypto.randomUUID(), productId: "", quantity: "", unitPrice: "", deliveryDays: "" }]);
  const updateLine = (key: string, values: Partial<(typeof lines)[number]>) => setLines(current => current.map(line => line.key === key ? { ...line, ...values } : line));
  const serializedLines = JSON.stringify(lines.map(({ key: _key, ...line }) => line));
  return <div className="form-grid">
    <div className="field form-span"><label>{purchase ? "Proveedor *" : "Cliente (opcional)"}</label><select name="partyId" required={purchase}><option value="">{purchase ? "Selecciona un proveedor" : "Entrega sin cliente asignado"}</option>{parties.map(party => <option value={party.id} key={party.id}>{party.legalName}{party.taxId ? ` · ${party.taxId}` : ""}</option>)}</select></div>
    <section className="form-span operation-lines" aria-label="Partidas del documento">
      <div className="operation-lines-heading"><div><b>Partidas</b><span>Agrega todos los productos incluidos en el documento.</span></div><button type="button" className="secondary" onClick={() => setLines(current => [...current, { key: crypto.randomUUID(), productId: "", quantity: "", unitPrice: "", deliveryDays: "" }])}><Plus size={15}/> Agregar partida</button></div>
      <input type="hidden" name="linesJson" value={serializedLines}/>
      {lines.map((line, index) => <div className="operation-line" key={line.key}>
        <span className="operation-line-number">{index + 1}</span>
        <label className="field operation-line-product"><span>Producto *</span><select required value={line.productId} onChange={event => updateLine(line.key, { productId: event.target.value })}><option value="">Selecciona producto</option>{products.map(product => <option value={product.id} key={product.id}>{product.technicalCode} · {product.description}{!purchase ? ` (existencia: ${numeric(product.stock)})` : ""}</option>)}</select></label>
        <label className="field"><span>Cantidad *</span><input type="number" min="0.001" step="0.001" required value={line.quantity} onChange={event => updateLine(line.key, { quantity: event.target.value })}/></label>
        <label className="field"><span>Precio unitario *</span><input type="number" min="0" step="0.01" required value={line.unitPrice} onChange={event => updateLine(line.key, { unitPrice: event.target.value })}/></label>
        {purchase && <label className="field"><span>Entrega (días)</span><input type="number" min="0" step="1" value={line.deliveryDays} onChange={event => updateLine(line.key, { deliveryDays: event.target.value })}/></label>}
        <button type="button" className="icon-button operation-line-remove" aria-label={`Quitar partida ${index + 1}`} disabled={lines.length === 1} onClick={() => setLines(current => current.filter(item => item.key !== line.key))}><X size={17}/></button>
      </div>)}
      {!products.length && <small className="field-hint">Primero registra un producto{purchase ? " y un proveedor" : ""}.</small>}
    </section>
    {purchase && <><div className="field"><label>Fecha esperada</label><input name="expectedDate" type="date"/></div><div className="field form-span"><label>Condiciones</label><input name="conditions" placeholder="Pago, envío u otras condiciones"/></div></>}
    <div className="field form-span"><label>Notas</label><textarea name="notes" rows={3} placeholder={purchase ? "Indicaciones de compra" : "Referencia de entrega"}/></div>
  </div>;
}
function AdjustmentFields({ products }: { products: Product[] }) { return <div className="form-grid"><div className="field form-span"><label>Producto *</label><select name="productId" required><option value="">Selecciona un producto</option>{products.map(product => <option value={product.id} key={product.id}>{product.technicalCode} · {product.description} (existencia: {numeric(product.stock)})</option>)}</select></div><div className="field"><label>Ajuste (+ / -) *</label><input name="quantity" type="number" step="0.001" required placeholder="Ej. 2 o -1"/></div><div className="field form-span"><label>Motivo / nota de auditoría *</label><textarea name="notes" minLength={3} required rows={3} placeholder="Explica el motivo del ajuste."/></div><div className="field-hint form-span"><Wrench size={15}/> Un ajuste negativo no puede dejar el inventario en negativo.</div></div>; }
