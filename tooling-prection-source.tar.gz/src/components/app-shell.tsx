"use client";

import Image from "next/image";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useRef, useState, type FormEvent } from "react";
import { ArchiveRestore, BadgeCheck, Boxes, ChevronDown, ClipboardCheck, FileBarChart, FileText, LayoutDashboard, LogOut, Menu, Package, Search, Settings, ShieldCheck, Tags, Truck, Upload, Users, X } from "lucide-react";
import "./app-shell.css";

const shortcuts = [["Inicio", "/dashboard", LayoutDashboard], ["Búsqueda", "/buscar", Search], ["Reportes", "/reportes", FileBarChart]] as const;
const groups = [
  { label: "Comercial", items: [["Clientes", "/clientes", Users], ["Cotizaciones", "/cotizaciones", FileText], ["Órdenes de clientes", "/ordenes-clientes", ClipboardCheck], ["Facturas de venta", "/facturas-venta", FileText], ["Remisiones", "/remisiones", Truck]] },
  { label: "Productos", items: [["Productos", "/productos", Package], ["Categorías", "/categorias", Tags], ["Marcas", "/marcas", BadgeCheck], ["Revisión técnica", "/revision-tecnica", ClipboardCheck], ["Inventario", "/inventario", Boxes], ["Conciliación", "/conciliacion", ArchiveRestore]] },
  { label: "Compras", items: [["Proveedores", "/proveedores", Users], ["Pedidos de compra", "/pedidos-compra", FileText], ["Facturas de compra", "/facturas-compra", FileText]] },
  { label: "Administración", items: [["Revisión de inventario", "/revision-inventario", ClipboardCheck], ["Empleados y usuarios", "/empleados", Users], ["Configuración", "/configuracion", Settings], ["Importaciones", "/importaciones", Upload], ["Auditoría", "/auditoria", ShieldCheck], ["Respaldos", "/respaldos", ArchiveRestore]] },
] as const;
const mainLinks = [
  { label: "Inicio", href: "/dashboard", paths: ["/dashboard"] },
  { label: "Cotizaciones", href: "/cotizaciones", paths: ["/cotizaciones"] },
  { label: "Ventas", href: "/facturas-venta", paths: ["/facturas-venta", "/clientes", "/ordenes-clientes", "/remisiones"] },
  { label: "Compras", href: "/facturas-compra", paths: groups[2].items.map(([, href]) => href) },
  { label: "Productos", href: "/productos", paths: groups[1].items.map(([, href]) => href) },
];

export function AppShell({ user, children }: { user: { name: string; email: string; role: string }; children: React.ReactNode }) {
  const [globalQuery, setGlobalQuery] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);
  const menu = useRef<HTMLDialogElement>(null);
  const searchInput = useRef<HTMLInputElement>(null);
  const searchButton = useRef<HTMLButtonElement>(null);
  const pathname = usePathname();
  const router = useRouter();
  const isAdmin = user.role === "ADMIN";
  const visibleGroups = groups.filter(group => isAdmin || group.label !== "Administración");
  const isCurrent = (href: string) => pathname === href || pathname.startsWith(href + "/");
  const initials = user.name.trim().split(/\s+/).slice(0, 2).map(part => part[0]).join("").toUpperCase() || "TP";

  useEffect(() => {
    if (searchOpen) searchInput.current?.focus();
  }, [searchOpen]);

  function submitSearch(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const query = globalQuery.trim();
    if (query.length < 2) return;
    setSearchOpen(false);
    router.push(`/buscar?q=${encodeURIComponent(query)}`);
  }

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.replace("/login");
    router.refresh();
  }

  const links = (items: readonly (readonly [string, string, typeof LayoutDashboard])[]) => items.map(([name, href, Icon]) =>
    <Link className="module-menu-link" aria-current={isCurrent(href) ? "page" : undefined} href={href} key={href} onClick={() => menu.current?.close()}>
      <Icon size={17} aria-hidden="true"/>{name}
    </Link>,
  );

  return <div className="shell" data-role={user.role}>
    <div className="shell-frame">
      <header className="topbar">
        <Link className="shell-brand" href="/dashboard" aria-label="Inicio de Tooling Prection">
          <span className="shell-brand-mark"><Image src="/brand/tooling-prection-logo.jpg" alt="" width={54} height={54}/></span>
          <span><strong>Tooling Prection</strong><small>ERP OPERATIVO</small></span>
        </Link>
        <nav className="shell-nav" aria-label="Navegación principal">
          {mainLinks.map(({ label, href, paths }) => <Link href={href} key={href} className={paths.some(isCurrent) ? "selected" : undefined} aria-current={isCurrent(href) ? "page" : undefined}>{label}</Link>)}
          <button type="button" onClick={() => menu.current?.showModal()} aria-haspopup="dialog" aria-controls="erp-modules">Más módulos <ChevronDown size={16} aria-hidden="true"/></button>
        </nav>
        <form id="erp-search" className={`global-search ${searchOpen ? "is-open" : ""}`} role="search" onSubmit={submitSearch} onKeyDown={event => {
          if (event.key === "Escape" && searchOpen) {
            setSearchOpen(false);
            searchButton.current?.focus();
          }
        }}>
          <input ref={searchInput} type="search" aria-label="Buscar en todo el sistema" placeholder="Buscar en el ERP…" value={globalQuery} onChange={event => setGlobalQuery(event.target.value)} minLength={2} required/>
          <button type="submit" aria-label="Buscar"><Search size={17}/></button>
        </form>
        <div className="shell-tools">
          <button type="button" className="shell-icon search-toggle" ref={searchButton} aria-label={searchOpen ? "Cerrar búsqueda" : "Abrir búsqueda"} aria-expanded={searchOpen} aria-controls="erp-search" onClick={() => setSearchOpen(open => !open)}>
            {searchOpen ? <X size={18}/> : <Search size={18}/>}
          </button>
          <button type="button" className="shell-icon shell-menu-toggle" onClick={() => menu.current?.showModal()} aria-label="Abrir módulos" aria-haspopup="dialog" aria-controls="erp-modules"><Menu size={19}/></button>
          <details className="shell-account">
            <summary className="shell-icon" aria-label="Mi cuenta">{initials}</summary>
            <div className="shell-account-panel">
              <strong>{user.name}</strong>
              <span>{isAdmin ? "Administrador" : "Vendedor"}</span>
              <button type="button" className="logout" onClick={logout}><LogOut size={15}/> Salir</button>
            </div>
          </details>
        </div>
      </header>
      <main className="main">{children}</main>
    </div>
    <dialog ref={menu} id="erp-modules" className="module-menu" aria-labelledby="erp-modules-title" onClick={event => {
      if (event.target === event.currentTarget) menu.current?.close();
    }}>
      <div className="module-menu-surface">
        <div className="module-menu-head"><h2 id="erp-modules-title">Módulos de Tooling Prection</h2><button type="button" className="shell-icon" aria-label="Cerrar módulos" onClick={() => menu.current?.close()}><X size={18}/></button></div>
        <nav aria-label="Todos los módulos">
          <div className="module-menu-shortcuts">{links(shortcuts)}</div>
          <div className="module-menu-grid">{visibleGroups.map(group => <section key={group.label}><h3>{group.label}</h3>{links(group.items)}</section>)}</div>
        </nav>
      </div>
    </dialog>
  </div>;
}
