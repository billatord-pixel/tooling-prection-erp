"use client";

import Image from "next/image";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState } from "react";
import { ArchiveRestore, BadgeCheck, Boxes, ClipboardCheck, FileBarChart, FileText, LayoutDashboard, Menu, Package, Search, Settings, ShieldCheck, Tags, Truck, Upload, Users, X } from "lucide-react";
import "./app-shell.css";

const shortcuts = [["Dashboard", "/dashboard", LayoutDashboard], ["Búsqueda", "/buscar", Search], ["Reportes", "/reportes", FileBarChart]] as const;
const groups = [
  { label: "COMERCIAL", items: [["Clientes", "/clientes", Users], ["Cotizaciones", "/cotizaciones", FileText], ["Facturas de venta", "/facturas-venta", FileText], ["Remisiones", "/remisiones", Truck]] },
  { label: "PRODUCTOS", items: [["Productos", "/productos", Package], ["Categorías", "/categorias", Tags], ["Marcas", "/marcas", BadgeCheck], ["Revisión técnica", "/revision-tecnica", ClipboardCheck], ["Inventario", "/inventario", Boxes], ["Conciliación", "/conciliacion", ArchiveRestore]] },
  { label: "COMPRAS", items: [["Proveedores", "/proveedores", Users], ["Pedidos", "/pedidos-compra", FileText], ["Facturas", "/facturas-compra", FileText]] },
  { label: "ADMINISTRACIÓN", items: [["Empleados", "/empleados", Users], ["Usuarios", "/usuarios", Users], ["Configuración", "/configuracion", Settings], ["Importaciones", "/importaciones", Upload], ["Auditoría", "/auditoria", ShieldCheck], ["Respaldos", "/respaldos", ArchiveRestore]] },
] as const;

export function AppShell({ user, children }: { user: { name: string; email: string; role: string }; children: React.ReactNode }) {
  const [open, setOpen] = useState(false); const pathname = usePathname(); const router = useRouter();
  async function logout() { await fetch("/api/auth/logout", { method: "POST" }); router.replace("/login"); router.refresh(); }
  const links = (items: readonly (readonly [string, string, typeof LayoutDashboard])[]) => items.map(([name, href, Icon]) => <Link className={`nav-item ${pathname === href ? "active" : ""}`} href={href} key={href} onClick={() => setOpen(false)}><Icon size={18}/>{name}</Link>);
  const nav = <aside className={`sidebar ${open ? "open" : ""}`}><div className="brand"><Image src="/brand/tooling-prection-logo.jpg" alt="Logotipo oficial Tooling Prection" width={52} height={52}/><div><strong>Tooling Prection</strong><span>OPERACIONES</span></div><button className="menu-button" onClick={() => setOpen(false)} aria-label="Cerrar menú"><X/></button></div><nav>{links(shortcuts)}{groups.map(group => <section key={group.label}><div className="nav-label">{group.label}</div>{links(group.items)}</section>)}</nav></aside>;
  return <div className="shell">{nav}<div className={`overlay ${open ? "show" : ""}`} onClick={() => setOpen(false)}/><main className="main"><header className="topbar"><button className="menu-button" onClick={() => setOpen(true)} aria-label="Abrir menú"><Menu/></button><label className="global-search"><Search size={17}/><input aria-label="Buscar en todo el sistema" placeholder="Buscar en todo el sistema…" /></label><div className="user"><div><b>{user.name}</b><span>{user.role}</span></div><button onClick={logout} className="logout">Salir</button></div></header>{children}</main></div>;
}
