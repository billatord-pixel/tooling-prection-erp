"use client";
import { useState } from "react";
import { FileText } from "lucide-react";
import "./reports-workspace.css";
export function OperationalReportsWorkspace() {
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [currency, setCurrency] = useState("USD");
  const invalid = !!from && !!to && from > to;
  const filters = new URLSearchParams({ currency });
  if (from) filters.set("from", from);
  if (to) filters.set("to", to);
  return <section className="content"><div className="title-row"><div><span className="module-eyebrow">CONSULTA Y DOCUMENTOS</span><h1>Reportes operativos PDF</h1><p>Consulta e imprime reportes de ventas y compras. El reporte general es exclusivo del administrador.</p></div></div><section className="panel" style={{ padding: "20px" }}><div className="report-filters"><label>Desde<input type="date" value={from} onChange={event => setFrom(event.target.value)}/></label><label>Hasta<input type="date" value={to} onChange={event => setTo(event.target.value)}/></label><label>Moneda<select value={currency} onChange={event => setCurrency(event.target.value)}><option>USD</option><option>MXN</option></select></label></div>{invalid ? <p role="alert">La fecha inicial no puede ser posterior a la fecha final.</p> : <div className="report-export"><a className="secondary report-download" href={`/api/reports/invoices/sales?${filters}`} target="_blank" rel="noreferrer"><FileText size={16}/> Reporte de ventas PDF</a><a className="secondary report-download" href={`/api/reports/invoices/purchases?${filters}`} target="_blank" rel="noreferrer"><FileText size={16}/> Reporte de compras PDF</a></div>}</section></section>;
}
