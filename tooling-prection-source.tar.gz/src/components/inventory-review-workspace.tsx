"use client";

import Link from "next/link";
import { useEffect, useState, type FormEvent } from "react";
import "./inventory-review-workspace.css";

type ReviewItem = {
  id: string;
  sourceBatch: string;
  sourcePage: number;
  sourceLine: number;
  originalName: string;
  reportedStock: string;
  reason: string;
  suggestedCode: string | null;
  suggestedDescription: string | null;
  resolvedCode: string | null;
  resolvedDescription: string | null;
  resolvedAt: string | null;
  productId: string | null;
};

const reasons: Record<string, string> = {
  codigo_no_explicito_o_ambiguo: "Código por identificar",
  codigo_repetido_descripciones_distintas: "Código repetido con distintas descripciones",
};

export function InventoryReviewWorkspace() {
  const [items, setItems] = useState<ReviewItem[]>([]);
  const [selectedId, setSelectedId] = useState("");
  const [query, setQuery] = useState("");
  const [showResolved, setShowResolved] = useState(false);
  const [code, setCode] = useState("");
  const [description, setDescription] = useState("");
  const [currentCode, setCurrentCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  useEffect(() => {
    const controller = new AbortController();
    fetch("/api/inventory/review", { signal: controller.signal }).then(async response => {
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "No se pudieron cargar las partidas.");
      if (!controller.signal.aborted) setItems(data);
    }).catch(err => {
      if (!controller.signal.aborted) setError(err.message);
    }).finally(() => {
      if (!controller.signal.aborted) setLoading(false);
    });
    return () => controller.abort();
  }, []);

  const pending = items.filter(item => !item.resolvedAt).length;
  const search = query.trim().toLocaleLowerCase("es-MX");
  const visible = items.filter(item => Boolean(item.resolvedAt) === showResolved &&
    [item.originalName, item.resolvedCode, item.suggestedCode, String(item.sourceLine)]
      .some(value => value?.toLocaleLowerCase("es-MX").includes(search)));
  const selected = visible.find(item => item.id === selectedId) || visible[0];
  const selectedIndex = selected ? visible.indexOf(selected) : -1;

  useEffect(() => {
    setCode(selected?.resolvedCode || selected?.suggestedCode || "");
    setDescription(selected?.resolvedDescription || selected?.suggestedDescription || selected?.originalName || "");
    setCurrentCode("");
  }, [selected]);

  async function save(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!selected || selected.resolvedAt || busy) return;
    setBusy(true);
    setError("");
    setNotice("");
    try {
      const response = await fetch("/api/inventory/review", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: selected.id, code, description, currentCode }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "No se pudo guardar la partida.");
      setItems(previous => previous.map(item => item.id === data.id ? data : item));
      setSelectedId(visible[selectedIndex + 1]?.id || "");
      setNotice(`Se guardó la partida ${selected.sourceLine} como ${data.resolvedCode}.`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "No se pudo guardar la partida.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="content inventory-review">
      <div className="title-row">
        <div>
          <Link className="back-link" href="/inventario">Volver a Inventario</Link>
          <span className="module-eyebrow">CATÁLOGO · INVENTARIO FÍSICO</span>
          <h1>Revisión de inventario</h1>
          <p>Define el código y la descripción de cada partida del conteo físico.</p>
        </div>
      </div>
      {error && <p className="error" role="alert">{error}</p>}
      {notice && <p className="inventory-review-notice" role="status">{notice}</p>}
      <div className="inventory-review-grid">
        <section className="panel inventory-review-list">
          <div className="panel-head"><h2>Partidas del conteo</h2></div>
          <div className="inventory-review-controls">
            <div className="module-tabs" aria-label="Estado de las partidas">
              <button type="button" disabled={busy} aria-pressed={!showResolved}
                className={!showResolved ? "selected" : ""} onClick={() => setShowResolved(false)}>
                Pendientes · {pending}
              </button>
              <button type="button" disabled={busy} aria-pressed={showResolved}
                className={showResolved ? "selected" : ""} onClick={() => setShowResolved(true)}>
                Guardadas · {items.length - pending}
              </button>
            </div>
            <label className="field">
              <span>Buscar partida</span>
              <input value={query} disabled={busy} onChange={event => setQuery(event.target.value)}
                placeholder="Nombre, código o número de partida"/>
            </label>
          </div>
          <ul className="inventory-review-rows">
            {visible.map(item => (
              <li key={item.id}>
                <button type="button" disabled={busy} aria-current={selected?.id === item.id ? "true" : undefined}
                  onClick={() => { setSelectedId(item.id); setError(""); }}>
                  <strong>{item.originalName}</strong>
                  <small>Partida {item.sourceLine} · Página {item.sourcePage}</small>
                </button>
              </li>
            ))}
          </ul>
          {!visible.length && <p className="empty">{loading ? "Cargando partidas…" : "No hay partidas en esta vista."}</p>}
        </section>
        <section className="panel inventory-review-detail" aria-label="Datos de la partida">
          {selected ? <>
            <div className="panel-head">
              <h2>Partida {selected.sourceLine}</h2>
              <span className="record-count">{selectedIndex + 1} de {visible.length}</span>
            </div>
            <div className="inventory-review-source">
              <small>{selected.sourceBatch} · Página {selected.sourcePage}</small>
              <strong>{selected.originalName}</strong>
              <span>Existencia en PDF (referencia): {Number(selected.reportedStock).toLocaleString("es-MX")}</span>
              <small>{reasons[selected.reason] || selected.reason}</small>
            </div>
            <form className="inventory-review-form" onSubmit={save}>
              <label className="field">
                <span>Código de herramienta</span>
                <input required maxLength={100} value={code} readOnly={Boolean(selected.resolvedAt)}
                  disabled={busy} onChange={event => setCode(event.target.value)}/>
              </label>
              <label className="field">
                <span>Descripción</span>
                <textarea required maxLength={2000} rows={3} value={description} readOnly={Boolean(selected.resolvedAt)}
                  disabled={busy} onChange={event => setDescription(event.target.value)}/>
              </label>
              {!selected.resolvedAt && <>
                <label className="field">
                  <span>Código actual del producto (opcional)</span>
                  <input maxLength={100} value={currentCode} disabled={busy}
                    onChange={event => setCurrentCode(event.target.value)} placeholder="Sólo si vas a corregir un código existente"/>
                  <small>Si el código ya existe, se guarda la descripción en ese producto. Un código nuevo crea una ficha con existencia inicial de 0.</small>
                </label>
                <button type="submit" className="primary" disabled={busy || !code.trim() || !description.trim()}>
                  {busy ? "Guardando…" : "Guardar y continuar"}
                </button>
              </>}
              {selected.resolvedAt && selected.productId && <Link className="secondary" href={`/productos/${selected.productId}`}>Ver producto</Link>}
            </form>
            <div className="inventory-review-navigation">
              <button type="button" className="secondary" disabled={busy || selectedIndex <= 0}
                onClick={() => setSelectedId(visible[selectedIndex - 1].id)}>Anterior</button>
              <button type="button" className="secondary" disabled={busy || selectedIndex >= visible.length - 1}
                onClick={() => setSelectedId(visible[selectedIndex + 1].id)}>Siguiente</button>
            </div>
          </> : <p className="empty">Selecciona una partida para revisar sus datos.</p>}
        </section>
      </div>
    </section>
  );
}
