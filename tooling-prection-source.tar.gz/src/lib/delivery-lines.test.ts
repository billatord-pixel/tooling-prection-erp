import { describe, expect, it } from "vitest";
import { aggregateDeliveryLines } from "./delivery-lines";

describe("aggregateDeliveryLines", () => {
  it("combines repeated product lines without floating-point drift", () => {
    const result = aggregateDeliveryLines([
      { productId: "p1", quantity: "0.1" },
      { productId: "p2", quantity: "3.25" },
      { productId: "p1", quantity: "0.2" },
    ]);

    expect(result.map(({ productId, quantity }) => [productId, quantity.toString()])).toEqual([
      ["p1", "0.3"],
      ["p2", "3.25"],
    ]);
  });
});
