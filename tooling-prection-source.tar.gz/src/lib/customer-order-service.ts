import { Prisma } from "@prisma/client";
import { z } from "zod";
import { randomUUID } from "node:crypto";
import {
  assertCapacity,
  customerOrderSchema,
  normalizeCustomerFolio,
  trackingQuantitySchema,
  mexicoToday,
} from "@/lib/customer-orders";


export class CustomerTrackingError extends Error {}
export const customerOrderInclude = {
  customer: true,
  invoiceLinks: {
    orderBy: { createdAt: "asc" as const },
    include: {
      salesInvoice: {
        select: {
          id: true,
          folio: true,
          issueDate: true,
          status: true,
          archivedAt: true,
        },
      },
    },
  },
  items: {
    orderBy: { lineNumber: "asc" as const },
    include: {
      deliveries: {
        orderBy: { createdAt: "desc" as const },
        include: {
          invoiceLink: {
            include: { salesInvoice: { select: { id: true, folio: true } } },
          },
          deliveryLine: {
            include: { delivery: { select: { id: true, folio: true } } },
          },
        },
      },
      allocations: {
        include: {
          purchaseOrderLine: {
            include: { purchaseOrder: { include: { supplier: true } } },
          },
        },
      },
    },
  },
} satisfies Prisma.CustomerOrderInclude;
export async function lockCustomerTracking(tx: Prisma.TransactionClient) {
  await tx.$queryRaw`SELECT 1 FROM (SELECT pg_advisory_xact_lock(71300)) AS customer_tracking_lock`;
}
async function audit(
  tx: Prisma.TransactionClient,
  userId: string,
  entityId: string,
  action: "CREATE" | "UPDATE" | "STATUS_CHANGE" | "SOFT_DELETE" | "RESTORE",
  previousData: Prisma.InputJsonValue | undefined,
  newData: Prisma.InputJsonValue,
) {
  await tx.auditEvent.create({
    data: {
      userId,
      entity: "CustomerOrder",
      entityId,
      action,
      before: previousData,
      after: { ...newData as object, inventoryAffected: false },

    },
  });
}
export async function saveCustomerOrder(
  tx: Prisma.TransactionClient,
  raw: unknown,
  userId: string,
  id?: string,
  expectedAt?: string,
  newId?: string,
) {
  const data = customerOrderSchema.parse(raw);
  const numbers = data.items.map((item,index)=>item.lineNumber ?? index+1);
  if (new Set(numbers).size !== numbers.length) throw new CustomerTrackingError("Los números de partida no deben repetirse.");
  await lockCustomerTracking(tx);
  const previous = id
    ? await tx.customerOrder.findUnique({
        where: { id },
        include: customerOrderInclude,
      })
    : null;
  if (id && (!previous || previous.deletedAt))
    throw new CustomerTrackingError("La orden no está disponible.");
  if (
    previous &&
    (!expectedAt || previous.updatedAt.toISOString() !== expectedAt)
  )
    throw new CustomerTrackingError(
      "La orden cambió en otra sesión. Recarga antes de editar.",
    );
  if (previous?.status === "CANCELLED")
    throw new CustomerTrackingError("Reactiva la orden antes de editarla.");
  const customer = await tx.party.findFirst({
    where: { id: data.customerId, kind: "CUSTOMER", status: "ACTIVE" },
  });
  const company = await tx.companySettings.findFirst();
  if (!customer || !company)
    throw new CustomerTrackingError("Cliente o empresa no disponible.");
  if (
    (previous &&
      previous.customerId !== data.customerId &&
      previous.items.some(
        (i) => i.deliveries.some((d) => !d.deletedAt) || i.allocations.length,
      )) ||
    (previous &&
      previous.customerId !== data.customerId &&
      previous.invoiceLinks.some((link) => !link.deletedAt))
  )
    throw new CustomerTrackingError(
      "Retira los vínculos y las entregas antes de cambiar de cliente.",
    );
  const normalizedFolio = normalizeCustomerFolio(data.folio),
    revision = data.revision.toUpperCase();
  const duplicate = await tx.customerOrder.findUnique({
    where: {
      customerId_normalizedFolio_revision: {
        customerId: data.customerId,
        normalizedFolio,
        revision,
      },
    },
  });
  if (duplicate && duplicate.id !== id)
    throw new CustomerTrackingError(
      `Esta orden ya está registrada${duplicate.deletedAt ? " (archivada)" : ""}. Abre la existente para editarla.`,
    );
  const incomingIds = data.items.flatMap((i) => (i.id ? [i.id] : []));
  if (
    new Set(incomingIds).size !== incomingIds.length ||
    incomingIds.some((itemId) => !previous?.items.some((i) => i.id === itemId))
  )
    throw new CustomerTrackingError(
      "Las partidas a editar no pertenecen a esta orden.",
    );
  for (const old of previous?.items ?? []) {
    const next = data.items.find((i) => i.id === old.id),
      activeDeliveries = old.deliveries.filter((d) => !d.deletedAt);
    const delivered = activeDeliveries.reduce(
      (sum, d) => sum.plus(d.quantity),
      new Prisma.Decimal(0),
    );
    const assigned = old.allocations
      .filter((a) => a.purchaseOrderLine.purchaseOrder.status !== "CANCELLED")
      .reduce((sum, a) => sum.plus(a.quantity), new Prisma.Decimal(0));
    if (!next && (old.deliveries.length || old.allocations.length))
      throw new CustomerTrackingError(
        "No puedes eliminar una partida con historial de entregas o vínculos.",
      );
    if (
      next &&
      (new Prisma.Decimal(next.quantity).lt(delivered) ||
        new Prisma.Decimal(next.quantity).lt(assigned))
    )
      throw new CustomerTrackingError(
        "La cantidad no puede ser menor a lo entregado o vinculado.",
      );
    if (
      next &&
      (activeDeliveries.length || old.allocations.length) &&
      (next.unit !== old.unit || (next.productId ?? null) !== old.productId)
    )
      throw new CustomerTrackingError(
        "No cambies la unidad o el producto de una partida con actividad; desvincúlala primero.",
      );
  }
  for (const productId of new Set(
    data.items.flatMap((i) => (i.productId ? [i.productId] : [])),
  ))
    if (
      !(await tx.product.findFirst({
        where: { id: productId, status: "ACTIVE" },
      }))
    )
      throw new CustomerTrackingError(
        "Un producto seleccionado ya no está disponible.",
      );
  const fields = {
    customerId: customer.id,
    folio: data.folio,
    normalizedFolio,
    revision,
    orderDate: new Date(`${data.orderDate}T12:00:00Z`),
    dueDate: data.dueDate ? new Date(`${data.dueDate}T12:00:00Z`) : null,
    deadlineText: data.deadlineText ?? null,
    currency: data.currency,
    declaredTotal: data.declaredTotal ?? null,
    contactName: data.contactName ?? null,
    deliveryAddress: data.deliveryAddress ?? null,
    notesText: data.notesText ?? null,
  };
  const order = previous
    ? await tx.customerOrder.update({ where: { id }, data: fields })
    : await tx.customerOrder.create({
        data: {
          ...fields,
          id: newId,
          createdById: userId,
          companySnapshot: JSON.parse(JSON.stringify(company)),
        },
      });
  // Retain IDs so references remain stable when lines are reordered.
  for (const item of previous?.items ?? [])
    await tx.customerOrderItem.update({
      where: { id: item.id },
      data: { lineNumber: -item.lineNumber },
    });
  for (const [index, item] of data.items.entries()) {
    const fields = {
      lineNumber: item.lineNumber ?? index + 1,
      customerCode: item.customerCode ?? null,
      description: item.description,
      productId: item.productId ?? null,
      quantity: item.quantity,
      unit: item.unit,
      unitPrice: item.unitPrice ?? null,
      dueDate: item.dueDate ? new Date(`${item.dueDate}T12:00:00Z`) : null,
      notesText: item.notesText ?? null,
    };
    if (item.id)
      await tx.customerOrderItem.update({
        where: { id: item.id },
        data: fields,
      });
    else
      await tx.customerOrderItem.create({
        data: { ...fields, orderId: order.id },
      });
  }
  if (previous)
    await tx.customerOrderItem.deleteMany({
      where: {
        orderId: order.id,
        id: { notIn: incomingIds },
        lineNumber: { lt: 0 },
      },
    });
  await audit(
    tx,
    userId,
    order.id,
    previous ? "UPDATE" : "CREATE",
    previous
      ? {
          folio: previous.folio,
          customerId: previous.customerId,
          items: previous.items.map((i) => ({
            id: i.id,
            description: i.description,
            quantity: i.quantity.toString(),
            dueDate: i.dueDate?.toISOString() ?? null,
          })),
          dueDate: previous.dueDate?.toISOString() ?? null,
        }
      : undefined,
    {
      ...data,
      items: data.items.map((i) => ({ ...i })),
      inventoryAffected: false,
    },
  );
  return order;
}

async function editableItem(tx: Prisma.TransactionClient, id: string) {
  const item = await tx.customerOrderItem.findUnique({
    where: { id },
    include: { order: true, deliveries: true, allocations: true },
  });
  if (!item || item.order.deletedAt || item.order.status !== "ACTIVE")
    throw new CustomerTrackingError(
      "La orden debe estar activa para registrar esta operación.",
    );
  return item;
}
export async function allocateCustomerMaterial(
  tx: Prisma.TransactionClient,
  orderItemId: string,
  purchaseOrderLineId: string,
  quantity: unknown,
  userId: string,
) {
  const qty = trackingQuantitySchema.parse(quantity);
  await lockCustomerTracking(tx);
  const item = await editableItem(tx, orderItemId);
  const purchase = await tx.purchaseOrderLine.findUnique({
    where: { id: purchaseOrderLineId },
    include: { purchaseOrder: true, product: true },
  });
  await tx.$queryRaw`SELECT id FROM "PurchaseOrderLine" WHERE id=${purchaseOrderLineId} FOR UPDATE`;
  if (
    !purchase ||
    purchase.purchaseOrder.status === "ARCHIVED" ||
    purchase.purchaseOrder.status === "CANCELLED"
  )
    throw new CustomerTrackingError(
      "El pedido del proveedor no está disponible.",
    );
  if (item.unit.toUpperCase() !== purchase.product.unit.toUpperCase())
    throw new CustomerTrackingError(
      "Las unidades son distintas. Revisa la partida antes de vincularla.",
    );
  const same = await tx.customerOrderAllocation.findUnique({
    where: {
      orderItemId_purchaseOrderLineId: { orderItemId, purchaseOrderLineId },
    },
  });
  if (same)
    throw new CustomerTrackingError(
      "Esta partida del proveedor ya está vinculada. Retira el vínculo si necesitas corregir su cantidad.",
    );
  const assigned = await tx.customerOrderAllocation.findMany({
    where: {
      orderItemId,
      purchaseOrderLine: {
        purchaseOrder: { status: { notIn: ["CANCELLED", "ARCHIVED"] } },
      },
    },
  });
  assertCapacity(
    item.quantity,
    assigned.reduce((s, a) => s.plus(a.quantity), new Prisma.Decimal(0)),
    qty,
    "La cantidad vinculada a la orden del cliente",
  );
  const used = await tx.customerOrderAllocation.findMany({
    where: { purchaseOrderLineId, orderItem: { order: { status: "ACTIVE" } } },
  });
  assertCapacity(
    purchase.quantity,
    used.reduce((s, a) => s.plus(a.quantity), new Prisma.Decimal(0)),
    qty,
    "La cantidad asignada del pedido a proveedor",
  );
  const allocation = await tx.customerOrderAllocation.create({
    data: { orderItemId, purchaseOrderLineId, quantity: qty },
  });
  await tx.customerOrder.update({
    where: { id: item.orderId },
    data: { updatedAt: new Date() },
  });
  await audit(tx, userId, item.orderId, "UPDATE", undefined, {
    operation: "LINK_PURCHASE",
    allocationId: allocation.id,
    orderItemId,
    purchaseOrderLineId,
    quantity: qty,
  });
  return allocation;
}
export async function recordCustomerDelivery(
  tx: Prisma.TransactionClient,
  raw: {
    id: string;
    orderItemId: string;
    quantity: unknown;
    deliveryDate: string;
    deliveryLineId?: string;
    invoiceLinkId?: string;
    notesText?: string;
  },
  userId: string,
) {
  const id = z.string().min(1).max(100).parse(raw.id),
    qty = trackingQuantitySchema.parse(raw.quantity);
  const day = customerOrderSchema.shape.orderDate.parse(raw.deliveryDate);
  if (raw.notesText && raw.notesText.length > 4000)
    throw new CustomerTrackingError(
      "Las notas de entrega son demasiado largas.",
    );
  if (raw.deliveryLineId) z.string().min(1).max(100).parse(raw.deliveryLineId);
  if (raw.invoiceLinkId) z.string().min(1).max(100).parse(raw.invoiceLinkId);
  await lockCustomerTracking(tx);
  const item = await editableItem(tx, z.string().min(1).max(100).parse(raw.orderItemId));
  const repeated = await tx.customerOrderDelivery.findUnique({ where: { id } });
  if (repeated) {
    if (
      repeated.orderItemId === raw.orderItemId &&
      repeated.quantity.eq(qty) &&
      !repeated.deletedAt &&
      (repeated.deliveryLineId ?? undefined) === raw.deliveryLineId &&
      (repeated.invoiceLinkId ?? undefined) === raw.invoiceLinkId &&
      repeated.deliveryDate.toISOString().slice(0, 10) === day
    )
      return repeated;
    throw new CustomerTrackingError(
      "Esta operación ya fue procesada con otros datos. Recarga la orden.",
    );
  }
  const delivered = item.deliveries
    .filter((d) => !d.deletedAt)
    .reduce((s, d) => s.plus(d.quantity), new Prisma.Decimal(0));
  assertCapacity(item.quantity, delivered, qty, "La entrega");
  if (raw.invoiceLinkId) {
    const linkedInvoice = await tx.customerOrderInvoiceLink.findUnique({
      where: { id: raw.invoiceLinkId },
      include: { salesInvoice: true },
    });
    if (
      !linkedInvoice ||
      linkedInvoice.orderId !== item.orderId ||
      linkedInvoice.deletedAt ||
      linkedInvoice.salesInvoice.archivedAt ||
      linkedInvoice.salesInvoice.customerId !== item.order.customerId ||
      ["DRAFT", "CANCELLED"].includes(linkedInvoice.salesInvoice.status)
    )
      throw new CustomerTrackingError(
        "Selecciona una factura vigente vinculada a esta misma orden.",
      );
  }
  if (raw.deliveryLineId) {
    await tx.$queryRaw`SELECT id FROM "DeliveryLine" WHERE id=${raw.deliveryLineId} FOR UPDATE`;
    const source = await tx.deliveryLine.findUnique({
      where: { id: raw.deliveryLineId },
      include: {
        delivery: true,
        product: true,
        customerOrderDeliveries: { where: { deletedAt: null } },
      },
    });
    if (
      !source ||
      source.delivery.status !== "DELIVERED" ||
      source.delivery.customerId !== item.order.customerId
    )
      throw new CustomerTrackingError(
        "La remisión debe ser válida y del mismo cliente.",
      );
    if (source.product.unit.toUpperCase() !== item.unit.toUpperCase())
      throw new CustomerTrackingError(
        "Las unidades de la remisión no coinciden.",
      );
    assertCapacity(
      source.quantity,
      source.customerOrderDeliveries.reduce(
        (s, d) => s.plus(d.quantity),
        new Prisma.Decimal(0),
      ),
      qty,
      "La cantidad entregada de la remisión",
    );
  }
  const delivery = await tx.customerOrderDelivery.create({
    data: {
      id,
      orderItemId: item.id,
      quantity: qty,
      deliveryDate: new Date(`${day}T12:00:00Z`),
      deliveryLineId: raw.deliveryLineId,
      invoiceLinkId: raw.invoiceLinkId,
      notesText: raw.notesText,
    },
  });
  await tx.customerOrder.update({
    where: { id: item.orderId },
    data: { updatedAt: new Date() },
  });
  await audit(tx, userId, item.orderId, "UPDATE", undefined, {
    operation: "DELIVERY",
    deliveryId: id,
    orderItemId: item.id,
    quantity: qty,
    deliveryDate: day,
    deliveryLineId: raw.deliveryLineId ?? null,
    invoiceLinkId: raw.invoiceLinkId ?? null,
  });
  return delivery;
}

export async function linkCustomerInvoice(
  tx: Prisma.TransactionClient,
  orderId: string,
  folio: string,
  markDelivered: boolean,
  userId: string,
) {
  z.string().min(1).max(100).parse(orderId);
  const reference = z
    .string()
    .trim()
    .min(1, "Escribe el folio de la factura.")
    .max(60)
    .parse(folio);
  await lockCustomerTracking(tx);
  const order = await tx.customerOrder.findUnique({
    where: { id: orderId },
    include: customerOrderInclude,
  });
  if (!order || order.deletedAt || order.status !== "ACTIVE")
    throw new CustomerTrackingError(
      "La orden no está disponible para registrar entregas.",
    );
  const candidates = await tx.salesInvoice.findMany({
    where: { folio: { equals: reference, mode: "insensitive" } },
    take: 2,
  });
  if (candidates.length !== 1)
    throw new CustomerTrackingError(
      candidates.length
        ? "El folio es ambiguo. Revisa la factura antes de vincularla."
        : "No existe una factura con ese folio. Usa el folio que aparece en Ventas.",
    );
  const invoice = candidates[0]!;
  await tx.$queryRaw`SELECT id FROM "SalesInvoice" WHERE id=${invoice.id} FOR UPDATE`;
  if (invoice.customerId !== order.customerId)
    throw new CustomerTrackingError(
      "La factura corresponde a otro cliente; no puede vincularse a esta orden.",
    );
  if (invoice.archivedAt || ["CANCELLED", "DRAFT"].includes(invoice.status))
    throw new CustomerTrackingError(
      "No puedes vincular una factura cancelada, archivada o en borrador.",
    );
  const previous = await tx.customerOrderInvoiceLink.findUnique({
    where: { orderId_salesInvoiceId: { orderId, salesInvoiceId: invoice.id } },
  });
  const link = previous
    ? previous.deletedAt
      ? await tx.customerOrderInvoiceLink.update({
          where: { id: previous.id },
          data: { deletedAt: null },
        })
      : previous
    : await tx.customerOrderInvoiceLink.create({
        data: { orderId, salesInvoiceId: invoice.id },
      });
  let completed = new Prisma.Decimal(0);
  if (markDelivered) {
    for (const item of order.items) {
      const delivered = item.deliveries
        .filter((event) => !event.deletedAt)
        .reduce(
          (sum, event) => sum.plus(event.quantity),
          new Prisma.Decimal(0),
        );
      const pending = item.quantity.minus(delivered);
      if (pending.lte(0)) continue;
      await recordCustomerDelivery(
        tx,
        {
          id: randomUUID(),
          orderItemId: item.id,
          quantity: pending.toString(),
          deliveryDate: mexicoToday(),
          invoiceLinkId: link.id,
          notesText: `Saldo pendiente cerrado por confirmación manual de entrega total. Factura ${invoice.folio}; la fecha corresponde a esta confirmación. Seguimiento comercial sin repetir la salida de inventario.`,
        },
        userId,
      );
      completed = completed.plus(pending);
    }
  }
  if (!previous || previous.deletedAt || completed.gt(0)) {
    await tx.customerOrder.update({
      where: { id: orderId },
      data: { updatedAt: new Date() },
    });
    await audit(tx, userId, orderId, "UPDATE", undefined, {
      operation: "LINK_INVOICE",
      invoiceId: invoice.id,
      invoiceLinkId: link.id,
      folio: invoice.folio,
      markDelivered,
      completedQuantity: completed.toString(),
      ownerConfirmedFullDelivery: markDelivered,
    });
  }
  return link;
}

export async function unlinkCustomerInvoice(
  tx: Prisma.TransactionClient,
  orderId: string,
  id: string,
  reason: string,
  userId: string,
) {
  z.string().min(1).max(100).parse(orderId);
  z.string().min(1).max(100).parse(id);
  if (!reason.trim() || reason.length > 500)
    throw new CustomerTrackingError(
      "Indica el motivo de la corrección (máximo 500 caracteres).",
    );
  await lockCustomerTracking(tx);
  const link = await tx.customerOrderInvoiceLink.findFirst({
    where: { id, orderId },
    include: { salesInvoice: { select: { folio: true } } },
  });
  if (!link)
    throw new CustomerTrackingError("La factura no pertenece a esta orden.");
  if (!link.deletedAt) {
    await tx.customerOrderInvoiceLink.update({
      where: { id },
      data: { deletedAt: new Date() },
    });
    await tx.customerOrder.update({
      where: { id: orderId },
      data: { updatedAt: new Date() },
    });
    await audit(
      tx,
      userId,
      orderId,
      "UPDATE",
      { invoiceLinkId: id, folio: link.salesInvoice.folio },
      { operation: "UNLINK_INVOICE", reason, deliveriesUnchanged: true },
    );
  }
}

export async function guardSalesInvoiceCustomer(
  tx: Prisma.TransactionClient,
  invoiceId: string,
  customerId: string,
) {
  const incompatible = await tx.customerOrderInvoiceLink.findFirst({
    where: {
      salesInvoiceId: invoiceId,
      deletedAt: null,
      order: { customerId: { not: customerId } },
    },
  });
  if (incompatible)
    throw new CustomerTrackingError(
      "Retira el vínculo con la orden del cliente antes de cambiar el cliente de esta factura.",
    );
}

export async function removeCustomerTracking(
  tx: Prisma.TransactionClient,
  id: string,
  type: "allocation" | "delivery",
  reason: string,
  userId: string,
) {
  z.string().min(1).max(100).parse(id);
  if (!reason.trim() || reason.length > 500)
    throw new CustomerTrackingError(
      "Indica el motivo de la corrección (máximo 500 caracteres).",
    );
  await lockCustomerTracking(tx);
  if (type === "allocation") {
    const row = await tx.customerOrderAllocation.findUnique({
      where: { id },
      include: { orderItem: true },
    });
    if (!row) throw new CustomerTrackingError("El vínculo ya no existe.");
    await tx.customerOrderAllocation.delete({ where: { id } });
    await tx.customerOrder.update({
      where: { id: row.orderItem.orderId },
      data: { updatedAt: new Date() },
    });
    await audit(
      tx,
      userId,
      row.orderItem.orderId,
      "UPDATE",
      {
        allocationId: id,
        orderItemId: row.orderItemId,
        purchaseOrderLineId: row.purchaseOrderLineId,
        quantity: row.quantity.toString(),
      },
      { operation: "UNLINK_PURCHASE", reason },
    );
    return row.orderItem.orderId;
  }
  const row = await tx.customerOrderDelivery.findUnique({
    where: { id },
    include: { orderItem: true },
  });
  if (!row) throw new CustomerTrackingError("La entrega no existe.");
  if (!row.deletedAt) {
    await tx.customerOrderDelivery.update({
      where: { id },
      data: { deletedAt: new Date(), deliveryLineId: null },
    });
    await tx.customerOrder.update({
      where: { id: row.orderItem.orderId },
      data: { updatedAt: new Date() },
    });
    await audit(
      tx,
      userId,
      row.orderItem.orderId,
      "UPDATE",
      {
        deliveryId: id,
        orderItemId: row.orderItemId,
        quantity: row.quantity.toString(),
        deliveryLineId: row.deliveryLineId,
      },
      { operation: "VOID_DELIVERY", reason },
    );
  }
  return row.orderItem.orderId;
}

export async function changeCustomerOrderState(
  tx: Prisma.TransactionClient,
  id: string,
  operation: "cancel" | "reactivate" | "archive" | "restore",
  userId: string,
) {
  await lockCustomerTracking(tx);
  const order = await tx.customerOrder.findUnique({
    where: { id: z.string().min(1).max(100).parse(id) },
    include: customerOrderInclude,
  });
  if (!order) throw new CustomerTrackingError("La orden no existe.");
  if (operation === "reactivate") {
    for (const item of order.items)
      for (const allocation of item.allocations) {
        if (
          allocation.purchaseOrderLine.purchaseOrder.status === "CANCELLED" ||
          allocation.purchaseOrderLine.purchaseOrder.status === "ARCHIVED"
        )
          throw new CustomerTrackingError(
            "Retira los vínculos con pedidos cancelados antes de reactivar.",
          );
        const other = await tx.customerOrderAllocation.findMany({
          where: {
            purchaseOrderLineId: allocation.purchaseOrderLineId,
            orderItem: { order: { status: "ACTIVE", id: { not: id } } },
          },
        });
        const own = order.items
          .flatMap((i) => i.allocations)
          .filter(
            (a) => a.purchaseOrderLineId === allocation.purchaseOrderLineId,
          )
          .reduce((s, a) => s.plus(a.quantity), new Prisma.Decimal(0));
        assertCapacity(
          allocation.purchaseOrderLine.quantity,
          other.reduce((s, a) => s.plus(a.quantity), new Prisma.Decimal(0)),
          own,
          "El material al reactivar",
        );
      }
  }
  const data =
    operation === "cancel"
      ? { status: "CANCELLED" }
      : operation === "reactivate"
        ? { status: "ACTIVE" }
        : operation === "archive"
          ? { deletedAt: new Date() }
          : { deletedAt: null };
  await tx.customerOrder.update({ where: { id }, data });
  await audit(
    tx,
    userId,
    id,
    operation === "archive"
      ? "SOFT_DELETE"
      : operation === "restore"
        ? "RESTORE"
        : "STATUS_CHANGE",
    { status: order.status, deletedAt: order.deletedAt?.toISOString() ?? null },
    { operation },
  );
}

export async function guardPurchaseCustomerLinks(
  tx: Prisma.TransactionClient,
  oldIds: string[],
  incoming: Array<{ id?: string; quantity: number; productId: string }>,
) {
  const links = await tx.customerOrderAllocation.findMany({
    where: { purchaseOrderLineId: { in: oldIds } },
    include: {
      orderItem: { include: { order: true } },
      purchaseOrderLine: true,
    },
  });
  for (const id of new Set(links.map((l) => l.purchaseOrderLineId))) {
    const next = incoming.find((i) => i.id === id),
      rows = links.filter((l) => l.purchaseOrderLineId === id);
    if (!next)
      throw new CustomerTrackingError(
        "Retira los vínculos de órdenes de clientes antes de eliminar esta partida.",
      );
    const used = rows
      .filter((l) => l.orderItem.order.status === "ACTIVE")
      .reduce((s, l) => s.plus(l.quantity), new Prisma.Decimal(0));
    if (
      used.gt(next.quantity) ||
      rows[0]!.purchaseOrderLine.productId !== next.productId
    )
      throw new CustomerTrackingError(
        "Esta partida está vinculada a órdenes de clientes. No puedes reducirla por debajo de lo asignado ni cambiar su producto.",
      );
  }
}
