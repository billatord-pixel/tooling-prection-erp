/** Keep the fiscal calendar day, independently of the viewer's timezone. */
export function monthlyInvoiceDateLabel(value?:string) {
  const match=value?.match(/^(\d{4})-(\d{2})-(\d{2})(?:T|$)/);
  return match?`${match[3]}/${match[2]}/${match[1]}`:"Sin fecha";
}
