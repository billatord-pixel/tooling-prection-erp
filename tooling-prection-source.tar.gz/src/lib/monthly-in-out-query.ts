import {getMonthlyPurchasedProducts} from "./monthly-purchased-products-query";
import {getMonthlySoldProducts} from "./monthly-sold-products-query";
import {mergeMonthlyInOut} from "./monthly-in-out";
export async function getMonthlyInOut(month:string){
 const [purchases,sales]=await Promise.all([getMonthlyPurchasedProducts(month),getMonthlySoldProducts(month)]);
 return mergeMonthlyInOut(purchases,sales);
}
