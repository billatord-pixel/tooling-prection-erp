import { beforeEach, describe, expect, it, vi } from "vitest";
const mock = vi.hoisted(() => ({ products: vi.fn(), invoices: vi.fn(), delivery: vi.fn(), order: vi.fn() }));
vi.mock("@/lib/auth", () => ({ currentSession: async () => ({ id: "admin", role: "ADMIN" }) }));
vi.mock("@/lib/db", () => ({ db: {
  companySettings: { findFirst: async () => null }, product: { findMany: mock.products },
  inventoryPhysicalValuation: { findFirst: async () => null },
  salesInvoice: { findMany: mock.invoices }, delivery: { findUnique: mock.delivery }, purchaseOrder: { findUnique: mock.order },
} }));
const product = { id: "p", technicalCode: "EDP-123456", description: "Herramienta de precisión", currency: "USD", unit: "PZA", stock: 10, onOrder: 0, baseCost: 2, salePrice: 5, brand: null, category: null, mainSupplier: null };
const line = { product, productId: "p", description: product.description, quantity: 2, unitPrice: 5, amount: 10, discount: 0, lot: null, note: null };
const customer = { legalName: "CLIENTE DE PRUEBA", taxId: "AAA010101AAA" };
const pages = async (response: Response) => { expect(response.status).toBe(200); const buffer = Buffer.from(await response.arrayBuffer()); expect(buffer.subarray(0, 5).toString()).toBe("%PDF-"); return (buffer.toString("latin1").match(/\/Type\s*\/Page\b/g) || []).length; };
describe("PDF operativos: no añadir hojas vacías", () => {
  beforeEach(() => {
    mock.products.mockResolvedValue([product]);
    mock.invoices.mockResolvedValue([{ folio: "F-TEST", currency: "USD", total: 11.6, issueDate: new Date("2026-10-01T12:00:00Z"), customer, _count: { lines: 1 } }]);
    mock.delivery.mockResolvedValue({ id: "d", folio: "REM-TEST", issueDate: new Date(), currency: "USD", status: "DRAFT", customer, warehouse: "Principal", lines: [line], subtotal: 10, discount: 0, tax: 1.6, total: 11.6, taxRate: .16, notes: "Entrega de prueba" });
    mock.order.mockResolvedValue({ id: "o", folio: "OC-TEST", issueDate: new Date(), status: "PENDING", supplier: { ...customer, tradeName: customer.legalName }, lines: [line], subtotal: 10, tax: 1.6, total: 11.6 });
  });
  it("remisión sencilla en una hoja", async () => {
    const { GET } = await import("@/app/api/deliveries/[id]/pdf/route");
    expect(await pages(await GET(new Request("http://localhost/pdf"), { params: Promise.resolve({ id: "d" }) }))).toBe(1);
  });
  it("resumen sencillo de productos en una hoja", async () => {
    const { GET } = await import("@/app/api/products/summary/route");
    expect(await pages(await GET(new Request("http://localhost/pdf")))).toBe(1);
  });
  it("cuentas por cobrar sencillas en una hoja", async () => {
    const { GET } = await import("@/app/api/invoices/sales/export/route");
    expect(await pages(await GET())).toBe(1);
  });
  it("pedido sencillo en una hoja", async () => {
    const { GET } = await import("@/app/api/purchase-orders/[id]/pdf/route");
    expect(await pages(await GET(new Request("http://localhost/pdf"), { params: Promise.resolve({ id: "o" }) }))).toBe(1);
  });
  it("productos con varias páginas sin triplicar su paginación", async () => {
    mock.products.mockResolvedValue(Array.from({ length: 80 }, () => product));
    const { GET } = await import("@/app/api/products/summary/route");
    const count = await pages(await GET(new Request("http://localhost/pdf")));
    expect(count).toBeGreaterThan(1); expect(count).toBeLessThan(9);
  });
});
