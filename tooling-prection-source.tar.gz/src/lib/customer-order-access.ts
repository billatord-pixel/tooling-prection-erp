import type { Role } from "@prisma/client";
export type CustomerOrderPermission = "read" | "create" | "update" | "deliver" | "link";
export function canCustomerOrder(role: Role, permission: CustomerOrderPermission) {
  return permission === "read" || role === "ADMIN";
}
