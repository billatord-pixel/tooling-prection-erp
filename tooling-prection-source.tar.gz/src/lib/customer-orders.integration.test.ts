import { beforeAll,afterAll,describe,it,expect,vi } from "vitest";
import { randomUUID,createHash } from "node:crypto";
const session=vi.hoisted(()=>({id:"",role:"ADMIN"}));
vi.mock("@/lib/auth",()=>({currentSession:async()=>session}));
import { db } from "./db";
import { saveCustomerOrder,customerOrderInclude,recordCustomerDelivery,allocateCustomerMaterial,linkCustomerInvoice,changeCustomerOrderState,removeCustomerTracking,unlinkCustomerInvoice } from "./customer-order-service";
import { orderProgress } from "./customer-orders";
import { POST,GET } from "@/app/api/ordenes-clientes/route";
import { GET as document } from "@/app/api/ordenes-clientes/documento/route";
import { buildCustomerOrdersPendingPdf } from "./customer-orders-pdf";
const enabled=process.env.DATABASE_URL==="postgresql://postgres@127.0.0.1:54987/postgres"&&process.env.TP_INVENTORY_TEST_URL===process.env.DATABASE_URL;
describe.skipIf(!enabled)("Órdenes en PostgreSQL aislado: saldos y movimientos intactos",()=>{
  const validFolio="QA-F-"+randomUUID().toUpperCase();
  let customerId="",otherCustomerId="",productId="",purchaseId="",deliveryId="",before="";
  const snapshot=async()=>createHash("sha256").update(JSON.stringify({products:await db.product.findMany({orderBy:{id:"asc"},select:{id:true,stock:true,onOrder:true,baseCost:true}}),movements:await db.inventoryMovement.findMany({orderBy:{id:"asc"}}),invoices:await db.salesInvoice.findMany({orderBy:{id:"asc"}})})).digest("hex");
  const input=(folio:string)=>({customerId,folio,orderDate:"2026-10-14",currency:"USD",items:[{description:"Herramienta repetida",quantity:5,unit:"PZA",dueDate:"2026-10-10",productId},{description:"Herramienta repetida",quantity:5,unit:"PZA",dueDate:"2026-10-18",productId}]});
  const create=async(folio:string)=>db.$transaction(tx=>saveCustomerOrder(tx,input(folio),session.id));
  const load=(id:string)=>db.customerOrder.findUniqueOrThrow({where:{id},include:customerOrderInclude});
  beforeAll(async()=>{
    session.id=(await db.user.findFirstOrThrow({where:{role:"ADMIN"}})).id;
    customerId=(await db.party.create({data:{kind:"CUSTOMER",legalName:"Cliente ficticio pruebas OC"}})).id;
    otherCustomerId=(await db.party.create({data:{kind:"CUSTOMER",legalName:"Otro cliente ficticio"}})).id;
    productId=(await db.product.create({data:{technicalCode:"QA-OC-"+randomUUID(),description:"Herramienta ficticia",unit:"PZA",stock:40}})).id;
    const supplier=await db.party.create({data:{kind:"SUPPLIER",legalName:"Proveedor ficticio"}});
    const purchase=await db.purchaseOrder.create({data:{folio:"QA-P-"+randomUUID(),supplierId:supplier.id,lines:{create:{productId,description:"Herramienta",quantity:8,unitPrice:10}}},include:{lines:true}});purchaseId=purchase.lines[0].id;
    const delivery=await db.delivery.create({data:{folio:"QA-R-"+randomUUID(),customerId,status:"DELIVERED",lines:{create:{productId,description:"Herramienta",quantity:4,unitPrice:15,amount:60}}},include:{lines:true}});deliveryId=delivery.lines[0].id;
    (await db.salesInvoice.create({data:{folio:validFolio,customerId,issueDate:new Date(),subtotal:10,total:10}})).id;
    before=await snapshot();
  });
  afterAll(async()=>{if(before)expect(await snapshot()).toBe(before);await db.$disconnect();});
  it("edita conservando IDs, persiste y evita concurrencia",async()=>{
    const order=await create("QA-EDIT"),stored=await load(order.id),raw={...input("QA-EDIT"),items:stored.items.map((i,n)=>({...input("QA-EDIT").items[n],id:i.id,description:"Editada "+n}))};
    await db.$transaction(tx=>saveCustomerOrder(tx,raw,session.id,order.id,stored.updatedAt.toISOString()));
    expect((await load(order.id)).items.map(i=>i.id)).toEqual(stored.items.map(i=>i.id));
    await expect(db.$transaction(tx=>saveCustomerOrder(tx,raw,session.id,order.id,stored.updatedAt.toISOString()))).rejects.toThrow("otra sesión");
    const duplicate=await Promise.allSettled([create("QA-DUP"),create("qa dup")]);expect(duplicate.filter(r=>r.status==="fulfilled")).toHaveLength(1);
  });
  it("entregas idempotentes, parciales y cierre completo confirmado",async()=>{
    const order=await create("QA-PARCIAL"),stored=await load(order.id),raw={id:randomUUID(),orderItemId:stored.items[0].id,quantity:2,deliveryDate:"2026-10-14"};
    await db.$transaction(tx=>recordCustomerDelivery(tx,raw,session.id));await db.$transaction(tx=>recordCustomerDelivery(tx,raw,session.id));
    expect(orderProgress(await load(order.id)).pending).toBe(8);
    await db.$transaction(tx=>linkCustomerInvoice(tx,order.id,validFolio,false,session.id));
    expect(orderProgress(await load(order.id)).pending).toBe(8);
    await db.$transaction(tx=>linkCustomerInvoice(tx,order.id,validFolio,true,session.id));await db.$transaction(tx=>linkCustomerInvoice(tx,order.id,validFolio,true,session.id));
    const done=await load(order.id);expect(orderProgress(done).status).toBe("DELIVERED");expect(done.invoiceLinks).toHaveLength(1);expect(done.items[0].deliveries).toHaveLength(2);
    await db.$transaction(tx=>unlinkCustomerInvoice(tx,order.id,done.invoiceLinks[0].id,"Corrección de referencia",session.id));expect(orderProgress(await load(order.id)).pending).toBe(0);
  });
  it("facturas inexistentes, otro cliente, canceladas/borrador/archivo y ambiguas",async()=>{
    const order=await create("QA-FACTURAS");
    await expect(db.$transaction(tx=>linkCustomerInvoice(tx,order.id,"NO-EXISTE",false,session.id))).rejects.toThrow("No existe");
    for(const [folio,status,customer,archived] of [["QA-OTRO","PENDING",otherCustomerId,false],["QA-CANCEL","CANCELLED",customerId,false],["QA-DRAFT","DRAFT",customerId,false],["QA-ARCH","PENDING",customerId,true]] as const){
      await db.salesInvoice.create({data:{folio,customerId:customer,status,archivedAt:archived?new Date():null,issueDate:new Date(),subtotal:10,total:10}});
      await expect(db.$transaction(tx=>linkCustomerInvoice(tx,order.id,folio,false,session.id))).rejects.toThrow();
      await db.salesInvoice.delete({where:{folio}});
    }
    await db.salesInvoice.create({data:{folio:validFolio.toLowerCase(),customerId,issueDate:new Date(),subtotal:10,total:10}});
    await expect(db.$transaction(tx=>linkCustomerInvoice(tx,order.id,validFolio,false,session.id))).rejects.toThrow("ambiguo");
    await db.salesInvoice.delete({where:{folio:validFolio.toLowerCase()}});
    const second=await db.salesInvoice.create({data:{folio:"QA-F-SECOND",customerId,issueDate:new Date(),subtotal:10,total:10}});
    await db.$transaction(tx=>linkCustomerInvoice(tx,order.id,validFolio,false,session.id));await db.$transaction(tx=>linkCustomerInvoice(tx,order.id,second.folio,false,session.id));expect((await load(order.id)).invoiceLinks).toHaveLength(2);
    // Keep invoice snapshot invariant after the temporary fixture.
    await db.customerOrderInvoiceLink.deleteMany({where:{salesInvoiceId:second.id}});await db.salesInvoice.delete({where:{id:second.id}});
  });
  it("capacidad concurrente proveedor y reactivación",async()=>{
    const a=await create("QA-ALLOC-A"),b=await create("QA-ALLOC-B"),ai=(await load(a.id)).items[0],bi=(await load(b.id)).items[0];
    const results=await Promise.allSettled([db.$transaction(tx=>allocateCustomerMaterial(tx,ai.id,purchaseId,5,session.id)),db.$transaction(tx=>allocateCustomerMaterial(tx,bi.id,purchaseId,5,session.id))]);
    expect(results.filter(r=>r.status==="fulfilled")).toHaveLength(1);
    const winner=results[0].status==="fulfilled"?a:b,loser=winner.id===a.id?b:a,li=(await load(loser.id)).items[0];
    await db.$transaction(tx=>changeCustomerOrderState(tx,winner.id,"archive",session.id));
    await expect(db.$transaction(tx=>allocateCustomerMaterial(tx,li.id,purchaseId,5,session.id))).rejects.toThrow("disponible");
    await db.$transaction(tx=>changeCustomerOrderState(tx,winner.id,"restore",session.id));await db.$transaction(tx=>changeCustomerOrderState(tx,winner.id,"cancel",session.id));
    await db.$transaction(tx=>allocateCustomerMaterial(tx,li.id,purchaseId,5,session.id));
    await expect(db.$transaction(tx=>changeCustomerOrderState(tx,winner.id,"reactivate",session.id))).rejects.toThrow("disponible");
  });
  it("remisión entregada no se despacha otra vez ni sobreasigna",async()=>{
    const a=await create("QA-REM-A"),b=await create("QA-REM-B"),ai=(await load(a.id)).items[0],bi=(await load(b.id)).items[0],raw={id:randomUUID(),orderItemId:ai.id,quantity:4,deliveryDate:"2026-10-14",deliveryLineId:deliveryId};
    await db.$transaction(tx=>recordCustomerDelivery(tx,raw,session.id));
    await expect(db.$transaction(tx=>recordCustomerDelivery(tx,{...raw,id:randomUUID(),orderItemId:bi.id,quantity:1},session.id))).rejects.toThrow("disponible");
    const row=(await load(a.id)).items[0].deliveries[0];await db.$transaction(tx=>removeCustomerTracking(tx,row.id,"delivery","Corrección",session.id));
    await db.$transaction(tx=>recordCustomerDelivery(tx,{...raw,id:randomUUID(),orderItemId:bi.id,quantity:1},session.id));
    const current=await load(b.id);
    const rawEdit={...input("QA-REM-B"),items:current.items.map((i,n)=>({...input("QA-REM-B").items[n],id:i.id}))};
    await expect(db.$transaction(tx=>saveCustomerOrder(tx,{...rawEdit,items:rawEdit.items.map((i,n)=>({...i,quantity:n===0?.5:5}))},session.id,b.id,current.updatedAt.toISOString()))).rejects.toThrow("menor");
    await expect(db.$transaction(tx=>saveCustomerOrder(tx,{...rawEdit,items:rawEdit.items.slice(1)},session.id,b.id,current.updatedAt.toISOString()))).rejects.toThrow("historial");
    await expect(db.$transaction(tx=>saveCustomerOrder(tx,{...rawEdit,items:rawEdit.items.map((i,n)=>({...i,unit:n===0?"KG":"PZA"}))},session.id,b.id,current.updatedAt.toISOString()))).rejects.toThrow("unidad");
  });
  it("PDF privado, duplicado archivado y vendedor bloqueado",async()=>{
    const bytes=await buildCustomerOrdersPendingPdf({company:{legalName:"Tooling Prection",tradeName:"Tooling Prection"},rows:[],filterLabel:"Prueba"});
    const form=()=>{const f=new FormData();f.set("data",JSON.stringify(input("QA-PDF")));f.set("reviewed","true");f.set("pdf",new File([Uint8Array.from(bytes)],"ejemplo.pdf",{type:"application/pdf"}));return f;};
    const response=await POST(new Request("http://local/api",{method:"POST",body:form()}));const data=await response.json();expect(response.status,JSON.stringify(data)).toBe(200);
    const file=await db.customerOrderAttachment.findFirstOrThrow({where:{orderId:data.id}});
    expect((await document(new Request("http://local/api?id="+file.id))).status).toBe(200);
    await db.$transaction(tx=>changeCustomerOrderState(tx,data.id,"archive",session.id));
    expect((await POST(new Request("http://local/api",{method:"POST",body:form()}))).status).toBe(400);
    session.role="SALES";expect((await POST(new Request("http://local/api",{method:"POST",body:form()}))).status).toBe(403);expect((await GET(new Request("http://local/api?id="+data.id))).status).toBe(200);session.role="ADMIN";
  });
});
