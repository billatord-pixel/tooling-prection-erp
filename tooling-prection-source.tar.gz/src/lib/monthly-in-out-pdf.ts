import { PDFDocument,rgb } from "pdf-lib";
import { drawBrandedPdfHeader,loadOperationalPdfAssets,pdfBrand,wrapOperationalPdfText } from "@/lib/customer-order-pdf-assets";
import type { InOutReport } from "@/lib/monthly-in-out";
import { monthlyInvoiceDateLabel } from "@/lib/monthly-invoice-date";
const qty=(value:number)=>value.toLocaleString("es-MX",{maximumFractionDigits:3});
export async function createMonthlyInOutPdf(report:InOutReport,company:{tradeName:string;taxId?:string|null;email?:string|null},logoBytes?:Uint8Array) {
  const title="Entradas y salidas";
  const pdf=await PDFDocument.create();pdf.setTitle(title+" - "+report.month);pdf.setAuthor(company.tradeName);
  const {regular,bold,logo}=await loadOperationalPdfAssets(pdf,logoBytes,{report,company});
  const width=792,height=612,left=32,right=760,cols=[86,174,135,115,115,52,51];
  const headings=["CÓDIGO","DESCRIPCIÓN","PROVEEDOR","COMPRA / FECHA","VENTA / FECHA","ENTRADAS","SALIDAS"];
  const strong=(i:number)=>i===0||i>=5;
  let page=pdf.addPage([width,height]),y=0,bodyTop=0;
  const monthLabel=new Intl.DateTimeFormat("es-MX",{month:"long",year:"numeric",timeZone:"UTC"}).format(new Date(report.month+"-01T12:00:00Z"));
  const generated=new Intl.DateTimeFormat("es-MX",{dateStyle:"short",timeStyle:"short",timeZone:"America/Mexico_City"}).format(new Date());
  function header(){
    drawBrandedPdfHeader(page,{margin:left,height:54,regular,bold,logo,companyName:company.tradeName,metadata:[company.taxId?"RFC "+company.taxId:"",company.email].filter(Boolean).join(" | "),section:"ENTRADAS Y SALIDAS",folio:monthLabel.toUpperCase()});
    page.drawText(title,{x:left,y:520,size:18,font:bold,color:pdfBrand.ink});
    const totals="Entradas (verde): "+(report.incomingTotals.map(t=>qty(t.quantity)+" "+t.unit).join(", ")||"0")+" | Salidas (rojo): "+(report.outgoingTotals.map(t=>qty(t.quantity)+" "+t.unit).join(", ")||"0");
    const info=monthLabel+" | "+report.purchaseInvoiceCount+" compras | "+report.salesInvoiceCount+" ventas | "+report.rows.length+" herramientas | "+totals;
    const infoLines=wrapOperationalPdfText(info,regular,8,right-left);
    infoLines.forEach((line,i)=>page.drawText(line,{x:left,y:501-i*11,size:8,font:regular,color:pdfBrand.muted}));
    y=480-(infoLines.length-1)*11;
    page.drawRectangle({x:left,y:y-25,width:right-left,height:25,color:pdfBrand.skyTint});
    let x=left;
    headings.forEach((text,i)=>{page.drawText(text,{x:x+5,y:y-15,size:6.7,font:bold,color:pdfBrand.ink});x+=cols[i];});
    y-=25;bodyTop=y;
  }
  function next(){page=pdf.addPage([width,height]);header();}
  header();
  for(const [index,row]of report.rows.entries()){
    const refs=(invoices:typeof row.purchases,col:number)=>invoices.length?invoices.flatMap(invoice=>wrapOperationalPdfText(invoice.folio+" | "+monthlyInvoiceDateLabel(invoice.issueDate),regular,8,cols[col]-12)):["-"];
    const cells=[row.code,row.description,row.suppliers.map(s=>s.name).join("; ")||"-","","",qty(row.incoming)+" "+row.unit,qty(row.outgoing)+" "+row.unit];
    const lines=cells.map((cell,i)=>i===3?refs(row.purchases,i):i===4?refs(row.sales,i):wrapOperationalPdfText(cell,strong(i)?bold:regular,8,cols[i]-12));
    const count=Math.max(...lines.map(c=>c.length)),rowHeight=Math.max(29,14+count*11);
    if(y-rowHeight<54&&rowHeight<=bodyTop-54)next();
    let offset=0;
    while(offset<count){
      if(y<85)next();
      const fits=Math.max(1,Math.floor((y-54-14)/11)),take=Math.min(fits,count-offset),h=Math.max(29,14+take*11);
      if(index%2===1)page.drawRectangle({x:left,y:y-h,width:right-left,height:h,color:pdfBrand.paper});
      let x=left;
      lines.forEach((cell,i)=>{cell.slice(offset,offset+take).forEach((text,n)=>page.drawText(text,{x:x+6,y:y-14-n*11,size:8,font:strong(i)?bold:regular,color:i===5?rgb(.05,.42,.20):i===6?rgb(.72,.10,.13):pdfBrand.ink}));x+=cols[i];});
      page.drawLine({start:{x:left,y:y-h},end:{x:right,y:y-h},thickness:.4,color:pdfBrand.border});y-=h;offset+=take;
      if(offset<count){next();page.drawText("Continuación de herramienta: "+row.code,{x:left,y:y-12,size:7,font:bold,color:pdfBrand.muted});y-=24;}
    }
  }
  if(!report.rows.length)page.drawText("No hay compras ni ventas en el mes seleccionado.",{x:left,y:y-25,size:10,font:regular,color:pdfBrand.muted});
  pdf.getPages().forEach((p,i,pages)=>{
    p.drawLine({start:{x:left,y:30},end:{x:right,y:30},thickness:.5,color:pdfBrand.border});
    p.drawText("Cantidades facturadas del mes | No representa existencia ni saldo inicial.",{x:left,y:17,size:6.3,font:regular,color:pdfBrand.muted});
    const footer="Generado "+generated+" | Página "+(i+1)+" de "+pages.length;
    p.drawText(footer,{x:right-regular.widthOfTextAtSize(footer,6.3),y:17,size:6.3,font:regular,color:pdfBrand.muted});
  });
  return pdf.save();
}
