import { z } from "zod";
import { Prisma } from "@prisma/client";

import {
  customerOrderStatuses,
  dateOnly,
  mexicoToday,
  remainingDays,
  normalizeCustomerFolio,
} from "@/lib/customer-order-calendar";
export {
  customerOrderStatuses,
  dateOnly,
  displayOrderDate,
  mexicoToday,
  remainingDays,
  normalizeCustomerFolio,
} from "@/lib/customer-order-calendar";
const decimal = (value: unknown) => new Prisma.Decimal(String(value ?? 0));
export type TrackingItem = {
  quantity: unknown;
  dueDate?: Date | null;
  deliveries: Array<{ quantity: unknown; deletedAt?: Date | null }>;
  allocations: Array<{
    quantity: unknown;
    purchaseOrderLine: {
      purchaseOrder: {
        status: string;
        deletedAt?: Date | null;
        folio: string;
        id: string;
      };
    };
  }>;
};
export function itemProgress(item: TrackingItem) {
  const delivered = item.deliveries
    .filter((d) => !d.deletedAt)
    .reduce((sum, d) => sum.plus(decimal(d.quantity)), decimal(0));
  const linked = item.allocations
    .filter(
      (a) =>
        !a.purchaseOrderLine.purchaseOrder.deletedAt &&
        !["CANCELLED", "ARCHIVED"].includes(a.purchaseOrderLine.purchaseOrder.status),
    )
    .reduce((sum, a) => sum.plus(decimal(a.quantity)), decimal(0));
  const requested = item.allocations
    .filter(
      (a) =>
        !a.purchaseOrderLine.purchaseOrder.deletedAt &&
        !["CANCELLED", "ARCHIVED", "DRAFT"].includes(
          a.purchaseOrderLine.purchaseOrder.status,
        ),
    )
    .reduce((sum, a) => sum.plus(decimal(a.quantity)), decimal(0));
  return {
    delivered: delivered.toNumber(),
    pending: Prisma.Decimal.max(
      0,
      decimal(item.quantity).minus(delivered),
    ).toNumber(),
    requested: requested.toNumber(),
    linked: linked.toNumber(),
    unrequested: Prisma.Decimal.max(
      0,
      decimal(item.quantity).minus(Prisma.Decimal.max(requested, delivered)),
    ).toNumber(),
  };
}
export function orderProgress(
  order: { status: string; dueDate?: Date | null; items: TrackingItem[] },
  today = mexicoToday(),
) {
  const lines = order.items.map((item) => ({
    ...itemProgress(item),
    dueDate: item.dueDate ?? order.dueDate ?? null,
  }));
  const pending = lines.reduce((s, l) => s + l.pending, 0),
    delivered = lines.reduce((s, l) => s + l.delivered, 0);
  const status =
    order.status === "CANCELLED"
      ? "CANCELLED"
      : pending === 0
        ? "DELIVERED"
        : delivered > 0
          ? "PARTIAL"
          : "PENDING";
  const open = lines.filter((l) => l.pending > 0);
  const dates = open
    .flatMap((l) => (l.dueDate ? [dateOnly(l.dueDate)] : []))
    .sort();
  const nextDueDate = dates[0] ?? null;
  const days = nextDueDate ? remainingDays(nextDueDate, today) : null;
  return {
    status: status as keyof typeof customerOrderStatuses,
    pending,
    delivered,
    nextDueDate,
    days,
    missingDates: open.some((l) => !l.dueDate),
    unrequested: lines.reduce((s, l) => s + l.unrequested, 0),
    requested: lines.reduce((s, l) => s + l.requested, 0),
    linked: lines.reduce((s, l) => s + l.linked, 0),
  };
}
export function assertCapacity(
  total: unknown,
  used: unknown,
  adding: unknown,
  label = "La cantidad",
) {
  const qty = decimal(adding);
  if (qty.lte(0) || decimal(used).plus(qty).gt(decimal(total)))
    throw new Error(`${label} supera la cantidad disponible o no es positiva.`);
}
export function matchesCustomerDeadline(
  item: TrackingItem,
  orderDueDate: Date | null | undefined,
  filters: { state?: string; from?: string; to?: string },
  today = mexicoToday(),
) {
  const state = filters.state ?? "pending";
  if ((filters.from || filters.to) && itemProgress(item).pending <= 0) return false;
  if (
    ["pending", "PENDING", "PARTIAL", "overdue", "soon", "undated"].includes(
      state,
    ) &&
    itemProgress(item).pending <= 0
  )
    return false;
  const due = item.dueDate ?? orderDueDate;
  const day = due ? dateOnly(due) : null;
  if (
    (filters.from && (!day || day < filters.from)) ||
    (filters.to && (!day || day > filters.to))
  )
    return false;
  const days = day ? remainingDays(day, today) : null;
  if (state === "overdue") return days !== null && days < 0;
  if (state === "soon") return days !== null && days >= 0 && days <= 7;
  if (state === "undated") return day === null;
  return true;
}
const optionalText = (max: number) =>
  z
    .string()
    .trim()
    .max(max)
    .nullish()
    .transform((v) => v || undefined);
const isoDate = z
  .string()
  .regex(/^\d{4}-\d{2}-\d{2}$/, "Indica una fecha válida.")
  .refine(
    (v) =>
      Number.isFinite(Date.parse(`${v}T12:00:00Z`)) &&
      new Date(`${v}T12:00:00Z`).toISOString().slice(0, 10) === v,
    "La fecha no existe.",
  );
const optionalDate = isoDate.optional();
const qty = z.coerce
  .number()
  .finite()
  .positive()
  .max(1e10)
  .refine(
    (v) => Math.abs(v * 10000 - Math.round(v * 10000)) < 0.0001,
    "Usa máximo cuatro decimales.",
  );
export const customerOrderItemSchema = z.object({
  lineNumber: z.coerce.number().int().min(1).max(100000).optional(),
  id: z.string().min(1).max(100).optional(),
  productId: z.string().min(1).max(100).optional(),
  customerCode: optionalText(200),
  description: z.string().trim().min(1, "Escribe la descripción.").max(3000),
  quantity: qty,
  unit: z.string().trim().min(1).max(20),
  unitPrice: z.coerce.number().finite().min(0).max(1e12).optional(),
  dueDate: optionalDate,
  notesText: optionalText(4000),
});
export const customerOrderSchema = z.object({
  customerId: z.string().min(1).max(100),
  folio: z
    .string()
    .trim()
    .min(1, "Escribe el folio original.")
    .max(100)
    .refine((v) => !!normalizeCustomerFolio(v), "El folio no es válido."),
  revision: z.string().trim().max(40).default(""),
  orderDate: isoDate,
  dueDate: optionalDate,
  deadlineText: optionalText(500),
  currency: z.enum(["MXN", "USD", "EUR"]),
  declaredTotal: z.coerce.number().finite().min(0).max(1e14).optional(),
  contactName: optionalText(200),
  deliveryAddress: optionalText(4000),
  notesText: optionalText(8000),
  items: z
    .array(customerOrderItemSchema)
    .min(1, "Agrega al menos una partida.")
    .max(200),
});
export const trackingQuantitySchema = qty;
