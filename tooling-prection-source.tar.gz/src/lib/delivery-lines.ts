import { Prisma } from "@prisma/client";

export function aggregateDeliveryLines(
  lines: Array<{ productId: string; quantity: Prisma.Decimal | number | string }>,
) {
  const quantities = new Map<string, Prisma.Decimal>();
  for (const line of lines) {
    const quantity = new Prisma.Decimal(line.quantity);
    quantities.set(
      line.productId,
      (quantities.get(line.productId) ?? new Prisma.Decimal(0)).plus(quantity),
    );
  }
  return [...quantities].map(([productId, quantity]) => ({
    productId,
    quantity,
  }));
}
