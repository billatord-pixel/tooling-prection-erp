import { Role } from "@prisma/client";

export type Permission = "read" | "create" | "update" | "archive" | "process" | "admin";

const rules: Record<Role, Permission[]> = {
  ADMIN: ["read", "create", "update", "archive", "process", "admin"],
  // Legacy database enum values remain only for a safe rollout; they receive
  // the least-privilege behavior and are normalized to SALES by the seed.
  PURCHASES: ["read"],
  SALES: ["read"],
  INVENTORY: ["read"],
  READONLY: ["read"],
};

export function can(role: Role, permission: Permission) {
  return rules[role].includes(permission);
}
