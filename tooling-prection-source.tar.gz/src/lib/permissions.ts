import { Role } from "@prisma/client";

export type Permission = "read" | "create" | "update" | "archive" | "process" | "admin";

const rules: Record<Role, Permission[]> = {
  ADMIN: ["read", "create", "update", "archive", "process", "admin"],
  PURCHASES: ["read", "create", "update", "archive", "process"],
  SALES: ["read", "create", "update", "archive", "process"],
  INVENTORY: ["read", "create", "update", "process"],
  READONLY: ["read"],
};

export function can(role: Role, permission: Permission) {
  return rules[role].includes(permission);
}
