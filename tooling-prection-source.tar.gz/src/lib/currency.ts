/** Exchange rate is expressed as MXN for one USD. */
export function convertAmount(amount: number, from: string, to: string, mxnPerUsd: number): number | null {
  if (!Number.isFinite(amount)) return null;
  if (from === to) return amount;
  if (!Number.isFinite(mxnPerUsd) || mxnPerUsd <= 1) return null;
  if (from === "USD" && to === "MXN") return amount * mxnPerUsd;
  if (from === "MXN" && to === "USD") return amount / mxnPerUsd;
  return null;
}
