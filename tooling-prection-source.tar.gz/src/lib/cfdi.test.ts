import { describe, expect, it } from "vitest";
import { normalizedDescription, parseCfdi } from "./cfdi";

const xml = `<?xml version="1.0"?><cfdi:Comprobante xmlns:cfdi="http://www.sat.gob.mx/cfd/4" xmlns:tfd="http://www.sat.gob.mx/TimbreFiscalDigital" Serie="A" Folio="12" Fecha="2026-10-01T10:00:00" Moneda="MXN" SubTotal="100.00" Total="116.00" FormaPago="03" MetodoPago="PUE"><cfdi:Emisor Rfc="AAA010101AAA" Nombre="Proveedor prueba"/><cfdi:Receptor Rfc="BBB010101BBB" Nombre="Tooling Prection"/><cfdi:Conceptos><cfdi:Concepto NoIdentificacion="WNMG432" Cantidad="2" ClaveUnidad="H87" Descripcion="Inserto de carburo" ValorUnitario="50" Importe="100"/></cfdi:Conceptos><cfdi:Impuestos TotalImpuestosTrasladados="16"/><cfdi:Complemento><tfd:TimbreFiscalDigital UUID="11111111-1111-1111-1111-111111111111"/></cfdi:Complemento></cfdi:Comprobante>`;

describe("CFDI", () => {
  it("extrae los datos necesarios para una factura", () => {
    const cfdi = parseCfdi(xml);
    expect(cfdi.uuid).toBe("11111111-1111-1111-1111-111111111111");
    expect(cfdi.issuer.rfc).toBe("AAA010101AAA");
    expect(cfdi.concepts).toEqual([expect.objectContaining({ code: "WNMG432", quantity: 2, amount: 100 })]);
    expect(cfdi.exchangeRate).toBe(1);
  });

  it("captura el TipoCambio del comprobante USD en MXN por unidad", () => {
    const usdXml = xml.replace('Moneda="MXN"', 'Moneda="USD" TipoCambio="17.811700"');
    expect(parseCfdi(usdXml).exchangeRate).toBe(17.8117);
  });

  it("normaliza descripciones para cotejo explícito", () => {
    expect(normalizedDescription("  Inserto  de  CÁRBURO ")).toBe("inserto de carburo");
  });
});
