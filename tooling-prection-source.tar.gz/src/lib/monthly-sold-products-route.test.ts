import { beforeEach,describe,it,expect,vi } from "vitest";
const mock=vi.hoisted(()=>({session:vi.fn(),invoices:vi.fn()}));
vi.mock("@/lib/auth",()=>({currentSession:mock.session}));
vi.mock("@/lib/db",()=>({db:{salesInvoice:{findMany:mock.invoices},companySettings:{findFirst:async()=>({tradeName:"Tooling Prection"})}}}));
import { GET } from "@/app/api/reports/sold-products/route";
describe("reporte de herramientas: consulta privada sin mutaciones",()=>{
  beforeEach(()=>{vi.clearAllMocks();mock.session.mockResolvedValue({id:"u",role:"SALES"});mock.invoices.mockResolvedValue([{id:"f1",folio:"F-1",issueDate:new Date("2026-10-01T00:00:00Z"),rawXml:null,lines:[{description:"Redacción fiscal",quantity:2,unit:"H87",product:{technicalCode:"EDP 123",description:"Herramienta catálogo",unit:"PZA"}}]}]);});
  it("sin sesión está protegido",async()=>{mock.session.mockResolvedValue(null);expect((await GET(new Request("http://local/api?month=2026-10"))).status).toBe(401);expect(mock.invoices).not.toHaveBeenCalled();});
  it("vendedor puede consultar sin ampliar permisos de escritura",async()=>{const r=await GET(new Request("http://local/api?month=2026-10"));expect(r.status).toBe(200);expect((await r.json()).rows[0]).toMatchObject({code:"EDP 123",description:"Herramienta catálogo",quantity:2});});
  it("vendedor puede imprimir este reporte no financiero",async()=>{const r=await GET(new Request("http://local/api?month=2026-10&format=pdf"));expect(r.status).toBe(200);expect(r.headers.get("content-type")).toBe("application/pdf");});
  it("filtra por mes fiscal y excluye canceladas, borradores y archivadas",async()=>{await GET(new Request("http://local/api?month=2026-10"));const args=mock.invoices.mock.calls[0][0];expect(args.select.issueDate).toBe(true);expect(args.where.status).toEqual({notIn:["CANCELLED","DRAFT"]});expect(args.where.archivedAt).toBeNull();expect(args.where.issueDate.gte.toISOString()).toBe("2026-10-01T00:00:00.000Z");expect(args.where.issueDate.lt.toISOString()).toBe("2026-11-01T00:00:00.000Z");});
  it("un código XML sin asociación de catálogo se conserva sin adivinar",async()=>{mock.invoices.mockResolvedValue([{id:"f1",folio:"F-1",issueDate:new Date("2026-10-01T00:00:00Z"),rawXml:'<Comprobante><Conceptos><Concepto NoIdentificacion="EDP 77" Descripcion="Herramienta libre" Cantidad="2"/></Conceptos></Comprobante>',lines:[{description:"Herramienta libre",quantity:2,unit:"PZA",product:null}]}]);const r=await GET(new Request("http://local/api?month=2026-10"));expect((await r.json()).rows[0].code).toBe("EDP 77");});
  it("incluye la fecha fiscal de la factura en cada referencia",async()=>{const r=await GET(new Request("http://local/api?month=2026-10"));expect((await r.json()).rows[0].invoices[0].issueDate).toBe("2026-10-01");});
  it("mes inválido no consulta datos",async()=>{expect((await GET(new Request("http://local/api?month=2026-13"))).status).toBe(400);expect(mock.invoices).not.toHaveBeenCalled();});
  it("incluye todos los meses del rango y rechaza un rango invertido",async()=>{
    const response=await GET(new Request("http://local/api?month=2026-09&endMonth=2026-10"));
    expect(await response.json()).toMatchObject({month:"2026-09",endMonth:"2026-10",invoiceCount:1});
    expect(mock.invoices.mock.calls[0][0].where.issueDate).toEqual({gte:new Date("2026-09-01"),lt:new Date("2026-11-01")});
    const invalid=await GET(new Request("http://local/api?month=2026-10&endMonth=2026-09"));
    expect(invalid.status).toBe(400);
    expect(mock.invoices).toHaveBeenCalledTimes(1);
  });
});
