import { z } from "zod";
import { db } from "@/lib/db";

export const quoteSchema = z.object({
  customerId: z.string().optional().nullable(), contactName: z.string().optional(), attention: z.string().optional(),
  issueDate: z.string().optional(), validUntil: z.string().optional(), sellerName: z.string().optional(),
  shippingMethod: z.string().optional(), currency: z.enum(["MXN", "USD", "EUR"]).default("MXN"),
  exchangeRate: z.coerce.number().positive().default(1), taxRate: z.coerce.number().min(0).max(100).default(16),
  paymentTerms: z.string().optional(), notes: z.string().optional(),
  lines: z.array(z.object({ productId: z.string().optional().nullable(), productCode: z.string().trim().optional(), description: z.string().trim().min(1), leadTime: z.string().trim().optional(), quantity: z.coerce.number().positive(), listPrice: z.coerce.number().min(0), costPrice: z.coerce.number().min(0).optional(), discount: z.coerce.number().min(0).max(100).default(0) })).min(1),
});
const money = (value: number) => Math.round((value + Number.EPSILON) * 100) / 100;

export async function calculateLines(input: z.infer<typeof quoteSchema>) {
  const ids = [...new Set(input.lines.map(line => line.productId).filter((id): id is string => !!id))];
  const products = ids.length ? await db.product.findMany({ where: { id: { in: ids }, status: "ACTIVE" } }) : [];
  if (products.length !== ids.length) throw new Error("Una o más partidas seleccionadas ya no corresponden a productos activos.");
  const lines = input.lines.map(item => {
    const product = products.find(candidate => candidate.id === item.productId);
    const listPrice = money(item.listPrice); const unitPrice = money(listPrice * (1 - item.discount / 100));
    const costPrice = product ? money(Number(product.baseCost) / input.exchangeRate) : item.costPrice === undefined ? null : money(item.costPrice / input.exchangeRate);
    return { productId: product?.id ?? null, productCode: product?.technicalCode ?? item.productCode?.trim() ?? null, description: item.description.trim(), leadTime: item.leadTime?.trim() || null, quantity: item.quantity, listPrice, costPrice, unitPrice, discount: item.discount, amount: money(item.quantity * unitPrice) };
  });
  const gross = lines.reduce((sum, item) => sum + Number(item.listPrice) * Number(item.quantity), 0);
  const subtotal = money(lines.reduce((sum, item) => sum + Number(item.amount), 0));
  const discount = money(gross - subtotal); const tax = money(subtotal * input.taxRate / 100);
  return { lines, subtotal, discount, tax, total: money(subtotal + tax) };
}
