import { XMLParser } from "fast-xml-parser";

const attr = (node: Record<string, unknown>, key: string) => String(node[`@_${key}`] ?? "");
const number = (value: string) => Number(value || 0);
const asArray = <T>(value: T | T[] | undefined): T[] => value === undefined ? [] : Array.isArray(value) ? value : [value];

export type ParsedCfdi = {
  uuid?: string; series?: string; folio?: string; issueDate: Date; currency: string; exchangeRate: number | null; subtotal: number; total: number;
  tax: number; paymentForm?: string; paymentMethod?: string;
  issuer: { rfc: string; name: string }; receiver: { rfc: string; name: string };
  concepts: Array<{ description: string; quantity: number; unit?: string; unitPrice: number; amount: number; code?: string }>;
};

export function parseCfdi(xml: string): ParsedCfdi {
  const document = new XMLParser({ ignoreAttributes: false, attributeNamePrefix: "@_", removeNSPrefix: true }).parse(xml);
  const comprobante = document.Comprobante;
  if (!comprobante) throw new Error("El archivo no contiene un CFDI Comprobante válido.");
  const impuestos = comprobante.Impuestos ?? {};
  const complemento = comprobante.Complemento ?? {};
  const timbre = complemento.TimbreFiscalDigital ?? complemento["tfd:TimbreFiscalDigital"] ?? {};
  const conceptos = asArray(comprobante.Conceptos?.Concepto).map((concepto: Record<string, unknown>) => ({
    description: attr(concepto, "Descripcion"), quantity: number(attr(concepto, "Cantidad")), unit: attr(concepto, "Unidad") || attr(concepto, "ClaveUnidad"),
    unitPrice: number(attr(concepto, "ValorUnitario")), amount: number(attr(concepto, "Importe")), code: attr(concepto, "NoIdentificacion"),
  }));
  const currency = attr(comprobante, "Moneda") || "MXN";
  const exchangeRateValue = number(attr(comprobante, "TipoCambio"));
  return {
    uuid: attr(timbre, "UUID") || undefined, series: attr(comprobante, "Serie") || undefined, folio: attr(comprobante, "Folio") || undefined,
    issueDate: new Date(attr(comprobante, "Fecha")), currency, exchangeRate: currency === "MXN" ? 1 : exchangeRateValue > 0 ? exchangeRateValue : null, subtotal: number(attr(comprobante, "SubTotal")), total: number(attr(comprobante, "Total")),
    tax: number(attr(impuestos, "TotalImpuestosTrasladados")), paymentForm: attr(comprobante, "FormaPago") || undefined, paymentMethod: attr(comprobante, "MetodoPago") || undefined,
    issuer: { rfc: attr(comprobante.Emisor ?? {}, "Rfc"), name: attr(comprobante.Emisor ?? {}, "Nombre") },
    receiver: { rfc: attr(comprobante.Receptor ?? {}, "Rfc"), name: attr(comprobante.Receptor ?? {}, "Nombre") }, concepts: conceptos,
  };
}

export function normalizedDescription(value: string) {
  return value.toLocaleLowerCase("es-MX").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\s+/g, " ").trim();
}
