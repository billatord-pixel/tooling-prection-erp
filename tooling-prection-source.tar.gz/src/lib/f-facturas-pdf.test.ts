import { describe,it,expect } from "vitest";
import { createFFacturasPdf } from "./f-facturas-pdf";
import { readCustomerOrderPdf } from "./customer-order-pdf-reader";

describe("F-Facturas compact PDF",()=>{
  it.each([[0,1],[70,1],[71,2],[140,2],[141,3]])("keeps %i invoices within %i pages without blank overflow",async(count,pages)=>{
    const invoices=Array.from({length:count},(_,i)=>({folio:`F-${1000+i}`,total:1234.56,currency:i%2 ? "MXN":"USD",mxnTotal:i%2 ? 1234.56 : 22222.08})).reverse();
    const bytes=await createFFacturasPdf({invoices,period:"Todos los periodos",statusLabel:"Todas"});
    expect((bytes.toString("latin1").match(/\/Type\s*\/Page\b/g)||[]).length).toBe(pages);
    const text=await readCustomerOrderPdf(bytes);
    const folios=text.match(/F-\d+/g)||[];
    expect(folios.length).toBe(count);
    expect(new Set(folios).size).toBe(count);
    if(count){expect(text).toContain("USD 1,234.56");expect(text).toContain("MXN 1,234.56");expect(text).toContain("MXN 22,222.08");expect(text).toMatch(/F-1001\s+-\s+MXN 1,234.56/);}
  });
});
