import { z } from "zod";

export const productSchema = z.object({
  technicalCode: z.string().trim().min(1, "El código técnico es obligatorio.").max(100),
  description: z.string().trim().min(1, "La descripción es obligatoria.").max(2000),
  fiscalDescription: z.string().trim().max(1000).optional().nullable(),
  unit: z.string().trim().min(1).max(20).default("PZA"),
  currency: z.enum(["USD", "MXN", "EUR"]).default("USD"),
  baseCost: z.coerce.number().min(0).default(0),
  salePrice: z.coerce.number().min(0).default(0),
  minimumStock: z.coerce.number().min(0).default(0),
  brandId: z.string().trim().optional().nullable(),
  categoryId: z.string().trim().optional().nullable(),
  mainSupplierId: z.string().trim().optional().nullable(),
  leadTimeDays: z.coerce.number().int().min(0).optional().nullable(),
});
