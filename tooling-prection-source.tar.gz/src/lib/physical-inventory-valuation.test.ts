import { describe, expect, it } from "vitest";
import { physicalInventoryByProduct, summarizePhysicalInventory } from "./physical-inventory-valuation";

const lines = [
  { quantity: "10", unitPrice: "8.21", printedAmount: "82.13" },
  { quantity: "-2", unitPrice: "3.25", printedAmount: "-6.50" },
  { quantity: "0", unitPrice: null, printedAmount: null },
];

describe("valuación del corte físico", () => {
  it("suma por partida y concilia el importe impreso sin perder el precio visible", () => {
    expect(summarizePhysicalInventory({ title: "Corte", currency: "USD", documentTotal: "75.63", lines }))
      .toMatchObject({ currency: "USD", lines: 3, calculatedTotal: 75.60, roundingAdjustment: .03, adjustedLines: 1, total: 75.63 });
  });

  it("rechaza un total incompleto o una partida con saldo y sin precio", () => {
    expect(() => summarizePhysicalInventory({ title: "Corte", currency: "USD", documentTotal: "75.60", lines })).toThrow("no coincide");
    expect(() => summarizePhysicalInventory({ title: "Corte", currency: "USD", documentTotal: "0", lines: [{ ...lines[2], quantity: 1 }] })).toThrow("requiere precio");
  });

  it("aplica la corrección de una partida sin perder el importe original del documento", () => {
    const corrected = { ...lines[0], useCalculatedAmount: true };
    const snapshot = { title: "Corte", currency: "USD", documentTotal: "75.63", lines: [corrected, ...lines.slice(1)] };
    expect(summarizePhysicalInventory(snapshot)).toMatchObject({ calculatedTotal: 75.60, total: 75.60, roundingAdjustment: 0, adjustedLines: 0 });
    expect(physicalInventoryByProduct([{ ...corrected, productId: "p", review: null }]).get("p"))
      .toEqual({ quantity: 10, amount: 82.10, unitPrices: [8.21] });
    expect(corrected.printedAmount).toBe("82.13");
  });

  it("muestra precios y cantidades del PDF incluso si la ficha se vinculó en la revisión", () => {
    const byProduct = physicalInventoryByProduct([
      { ...lines[0], productId: "p", review: null },
      { ...lines[1], productId: null, review: { productId: "p" } },
      { ...lines[2], productId: null, review: { productId: null } },
    ]);
    expect([...byProduct]).toEqual([["p", { quantity: 8, amount: 75.63, unitPrices: [3.25, 8.21] }]]);
  });
});
