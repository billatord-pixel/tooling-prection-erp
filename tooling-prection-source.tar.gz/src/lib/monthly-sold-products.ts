import { Prisma } from "@prisma/client";

export type MonthlyProductInvoice = { id:string; folio:string; issueDate?:string };
export type SoldProductLine = { code?: string | null; description: string; quantity: unknown; unit?: string | null; invoiceId: string; folio: string; issueDate?:string };
export type MonthlySoldProduct = { code: string; description: string; unit: string; quantity: number; invoices: MonthlyProductInvoice[]; suppliers?: Array<{id:string;name:string}> };
export type MonthlySoldProductsReport = { month: string; invoiceCount: number; productCount: number; totalsByUnit: Array<{unit:string;quantity:number}>; rows: MonthlySoldProduct[] };
export function monthlyInvoiceRange(month: string) {
  if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(month) || Number(month.slice(0,4))<1900 || Number(month.slice(0,4))>9998) throw Error("Selecciona un mes válido (AAAA-MM).");
  const start=new Date(month+"-01T00:00:00.000Z"), end=new Date(start);
  end.setUTCMonth(end.getUTCMonth()+1);
  return {gte:start,lt:end};
}
const clean=(value:string)=>value.normalize("NFKC").trim().replace(/\s+/g," ");
export function soldProductUnit(unit?:string|null) {
  const value=clean(unit||"PZA").toUpperCase();
  return ["H87","PZA","PZ","PZAS","PIEZA","PIEZAS","PC","PCS","EA"].includes(value)?"PZA":value;
}
/** One row per tool code + description + compatible unit, never per invoice. */
export function groupMonthlySoldProducts(month:string,lines:SoldProductLine[],invoiceCount?:number):MonthlySoldProductsReport {
  monthlyInvoiceRange(month);
  const groups=new Map<string,{code:string;description:string;unit:string;quantity:Prisma.Decimal;invoices:Map<string,MonthlyProductInvoice>}>();
  const invoiceIds=new Set<string>();
  for(const line of lines){
    const code=clean(line.code||"")||"Sin código",description=clean(line.description)||"Sin descripción",unit=soldProductUnit(line.unit);
    const key=JSON.stringify([code.toUpperCase(),description.toLocaleUpperCase("es-MX"),unit]);
    const quantity=new Prisma.Decimal(String(line.quantity));
    if(!quantity.isFinite()) throw Error("Existe una partida con cantidad inválida.");
    const row=groups.get(key)||{code,description,unit,quantity:new Prisma.Decimal(0),invoices:new Map()};
    row.quantity=row.quantity.plus(quantity);
    row.invoices.set(line.invoiceId,{id:line.invoiceId,folio:line.folio,...(line.issueDate?{issueDate:line.issueDate}: {})});
    invoiceIds.add(line.invoiceId);groups.set(key,row);
  }
  const collator=new Intl.Collator("es-MX",{numeric:true,sensitivity:"base"});
  const rows=[...groups.values()].map(row=>({code:row.code,description:row.description,unit:row.unit,quantity:row.quantity.toNumber(),invoices:[...row.invoices.values()].sort((a,b)=>collator.compare(a.folio,b.folio))})).sort((a,b)=>collator.compare(a.code,b.code)||collator.compare(a.description,b.description)||collator.compare(a.unit,b.unit));
  const totals=new Map<string,Prisma.Decimal>();
  for(const row of groups.values()) totals.set(row.unit,(totals.get(row.unit)||new Prisma.Decimal(0)).plus(row.quantity));
  return {month,invoiceCount:invoiceCount??invoiceIds.size,productCount:rows.length,totalsByUnit:[...totals].map(([unit,quantity])=>({unit,quantity:quantity.toNumber()})),rows};
}
