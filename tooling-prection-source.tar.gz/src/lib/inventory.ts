import { DocumentType, InventoryMovementType, Prisma } from "@prisma/client";
import { db } from "@/lib/db";

export type MovementInput = {
  productId: string;
  type: InventoryMovementType;
  quantity: Prisma.Decimal | number | string;
  sourceType: DocumentType;
  sourceId: string;
  notes?: string;
  purchaseInvoiceId?: string;
  salesInvoiceId?: string;
  deliveryId?: string;
  reversalOfId?: string;
};

export async function applyMovementInTransaction(tx: Prisma.TransactionClient, input: MovementInput) {
  const exists = await tx.inventoryMovement.findUnique({ where: { productId_sourceType_sourceId_type: { productId: input.productId, sourceType: input.sourceType, sourceId: input.sourceId, type: input.type } } });
  if (exists) return exists;
  const product = await tx.product.update({ where: { id: input.productId }, data: { stock: { increment: input.quantity } } });
  const newStock = new Prisma.Decimal(product.stock);
  // A valid receipt must be recorded even when earlier purchases/opening stock
  // are missing. Only outgoing non-invoice operations enforce available stock.
  if (newStock.isNegative() && new Prisma.Decimal(input.quantity).isNegative() && input.type !== InventoryMovementType.SALE) throw new Error(`Existencia insuficiente para ${product.description}.`);
  return tx.inventoryMovement.create({ data: { ...input, quantity: input.quantity, balanceAfter: newStock } });
}

export async function applyMovement(input: MovementInput) {
  return db.$transaction(tx => applyMovementInTransaction(tx, input));
}
