import { DocumentType, InventoryMovementType, Prisma } from "@prisma/client";
import { db } from "@/lib/db";

export async function applyMovement(input: { productId: string; type: InventoryMovementType; quantity: number; sourceType: DocumentType; sourceId: string; notes?: string; purchaseInvoiceId?: string; salesInvoiceId?: string; deliveryId?: string }) {
  return db.$transaction(async (tx) => {
    const exists = await tx.inventoryMovement.findUnique({ where: { productId_sourceType_sourceId_type: { productId: input.productId, sourceType: input.sourceType, sourceId: input.sourceId, type: input.type } } });
    if (exists) return exists;
    const product = await tx.product.findUniqueOrThrow({ where: { id: input.productId } });
    const newStock = new Prisma.Decimal(product.stock).plus(input.quantity);
    if (newStock.isNegative()) throw new Error(`Existencia insuficiente para ${product.description}.`);
    await tx.product.update({ where: { id: product.id }, data: { stock: newStock } });
    return tx.inventoryMovement.create({ data: { ...input, quantity: input.quantity, balanceAfter: newStock } });
  });
}
