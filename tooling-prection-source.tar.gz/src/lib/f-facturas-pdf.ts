import PDFDocument from "pdfkit";
import { formatMoney } from "@/lib/money-format";
import { TOOLING_PDF, drawToolingPdfRail, drawToolingPdfFooter } from "@/lib/pdf-brand";

type Options = {
  invoices: Array<{ folio: string; total: unknown; currency: string; mxnTotal: number | null }>;
  period: string;
  statusLabel: string;
  companyName?: string;
  logo?: Buffer;
};

/** Two independent, top-to-bottom tables; fixed cells never trigger flow pagination. */
export async function createFFacturasPdf(options: Options): Promise<Buffer> {
  const invoices = [...options.invoices].sort((a,b) => a.folio.localeCompare(b.folio, "es", { numeric: true }));
  const doc = new PDFDocument({ size: "LETTER", margin: 32, bufferPages: true, info: { Title: "F-Facturas", Author: options.companyName || "Tooling Prection" } });
  const chunks: Buffer[] = [];
  const done = new Promise<Buffer>((resolve,reject) => {
    doc.on("data", chunk => chunks.push(Buffer.from(chunk)));
    doc.on("end", () => resolve(Buffer.concat(chunks)));
    doc.on("error", reject);
  });
  const left = 32, gap = 16, blockWidth = 266, headerY = 112, rowY = 136, rowHeight = 17, perColumn = 35;
  const pageCount = Math.max(1, Math.ceil(invoices.length / (perColumn * 2)));
  function text(value: string, x: number, y: number, width: number, size: number, bold = false, right = false, color: string = TOOLING_PDF.ink) {
    doc.font(bold ? "Times-Bold" : "Times-Roman").fontSize(size).fillColor(color);
    if (doc.widthOfString(value) > width) doc.fontSize(size * width / doc.widthOfString(value));
    doc.text(value, right ? x + width - doc.widthOfString(value) : x, y, { lineBreak: false });
  }
  for (let page = 0; page < pageCount; page++) {
    if (page) doc.addPage();
    drawToolingPdfRail(doc);
    if (options.logo) doc.image(options.logo, left, 23, { fit: [43,35] });
    text(options.companyName || "Tooling Prection", left + (options.logo ? 54 : 0), 28, 360, 16, true, false, TOOLING_PDF.navy);
    text("F-Facturas", 430, 29, 150, 18, true, true, TOOLING_PDF.blue);
    doc.moveTo(left, 66).lineTo(580,66).lineWidth(.6).strokeColor(TOOLING_PDF.border).stroke();
    text(options.period, left, 77, 548, 10);
    text(`${options.statusLabel} · ${invoices.length} facturas · USD a MXN: FIX de Banxico de la fecha de facturación o último anterior`, left, 94, 548, 8, false, false, TOOLING_PDF.muted);
    const pageInvoices = invoices.slice(page * 70, (page + 1) * 70);
    // Balance the last page without breaking the reading order.
    const split = Math.ceil(pageInvoices.length / 2);
    for (let column = 0; column < 2; column++) {
      const x = left + column * (blockWidth + gap);
      doc.roundedRect(x, headerY, blockWidth, 22, 4).fill(TOOLING_PDF.navy);
      text("Folio", x + 8, headerY + 5, 56, 9, true, false, "#FFFFFF");
      text("Monto USD", x + 70, headerY + 5, 86, 9, true, true, "#FFFFFF");
      text("Monto MXN", x + 164, headerY + 5, 94, 9, true, true, "#FFFFFF");
      const entries = column === 0 ? pageInvoices.slice(0,split) : pageInvoices.slice(split);
      entries.forEach((invoice,index) => {
        const y = rowY + index * rowHeight;
        if (index % 2 === 0) doc.rect(x,y,blockWidth,rowHeight).fill(TOOLING_PDF.row);
        text(invoice.folio, x + 8, y + 3, 56, 9, true);
        text(invoice.currency === "USD" ? formatMoney(invoice.total,"USD") : "-", x + 70, y + 3, 86, 9, false, true);
        text(invoice.mxnTotal === null ? "Sin conversión" : formatMoney(invoice.mxnTotal,"MXN"), x + 164, y + 3, 94, 9, false, true);
        doc.moveTo(x,y+rowHeight).lineTo(x+blockWidth,y+rowHeight).lineWidth(.25).strokeColor(TOOLING_PDF.border).stroke();
      });
    }
    if (!invoices.length) text("No hay facturas con los filtros seleccionados.",left,151,548,11);
    drawToolingPdfFooter(doc, "F-Facturas | Tooling Prection", page + 1, pageCount, left, 580);
  }
  doc.end();
  return done;
}
