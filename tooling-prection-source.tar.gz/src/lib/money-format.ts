/** Explicit ISO code for both pesos and foreign currency; safe in browser and PDF. */
export function formatMoney(amount: unknown, currency = "USD") {
  const code = /^[A-Z]{3}$/.test(currency) ? currency : "USD";
  return new Intl.NumberFormat("es-MX", { style: "currency", currency: code, currencyDisplay: "code", minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(Number(amount ?? 0)).replaceAll("\u00a0", " ");
}
