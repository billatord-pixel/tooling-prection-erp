import { PDFDocument, rgb } from "pdf-lib";
import { pdfBrand, drawBrandedPdfHeader } from "@/lib/customer-order-pdf-assets";
import {
  loadOperationalPdfAssets,
  wrapOperationalPdfText,
} from "@/lib/customer-order-pdf-assets";
import {
  displayOrderDate,
  remainingDays,
  mexicoToday,
} from "@/lib/customer-orders";
export type CustomerPendingReportRow = {
  orderId?: string;
  lineNumber?: number;
  customer: string;
  folio: string;
  description: string;
  quantity: number;
  unit: string;
  dueDate?: string | null;
  suppliers: string;
  notes?: string | null;
};
export function groupCustomerPendingReportRows(
  rows: CustomerPendingReportRow[],
) {
  const groups = new Map<string, CustomerPendingReportRow[]>();
  for (const row of rows) {
    const key = row.orderId ?? JSON.stringify([row.customer, row.folio]);
    const group = groups.get(key) ?? [];
    group.push(row);
    groups.set(key, group);
  }
  const firstDeadline = (group: CustomerPendingReportRow[]) =>
    group.map((row) => row.dueDate ?? "9999").sort()[0]!;
  return [...groups.values()]
    .map((group) =>
      group.sort((a, b) => (a.lineNumber ?? 0) - (b.lineNumber ?? 0)),
    )
    .sort(
      (a, b) =>
        firstDeadline(a).localeCompare(firstDeadline(b)) ||
        a[0]!.customer.localeCompare(b[0]!.customer, "es") ||
        a[0]!.folio.localeCompare(b[0]!.folio, "es", { numeric: true }),
    );
}
export async function buildCustomerOrdersPendingPdf(input: {
  company: {
    legalName: string;
    tradeName: string;
    taxId?: string | null;
    email?: string | null;
  };
  rows: CustomerPendingReportRow[];
  filterLabel: string;
  logoBytes?: Uint8Array;
  today?: string;
}) {
  const pdf = await PDFDocument.create();
  pdf.setTitle("Órdenes de clientes pendientes de surtir");
  pdf.setAuthor("Tooling Prection ERP");
  const { regular, bold, logo } = await loadOperationalPdfAssets(
    pdf,
    input.logoBytes,
    input,
  );
  const width = 792,
    height = 612,
    margin = 32,
    today = input.today ?? mexicoToday(),
    contentWidth = width - margin * 2;
  const groups = groupCustomerPendingReportRows(input.rows);
  const cols = [55, 309, 64, 77, 83, 140];
  let page = pdf.addPage([width, height]),
    y = 0;
  const safe = (value: unknown) =>
    String(value ?? "")
      .replace(/[\u2010-\u2015]/g, "-")
      .replace(/[\r\n]+/g, " ");
  function header(continued = false) {
    drawBrandedPdfHeader(page, {
      margin,
      height: 54,
      regular,
      bold,
      logo,
      companyName: input.company.tradeName,
      metadata: [
        input.company.taxId ? `RFC ${input.company.taxId}` : null,
        input.company.email,
      ]
        .filter(Boolean)
        .join(" | "),
      section: "ÓRDENES DE CLIENTES",
      folio: continued ? "CONTINUACIÓN" : "PENDIENTES DE SURTIR",
    });
    page.drawText("Órdenes de clientes pendientes de surtir", {
      x: margin,
      y: 520,
      size: 18,
      font: bold,
      color: pdfBrand.ink,
    });
    const info = `${displayOrderDate(today)} · ${groups.length} órdenes · ${input.rows.length} partidas · ${input.filterLabel}`;
    const infoLines = wrapOperationalPdfText(info, regular, 8, contentWidth);
    infoLines.forEach((line, i) =>
      page.drawText(line, {
        x: margin,
        y: 503 - i * 10,
        size: 8,
        font: regular,
        color: pdfBrand.muted,
      }),
    );
    y = 490 - infoLines.length * 10;
    page.drawRectangle({
      x: margin,
      y: y - 26,
      width: contentWidth,
      height: 26,
      color: pdfBrand.skyTint,
    });
    let x = margin;
    [
      "PARTIDA",
      "DESCRIPCIÓN",
      "PENDIENTE",
      "FECHA LÍMITE",
      "PLAZO",
      "PEDIDOS A PROVEEDORES",
    ].forEach((label, i) => {
      const lines = wrapOperationalPdfText(label, bold, 6.3, cols[i]! - 10);
      lines.forEach((line, index) =>
        page.drawText(line, {
          x: x + 5,
          y: y - 11 - index * 8,
          size: 6.3,
          font: bold,
          color: pdfBrand.ink,
        }),
      );
      x += cols[i]!;
    });
    y -= 26;
  }
  function orderHeader(group: CustomerPendingReportRow[], continued = false) {
    const row = group[0]!;
    const label = `${safe(row.customer)} | ${safe(row.folio)} | ${group.length} ${group.length === 1 ? "partida pendiente" : "partidas pendientes"}${continued ? " | Continuación" : ""}`;
    const lines = wrapOperationalPdfText(label, bold, 8, contentWidth - 16);
    const bandHeight = 16 + lines.length * 10;
    y -= 6;
    page.drawRectangle({
      x: margin,
      y: y - bandHeight,
      width: contentWidth,
      height: bandHeight,
      color: pdfBrand.skyTint,
    });
    lines.forEach((line, i) =>
      page.drawText(line, {
        x: margin + 8,
        y: y - 13 - i * 10,
        size: 8,
        font: bold,
        color: pdfBrand.ink,
      }),
    );
    y -= bandHeight;
  }
  function cells(row: CustomerPendingReportRow, index: number) {
    const days = row.dueDate ? remainingDays(row.dueDate, today) : null;
    return [
      String(row.lineNumber ?? index + 1),
      `${row.description}${row.notes ? ` | Notas: ${row.notes}` : ""}`,
      `${row.quantity.toLocaleString("es-MX", { maximumFractionDigits: 4 })} ${row.unit}`,
      row.dueDate ? displayOrderDate(row.dueDate) : "Por confirmar",
      days === null
        ? "Fecha pendiente"
        : days < 0
          ? `${Math.abs(days)} días de atraso`
          : days === 0
            ? "Entrega hoy"
            : `${days} días restantes`,
      row.suppliers || "Sin vincular",
    ].map((value, i) =>
      wrapOperationalPdfText(
        safe(value),
        i === 0 || i === 2 ? bold : regular,
        7,
        cols[i]! - 10,
      ),
    );
  }
  function nextPage(group: CustomerPendingReportRow[]) {
    page = pdf.addPage([width, height]);
    header(true);
    orderHeader(group, true);
  }
  header();
  const bodyTop = y;
  for (const group of groups) {
    const groupLabel = `${safe(group[0]!.customer)} | ${safe(group[0]!.folio)} | ${group.length} ${group.length === 1 ? "partida pendiente" : "partidas pendientes"}`;
    const groupHeight =
      22 +
      wrapOperationalPdfText(groupLabel, bold, 8, contentWidth - 16).length *
        10 +
      group.reduce(
        (sum, row, index) =>
          sum +
          Math.max(
            27,
            14 +
              Math.max(...cells(row, index).map((column) => column.length)) * 9,
          ),
        0,
      );
    // Keep a complete small order on one page, including its different schedules.
    if (y < 130 || (groupHeight <= bodyTop - 46 && y - groupHeight < 46)) {
      page = pdf.addPage([width, height]);
      header(true);
    }
    orderHeader(group);
    for (const [index, row] of group.entries()) {
      const days = row.dueDate ? remainingDays(row.dueDate, today) : null;
      const dueColor =
        days === null
          ? pdfBrand.muted
          : days < 0
            ? rgb(0.72, 0.16, 0.16)
            : days <= 7
              ? rgb(0.64, 0.39, 0.02)
              : rgb(0.13, 0.43, 0.29);
      const lines = cells(row, index);
      const totalLines = Math.max(...lines.map((part) => part.length));
      // Keep a normal-length item together instead of splitting it at the footer.
      if (y - Math.max(27, 14 + totalLines * 9) < 46 && totalLines <= 35)
        nextPage(group);
      let offset = 0;
      while (offset < totalLines) {
        if (y < 73) nextPage(group);
        const fits = Math.max(1, Math.floor((y - 46 - 14) / 9));
        const count = Math.min(totalLines - offset, fits),
          rowHeight = Math.max(27, 14 + count * 9);
        if (index % 2 === 0)
          page.drawRectangle({
            x: margin,
            y: y - rowHeight,
            width: contentWidth,
            height: rowHeight,
            color: pdfBrand.paper,
          });
        let x = margin;
        lines.forEach((parts, i) => {
          parts.slice(offset, offset + count).forEach((line, lineIndex) =>
            page.drawText(line, {
              x: x + 5,
              y: y - 13 - lineIndex * 9,
              size: 7,
              font: i === 0 || i === 2 ? bold : regular,
              color: i === 3 || i === 4 ? dueColor : pdfBrand.ink,
            }),
          );
          x += cols[i]!;
        });
        page.drawLine({
          start: { x: margin, y: y - rowHeight },
          end: { x: width - margin, y: y - rowHeight },
          thickness: 0.4,
          color: pdfBrand.border,
        });
        y -= rowHeight;
        offset += count;
        if (offset < totalLines) {
          nextPage(group);
          page.drawText(
            `Continuación de partida ${row.lineNumber ?? index + 1}`,
            {
              x: margin,
              y: y - 10,
              size: 6.5,
              font: bold,
              color: pdfBrand.muted,
            },
          );
          y -= 18;
        }
      }
    }
  }
  if (!input.rows.length)
    page.drawText(
      "No hay partidas pendientes para los filtros seleccionados.",
      { x: margin, y: y - 25, size: 10, font: regular, color: pdfBrand.muted },
    );
  pdf.getPages().forEach((current, index, pages) => {
    current.drawLine({
      start: { x: margin, y: 28 },
      end: { x: width - margin, y: 28 },
      thickness: 0.5,
      color: pdfBrand.border,
    });
    current.drawText(
      "Seguimiento comercial - No reserva ni modifica inventario.",
      { x: margin, y: 15, size: 6.5, font: regular, color: pdfBrand.muted },
    );
    const number = `Página ${index + 1} de ${pages.length}`;
    current.drawText(number, {
      x: width - margin - regular.widthOfTextAtSize(number, 6.5),
      y: 15,
      size: 6.5,
      font: regular,
      color: pdfBrand.muted,
    });
  });
  return pdf.save();
}
