import { describe,it,expect } from "vitest";
import { PDFDocument } from "pdf-lib";
import { groupMonthlySoldProducts,monthlyInvoiceRange } from "./monthly-sold-products";
import { createMonthlySoldProductsPdf } from "./monthly-sold-products-pdf";
import { readCustomerOrderPdf } from "./customer-order-pdf-reader";
const line={code:"EDP 410755",description:"RCMX2507M0-RR UH6400",quantity:2,unit:"PZA",invoiceId:"a",folio:"F-10"};
describe("productos vendidos agrupados por herramienta",()=>{
  it("suma distintas facturas en una fila y lista folios sin duplicarlos",()=>{
    const report=groupMonthlySoldProducts("2026-10",[line,{...line,quantity:3},{...line,quantity:20,invoiceId:"b",folio:"F-11"}]);
    expect(report.rows).toHaveLength(1);expect(report.rows[0].quantity).toBe(25);expect(report.rows[0].invoices.map(i=>i.folio)).toEqual(["F-10","F-11"]);expect(report.invoiceCount).toBe(2);
  });
  it("una factura con varios productos no crea grupo por factura",()=>expect(groupMonthlySoldProducts("2026-10",[line,{...line,code:"EDP 99",description:"Otra herramienta"}]).rows).toHaveLength(2));
  it("mismo código con descripción distinta conserva filas independientes",()=>expect(groupMonthlySoldProducts("2026-10",[line,{...line,description:"Otra geometría"}]).rows).toHaveLength(2));
  it("normaliza sólo mayúsculas y espacios, no elimina ceros ni signos",()=>{expect(groupMonthlySoldProducts("2026-10",[line,{...line,code:" edp   410755 ",description:" rcmx2507m0-rr   uh6400 "}]).rows).toHaveLength(1);expect(groupMonthlySoldProducts("2026-10",[line,{...line,code:"EDP 0410755"}]).rows).toHaveLength(2);});
  it("suma decimal precisa y unifica unidad pieza SAT",()=>expect(groupMonthlySoldProducts("2026-10",[{...line,quantity:".1",unit:"H87"},{...line,quantity:".2",unit:"PIEZAS"}]).rows[0]).toMatchObject({quantity:.3,unit:"PZA"}));
  it("no suma kilos con piezas",()=>expect(groupMonthlySoldProducts("2026-10",[line,{...line,unit:"KG"}]).rows).toHaveLength(2));
  it("partidas sin catálogo no se pierden",()=>expect(groupMonthlySoldProducts("2026-10",[{...line,code:null}]).rows[0].code).toBe("Sin código"));
  it("ordena folios y códigos naturalmente",()=>expect(groupMonthlySoldProducts("2026-10",[{...line,folio:"F-10"},{...line,folio:"F-2",invoiceId:"b"}]).rows[0].invoices.map(i=>i.folio)).toEqual(["F-2","F-10"]));
  it.each(["2026-00","2026-13","2026-1","26-10","2026-10-01","no"])("rechaza mes inválido %s",month=>expect(()=>monthlyInvoiceRange(month)).toThrow());
  it("cambio de año y febrero bisiesto, límites sin desplazamiento",()=>{expect(monthlyInvoiceRange("2026-12").lt.toISOString()).toBe("2027-01-01T00:00:00.000Z");expect(monthlyInvoiceRange("2024-02").gte.toISOString()).toBe("2024-02-01T00:00:00.000Z");expect(monthlyInvoiceRange("2024-02").lt.toISOString()).toBe("2024-03-01T00:00:00.000Z");});
  it("mes sin ventas ofrece reporte vacío válido",()=>expect(groupMonthlySoldProducts("2026-10",[])).toMatchObject({invoiceCount:0,productCount:0,rows:[],totalsByUnit:[]}));
  it("PDF con todos los folios y descripción completa en varias páginas",async()=>{
    const lines=Array.from({length:150},(_,i)=>({...line,invoiceId:"i"+i,folio:"F-"+(10000+i)}));
    const report=groupMonthlySoldProducts("2026-10",lines);report.rows[0].description="Herramienta de precisión "+("Descripción larga sin omisiones. ".repeat(200))+"MARCA-FINAL-DESCRIPCION";
    const bytes=Buffer.from(await createMonthlySoldProductsPdf(report,{tradeName:"Tooling Prection"}));
    expect((await PDFDocument.load(bytes)).getPageCount()).toBeGreaterThan(1);
    const text=await readCustomerOrderPdf(bytes);expect(text).toContain("F-10000");expect(text).toContain("F-10149");expect(text).toContain("MARCA-FINAL-DESCRIPCION");expect(text).toContain("300 PZA");
  });
});
