import { Role } from "@prisma/client";
import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";
import { db } from "@/lib/db";

const COOKIE = "tp_erp_session";
const secret = () => {
  if (process.env.NODE_ENV === "production" && (!process.env.AUTH_SECRET || process.env.AUTH_SECRET.length < 32)) {
    throw new Error("AUTH_SECRET debe estar configurado de forma segura en producción.");
  }
  return new TextEncoder().encode(process.env.AUTH_SECRET || "development-only-change-me-before-deploying-please-1234567890");
};

export type Session = { id: string; email: string; name: string; role: Role };

export async function createSession(session: Session) {
  return new SignJWT(session).setProtectedHeader({ alg: "HS256" }).setIssuedAt().setExpirationTime("8h").sign(secret());
}

export async function currentSession(): Promise<Session | null> {
  const token = (await cookies()).get(COOKIE)?.value;
  if (!token) return null;
  try {
    const payload = (await jwtVerify(token, secret())).payload;
    if (typeof payload.id !== "string") return null;
    const user = await db.user.findUnique({ where: { id: payload.id }, select: { id: true, name: true, email: true, role: true, isActive: true } });
    if (!user?.isActive) return null;
    return { id: user.id, name: user.name, email: user.email, role: user.role };
  } catch {
    return null;
  }
}

export async function setSession(session: Session) {
  const token = await createSession(session);
  (await cookies()).set(COOKIE, token, { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax", path: "/", maxAge: 60 * 60 * 8 });
}

export async function clearSession() {
  (await cookies()).delete(COOKIE);
}
