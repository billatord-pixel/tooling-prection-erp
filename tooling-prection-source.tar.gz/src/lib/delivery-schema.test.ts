import { describe, expect, it } from "vitest";
import { deliverySchema, deliveryTotals } from "./delivery-schema";

describe("delivery totals", () => {
  it("calculates line discounts, IVA, and currency totals without floating point drift", () => {
    const input = deliverySchema.parse({
      customerId: "customer-1", currency: "MXN", taxRate: 16,
      lines: [
        { productId: "product-1", description: "Broca", quantity: 2, listPrice: 100, discount: 10 },
        { productId: "product-2", description: "Inserto", quantity: 1, listPrice: 50, discount: 0 },
      ],
    });

    expect(deliveryTotals(input)).toEqual({
      lines: [
        { productId: "product-1", description: "Broca", quantity: 2, listPrice: 100, discount: 10, lot: undefined, note: undefined, unitPrice: 90, amount: 180 },
        { productId: "product-2", description: "Inserto", quantity: 1, listPrice: 50, discount: 0, lot: undefined, note: undefined, unitPrice: 50, amount: 50 },
      ], subtotal: 250, discount: 20, tax: 36.8, total: 266.8,
    });
  });

  it("rejects a discount above one hundred percent", () => {
    expect(() => deliverySchema.parse({ customerId: "c", lines: [{ productId: "p", description: "Item", quantity: 1, listPrice: 10, discount: 101 }] })).toThrow();
  });
});
