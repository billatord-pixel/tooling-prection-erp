import { describe, expect, it } from "vitest";
import { Role } from "@prisma/client";
import { can } from "./permissions";

describe("role permissions", () => {
  it("gives Administrators full access", () => {
    for (const permission of ["read", "create", "update", "archive", "process", "admin"] as const) {
      expect(can(Role.ADMIN, permission)).toBe(true);
    }
  });

  it("keeps Sellers read-only outside the dedicated quote creation flow", () => {
    expect(can(Role.SALES, "read")).toBe(true);
    for (const permission of ["create", "update", "archive", "process", "admin"] as const) {
      expect(can(Role.SALES, permission)).toBe(false);
    }
  });

  it("keeps deprecated database roles least-privileged during rollout", () => {
    for (const role of [Role.PURCHASES, Role.INVENTORY, Role.READONLY]) {
      expect(can(role, "read")).toBe(true);
      expect(can(role, "create")).toBe(false);
      expect(can(role, "update")).toBe(false);
      expect(can(role, "process")).toBe(false);
    }
  });
});
