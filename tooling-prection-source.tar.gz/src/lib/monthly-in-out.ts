import type { MonthlySoldProductsReport,MonthlyProductInvoice } from "./monthly-sold-products";
export type InOutRow={code:string;description:string;unit:string;incoming:number;outgoing:number;purchases:MonthlyProductInvoice[];sales:MonthlyProductInvoice[];suppliers:Array<{id:string;name:string}>};
export type InOutReport={month:string;purchaseInvoiceCount:number;salesInvoiceCount:number;rows:InOutRow[];incomingTotals:MonthlySoldProductsReport["totalsByUnit"];outgoingTotals:MonthlySoldProductsReport["totalsByUnit"]};
export function mergeMonthlyInOut(purchases:MonthlySoldProductsReport,sales:MonthlySoldProductsReport):InOutReport{
  if(purchases.month!==sales.month)throw Error("Los meses deben coincidir.");
  const groups=new Map<string,InOutRow>();
  for(const [kind,report] of [["purchase",purchases],["sale",sales]] as const)for(const row of report.rows){
    const normalize=(s:string)=>s.normalize("NFKC").trim().replace(/\s+/g," ").toLocaleUpperCase("es-MX");
    const key=JSON.stringify([normalize(row.code),normalize(row.description),row.unit]);
    const result=groups.get(key)||{code:row.code,description:row.description,unit:row.unit,incoming:0,outgoing:0,purchases:[],sales:[],suppliers:[]};
    if(kind==="purchase"){result.incoming=row.quantity;result.purchases=row.invoices;result.suppliers=row.suppliers||[];}
    else{result.outgoing=row.quantity;result.sales=row.invoices;}
    groups.set(key,result);
  }
  const sort=new Intl.Collator("es-MX",{numeric:true,sensitivity:"base"});
  return{month:purchases.month,purchaseInvoiceCount:purchases.invoiceCount,salesInvoiceCount:sales.invoiceCount,rows:[...groups.values()].sort((a,b)=>sort.compare(a.code,b.code)||sort.compare(a.description,b.description)||sort.compare(a.unit,b.unit)),incomingTotals:purchases.totalsByUnit,outgoingTotals:sales.totalsByUnit};
}
