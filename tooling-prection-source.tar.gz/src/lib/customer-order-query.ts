import { db } from "@/lib/db";
import { customerOrderInclude } from "@/lib/customer-order-service";
import {
  orderProgress,
  matchesCustomerDeadline,
  mexicoToday,
  remainingDays,
} from "@/lib/customer-orders";
export type CustomerOrderFilters = {
  q?: string;
  customerId?: string;
  state?: string;
  from?: string;
  to?: string;
  archived?: boolean;
  page?: number;
};
export async function listCustomerOrders(filters: CustomerOrderFilters) {
  const q = filters.q?.trim().slice(0, 100) ?? "";
  const rows = await db.customerOrder.findMany({
    where: {
      deletedAt: filters.archived ? { not: null } : null,
      ...(filters.customerId ? { customerId: filters.customerId } : {}),
      ...(q
        ? {
            OR: [
              { folio: { contains: q, mode: "insensitive" as const } },
              {
                customer: {
                  legalName: { contains: q, mode: "insensitive" as const },
                },
              },
              {
                customer: {
                  tradeName: { contains: q, mode: "insensitive" as const },
                },
              },
              {
                items: {
                  some: {
                    description: { contains: q, mode: "insensitive" as const },
                  },
                },
              },
            ],
          }
        : {}),
    },
    include: customerOrderInclude,
    orderBy: [{ orderDate: "desc" }, { createdAt: "desc" }],
  });
  const today = mexicoToday();
  return rows
    .map((row) => ({ ...row, progress: orderProgress(row, today) }))
    .filter((row) => {
      const state = filters.state ?? "pending";
      if (
        state === "pending" &&
        !["PENDING", "PARTIAL"].includes(row.progress.status)
      )
        return false;
      if (
        ["overdue", "soon", "undated"].includes(state) &&
        row.progress.status === "CANCELLED"
      )
        return false;
      if (
        ["PENDING", "PARTIAL", "DELIVERED", "CANCELLED"].includes(state) &&
        row.progress.status !== state
      )
        return false;
      if (
        ["overdue", "soon", "undated"].includes(state) ||
        filters.from ||
        filters.to
      )
        return row.items.some((item) =>
          matchesCustomerDeadline(item, row.dueDate, filters, today),
        );
      return true;
    })
    .sort((a, b) => {
      const activeA = ["PENDING", "PARTIAL"].includes(a.progress.status),
        activeB = ["PENDING", "PARTIAL"].includes(b.progress.status);
      if (activeA !== activeB) return activeA ? -1 : 1;
      const urgencyA = a.progress.nextDueDate
        ? remainingDays(a.progress.nextDueDate, today)
        : Number.MAX_SAFE_INTEGER;
      const urgencyB = b.progress.nextDueDate
        ? remainingDays(b.progress.nextDueDate, today)
        : Number.MAX_SAFE_INTEGER;
      return (
        urgencyA - urgencyB ||
        b.orderDate.getTime() - a.orderDate.getTime() ||
        a.folio.localeCompare(b.folio, "es", { numeric: true })
      );
    });
}
export function parseCustomerOrderFilters(
  params: Record<string, string | string[] | undefined>,
): CustomerOrderFilters {
  const text = (name: string) =>
    typeof params[name] === "string" ? (params[name] as string) : undefined;
  const customerId = text("customerId");
  return {
    q: text("q"),
    customerId:
      customerId && /^[a-z0-9-]{1,100}$/i.test(customerId)
        ? customerId
        : undefined,
    state: text("state") ?? "pending",
    from: /^\d{4}-\d{2}-\d{2}$/.test(text("from") ?? "")
      ? text("from")
      : undefined,
    to: /^\d{4}-\d{2}-\d{2}$/.test(text("to") ?? "") ? text("to") : undefined,
    archived: text("archived") === "1",
    page: Math.max(1, Number(text("page")) || 1),
  };
}
