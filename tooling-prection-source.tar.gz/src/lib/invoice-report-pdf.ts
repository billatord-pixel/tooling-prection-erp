import { formatMoney } from "@/lib/money-format";
import type { BanxicoFix } from "@/lib/banxico-fix";
import { monthlyInvoiceDateLabel } from "@/lib/monthly-invoice-date";
import PDFDocument from "pdfkit";
import { TOOLING_CONTACT_EMAIL, TOOLING_PDF, drawToolingPdfRail } from "@/lib/pdf-brand";

export type InvoiceReportRow = {
  issueDate: Date;
  folio: string;
  counterparty: string;
  currency: string;
  reportTotal: number | null;
  status: string;
  lineCount: number;
  fix?: BanxicoFix;
  details?: Array<{ code?: string; description: string; quantity: number; amount: number | null }>;
};

type InvoiceReportOptions = {
  kind: "sales" | "purchases";
  currency: string;
  title: string;
  period: string;
  invoices: InvoiceReportRow[];
  salesDetail?: boolean;
  companyName?: string;
  taxId?: string;
  logo?: Buffer;
};

const states: Record<string, { label: string; text: string; background: string }> = {
  PAID: { label: "Pagada", text: "#166534", background: "#DCFCE7" },
  PENDING: { label: "Pendiente", text: "#854D0E", background: "#FEF3C7" },
  CANCELLED: { label: "Cancelada", text: "#B91C1C", background: "#FEE2E2" },
};

const money = formatMoney;
const dateLabel = (value: Date) => new Intl.DateTimeFormat("es-MX", { day: "2-digit", month: "short", year: "numeric", timeZone: "UTC" }).format(value).replaceAll(".", "");

/** Fixed-width cells and explicitly positioned text keep PDFKit from creating implicit pages. */
export async function createInvoiceReportPdf(options: InvoiceReportOptions): Promise<Buffer> {
  const { invoices, currency } = options;
  const subject = options.kind === "sales" ? "ventas" : "compras";
  const doc = new PDFDocument({ size: "LETTER", margins: { top: 32, left: 32, right: 32, bottom: 52 }, bufferPages: true, info: { Title: options.title, Author: options.companyName || "Tooling Prection" } });
  const chunks: Buffer[] = [];
  const done = new Promise<Buffer>((resolve, reject) => {
    doc.on("data", chunk => chunks.push(Buffer.from(chunk)));
    doc.on("end", () => resolve(Buffer.concat(chunks)));
    doc.on("error", reject);
  });
  const left = 32, right = doc.page.width - 32, width = right - left;
  // 548 points: exactly the printable width of a Letter page with 32-point margins.
  const columns = [56, 66, 180, 42, 40, 92, 72];
  const bodyBottom = doc.page.height - 58;
  const lineHeight = 12, padding = 6;
  const total = invoices.reduce((sum, row) => sum + (row.status === "CANCELLED" ? 0 : row.reportTotal ?? 0), 0);
  const cancelled = invoices.filter(row => row.status === "CANCELLED").length;
  const missing = invoices.filter(row => row.status !== "CANCELLED" && row.reportTotal === null).length;

  const singleLine = (text: string, x: number, y: number, cellWidth: number, size: number, color: string, bold = false, align: "left" | "center" | "right" = "left") => {
    doc.font(bold ? "Helvetica-Bold" : "Helvetica").fontSize(size).fillColor(color);
    const originalWidth = doc.widthOfString(text);
    if (originalWidth > cellWidth) doc.fontSize(size * cellWidth / originalWidth);
    const textWidth = doc.widthOfString(text);
    const offset = align === "right" ? cellWidth - textWidth : align === "center" ? (cellWidth - textWidth) / 2 : 0;
    doc.text(text, x + offset, y, { lineBreak: false });
  };

  const wrap = (text: string, cellWidth: number, bold: boolean) => {
    doc.font(bold ? "Helvetica-Bold" : "Helvetica").fontSize(8);
    const lines: string[] = [];
    let line = "";
    for (const paragraph of text.split(/\r?\n/)) {
      for (const word of paragraph.split(/\s+/).filter(Boolean)) {
        const candidate = line ? `${line} ${word}` : word;
        if (doc.widthOfString(candidate) <= cellWidth) { line = candidate; continue; }
        if (line) { lines.push(line); line = ""; }
        for (const char of word) {
          if (line && doc.widthOfString(line + char) > cellWidth) { lines.push(line); line = ""; }
          line += char;
        }
      }
      if (line) { lines.push(line); line = ""; }
    }
    return lines.length ? lines : [""];
  };

  const heading = (continued = false, detail = false) => {
    drawToolingPdfRail(doc);
    if (options.logo) doc.image(options.logo, left, 24, { fit: [42, 36] });
    singleLine(options.companyName || "Tooling Prection", left + 54, 27, width - 156, 16, TOOLING_PDF.navy, true);
    singleLine([options.taxId ? `RFC ${options.taxId}` : "", TOOLING_CONTACT_EMAIL].filter(Boolean).join(" | "), left + 54, 49, width - 156, 7, TOOLING_PDF.muted);
    singleLine(subject.toUpperCase(), right - 88, 30, 88, 9, TOOLING_PDF.blue, true, "right");
    doc.moveTo(left, 72).lineTo(right, 72).lineWidth(1).strokeColor(TOOLING_PDF.border).stroke();
    singleLine(detail ? "Detalle de partidas · MXN" : options.title, left, 85, width, continued ? 14 : 17, TOOLING_PDF.navy, true);
    singleLine(options.period, left, 109, width, 8.5, TOOLING_PDF.muted);
    if (detail) {
      singleLine("Importe antes de descuentos e impuestos. Si el FIX es anterior, se muestra su fecha debajo de la tasa.", left, 124, width, 7.3, TOOLING_PDF.muted);
      return 142;
    }
    if (continued) return 130;

    const cards = [{ label: "FACTURAS EN EL PERIODO", value: String(invoices.length), width: 152 }, { label: `TOTAL VIGENTE ${currency}`, value: money(total, currency), width: 232 }, { label: "CANCELADAS", value: String(cancelled), width: 144 }];
    let x = left;
    for (const card of cards) {
      doc.roundedRect(x, 132, card.width, 44, 6).fill(TOOLING_PDF.pale);
      singleLine(card.label, x + 10, 140, card.width - 20, 6.5, TOOLING_PDF.muted, true);
      singleLine(card.value, x + 10, 153, card.width - 20, 13, TOOLING_PDF.navy, true);
      x += card.width + 10;
    }
    singleLine("Las canceladas se muestran para consulta y no se suman al total vigente.", left, 186, width, 7.3, TOOLING_PDF.muted);
    if (options.salesDetail) {
      singleLine("USD convertidos con el FIX de determinación de Banxico de la fecha de facturación o el último anterior disponible.", left, 199, width, 7.3, TOOLING_PDF.muted);
      if (missing) singleLine(`${missing} factura(s) sin tipo de cambio disponible: excluidas del total convertido.`, left, 212, width, 7.3, states.PENDING.text);
      return missing ? 230 : 217;
    }
    if (missing) {
      singleLine(`${missing} factura(s) sin tipo de cambio: excluidas del total convertido.`, left, 199, width, 7.3, states.PENDING.text);
      return 217;
    }
    return 204;
  };

  function drawTable(headers: string[], widths: number[], rows: { cells: string[]; status: string }[], detail = false) {
    const alignment = (column: number) => column === 6 || (!detail && column === 3) ? "center" : column >= 4 ? "right" : "left";
    const tableHeader = (top: number) => {
      doc.roundedRect(left, top, width, 24, 4).fill(TOOLING_PDF.navy);
      let x = left;
      headers.forEach((header, column) => {
        singleLine(header, x + padding, top + 8, widths[column] - padding * 2, 6.6, "#FFFFFF", true, alignment(column));
        x += widths[column];
      });
      return top + 24;
    };

    let y = tableHeader(heading(false, detail));
    const nextPage = () => { doc.addPage(); y = tableHeader(heading(true, detail)); };
    rows.forEach(({cells,status}, index) => {
      const lines = cells.map((cell, column) => column < (detail ? 4 : 3) ? wrap(cell, widths[column] - padding * 2, column === 1) : [cell]);
      const numberOfLines = Math.max(1, ...lines.map(cell => cell.length));
      const fullHeight = Math.max(30, numberOfLines * lineHeight + padding * 2);
      // Keep a normal invoice together; very long cells can continue on the next page.
      if (y + fullHeight > bodyBottom && fullHeight <= bodyBottom - (detail ? 166 : 154)) nextPage();
      let offset = 0;
      while (offset < numberOfLines) {
        const capacity = Math.floor((bodyBottom - y - padding * 2) / lineHeight);
        if (capacity < 1 || bodyBottom - y < 30) { nextPage(); continue; }
        const count = Math.min(capacity, numberOfLines - offset);
        const rowHeight = Math.max(30, count * lineHeight + padding * 2);
        if (index % 2 === 1) doc.rect(left, y, width, rowHeight).fill(TOOLING_PDF.row);
        let x = left;
        lines.forEach((cellLines, column) => {
          cellLines.slice(offset, offset + count).forEach((value, line) => singleLine(value, x + padding, y + padding + line * lineHeight, widths[column] - padding * 2, 8, TOOLING_PDF.ink, column === 1, alignment(column)));
          x += widths[column];
        });
        if (offset === 0) {
          const state = states[status] || { label: status, text: TOOLING_PDF.muted, background: TOOLING_PDF.pale };
          doc.roundedRect(x + 4, y + 6, widths[6] - 8, 18, 5).fill(state.background);
          singleLine(state.label, x + 8, y + 11, widths[6] - 16, 7, state.text, true, "center");
        }
        y += rowHeight;
        doc.moveTo(left, y).lineTo(right, y).lineWidth(.35).strokeColor(TOOLING_PDF.border).stroke();
        offset += count;
        if (offset < numberOfLines) nextPage();
      }
    });
    if (!rows.length) singleLine("No hay facturas en el periodo seleccionado.", left, y + 18, width, 9, TOOLING_PDF.muted, false, "center");
  }

  drawTable(["FECHA", "FOLIO", options.kind === "sales" ? "CLIENTE" : "PROVEEDOR", "MONEDA", "PARTIDAS", `TOTAL ${currency}`, "ESTADO"], columns, invoices.map(invoice => ({
    cells: [dateLabel(invoice.issueDate), invoice.folio, invoice.counterparty, invoice.currency, String(invoice.lineCount), invoice.reportTotal === null ? "Sin conversión" : money(invoice.reportTotal, currency)],
    status: invoice.status,
  })));
  if (options.salesDetail && invoices.length) {
    doc.addPage();
    const rows = invoices.flatMap(invoice => {
      const date = dateLabel(invoice.issueDate);
      const fix = invoice.fix;
      const priorFix = fix && fix.date !== invoice.issueDate.toISOString().slice(0,10);
      const reference = fix
        ? `${invoice.folio}\nFIX ${fix.rate}${priorFix ? "\n"+monthlyInvoiceDateLabel(fix.date) : ""}`
        : invoice.folio;
      const details = invoice.details?.length ? invoice.details : [{description:"Factura sin partidas registradas",quantity:null,amount:null}];
      return details.map(line => ({
        status: invoice.status,
        cells: [
          date,
          reference,
          invoice.counterparty,
          "code" in line && line.code ? `${line.code}\n${line.description}` : line.description,
          line.quantity === null ? "—" : line.quantity.toLocaleString("es-MX",{maximumFractionDigits:3}),
          line.quantity === null ? "—" : line.amount === null ? "Sin conversión" : money(line.amount,currency),
        ],
      }));
    });
    drawTable(["FECHA", "FOLIO / FIX", "CLIENTE", "CÓDIGO / DESCRIPCIÓN", "CANT.", "IMPORTE MXN", "ESTADO"], [55,67,95,151,38,83,59], rows, true);
  }

  const pages = doc.bufferedPageRange();
  const generated = new Intl.DateTimeFormat("es-MX", { dateStyle: "short", timeStyle: "short", timeZone: "America/Mexico_City" }).format(new Date());
  for (let index = 0; index < pages.count; index++) {
    doc.switchToPage(pages.start + index);
    doc.moveTo(left, 750).lineTo(right, 750).lineWidth(.5).strokeColor(TOOLING_PDF.border).stroke();
    // These calls deliberately bypass PDFKit's flow layout below the body margin.
    singleLine(`Tooling Prection | ${subject} | Uso interno`, left, 761, 238, 6.5, TOOLING_PDF.muted);
    singleLine(`Generado ${generated}`, left + 248, 761, 210, 6.5, TOOLING_PDF.muted);
    singleLine(`Página ${index + 1} de ${pages.count}`, right - 74, 761, 74, 6.5, TOOLING_PDF.muted, false, "right");
  }
  doc.end();
  return done;
}
