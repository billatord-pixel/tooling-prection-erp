import { describe, expect, it } from "vitest";
import { invoiceTechnicalCode, productCodeCandidates } from "./product-code";
describe("supplier tool codes", () => {
  it("matches the same EDP with or without its prefix", () => {
    expect(productCodeCandidates("410755")).toContain("EDP 410755");
    expect(productCodeCandidates("EDP 410755")).toContain("410755");
  });
  it("does not merge two CE tools under supplier internal code 2", () => {
    expect(invoiceTechnicalCode("2", "CARTUCHO CE-21201")).toBe("CE-21201");
    expect(invoiceTechnicalCode("2", "CE-23330 CABEZAL DE ROSCADO")).toBe("CE-23330");
  });
  it("does not use SAT codes or item legends as the product code", () => {
    expect(invoiceTechnicalCode("EDP 410755", "RCMX2507M0-RR UH6400 Item.00010")).toBe("EDP 410755");
    expect(productCodeCandidates("CE-23330")).toEqual(["CE-23330"]);
  });
});
