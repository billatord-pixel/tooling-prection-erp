export type CustomerOrderPreview = {
  folio?: string; orderDate?: string; dueDate?: string; currency?: string;
  items: Array<{lineNumber?:number; description: string; quantity: number; unit: string; customerCode?: string; unitPrice?: number}>;
  warnings: string[];
};
export function parseOrderDocumentDate(value: string) {
  const m = value.match(/^(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})$/);
  if (!m) return undefined;
  const date = m[3] + "-" + m[2].padStart(2,"0") + "-" + m[1].padStart(2,"0");
  const d = new Date(date + "T12:00:00Z");
  return Number.isFinite(d.getTime()) && d.toISOString().slice(0,10) === date ? date : undefined;
}
// Generic proposals only. No customer identities or Gerat-specific agreements.
export function parseCustomerOrderText(text: string): CustomerOrderPreview {
  const result: CustomerOrderPreview = { items: [], warnings: ["Revisa la propuesta contra el PDF original antes de guardar. No se leen sellos, correcciones manuscritas ni imágenes."] };
  result.folio = text.match(/(?:ORDEN(?: DE COMPRA)?|PO|PEDIDO|FOLIO)\s*(?:No\.?)?\s*[#:]\s*([\w-]+)/i)?.[1];
  result.orderDate = parseOrderDocumentDate(text.match(/(?:Fecha(?: de emisión)?|Date)\s*:\s*(\d{2}[\/.-]\d{2}[\/.-]\d{4})/i)?.[1] || "");
  result.dueDate = parseOrderDocumentDate(text.match(/Fecha (?:l[ií]mite|requerida|de entrega)\s*:\s*(\d{2}[\/.-]\d{2}[\/.-]\d{4})/i)?.[1] || "");
  result.currency = text.match(/\b(USD|MXN|EUR)\b/i)?.[1]?.toUpperCase();
  for (const line of text.split("\n")) {
    const m = line.trim().match(/^\d+\s+(\d+(?:\.\d+)?)\s+(PZA|PCS|PIEZAS|KG|M|LT)\s+(.+?)\s+\$?([\d,]+\.\d{2})\s+\$?([\d,]+\.\d{2})$/i);
    if (m) result.items.push({lineNumber:Number(line.trim().match(/^\d+/)?.[0]),quantity: Number(m[1]), unit: /^(PCS|PIEZAS)$/i.test(m[2]) ? "PZA" : m[2].toUpperCase(), description: m[3], unitPrice: Number(m[4].replaceAll(",",""))});
  }
  if (!result.items.length) result.warnings.push("Formato no reconocido o PDF escaneado: captura las partidas manualmente. El original se conservará.");
  if (!result.dueDate) result.warnings.push("No se identificó vencimiento general: no se propone ningún plazo.");
  return result;
}
