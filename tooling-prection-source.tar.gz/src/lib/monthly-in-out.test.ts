import {describe,it,expect,vi} from "vitest";
import {mergeMonthlyInOut} from "./monthly-in-out";
import {groupMonthlySoldProducts} from "./monthly-sold-products";
import {createMonthlyInOutPdf} from "./monthly-in-out-pdf";
import {readCustomerOrderPdf} from "./customer-order-pdf-reader";
import {PDFDocument} from "pdf-lib";
const line={code:"EDP 2",description:"Herramienta",quantity:5,unit:"PZA",invoiceId:"c",folio:"C-1",issueDate:"2026-10-01"};
const base=()=>groupMonthlySoldProducts("2026-10",[line]);
describe("entradas y salidas facturadas",()=>{
 it("une compras y ventas por herramienta sin restar ni duplicar cantidades",()=>{const report=mergeMonthlyInOut(base(),groupMonthlySoldProducts("2026-10",[{...line,invoiceId:"v",folio:"V-1",quantity:2,issueDate:"2026-10-02"}]));expect(report.rows).toHaveLength(1);expect(report.rows[0]).toMatchObject({incoming:5,outgoing:2,purchases:[{folio:"C-1",issueDate:"2026-10-01"}],sales:[{folio:"V-1",issueDate:"2026-10-02"}]});});
 it("incluye herramientas sólo compradas o sólo vendidas y ordena códigos naturalmente",()=>{const p=base();p.rows[0].suppliers=[{id:"s",name:"Proveedor"}];const r=mergeMonthlyInOut(p,groupMonthlySoldProducts("2026-10",[{...line,code:"EDP 10"}]));expect(r.rows.map(r=>r.code)).toEqual(["EDP 2","EDP 10"]);expect(r.rows[0].outgoing).toBe(0);expect(r.rows[1].incoming).toBe(0);expect(r.rows[0].suppliers[0].name).toBe("Proveedor");});
 it("no mezcla unidades incompatibles ni descripciones diferentes",()=>{expect(mergeMonthlyInOut(base(),groupMonthlySoldProducts("2026-10",[{...line,unit:"KG"},{...line,description:"Otra"}])).rows).toHaveLength(3);});
 it("rechaza periodos distintos",()=>{expect(()=>mergeMonthlyInOut(base(),{...base(),month:"2026-11"})).toThrow();});
 it("genera PDF multipágina conservando folios, fechas y proveedores completos",async()=>{const p=groupMonthlySoldProducts("2026-10",Array.from({length:100},(_,i)=>({...line,invoiceId:"p"+i,folio:"C-"+(i+1)})));p.rows[0].suppliers=[{id:"s",name:"Proveedor final"}];const report=mergeMonthlyInOut(p,base());const bytes=await createMonthlyInOutPdf(report,{tradeName:"Tooling Prection"});expect((await PDFDocument.load(bytes)).getPageCount()).toBeGreaterThan(1);const text=await readCustomerOrderPdf(Buffer.from(bytes));expect(text).toContain("C-100");expect(text).toContain("01/10/2026");expect(text).toContain("Proveedor final");expect(text).toContain("500 PZA");});
 it("mes sin facturas produce una sola hoja útil",async()=>{const empty=groupMonthlySoldProducts("2026-10",[]);expect((await PDFDocument.load(await createMonthlyInOutPdf(mergeMonthlyInOut(empty,empty),{tradeName:"Tooling Prection"}))).getPageCount()).toBe(1);});
});
const mock=vi.hoisted(()=>({session:vi.fn(),query:vi.fn()}));
vi.mock("@/lib/auth",()=>({currentSession:mock.session}));
vi.mock("@/lib/monthly-in-out-query",()=>({getMonthlyInOut:mock.query}));
vi.mock("@/lib/db",()=>({db:{companySettings:{findFirst:async()=>({tradeName:"Tooling Prection"})}}}));
import {GET} from "@/app/api/reports/in-out/route";
describe("acceso al reporte combinado",()=>{
 it("exige sesión",async()=>{mock.session.mockResolvedValue(null);expect((await GET(new Request("http://local/api?month=2026-10"))).status).toBe(401);});
 it("rechaza un mes inválido",async()=>{mock.session.mockResolvedValue({role:"SALES"});expect((await GET(new Request("http://local/api?month=2026-13"))).status).toBe(400);});
 it("permite al vendedor leer e imprimir este reporte operativo",async()=>{mock.session.mockResolvedValue({role:"SALES"});mock.query.mockResolvedValue(mergeMonthlyInOut(base(),base()));const json=await GET(new Request("http://local/api?month=2026-10"));expect(json.status).toBe(200);expect(json.headers.get("cache-control")).toBe("private, no-store");expect((await GET(new Request("http://local/api?month=2026-10&format=pdf"))).headers.get("content-type")).toBe("application/pdf");});
});
