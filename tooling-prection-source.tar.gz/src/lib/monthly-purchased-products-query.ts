import { db } from "@/lib/db";
import { parseCfdi } from "@/lib/cfdi";
import { groupMonthlySoldProducts, monthlyInvoiceRange, type SoldProductLine } from "@/lib/monthly-sold-products";

export async function getMonthlyPurchasedProducts(month:string) {
  const invoices=await db.purchaseInvoice.findMany({
    where:{issueDate:monthlyInvoiceRange(month),status:{notIn:["CANCELLED","DRAFT"]}},
    orderBy:[{issueDate:"asc"},{id:"asc"}],
    select:{id:true,folio:true,rawXml:true,supplier:{select:{id:true,legalName:true}},lines:{orderBy:{id:"asc"},select:{description:true,quantity:true,unit:true,product:{select:{technicalCode:true,description:true,unit:true}}}}},
  });
  const lines:SoldProductLine[]=[];
  for(const invoice of invoices){
    // Catalogue identity keeps the same tool together despite fiscal wording changes.
    // An unlinked line still appears; use its XML code only if exactly matched.
    let parsed:ReturnType<typeof parseCfdi>|null=null;
    if(invoice.lines.some(line=>!line.product)&&invoice.rawXml){try{parsed=parseCfdi(invoice.rawXml);}catch{/* do not omit unlinked lines */}}
    for(const line of invoice.lines){
      const matches=parsed?.concepts.filter(item=>item.description.trim()===line.description.trim()&&Number(item.quantity)===Number(line.quantity))||[];
      const codes=[...new Set(matches.map(item=>item.code).filter(Boolean))];
      lines.push({code:line.product?.technicalCode||(codes.length===1?codes[0]:null),description:line.product?.description||line.description,quantity:line.quantity,unit:line.unit||line.product?.unit,invoiceId:invoice.id,folio:invoice.folio});
    }
  }
  const report=groupMonthlySoldProducts(month,lines,invoices.length);
  const suppliersByInvoice=new Map(invoices.map(invoice=>[invoice.id,invoice.supplier]));
  for(const row of report.rows){
    const suppliers=new Map<string,{id:string;name:string}>();
    for(const invoice of row.invoices){
      const supplier=suppliersByInvoice.get(invoice.id);
      if(supplier)suppliers.set(supplier.id,{id:supplier.id,name:supplier.legalName});
    }
    row.suppliers=[...suppliers.values()].sort((a,b)=>a.name.localeCompare(b.name,"es-MX"));
  }
  return report;
}
