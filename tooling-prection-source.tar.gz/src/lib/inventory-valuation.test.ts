import { describe,expect,it } from "vitest";
import { formatMoney } from "./money-format";
import { valueInventoryProduct, summarizeInventoryValuation, inventoryValuationInclude } from "./inventory-valuation";
const product={id:"p",stock:4,currency:"USD",baseCost:10};
const sale=(currency="USD",exchangeRate:number|null=18,unitPrice=25)=>({unitPrice,salesInvoice:{folio:"F-2",currency,exchangeRate}});
const purchase=(unitPrice=12)=>({unitPrice,purchaseInvoice:{folio:"FC-1",currency:"USD",exchangeRate:18}});
describe("moneda explícita y valoración de inventario comercial",()=>{
  it.each(["MXN","USD","EUR"])("identifica %s incluso importes cero",currency=>{expect(formatMoney(1234.5,currency)).toContain(currency);expect(formatMoney(0,currency)).toContain(currency);});
  it("venta vigente prevalece sobre precio de compra/catálogo",()=>expect(valueInventoryProduct({...product,salesInvoiceLines:[sale()],purchaseInvoiceLines:[purchase()]})).toMatchObject({source:"SALE",currency:"USD",unitPrice:25,nativeValue:100}));
  it("sin ventas utiliza última compra",()=>expect(valueInventoryProduct({...product,purchaseInvoiceLines:[purchase()]})).toMatchObject({source:"PURCHASE",unitPrice:12,nativeValue:48}));
  it("no factura ni precio inventado en artículos sólo de catálogo",()=>expect(valueInventoryProduct(product)).toMatchObject({source:"CATALOG_COST",nativeValue:40}));
  it("conversión MXN con tipo de cambio del documento elegido",()=>expect(valueInventoryProduct({...product,salesInvoiceLines:[sale()]},"MXN").value).toBe(1800));
  it("MXN no se convierte ni mezcla con USD por una tasa ajena",()=>{const p={...product,salesInvoiceLines:[sale("MXN",1)]};expect(valueInventoryProduct(p,"MXN").value).toBe(100);expect(valueInventoryProduct(p,"USD").value).toBeNull();expect(summarizeInventoryValuation([p],"USD")).toMatchObject({missingConversion:1,total:0,nativeTotals:[{currency:"MXN",total:100}]});});
  it("respaldo de TipoCambio XML si no está normalizado en base",()=>{const line=sale("USD",null);return expect(valueInventoryProduct({...product,salesInvoiceLines:[{...line,salesInvoice:{...line.salesInvoice,rawXml:'<Comprobante Moneda="USD" TipoCambio="19"><Conceptos/></Comprobante>'}}]},"MXN").value).toBe(1900);});
  it("no usa tipos de cambio ficticios para catálogo",()=>expect(valueInventoryProduct(product,"MXN").value).toBeNull());
  it("no exige conversión para una existencia cero",()=>expect(summarizeInventoryValuation([{...product,stock:0}],"MXN").missingConversion).toBe(0));
  it("separa el saldo sin precio de los importes que no se pueden convertir",()=>{
    const summary=summarizeInventoryValuation([
      {...product,baseCost:0},
      {...product,baseCost:0,stock:-1},
      {...product,baseCost:0,stock:0},
      product,
      {...product,salesInvoiceLines:[sale("USD",null,0)]},
      {...product,purchaseInvoiceLines:[purchase()]},
    ],"MXN");
    expect(summary).toMatchObject({missingPrice:2,missingConversion:1,valuedProducts:2,isPartial:true,total:864});
  });
  it("usa la precisión del precio y el tipo de cambio de la partida identificada en el XML",()=>{
    const line={...sale("USD",19,814.81),description:"Herramienta",quantity:8,amount:6518.52};
    const rawXml='<Comprobante Moneda="USD" TipoCambio="18"><Conceptos><Concepto Descripcion="Herramienta" Cantidad="8" ValorUnitario="814.8145" Importe="6518.516"/></Conceptos></Comprobante>';
    const p={...product,stock:8,salesInvoiceLines:[{...line,salesInvoice:{...line.salesInvoice,rawXml}}]};
    expect(valueInventoryProduct(p,"MXN")).toMatchObject({unitPrice:814.8145,exchangeRate:18,nativeValue:6518.516});
    expect(summarizeInventoryValuation([p],"MXN").total).toBe(117333.29);
  });
  it("conserva el precio guardado si dos conceptos XML coinciden con la misma partida",()=>{
    const line={...sale("MXN",1,10),description:"Herramienta",quantity:1,amount:10};
    const rawXml='<Comprobante Moneda="MXN"><Conceptos><Concepto Descripcion="Herramienta" Cantidad="1" ValorUnitario="10.001" Importe="10.001"/><Concepto Descripcion="Herramienta" Cantidad="1" ValorUnitario="10.002" Importe="10.002"/></Conceptos></Comprobante>';
    expect(valueInventoryProduct({...product,salesInvoiceLines:[{...line,salesInvoice:{...line.salesInvoice,rawXml}}]},"MXN")).toMatchObject({unitPrice:10,value:40});
  });
  it("respeta precio cero y negativos de existencia sin corregir saldos",()=>{expect(valueInventoryProduct({...product,salesInvoiceLines:[sale("USD",18,0)]}).nativeValue).toBe(0);expect(summarizeInventoryValuation([{...product,stock:-2,salesInvoiceLines:[sale()]}],"USD")).toMatchObject({total:-50,negativeStock:1});});
  it("suma decimal sin mezclar monedas",()=>expect(summarizeInventoryValuation([{...product,stock:3,baseCost:.1},{...product,stock:1,baseCost:.2}],"USD").total).toBe(.5));
  it("consulta sólo facturas vigentes, por fecha y sin filtro de periodo",()=>{expect(inventoryValuationInclude.salesInvoiceLines.where.salesInvoice).toEqual({status:{notIn:["CANCELLED","DRAFT"]},archivedAt:null});expect(inventoryValuationInclude.salesInvoiceLines.orderBy[0]).toEqual({salesInvoice:{issueDate:"desc"}});expect(inventoryValuationInclude.purchaseInvoiceLines.where.purchaseInvoice.status.notIn).toContain("CANCELLED");});
});
