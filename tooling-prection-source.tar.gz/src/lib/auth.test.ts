import { beforeEach, describe, expect, it, vi } from "vitest";
const mocks = vi.hoisted(() => ({ user: vi.fn(), token: vi.fn() }));
vi.mock("@/lib/db", () => ({ db: { user: { findUnique: mocks.user } } }));
vi.mock("next/headers", () => ({ cookies: async () => ({ get: () => ({ value: mocks.token() }) }) }));
import { createSession, currentSession } from "./auth";
describe("session authorization", () => {
  beforeEach(() => { vi.clearAllMocks(); });
  it("uses current database permissions rather than an old token role", async () => {
    mocks.token.mockReturnValue(await createSession({ id: "u", name: "User", email: "u@example.test", role: "ADMIN" }));
    mocks.user.mockResolvedValue({ id: "u", name: "User", email: "u@example.test", role: "SALES", isActive: true });
    expect((await currentSession())?.role).toBe("SALES");
  });
  it("rejects a disabled account immediately", async () => {
    mocks.token.mockReturnValue(await createSession({ id: "u", name: "User", email: "u@example.test", role: "ADMIN" }));
    mocks.user.mockResolvedValue({ id: "u", isActive: false });
    expect(await currentSession()).toBeNull();
  });
  it("rejects malformed tokens", async () => {
    mocks.token.mockReturnValue("invalid");
    expect(await currentSession()).toBeNull();
    expect(mocks.user).not.toHaveBeenCalled();
  });
});
