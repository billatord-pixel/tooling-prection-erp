// Browser-safe presentation/date helpers: never import the server Prisma client.
export const customerOrderStatuses = {
  PENDING: "Pendiente",
  PARTIAL: "Entrega parcial",
  DELIVERED: "Entregada",
  CANCELLED: "Cancelada",
} as const;
export const normalizeCustomerFolio = (value: string) =>
  value
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, "");
export const dateOnly = (value: Date | string) =>
  typeof value === "string"
    ? value.slice(0, 10)
    : value.toISOString().slice(0, 10);
export const displayOrderDate = (value?: Date | string | null) =>
  value
    ? dateOnly(value).split("-").reverse().join("/")
    : "Fecha por confirmar";
export const mexicoToday = (now = new Date()) =>
  new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/Mexico_City",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(now);
export function remainingDays(value: Date | string, today = mexicoToday()) {
  return Math.round(
    (Date.parse(`${dateOnly(value)}T12:00:00Z`) -
      Date.parse(`${today}T12:00:00Z`)) /
      86400000,
  );
}
