import { beforeEach, describe, expect, it, vi } from "vitest";
const products = vi.hoisted(() => vi.fn());
vi.mock("@/lib/db", () => ({ db: { product: { findMany: products } } }));
import { calculateLines, quoteSchema } from "./quote-schema";
describe("quotation costs respect the price currency", () => {
  beforeEach(() => products.mockResolvedValue([{ id: "p", technicalCode: "EDP-TEST", baseCost: 15, currency: "USD" }]));
  const input = (currency = "USD", costPrice?: number) => quoteSchema.parse({ currency, exchangeRate: 18, lines: [{ productId: "p", description: "Herramienta", quantity: 1, listPrice: 20, costPrice }] });
  it("does not divide USD costs when quoting in USD", async () => { expect((await calculateLines(input())).lines[0].costPrice).toBe(15); });
  it("converts MXN costs to USD exactly once", async () => { products.mockResolvedValue([{ id: "p", technicalCode: "EDP-TEST", baseCost: 270, currency: "MXN" }]); expect((await calculateLines(input())).lines[0].costPrice).toBe(15); });
  it("converts USD costs to MXN exactly once", async () => { expect((await calculateLines(input("MXN"))).lines[0].costPrice).toBe(270); });
  it("keeps a cost entered in the quotation currency", async () => { expect((await calculateLines(input("USD", 40))).lines[0].costPrice).toBe(40); });
});
