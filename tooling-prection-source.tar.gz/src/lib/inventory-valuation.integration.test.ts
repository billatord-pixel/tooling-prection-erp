import { describe,it,expect } from "vitest";
import { randomUUID } from "node:crypto";
import { db } from "./db";
import { inventoryValuationInclude, valueInventoryProduct } from "./inventory-valuation";
const enabled=process.env.DATABASE_URL==="postgresql://postgres@127.0.0.1:54987/postgres"&&process.env.TP_INVENTORY_TEST_URL===process.env.DATABASE_URL;
describe.skipIf(!enabled)("valoración con facturas reales en base restaurada aislada",()=>{
  it("selecciona última venta vigente o compra, sin mutar el ledger",async()=>{
    const before=await db.inventoryMovement.count();
    const token=randomUUID();
    await expect(db.$transaction(async tx=>{
      const customer=await tx.party.create({data:{kind:"CUSTOMER",legalName:"Cliente prueba valoración"}});
      const supplier=await tx.party.create({data:{kind:"SUPPLIER",legalName:"Proveedor prueba valoración"}});
      const a=await tx.product.create({data:{technicalCode:"QA-VAL-"+token,description:"Prueba valoración",stock:4,baseCost:8,currency:"USD"}});
      const b=await tx.product.create({data:{technicalCode:"QA-VAL-C-"+token,description:"Sólo compra",stock:3,baseCost:1,currency:"USD"}});
      await tx.purchaseInvoice.create({data:{folio:"QA-C-"+token,supplierId:supplier.id,issueDate:new Date("2026-10-01"),currency:"USD",exchangeRate:18,subtotal:100,total:116,lines:{create:[{productId:a.id,description:"Compra",quantity:4,unitPrice:10,amount:40},{productId:b.id,description:"Compra",quantity:3,unitPrice:12,amount:36}]}}});
      for(const [tag,status,price,date,archived]of [["old","PAID",20,"2026-10-01",false],["new","PENDING",25,"2026-10-02",false],["cancel","CANCELLED",999,"2026-10-03",false],["draft","DRAFT",999,"2026-10-04",false],["archived","PAID",999,"2026-10-05",true]] as const){
        await tx.salesInvoice.create({data:{folio:"QA-"+tag+"-"+token,customerId:customer.id,issueDate:new Date(date),status,currency:"USD",exchangeRate:18,archivedAt:archived?new Date():null,subtotal:price,total:price,lines:{create:{productId:a.id,description:"Venta",quantity:1,unitPrice:price,amount:price}}}});
      }
      const sold=await tx.product.findUniqueOrThrow({where:{id:a.id},include:inventoryValuationInclude});
      const bought=await tx.product.findUniqueOrThrow({where:{id:b.id},include:inventoryValuationInclude});
      expect(valueInventoryProduct(sold,"MXN")).toMatchObject({source:"SALE",unitPrice:25,value:1800});
      expect(valueInventoryProduct(bought,"MXN")).toMatchObject({source:"PURCHASE",unitPrice:12,value:648});
      expect(Number(sold.stock)).toBe(4);expect(Number(bought.stock)).toBe(3);
      expect(await tx.inventoryMovement.count()).toBe(before);
      throw Error("ROLLBACK_QA_VALUATION");
    },{timeout:30000})).rejects.toThrow("ROLLBACK_QA_VALUATION");
    expect(await db.inventoryMovement.count()).toBe(before);
    expect(await db.product.count({where:{technicalCode:{contains:token}}})).toBe(0);
    await db.$disconnect();
  },40000);
});
