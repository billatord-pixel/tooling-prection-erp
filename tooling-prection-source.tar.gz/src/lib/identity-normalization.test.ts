import { describe, expect, it } from "vitest";
import { normalizeMatch, normalizeTaxId } from "./identity-normalization";

describe("normalización de identificadores de factura", () => {
  it("compara razones sociales sin diferencias de acentos, mayúsculas ni espacios", () => {
    expect(normalizeMatch("  Industrias   del Bajío, S.A. de C.V. ")).toBe(normalizeMatch("INDUSTRIAS DEL BAJIO SA DE CV"));
  });

  it("normaliza RFC para que los separadores no provoquen duplicados", () => {
    expect(normalizeTaxId("ABC-010203-XY9")).toBe("ABC010203XY9");
  });
});
