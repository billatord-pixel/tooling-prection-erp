import { describe, expect, it, vi } from "vitest";
import { Prisma } from "@prisma/client";
vi.mock("@/lib/db", () => ({ db: {} }));
import { applyMovementInTransaction } from "./inventory";
function transaction(stock: number, exists: unknown = null) {
  return { inventoryMovement: { findUnique: vi.fn().mockResolvedValue(exists), create: vi.fn().mockImplementation(({ data }) => data) }, product: { update: vi.fn().mockResolvedValue({ id: "p", description: "Herramienta", stock: new Prisma.Decimal(stock) }) } };
}
describe("inventory movement safeguards", () => {
  it("records partial purchase receipts against a negative opening balance", async () => {
    const tx = transaction(-5);
    const result = await applyMovementInTransaction(tx as never, { productId: "p", type: "PURCHASE_RECEIPT", quantity: 5, sourceType: "PURCHASE_INVOICE", sourceId: "invoice" });
    expect(result.balanceAfter.toNumber()).toBe(-5);
    expect(tx.product.update).toHaveBeenCalledWith({ where: { id: "p" }, data: { stock: { increment: 5 } } });
  });
  it("does not apply the same source movement twice", async () => {
    const tx = transaction(10, { id: "existing" });
    expect(await applyMovementInTransaction(tx as never, { productId: "p", type: "PURCHASE_RECEIPT", quantity: 5, sourceType: "PURCHASE_INVOICE", sourceId: "invoice" })).toEqual({ id: "existing" });
    expect(tx.product.update).not.toHaveBeenCalled();
  });
  it("rejects deliveries without available stock inside the transaction", async () => {
    const tx = transaction(-1);
    await expect(applyMovementInTransaction(tx as never, { productId: "p", type: "DELIVERY", quantity: -2, sourceType: "DELIVERY", sourceId: "delivery" })).rejects.toThrow("Existencia insuficiente");
    expect(tx.inventoryMovement.create).not.toHaveBeenCalled();
  });
});
