import { Prisma } from "@prisma/client";
import { db } from "@/lib/db";

const sequenceId = "customer";

function formatCustomerCode(value: number) {
  return `CL-${String(value).padStart(5, "0")}`;
}

/** Assign codes to any legacy customer rows in original creation order. */
export async function ensureCustomerCodes() {
  for (let attempt = 0; attempt < 3; attempt += 1) {
    try {
      await db.$transaction(async (tx) => {
        const missing = await tx.party.findMany({
          where: { kind: "CUSTOMER", customerCode: null },
          orderBy: [{ createdAt: "asc" }, { id: "asc" }],
          select: { id: true },
        });
        if (missing.length === 0) return;

        const sequence = await tx.partyCodeSequence.upsert({
          where: { id: sequenceId },
          create: { id: sequenceId, nextValue: 0 },
          update: {},
        });
        let nextValue = sequence.nextValue;
        for (const customer of missing) {
          nextValue += 1;
          await tx.party.update({
            where: { id: customer.id },
            data: { customerCode: formatCustomerCode(nextValue) },
          });
        }
        await tx.partyCodeSequence.update({ where: { id: sequenceId }, data: { nextValue } });
      }, { isolationLevel: Prisma.TransactionIsolationLevel.Serializable });
      return;
    } catch (error) {
      if (!(error instanceof Prisma.PrismaClientKnownRequestError) || error.code !== "P2034" || attempt === 2) throw error;
    }
  }
}

export async function createCustomer(data: Prisma.PartyUncheckedCreateInput) {
  for (let attempt = 0; attempt < 3; attempt += 1) {
    try {
      return await db.$transaction(async (tx) => {
        const sequence = await tx.partyCodeSequence.upsert({
          where: { id: sequenceId },
          create: { id: sequenceId, nextValue: 1 },
          update: { nextValue: { increment: 1 } },
        });
        return tx.party.create({ data: { ...data, customerCode: formatCustomerCode(sequence.nextValue) } });
      }, { isolationLevel: Prisma.TransactionIsolationLevel.Serializable });
    } catch (error) {
      if (!(error instanceof Prisma.PrismaClientKnownRequestError) || error.code !== "P2034" || attempt === 2) throw error;
    }
  }
  throw new Error("No se pudo asignar el código de cliente.");
}
