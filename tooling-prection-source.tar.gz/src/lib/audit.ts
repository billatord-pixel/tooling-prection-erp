import { Prisma } from "@prisma/client";
import { db } from "@/lib/db";

export async function audit(input: { userId?: string; action: string; entity: string; entityId?: string; before?: Prisma.InputJsonValue; after?: Prisma.InputJsonValue; ipAddress?: string }) {
  return db.auditEvent.create({ data: input });
}
