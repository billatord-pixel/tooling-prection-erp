import { DocumentType, InventoryMovementType, Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { nextFolio } from "@/lib/folios";
import { ParsedCfdi } from "@/lib/cfdi";
import { aggregateInvoiceLines, allocateInvoiceReceipt } from "@/lib/purchase-lines";
import { applyMovementInTransaction } from "@/lib/inventory";

async function findProduct(description: string, technicalCode?: string) {
  if (technicalCode) {
    const coded = await db.product.findUnique({ where: { technicalCode } });
    if (coded) return coded;
  }
  const products = await db.product.findMany({ where: { status: "ACTIVE", description: { equals: description, mode: "insensitive" } }, take: 2 });
  return products.length === 1 ? products[0] : null;
}

async function upsertParty(kind: "SUPPLIER" | "CUSTOMER", rfc: string, name: string) {
  const existing = rfc ? await db.party.findFirst({ where: { kind, taxId: rfc } }) : null;
  if (existing) return { party: existing, created: false };
  return { party: null, created: false };
}

export async function previewInvoice(kind: "purchase" | "sales", cfdi: ParsedCfdi) {
  const party = kind === "purchase" ? cfdi.issuer : cfdi.receiver;
  const match = await upsertParty(kind === "purchase" ? "SUPPLIER" : "CUSTOMER", party.rfc, party.name);
  const lines = await Promise.all(cfdi.concepts.map(async line => ({ ...line, product: await findProduct(line.description, line.code) })));
  return { cfdi, party: match.party, needsPartyConfirmation: !match.party, lines };
}

export async function savePurchaseInvoice(cfdi: ParsedCfdi, xml: string, supplierId: string, purchaseOrderId?: string, productIds: string[] = []) {
  if (cfdi.uuid && await db.purchaseInvoice.findUnique({ where: { uuid: cfdi.uuid } })) throw new Error("Este UUID ya fue registrado en una factura de compra.");
  if (productIds.length > cfdi.concepts.length) throw new Error("Las asociaciones de producto no corresponden con las partidas del XML.");
  const selectedProductIds = [...new Set(productIds.filter(Boolean))];
  if (selectedProductIds.length) {
    const validProducts = await db.product.count({ where: { id: { in: selectedProductIds }, status: "ACTIVE" } });
    if (validProducts !== selectedProductIds.length) throw new Error("Una o más asociaciones corresponden a productos inexistentes o archivados.");
  }
  if (purchaseOrderId) {
    const order = await db.purchaseOrder.findUnique({ where: { id: purchaseOrderId }, select: { supplierId: true, status: true } });
    if (!order) throw new Error("El pedido de compra seleccionado ya no existe.");
    if (order.supplierId !== supplierId) throw new Error("La factura y el pedido deben corresponder al mismo proveedor.");
    if (order.status === "CANCELLED") throw new Error("No se puede relacionar una factura con un pedido cancelado.");
  }
  const folio = cfdi.series && cfdi.folio ? `${cfdi.series}-${cfdi.folio}` : await nextFolio(DocumentType.PURCHASE_INVOICE);
  const invoice = await db.purchaseInvoice.create({
    data: {
      folio, uuid: cfdi.uuid, series: cfdi.series, supplierId, purchaseOrderId, issueDate: cfdi.issueDate, currency: cfdi.currency,
      subtotal: cfdi.subtotal, tax: cfdi.tax, total: cfdi.total, paymentForm: cfdi.paymentForm, paymentMethod: cfdi.paymentMethod, rawXml: xml,
      fiscalData: cfdi as unknown as Prisma.InputJsonValue,
      lines: { create: await Promise.all(cfdi.concepts.map(async (line, index) => ({ description: line.description, unit: line.unit, quantity: line.quantity, unitPrice: line.unitPrice, amount: line.amount, productId: productIds[index] || (await findProduct(line.description, line.code))?.id }))) },
    }, include: { lines: true },
  });
  return invoice;
}

export async function processPurchaseInvoice(id: string) {
  return db.$transaction(async tx => {
    const invoice = await tx.purchaseInvoice.findUniqueOrThrow({ where: { id }, include: { lines: true, purchaseOrder: { include: { lines: true } } } });
    if (invoice.processedAt) return invoice;
    for (const line of invoice.lines) {
      if (!line.productId) throw new Error(`Asocia el producto para la partida: ${line.description}`);
    }

    // Una sola entrada por producto evita que la llave idempotente de movimientos
    // descarte partidas repetidas del mismo CFDI.
    for (const line of aggregateInvoiceLines(invoice.lines)) {
      await applyMovementInTransaction(tx, { productId: line.productId, type: InventoryMovementType.PURCHASE_RECEIPT, quantity: line.quantity, sourceType: DocumentType.PURCHASE_INVOICE, sourceId: invoice.id, purchaseInvoiceId: invoice.id });
    }

    if (invoice.purchaseOrderId && invoice.purchaseOrder) {
      if (invoice.purchaseOrder.status === "CANCELLED") throw new Error("No se puede recibir una factura contra un pedido cancelado.");
      const allocations = allocateInvoiceReceipt(invoice.purchaseOrder.lines, invoice.lines);
      for (const allocation of allocations) {
        await tx.purchaseOrderLine.update({ where: { id: allocation.orderLineId }, data: { receivedQuantity: { increment: allocation.quantity } } });
        const product = await tx.product.findUniqueOrThrow({ where: { id: allocation.productId } });
        await tx.product.update({ where: { id: product.id }, data: { onOrder: Prisma.Decimal.max(0, product.onOrder.minus(allocation.quantity)) } });
      }
      const finalLines = await tx.purchaseOrderLine.findMany({ where: { purchaseOrderId: invoice.purchaseOrderId } });
      const fullyReceived = finalLines.every(line => line.receivedQuantity.gte(line.quantity));
      await tx.purchaseOrder.update({ where: { id: invoice.purchaseOrderId }, data: { status: fullyReceived ? "DELIVERED" : "PENDING" } });
    }
    return tx.purchaseInvoice.update({ where: { id }, data: { processedAt: new Date() } });
  }, { isolationLevel: Prisma.TransactionIsolationLevel.Serializable });
}

export async function saveSalesInvoice(cfdi: ParsedCfdi, xml: string, customerId: string, attachments: Array<{ fileName: string; contentType: string; fileSize: number; data: Buffer }> = []) {
  if (cfdi.uuid && await db.salesInvoice.findUnique({ where: { uuid: cfdi.uuid } })) throw new Error("Este UUID ya fue registrado en una factura de venta.");
  const folio = cfdi.series && cfdi.folio ? `${cfdi.series}-${cfdi.folio}` : await nextFolio(DocumentType.SALES_INVOICE);
  const storedAttachments = attachments.map(file => { const data = new Uint8Array(new ArrayBuffer(file.data.byteLength)); data.set(file.data); return { fileName: file.fileName, contentType: file.contentType, fileSize: file.fileSize, data }; });
  return db.salesInvoice.create({
    data: {
      folio, uuid: cfdi.uuid, series: cfdi.series, customerId, issueDate: cfdi.issueDate, currency: cfdi.currency,
      subtotal: cfdi.subtotal, tax: cfdi.tax, total: cfdi.total, paymentForm: cfdi.paymentForm, paymentMethod: cfdi.paymentMethod, rawXml: xml,
      fiscalData: cfdi as unknown as Prisma.InputJsonValue,
      lines: { create: await Promise.all(cfdi.concepts.map(async line => ({ description: line.description, unit: line.unit, quantity: line.quantity, unitPrice: line.unitPrice, amount: line.amount, productId: (await findProduct(line.description, line.code))?.id }))) },
      attachments: storedAttachments.length ? { create: storedAttachments } : undefined,
    }, include: { lines: true },
  });
}

export async function processSalesInvoice(id: string) {
  return db.$transaction(async tx => {
    const invoice = await tx.salesInvoice.findUniqueOrThrow({ where: { id }, include: { lines: true } });
    if (invoice.processedAt) return invoice;
    for (const line of invoice.lines) {
      if (!line.productId) throw new Error(`Asocia el producto para la partida: ${line.description}`);
    }
    for (const line of aggregateInvoiceLines(invoice.lines)) {
      await applyMovementInTransaction(tx, { productId: line.productId, type: InventoryMovementType.SALE, quantity: line.quantity.negated(), sourceType: DocumentType.SALES_INVOICE, sourceId: invoice.id, salesInvoiceId: invoice.id });
    }
    return tx.salesInvoice.update({ where: { id }, data: { processedAt: new Date() } });
  }, { isolationLevel: Prisma.TransactionIsolationLevel.Serializable });
}
