import { DocumentType, InventoryMovementType, Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { nextFolio } from "@/lib/folios";
import { normalizedDescription, ParsedCfdi } from "@/lib/cfdi";
import { applyMovement } from "@/lib/inventory";

async function findProduct(description: string, technicalCode?: string) {
  if (technicalCode) {
    const coded = await db.product.findUnique({ where: { technicalCode } });
    if (coded) return coded;
  }
  const products = await db.product.findMany({ where: { status: "ACTIVE", description: { equals: description, mode: "insensitive" } }, take: 2 });
  return products.length === 1 ? products[0] : null;
}

async function upsertParty(kind: "SUPPLIER" | "CUSTOMER", rfc: string, name: string) {
  const existing = rfc ? await db.party.findFirst({ where: { kind, taxId: rfc } }) : null;
  if (existing) return { party: existing, created: false };
  return { party: null, created: false };
}

export async function previewInvoice(kind: "purchase" | "sales", cfdi: ParsedCfdi) {
  const party = kind === "purchase" ? cfdi.issuer : cfdi.receiver;
  const match = await upsertParty(kind === "purchase" ? "SUPPLIER" : "CUSTOMER", party.rfc, party.name);
  const lines = await Promise.all(cfdi.concepts.map(async line => ({ ...line, product: await findProduct(line.description, line.code) })));
  return { cfdi, party: match.party, needsPartyConfirmation: !match.party, lines };
}

export async function savePurchaseInvoice(cfdi: ParsedCfdi, xml: string, supplierId: string, purchaseOrderId?: string) {
  if (cfdi.uuid && await db.purchaseInvoice.findUnique({ where: { uuid: cfdi.uuid } })) throw new Error("Este UUID ya fue registrado en una factura de compra.");
  const folio = cfdi.series && cfdi.folio ? `${cfdi.series}-${cfdi.folio}` : await nextFolio(DocumentType.PURCHASE_INVOICE);
  const invoice = await db.purchaseInvoice.create({
    data: {
      folio, uuid: cfdi.uuid, series: cfdi.series, supplierId, purchaseOrderId, issueDate: cfdi.issueDate, currency: cfdi.currency,
      subtotal: cfdi.subtotal, tax: cfdi.tax, total: cfdi.total, paymentForm: cfdi.paymentForm, paymentMethod: cfdi.paymentMethod, rawXml: xml,
      fiscalData: cfdi as unknown as Prisma.InputJsonValue,
      lines: { create: await Promise.all(cfdi.concepts.map(async line => ({ description: line.description, unit: line.unit, quantity: line.quantity, unitPrice: line.unitPrice, amount: line.amount, productId: (await findProduct(line.description, line.code))?.id }))) },
    }, include: { lines: true },
  });
  return invoice;
}

export async function processPurchaseInvoice(id: string) {
  const invoice = await db.purchaseInvoice.findUniqueOrThrow({ where: { id }, include: { lines: { include: { product: true } }, purchaseOrder: { include: { lines: true } } } });
  if (invoice.processedAt) return invoice;
  for (const line of invoice.lines) {
    if (!line.productId) throw new Error(`Asocia el producto para la partida: ${line.description}`);
    await applyMovement({ productId: line.productId, type: InventoryMovementType.PURCHASE_RECEIPT, quantity: Number(line.quantity), sourceType: DocumentType.PURCHASE_INVOICE, sourceId: invoice.id, purchaseInvoiceId: invoice.id });
  }
  if (invoice.purchaseOrderId) {
    await db.$transaction(async tx => {
      for (const invoiceLine of invoice.lines) {
        const orderLine = invoice.purchaseOrder?.lines.find(line => normalizedDescription(line.description) === normalizedDescription(invoiceLine.description));
        if (orderLine && invoiceLine.productId) {
          const outstanding = Math.max(0, Number(orderLine.quantity) - Number(orderLine.receivedQuantity));
          const receivedNow = Math.min(outstanding, Number(invoiceLine.quantity));
          if (receivedNow > 0) {
            await tx.purchaseOrderLine.update({ where: { id: orderLine.id }, data: { receivedQuantity: { increment: receivedNow } } });
            const product = await tx.product.findUniqueOrThrow({ where: { id: invoiceLine.productId } });
            await tx.product.update({ where: { id: product.id }, data: { onOrder: Math.max(0, Number(product.onOrder) - receivedNow) } });
          }
        }
      }
      const orderLines = await tx.purchaseOrderLine.findMany({ where: { purchaseOrderId: invoice.purchaseOrderId! } });
      const fullyReceived = orderLines.every(line => Number(line.receivedQuantity) >= Number(line.quantity));
      await tx.purchaseOrder.update({ where: { id: invoice.purchaseOrderId! }, data: { status: fullyReceived ? "DELIVERED" : "PENDING" } });
    });
  }
  return db.purchaseInvoice.update({ where: { id }, data: { processedAt: new Date() } });
}

export async function saveSalesInvoice(cfdi: ParsedCfdi, xml: string, customerId: string) {
  if (cfdi.uuid && await db.salesInvoice.findUnique({ where: { uuid: cfdi.uuid } })) throw new Error("Este UUID ya fue registrado en una factura de venta.");
  const folio = cfdi.series && cfdi.folio ? `${cfdi.series}-${cfdi.folio}` : await nextFolio(DocumentType.SALES_INVOICE);
  return db.salesInvoice.create({
    data: {
      folio, uuid: cfdi.uuid, series: cfdi.series, customerId, issueDate: cfdi.issueDate, currency: cfdi.currency,
      subtotal: cfdi.subtotal, tax: cfdi.tax, total: cfdi.total, paymentForm: cfdi.paymentForm, paymentMethod: cfdi.paymentMethod, rawXml: xml,
      fiscalData: cfdi as unknown as Prisma.InputJsonValue,
      lines: { create: await Promise.all(cfdi.concepts.map(async line => ({ description: line.description, unit: line.unit, quantity: line.quantity, unitPrice: line.unitPrice, amount: line.amount, productId: (await findProduct(line.description, line.code))?.id }))) },
    }, include: { lines: true },
  });
}

export async function processSalesInvoice(id: string) {
  const invoice = await db.salesInvoice.findUniqueOrThrow({ where: { id }, include: { lines: true } });
  if (invoice.processedAt) return invoice;
  for (const line of invoice.lines) {
    if (!line.productId) throw new Error(`Asocia el producto para la partida: ${line.description}`);
    await applyMovement({ productId: line.productId, type: InventoryMovementType.SALE, quantity: -Number(line.quantity), sourceType: DocumentType.SALES_INVOICE, sourceId: invoice.id, salesInvoiceId: invoice.id });
  }
  return db.salesInvoice.update({ where: { id }, data: { processedAt: new Date() } });
}
