import { DocumentType, InventoryMovementType, Prisma, RecordStatus } from "@prisma/client";
import { db } from "@/lib/db";
import { nextFolio } from "@/lib/folios";
import { ParsedCfdi } from "@/lib/cfdi";
import { aggregateInvoiceLines, allocateInvoiceReceipt } from "@/lib/purchase-lines";
import { applyMovementInTransaction } from "@/lib/inventory";
import { normalizeMatch, normalizeTaxId } from "@/lib/identity-normalization";
import { createCustomerInTransaction } from "@/lib/customer-codes";

type PartyKind = "SUPPLIER" | "CUSTOMER";
type ProductLine = ParsedCfdi["concepts"][number];

async function findProduct(description: string, technicalCode?: string) {
  const code = technicalCode?.trim();
  if (code) {
    const coded = await db.product.findFirst({ where: { technicalCode: { equals: code, mode: "insensitive" } } });
    if (coded) return coded;
  }
  const products = await db.product.findMany({ where: { status: RecordStatus.ACTIVE }, take: 200 });
  const matches = products.filter(product => normalizeMatch(product.description) === normalizeMatch(description));
  return matches.length === 1 ? matches[0] : null;
}

async function findParty(kind: PartyKind, rfc: string, name: string) {
  const parties = await db.party.findMany({ where: { kind }, take: 500 });
  const normalizedRfc = normalizeTaxId(rfc);
  if (normalizedRfc) {
    const match = parties.find(party => normalizeTaxId(party.taxId || "") === normalizedRfc);
    if (match) return match;
  }
  const normalizedName = normalizeMatch(name);
  if (!normalizedName) return null;
  const matches = parties.filter(party => normalizeMatch(party.legalName) === normalizedName);
  return matches.length === 1 ? matches[0] : null;
}

async function resolvePartyInTransaction(tx: Prisma.TransactionClient, kind: PartyKind, name: string, rfc?: string, selectedId?: string) {
  const parties = await tx.party.findMany({ where: { kind }, take: 1000 });
  const normalizedRfc = normalizeTaxId(rfc);
  const byRfc = normalizedRfc ? parties.find(party => normalizeTaxId(party.taxId || "") === normalizedRfc) : undefined;
  if (byRfc) return byRfc;

  if (selectedId) {
    const selected = parties.find(party => party.id === selectedId);
    if (!selected) throw new Error(kind === "CUSTOMER" ? "El cliente seleccionado no existe." : "El proveedor seleccionado no existe.");
    const selectedRfc = normalizeTaxId(selected.taxId || "");
    if (normalizedRfc && selectedRfc && selectedRfc !== normalizedRfc) throw new Error("El RFC del registro seleccionado no coincide con el CFDI.");
    return selected;
  }

  const normalizedName = normalizeMatch(name);
  const sameName = normalizedName ? parties.filter(party => normalizeMatch(party.legalName) === normalizedName) : [];
  if (sameName.length === 1) {
    const existingRfc = normalizeTaxId(sameName[0].taxId || "");
    if (!normalizedRfc || !existingRfc || existingRfc === normalizedRfc) {
      if (normalizedRfc && !existingRfc) return tx.party.update({ where: { id: sameName[0].id }, data: { taxId: normalizedRfc } });
      return sameName[0];
    }
  }

  const legalName = name.trim() || (normalizedRfc ? `Registro CFDI ${normalizedRfc}` : "Registro CFDI sin razón social");
  const data = { kind, taxId: normalizedRfc || null, legalName, currency: "USD" };
  return kind === "CUSTOMER" ? createCustomerInTransaction(tx, data) : tx.party.create({ data });
}

async function resolveProductInTransaction(tx: Prisma.TransactionClient, line: ProductLine, index: number, kind: "purchase" | "sales", invoiceKey: string, currency: string, selectedId?: string) {
  if (selectedId) {
    const selected = await tx.product.findUnique({ where: { id: selectedId } });
    if (!selected) throw new Error(`El producto seleccionado para la partida ${index + 1} ya no existe.`);
    return selected.status === RecordStatus.ACTIVE ? selected : tx.product.update({ where: { id: selected.id }, data: { status: RecordStatus.ACTIVE } });
  }

  const code = line.code?.trim();
  if (code) {
    const coded = await tx.product.findFirst({ where: { technicalCode: { equals: code, mode: "insensitive" } } });
    if (coded) return coded.status === RecordStatus.ACTIVE ? coded : tx.product.update({ where: { id: coded.id }, data: { status: RecordStatus.ACTIVE } });
  }

  const products = await tx.product.findMany({ where: { status: RecordStatus.ACTIVE }, take: 1000 });
  const descriptions = products.filter(product => normalizeMatch(product.description) === normalizeMatch(line.description));
  if (descriptions.length === 1) return descriptions[0];

  const fallback = `CFDI-${normalizeMatch(invoiceKey).replace(/[^A-Z0-9]/g, "").slice(-18) || "SINREF"}-${index + 1}`;
  const technicalCode = (code || fallback).slice(0, 100);
  const collision = await tx.product.findFirst({ where: { technicalCode: { equals: technicalCode, mode: "insensitive" } } });
  if (collision) return collision;
  return tx.product.create({ data: {
    technicalCode,
    description: line.description.trim() || `Producto CFDI ${technicalCode}`,
    unit: line.unit?.trim() || "PZA",
    currency,
    baseCost: kind === "purchase" ? line.unitPrice : 0,
    salePrice: kind === "sales" ? line.unitPrice : 0,
  } });
}

export async function previewInvoice(kind: "purchase" | "sales", cfdi: ParsedCfdi) {
  const party = kind === "purchase" ? cfdi.issuer : cfdi.receiver;
  const match = await findParty(kind === "purchase" ? "SUPPLIER" : "CUSTOMER", party.rfc, party.name);
  const lines = await Promise.all(cfdi.concepts.map(async line => ({ ...line, product: await findProduct(line.description, line.code) })));
  return { cfdi, party: match, needsPartyConfirmation: !match, lines };
}

export async function savePurchaseInvoice(cfdi: ParsedCfdi, xml: string, supplierId?: string, purchaseOrderId?: string, productIds: string[] = [], attachments: Array<{ fileName: string; contentType: string; data: Buffer }> = []) {
  if (productIds.length > cfdi.concepts.length) throw new Error("Las asociaciones de producto no corresponden con las partidas del XML.");
  const folio = cfdi.series && cfdi.folio ? `${cfdi.series}-${cfdi.folio}` : await nextFolio(DocumentType.PURCHASE_INVOICE);
  const invoiceKey = cfdi.uuid || folio;
  return db.$transaction(async tx => {
    if (cfdi.uuid && await tx.purchaseInvoice.findUnique({ where: { uuid: cfdi.uuid } })) throw new Error("Este UUID ya fue registrado en una factura de compra.");
    const supplier = await resolvePartyInTransaction(tx, "SUPPLIER", cfdi.issuer.name, cfdi.issuer.rfc, supplierId);
    if (purchaseOrderId) {
      const order = await tx.purchaseOrder.findUnique({ where: { id: purchaseOrderId }, select: { supplierId: true, status: true } });
      if (!order) throw new Error("El pedido de compra seleccionado ya no existe.");
      if (order.supplierId !== supplier.id) throw new Error("La factura y el pedido deben corresponder al mismo proveedor.");
      if (order.status === "CANCELLED") throw new Error("No se puede relacionar una factura con un pedido cancelado.");
    }

    const mappedProductIds: string[] = [];
    for (const [index, line] of cfdi.concepts.entries()) mappedProductIds.push((await resolveProductInTransaction(tx, line, index, "purchase", invoiceKey, cfdi.currency, productIds[index])).id);
    const invoiceLines = cfdi.concepts.map((line, index) => ({ description: line.description, unit: line.unit, quantity: line.quantity, unitPrice: line.unitPrice, amount: line.amount, productId: mappedProductIds[index] }));
    const invoice = await tx.purchaseInvoice.create({
      data: {
        folio, uuid: cfdi.uuid, series: cfdi.series, supplierId: supplier.id, purchaseOrderId, issueDate: cfdi.issueDate, currency: cfdi.currency,
        subtotal: cfdi.subtotal, tax: cfdi.tax, total: cfdi.total, paymentForm: cfdi.paymentForm, paymentMethod: cfdi.paymentMethod, rawXml: xml,
        fiscalData: cfdi as unknown as Prisma.InputJsonValue, lines: { create: invoiceLines },
        attachments: attachments.length ? { create: attachments.map(file => ({ fileName: file.fileName, contentType: file.contentType, fileSize: file.data.length, data: new Uint8Array(file.data) })) } : undefined,
      }, include: { lines: true },
    });
    return processPurchaseInvoiceInTransaction(tx, invoice.id);
  }, { isolationLevel: Prisma.TransactionIsolationLevel.Serializable });
}

async function processPurchaseInvoiceInTransaction(tx: Prisma.TransactionClient, id: string) {
  const invoice = await tx.purchaseInvoice.findUniqueOrThrow({ where: { id }, include: { lines: true, purchaseOrder: { include: { lines: true } } } });
  if (invoice.processedAt) return invoice;
  for (const line of invoice.lines) if (!line.productId) throw new Error(`No se pudo asociar la partida: ${line.description}`);

  for (const line of aggregateInvoiceLines(invoice.lines)) {
    await applyMovementInTransaction(tx, { productId: line.productId, type: InventoryMovementType.PURCHASE_RECEIPT, quantity: line.quantity, sourceType: DocumentType.PURCHASE_INVOICE, sourceId: invoice.id, purchaseInvoiceId: invoice.id });
  }

  if (invoice.purchaseOrderId && invoice.purchaseOrder) {
    if (invoice.purchaseOrder.status === "CANCELLED") throw new Error("No se puede recibir una factura contra un pedido cancelado.");
    const allocations = allocateInvoiceReceipt(invoice.purchaseOrder.lines, invoice.lines);
    for (const allocation of allocations) {
      await tx.purchaseOrderLine.update({ where: { id: allocation.orderLineId }, data: { receivedQuantity: { increment: allocation.quantity } } });
      const product = await tx.product.findUniqueOrThrow({ where: { id: allocation.productId } });
      await tx.product.update({ where: { id: product.id }, data: { onOrder: Prisma.Decimal.max(0, product.onOrder.minus(allocation.quantity)) } });
    }
    const finalLines = await tx.purchaseOrderLine.findMany({ where: { purchaseOrderId: invoice.purchaseOrderId } });
    const fullyReceived = finalLines.every(line => line.receivedQuantity.gte(line.quantity));
    await tx.purchaseOrder.update({ where: { id: invoice.purchaseOrderId }, data: { status: fullyReceived ? "DELIVERED" : "PENDING" } });
  }
  return tx.purchaseInvoice.update({ where: { id }, data: { processedAt: new Date() }, include: { lines: true } });
}

export async function processPurchaseInvoice(id: string) {
  return db.$transaction(tx => processPurchaseInvoiceInTransaction(tx, id), { isolationLevel: Prisma.TransactionIsolationLevel.Serializable });
}

export async function saveSalesInvoice(cfdi: ParsedCfdi, xml: string, customerId?: string, attachments: Array<{ fileName: string; contentType: string; fileSize: number; data: Buffer }> = [], productIds: string[] = [], options: { historical?: boolean; productCodes?: string[] } = {}) {
  if (productIds.length > cfdi.concepts.length || (options.productCodes?.length || 0) > cfdi.concepts.length) throw new Error("Las asociaciones de producto no corresponden con las partidas del XML.");
  const folio = cfdi.series && cfdi.folio ? `${cfdi.series}-${cfdi.folio}` : await nextFolio(DocumentType.SALES_INVOICE);
  const invoiceKey = cfdi.uuid || folio;
  const storedAttachments = attachments.map(file => { const data = new Uint8Array(new ArrayBuffer(file.data.byteLength)); data.set(file.data); return { fileName: file.fileName, contentType: file.contentType, fileSize: file.fileSize, data }; });
  return db.$transaction(async tx => {
    if (cfdi.uuid && await tx.salesInvoice.findUnique({ where: { uuid: cfdi.uuid } })) throw new Error("Este UUID ya fue registrado en una factura de venta.");
    const customer = await resolvePartyInTransaction(tx, "CUSTOMER", cfdi.receiver.name, cfdi.receiver.rfc, customerId);
    const mappedProductIds: string[] = [];
    for (const [index, line] of cfdi.concepts.entries()) {
      const code = options.productCodes?.[index]?.trim() || line.code;
      mappedProductIds.push((await resolveProductInTransaction(tx, { ...line, code }, index, "sales", invoiceKey, cfdi.currency, productIds[index])).id);
    }
    const invoiceLines = cfdi.concepts.map((line, index) => ({ description: line.description, unit: line.unit, quantity: line.quantity, unitPrice: line.unitPrice, amount: line.amount, productId: mappedProductIds[index] }));
    const invoice = await tx.salesInvoice.create({
      data: {
        folio, uuid: cfdi.uuid, series: cfdi.series, customerId: customer.id, issueDate: cfdi.issueDate, currency: cfdi.currency,
        subtotal: cfdi.subtotal, tax: cfdi.tax, total: cfdi.total, paymentForm: cfdi.paymentForm, paymentMethod: cfdi.paymentMethod, rawXml: xml,
        fiscalData: cfdi as unknown as Prisma.InputJsonValue, inventoryDisposition: options.historical ? "HISTORICAL" : "APPLIED", lines: { create: invoiceLines },
        attachments: storedAttachments.length ? { create: storedAttachments } : undefined,
      }, include: { lines: true },
    });
    return options.historical ? invoice : processSalesInvoiceInTransaction(tx, invoice.id);
  }, { isolationLevel: Prisma.TransactionIsolationLevel.Serializable });
}

async function processSalesInvoiceInTransaction(tx: Prisma.TransactionClient, id: string) {
  const invoice = await tx.salesInvoice.findUniqueOrThrow({ where: { id }, include: { lines: true } });
  if (invoice.inventoryDisposition === "HISTORICAL") throw new Error("Las facturas históricas previas al arranque no generan movimientos de inventario.");
  if (invoice.processedAt) return invoice;
  for (const line of invoice.lines) if (!line.productId) throw new Error(`No se pudo asociar la partida: ${line.description}`);
  for (const line of aggregateInvoiceLines(invoice.lines)) {
    await applyMovementInTransaction(tx, { productId: line.productId, type: InventoryMovementType.SALE, quantity: line.quantity.negated(), sourceType: DocumentType.SALES_INVOICE, sourceId: invoice.id, salesInvoiceId: invoice.id });
  }
  return tx.salesInvoice.update({ where: { id }, data: { processedAt: new Date() }, include: { lines: true } });
}

export async function processSalesInvoice(id: string) {
  return db.$transaction(tx => processSalesInvoiceInTransaction(tx, id), { isolationLevel: Prisma.TransactionIsolationLevel.Serializable });
}
