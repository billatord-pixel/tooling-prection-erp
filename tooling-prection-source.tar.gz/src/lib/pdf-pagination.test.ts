import { describe, expect, it } from "vitest";
import PDFDocument from "pdfkit";
import { drawToolingPdfFooter } from "./pdf-brand";
describe("operational PDF footers", () => {
  for (const layout of ["portrait", "landscape"] as const) {
    it(`does not append blank ${layout} pages`, async () => {
      const doc = new PDFDocument({ size: "LETTER", layout, margins: { top: 38, left: 42, right: 42, bottom: 48 }, bufferPages: true });
      const chunks: Buffer[] = [];
      doc.on("data", data => chunks.push(Buffer.from(data)));
      const complete = new Promise<Buffer>(resolve => doc.on("end", () => resolve(Buffer.concat(chunks))));
      doc.text("Documento de prueba", 42, 90);
      doc.addPage(); doc.text("Continuación", 42, 90);
      const range = doc.bufferedPageRange();
      for (let page = 0; page < range.count; page++) { doc.switchToPage(page); drawToolingPdfFooter(doc, "Tooling Prection", page + 1, range.count); }
      expect(doc.bufferedPageRange().count).toBe(2);
      doc.end();
      const pdf = await complete;
      expect((pdf.toString("latin1").match(/\/Type\s*\/Page\b/g) || []).length).toBe(2);
    });
  }
});
