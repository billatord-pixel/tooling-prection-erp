// Reads bytes only: no URLs, scripts, OCR claims or inventory operations.
export async function readCustomerOrderPdf(bytes: Uint8Array) {
  const { getDocument } = await import("pdfjs-dist/legacy/build/pdf.mjs");
  const task = getDocument({
    data: Uint8Array.from(bytes),
    enableXfa: false,
    useSystemFonts: false,
    disableFontFace: true,
    verbosity: 0,
  });
  const timeout = setTimeout(() => void task.destroy(), 25000);
  try {
    const pdf = await task.promise;
    if (pdf.numPages > 40)
      throw new Error(
        "El PDF contiene demasiadas páginas para la lectura automática.",
      );
    const pages: string[] = [];
    for (let index = 1; index <= pdf.numPages; index++) {
      const page = await pdf.getPage(index);
      const content = await page.getTextContent();
      const words = content.items
        .filter(
          (item): item is Extract<typeof item, { str: string }> =>
            "str" in item,
        )
        .map((item) => ({
          text: item.str,
          x: item.transform[4] as number,
          y: item.transform[5] as number,
        }));
      const lines: Array<{
        y: number;
        words: Array<{ text: string; x: number }>;
      }> = [];
      for (const word of words.sort((a, b) => b.y - a.y || a.x - b.x)) {
        let line = lines.find((line) => Math.abs(line.y - word.y) < 2.5);
        if (!line) {
          line = { y: word.y, words: [] };
          lines.push(line);
        }
        line.words.push(word);
      }
      pages.push(
        lines
          .map((line) =>
            line.words
              .sort((a, b) => a.x - b.x)
              .map((word) => word.text)
              .join(" ")
              .replace(/\s+/g, " ")
              .trim(),
          )
          .filter(Boolean)
          .join("\n"),
      );
      page.cleanup();
    }
    return pages.join("\n\n").slice(0, 250000);
  } finally {
    clearTimeout(timeout);
    await task.destroy();
  }
}
