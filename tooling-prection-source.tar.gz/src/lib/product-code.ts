/** Some suppliers print only the numeric part of an EDP already in the catalog. */
export function invoiceTechnicalCode(code: string | undefined, description: string) {
  const value = code?.trim();
  if (value && /^\d{1,2}$/.test(value)) {
    const explicit = description.match(/\bCE-\d{4,8}\b/i)?.[0];
    if (explicit) return explicit.toUpperCase();
  }
  return value;
}
export function productCodeCandidates(code: string | undefined) {
  if (!code) return [];
  const value = code.trim();
  const numeric = value.replace(/^EDP\s*/i, "");
  if (!/^\d{5,12}$/.test(numeric)) return [value];
  return [...new Set([value, numeric, `EDP ${numeric}`, `EDP${numeric}`])];
}
