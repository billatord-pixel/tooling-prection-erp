import { Prisma } from "@prisma/client";
import { db } from "@/lib/db";

type Amount = Prisma.Decimal.Value;
type ValuationLine = { quantity: Amount; unitPrice: Amount | null; printedAmount: Amount | null; useCalculatedAmount?: boolean };

function calculateLine(line: ValuationLine) {
  const quantity = new Prisma.Decimal(line.quantity);
  const calculated = quantity.mul(line.unitPrice ?? 0).toDecimalPlaces(2);
  const documented = line.printedAmount === null ? calculated : new Prisma.Decimal(line.printedAmount);
  const effective = line.useCalculatedAmount ? calculated : documented;
  return { quantity, calculated, documented, effective };
}

export function summarizePhysicalInventory(snapshot: { title: string; currency: string; documentTotal: Amount; lines: ValuationLine[] }) {
  let calculated = new Prisma.Decimal(0);
  let printed = new Prisma.Decimal(0);
  let adjustment = new Prisma.Decimal(0);
  let adjustedLines = 0;
  for (const line of snapshot.lines) {
    const { quantity, calculated: amount, documented, effective } = calculateLine(line);
    if (line.unitPrice === null && !quantity.isZero()) throw new Error("Una partida con existencia requiere precio unitario.");
    const difference = effective.minus(amount);
    if (!difference.isZero()) adjustedLines++;
    calculated = calculated.plus(amount);
    printed = printed.plus(documented);
    adjustment = adjustment.plus(difference);
  }
  const total = calculated.plus(adjustment);
  if (!printed.equals(snapshot.documentTotal)) throw new Error("Los importes impresos no coinciden con el total del documento.");
  return {
    title: snapshot.title,
    currency: snapshot.currency,
    lines: snapshot.lines.length,
    calculatedTotal: calculated.toNumber(),
    roundingAdjustment: adjustment.toNumber(),
    adjustedLines,
    total: total.toNumber(),
  };
}

export async function loadPhysicalInventoryValuation() {
  const snapshot = await db.inventoryPhysicalValuation.findFirst({
    where: { publishedAt: { not: null } },
    orderBy: [{ publishedAt: "desc" }, { id: "desc" }],
    include: {
      lines: {
        select: {
          quantity: true, unitPrice: true, printedAmount: true, useCalculatedAmount: true, productId: true,
          review: { select: { productId: true } },
        },
      },
    },
  });
  return snapshot && { summary: summarizePhysicalInventory(snapshot), lines: snapshot.lines };
}

type LinkedLine = ValuationLine & { productId: string | null; review: { productId: string | null } | null };
export function physicalInventoryByProduct(lines: LinkedLine[]) {
  const grouped = new Map<string, {
    quantity: Prisma.Decimal;
    value: Prisma.Decimal;
    prices: Set<number>;
  }>();
  for (const line of lines) {
    const productId = line.productId ?? line.review?.productId;
    if (!productId) continue;
    const group = grouped.get(productId) ?? { quantity: new Prisma.Decimal(0), value: new Prisma.Decimal(0), prices: new Set<number>() };
    const { quantity, effective } = calculateLine(line);
    group.quantity = group.quantity.plus(quantity);
    group.value = group.value.plus(effective);
    if (line.unitPrice !== null) group.prices.add(Number(line.unitPrice));
    grouped.set(productId, group);
  }
  return new Map([...grouped].map(([id, group]) => [id, {
    quantity: group.quantity.toNumber(),
    amount: group.value.toNumber(),
    unitPrices: [...group.prices].sort((a, b) => a - b),
  }]));
}
