import { mexicoToday } from "@/lib/customer-order-calendar";

const endpoint = "https://www.banxico.org.mx/tipcamb/tipCamIHAction.do";
const dateForBanxico = (iso: string) => iso.split("-").reverse().join("/");

function banxicoUrl(from: string, to: string) {
  const params = new URLSearchParams({ idioma: "sp", fechaInicial: dateForBanxico(from), fechaFinal: dateForBanxico(to), salida: "HTML" });
  return `${endpoint}?${params}`;
}

function columnCells(html: string) {
  return [...html.matchAll(/<td\b[^>]*>([\s\S]*?)<\/td\s*>/gi)].map(match => match[1].trim());
}

export type BanxicoFix = { date: string; rate: string };

function readBanxicoFixes(html: string, from: string, to: string): BanxicoFix[] {
  // The source uses separate nested tables for dates, FIX, DOF and obligations.
  const header = /<td\b[^>]*>\s*Fecha\s*<\/td>\s*<td\b[^>]*>\s*Determinaci(?:&oacute;|ó)n\s*<\/td>[\s\S]*?<\/tr>/i.exec(html);
  if (!header) return [];
  const tables = html.slice(header.index + header[0].length).matchAll(/<table\b[^>]*>([\s\S]*?)<\/table\s*>/gi);
  const dateTable = tables.next().value?.[1];
  const fixTable = tables.next().value?.[1];
  if (!dateTable || !fixTable) return [];
  const dates = columnCells(dateTable);
  const rates = columnCells(fixTable);
  if (dates.length !== rates.length || !dates.every(date => /^\d{2}\/\d{2}\/\d{4}$/.test(date))) return [];

  const quotes: BanxicoFix[] = [];
  for (const [index, dateCell] of dates.entries()) {
    const date = dateCell.split("/").reverse().join("-");
    const rate = rates[index];
    if (date < from || date > to || !/^\d+\.\d{1,6}$/.test(rate) || Number(rate) <= 0) continue;
    quotes.push({ date, rate });
  }
  return quotes.sort((a,b)=>b.date.localeCompare(a.date));
}

export function readBanxicoFix(html: string, from: string, to: string) {
  return readBanxicoFixes(html, from, to)[0] ?? null;
}

function twoWeeksBefore(date: string) {
  const start = new Date(`${date}T00:00:00Z`);
  start.setUTCDate(start.getUTCDate() - 14);
  return start.toISOString().slice(0, 10);
}

async function fetchBanxicoFixes(from: string, to: string, today: string) {
  try {
    const response = await fetch(banxicoUrl(from, to), {
      next: { revalidate: to < today ? 3600 : 60 },
      signal: AbortSignal.timeout(4500),
    });
    if (response.ok) {
      const charset = /charset\s*=\s*utf-8/i.test(response.headers.get("content-type") ?? "") ? "utf-8" : "windows-1252";
      const html = new TextDecoder(charset).decode(await response.arrayBuffer());
      return readBanxicoFixes(html, from, to);
    }
  } catch {
    // An unavailable rate must not block the other indicators in the report.
  }
  return [];
}

export async function getBanxicoInventoryRate(now = new Date()) {
  const requestedDate = mexicoToday(now);
  const [fix] = await fetchBanxicoFixes(twoWeeksBefore(requestedDate), requestedDate, requestedDate);
  return { requestedDate, quote: fix ? { ...fix, sourceUrl: banxicoUrl(fix.date, fix.date) } : null };
}

export async function getBanxicoSalesRates(dates: string[], now = new Date()) {
  const today = mexicoToday(now);
  const years = new Map<string, string[]>();
  for (const date of [...new Set(dates)].sort()) {
    if (date > today) continue;
    const year = date.slice(0,4);
    const group = years.get(year) ?? [];
    group.push(date);
    years.set(year, group);
  }
  const rates = new Map<string, BanxicoFix>();
  await Promise.all([...years.values()].map(async days => {
    const quotes = await fetchBanxicoFixes(twoWeeksBefore(days[0]), days[days.length-1], today);
    for (const date of days) {
      const minimum = twoWeeksBefore(date);
      const fix = quotes.find(quote => quote.date <= date && quote.date >= minimum);
      if (fix) rates.set(date, fix);
    }
  }));
  return rates;
}

export type BanxicoInventoryRate = Awaited<ReturnType<typeof getBanxicoInventoryRate>>;
