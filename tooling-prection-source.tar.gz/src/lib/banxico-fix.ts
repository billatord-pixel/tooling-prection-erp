import { mexicoToday } from "@/lib/customer-order-calendar";

const endpoint = "https://www.banxico.org.mx/tipcamb/tipCamIHAction.do";
const dateForBanxico = (iso: string) => iso.split("-").reverse().join("/");

function banxicoUrl(from: string, to: string) {
  const params = new URLSearchParams({ idioma: "sp", fechaInicial: dateForBanxico(from), fechaFinal: dateForBanxico(to), salida: "HTML" });
  return `${endpoint}?${params}`;
}

function columnCells(html: string) {
  return [...html.matchAll(/<td\b[^>]*>([\s\S]*?)<\/td\s*>/gi)].map(match => match[1].trim());
}

export function readBanxicoFix(html: string, from: string, to: string) {
  // The source uses separate nested tables for dates, FIX, DOF and obligations.
  const header = /<td\b[^>]*>\s*Fecha\s*<\/td>\s*<td\b[^>]*>\s*Determinaci(?:&oacute;|ó)n\s*<\/td>[\s\S]*?<\/tr>/i.exec(html);
  if (!header) return null;
  const tables = html.slice(header.index + header[0].length).matchAll(/<table\b[^>]*>([\s\S]*?)<\/table\s*>/gi);
  const dateTable = tables.next().value?.[1];
  const fixTable = tables.next().value?.[1];
  if (!dateTable || !fixTable) return null;
  const dates = columnCells(dateTable);
  const rates = columnCells(fixTable);
  if (dates.length !== rates.length || !dates.every(date => /^\d{2}\/\d{2}\/\d{4}$/.test(date))) return null;

  let quote: { date: string; rate: string } | null = null;
  for (const [index, dateCell] of dates.entries()) {
    const date = dateCell.split("/").reverse().join("-");
    const rate = rates[index];
    if (date < from || date > to || !/^\d+\.\d{1,6}$/.test(rate) || Number(rate) <= 0) continue;
    if (!quote || date > quote.date) quote = { date, rate };
  }
  return quote;
}

export async function getBanxicoInventoryRate(now = new Date()) {
  const requestedDate = mexicoToday(now);
  const start = new Date(`${requestedDate}T00:00:00Z`);
  start.setUTCDate(start.getUTCDate() - 14);
  const from = start.toISOString().slice(0, 10);
  try {
    const response = await fetch(banxicoUrl(from, requestedDate), {
      next: { revalidate: 60 },
      signal: AbortSignal.timeout(4500),
    });
    if (response.ok) {
      const charset = /charset\s*=\s*utf-8/i.test(response.headers.get("content-type") ?? "") ? "utf-8" : "windows-1252";
      const html = new TextDecoder(charset).decode(await response.arrayBuffer());
      const fix = readBanxicoFix(html, from, requestedDate);
      if (fix) return { requestedDate, quote: { ...fix, sourceUrl: banxicoUrl(fix.date, fix.date) } };
    }
  } catch {
    // An unavailable rate must not block the other indicators in the report.
  }
  return { requestedDate, quote: null };
}

export type BanxicoInventoryRate = Awaited<ReturnType<typeof getBanxicoInventoryRate>>;
