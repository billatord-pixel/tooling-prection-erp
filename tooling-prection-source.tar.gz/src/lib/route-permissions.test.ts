import { beforeEach, describe, expect, it, vi } from "vitest";
const session = vi.hoisted(() => vi.fn());
vi.mock("@/lib/auth", () => ({ currentSession: session }));
vi.mock("@/lib/db", () => ({ db: {} }));
const routes = [
  ["órdenes de clientes", () => import("@/app/api/ordenes-clientes/route"), ["POST"]],
  ["lectura PDF de órdenes", () => import("@/app/api/ordenes-clientes/procesar/route"), ["POST"]],
  ["productos", () => import("@/app/api/products/route"), ["POST"]],
  ["clientes y proveedores", () => import("@/app/api/parties/route"), ["POST"]],
  ["catálogos", () => import("@/app/api/catalogs/route"), ["POST", "PATCH"]],
  ["pedidos", () => import("@/app/api/purchase-orders/route"), ["POST"]],
  ["facturas de compra", () => import("@/app/api/invoices/purchase/route"), ["POST"]],
  ["facturas de venta", () => import("@/app/api/invoices/sales/route"), ["POST"]],
  ["remisiones", () => import("@/app/api/deliveries/route"), ["POST"]],
  ["usuarios", () => import("@/app/api/users/route"), ["POST", "PATCH"]],
  ["empleados", () => import("@/app/api/employees/route"), ["POST", "PATCH"]],
  ["configuración", () => import("@/app/api/settings/route"), ["PUT"]],
  ["reporte general", () => import("@/app/api/reports/route"), ["GET"]],
  ["PDF general", () => import("@/app/api/reports/pdf/route"), ["GET"]],
  ["exportación de respaldo", () => import("@/app/api/backups/export/route"), ["GET"]],
  ["estado de respaldo", () => import("@/app/api/backups/status/route"), ["GET"]],
] as const;
describe("vendedor: cotizaciones y consulta, sin cambios administrativos", () => {
  beforeEach(() => session.mockResolvedValue({ id: "seller", role: "SALES" }));
  for (const [name, load, methods] of routes) for (const method of methods) it(`bloquea ${method} de ${name}`, async () => {
    const route = await load() as unknown as Record<string, (request: Request) => Promise<Response>>;
    const result = await route[method](new Request("http://localhost/api/test", { method, ...(method === "GET" ? {} : { headers: { "Content-Type": "application/json" }, body: "{}" }) }));
    expect(result.status).toBe(403);
  });
  it("permite entrar a la validación de nueva cotización", async () => {
    const { POST } = await import("@/app/api/quotes/route");
    const result = await POST(new Request("http://localhost/api/quotes", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" }));
    expect(result.status).toBe(400);
  });
  it("muestra al vendedor solo el panel de PDF operativos", async () => {
    const { default: Page } = await import("@/app/(protected)/[module]/page");
    const { OperationalReportsWorkspace } = await import("@/components/operational-reports-workspace");
    const result = await Page({ params: Promise.resolve({ module: "reportes" }) });
    expect(result.type).toBe(OperationalReportsWorkspace);
  });
});
