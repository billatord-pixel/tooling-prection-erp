import { Prisma } from "@prisma/client";
import { parseCfdi } from "@/lib/cfdi";

export const INVENTORY_VALUATION_METHOD = "Existencia actual × precio de la última venta facturada vigente; sin ventas, última compra vigente; sin facturas, costo de catálogo. Importes unitarios sin IVA.";
export const inventoryValuationInclude = {
  salesInvoiceLines: { where: { quantity: { gt: 0 }, salesInvoice: { status: { notIn: ["CANCELLED", "DRAFT"] }, archivedAt: null } }, orderBy: [{ salesInvoice: { issueDate: "desc" } }, { salesInvoice: { createdAt: "desc" } }, { id: "desc" }], take: 1, select: { unitPrice: true, salesInvoice: { select: { folio: true, currency: true, exchangeRate: true, rawXml: true } } } },
  purchaseInvoiceLines: { where: { quantity: { gt: 0 }, purchaseInvoice: { status: { notIn: ["CANCELLED", "DRAFT"] } } }, orderBy: [{ purchaseInvoice: { issueDate: "desc" } }, { purchaseInvoice: { createdAt: "desc" } }, { id: "desc" }], take: 1, select: { unitPrice: true, purchaseInvoice: { select: { folio: true, currency: true, exchangeRate: true, rawXml: true } } } },
} satisfies Prisma.ProductInclude;
type Invoice = { folio: string; currency: string; exchangeRate?: unknown; rawXml?: string | null };
export type ValuationProduct = { id?: string; stock: unknown; currency: string; baseCost: unknown; salesInvoiceLines?: Array<{ unitPrice: unknown; salesInvoice: Invoice }>; purchaseInvoiceLines?: Array<{ unitPrice: unknown; purchaseInvoice: Invoice }> };
function exchange(invoice: Invoice) {
  if (invoice.currency === "MXN") return 1;
  const rate = Number(invoice.exchangeRate);
  if (Number.isFinite(rate) && rate > 0) return rate;
  try { return invoice.rawXml ? parseCfdi(invoice.rawXml).exchangeRate : null; } catch { return null; }
}
export function valueInventoryProduct(product: ValuationProduct, targetCurrency?: string) {
  const sale = product.salesInvoiceLines?.[0], purchase = product.purchaseInvoiceLines?.[0];
  const source: "SALE" | "PURCHASE" | "CATALOG_COST" = sale ? "SALE" : purchase ? "PURCHASE" : "CATALOG_COST";
  const invoice = sale?.salesInvoice ?? purchase?.purchaseInvoice;
  const currency = invoice?.currency ?? product.currency;
  const unitPrice = new Prisma.Decimal(String(sale?.unitPrice ?? purchase?.unitPrice ?? product.baseCost));
  const nativeValue = unitPrice.mul(String(product.stock));
  let converted: Prisma.Decimal | null = nativeValue;
  if (targetCurrency && targetCurrency !== currency) {
    const rate = invoice ? exchange(invoice) : null;
    // Each source document's own MXN-per-unit rate. No unrelated/latest market FX.
    converted = targetCurrency === "MXN" && rate && rate > 0 ? nativeValue.mul(String(rate)) : null;
  }
  return { source, currency, unitPrice: unitPrice.toNumber(), folio: invoice?.folio ?? null, exchangeRate: invoice ? exchange(invoice) : null, nativeValue: nativeValue.toNumber(), value: converted?.toNumber() ?? null };
}
export function summarizeInventoryValuation(products: ValuationProduct[], targetCurrency?: string) {
  const native = new Map<string, Prisma.Decimal>();
  const sources = { SALE: 0, PURCHASE: 0, CATALOG_COST: 0 };
  let value = new Prisma.Decimal(0), missingConversion = 0, negativeStock = 0;
  for (const product of products) {
    const row = valueInventoryProduct(product, targetCurrency);
    native.set(row.currency, (native.get(row.currency) ?? new Prisma.Decimal(0)).plus(String(row.nativeValue)));
    sources[row.source]++;
    if (Number(product.stock) < 0) negativeStock++;
    if (row.value === null && Number(product.stock) !== 0) missingConversion++;
    else if (row.value !== null) value = value.plus(String(row.value));
  }
  return { method: INVENTORY_VALUATION_METHOD, currency: targetCurrency ?? null, total: targetCurrency ? value.toDecimalPlaces(2).toNumber() : null, nativeTotals: [...native].map(([currency, total]) => ({ currency, total: total.toDecimalPlaces(2).toNumber() })), missingConversion, negativeStock, sources };
}
