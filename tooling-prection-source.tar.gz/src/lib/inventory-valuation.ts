import { Prisma } from "@prisma/client";
import { parseCfdi } from "@/lib/cfdi";

export const INVENTORY_VALUATION_METHOD = "Se multiplica la existencia actual por el precio sin IVA de la última venta vigente. Si no hay venta, se usa la última compra vigente o, si no hay facturas, el costo registrado en el catálogo.";
const invoiceLineSelect = { unitPrice: true, description: true, quantity: true, amount: true } as const;
export const inventoryValuationInclude = {
  salesInvoiceLines: { where: { quantity: { gt: 0 }, salesInvoice: { status: { notIn: ["CANCELLED", "DRAFT"] }, archivedAt: null } }, orderBy: [{ salesInvoice: { issueDate: "desc" } }, { salesInvoice: { createdAt: "desc" } }, { id: "desc" }], take: 1, select: { ...invoiceLineSelect, salesInvoice: { select: { folio: true, currency: true, exchangeRate: true, rawXml: true } } } },
  purchaseInvoiceLines: { where: { quantity: { gt: 0 }, purchaseInvoice: { status: { notIn: ["CANCELLED", "DRAFT"] } } }, orderBy: [{ purchaseInvoice: { issueDate: "desc" } }, { purchaseInvoice: { createdAt: "desc" } }, { id: "desc" }], take: 1, select: { ...invoiceLineSelect, purchaseInvoice: { select: { folio: true, currency: true, exchangeRate: true, rawXml: true } } } },
} satisfies Prisma.ProductInclude;
type Invoice = { folio: string; currency: string; exchangeRate?: unknown; rawXml?: string | null };
type InvoiceLine = { unitPrice: unknown; description?: string; quantity?: unknown; amount?: unknown };
type Cfdi = ReturnType<typeof parseCfdi>;
export type ValuationProduct = { id?: string; stock: unknown; currency: string; baseCost: unknown; salesInvoiceLines?: Array<InvoiceLine & { salesInvoice: Invoice }>; purchaseInvoiceLines?: Array<InvoiceLine & { purchaseInvoice: Invoice }> };

function readInvoiceXml(invoice: Invoice | undefined) {
  try { return invoice?.rawXml ? parseCfdi(invoice.rawXml) : null; } catch { return null; }
}

function exchange(invoice: Invoice, xml: Cfdi | null) {
  if (invoice.currency === "MXN") return 1;
  const xmlRate = xml?.currency === invoice.currency ? xml.exchangeRate : null;
  if (xmlRate && Number.isFinite(xmlRate) && xmlRate > 0) return xmlRate;
  const rate = Number(invoice.exchangeRate);
  return Number.isFinite(rate) && rate > 0 ? rate : null;
}

function preciseUnitPrice(line: InvoiceLine, xml: Cfdi | null) {
  const stored = new Prisma.Decimal(String(line.unitPrice));
  if (!xml || line.description === undefined) return stored;
  // The product link identifies the tool. The XML only restores precision for this invoice line.
  const prices = new Set(xml.concepts.filter(concept =>
    concept.description === line.description &&
    concept.quantity === Number(line.quantity) &&
    Number.isFinite(concept.amount) && Number.isFinite(concept.unitPrice) &&
    new Prisma.Decimal(concept.amount).toDecimalPlaces(2).equals(String(line.amount)) &&
    new Prisma.Decimal(concept.unitPrice).toDecimalPlaces(2).equals(stored),
  ).map(concept => concept.unitPrice));
  return prices.size === 1 ? new Prisma.Decimal([...prices][0]) : stored;
}

function calculateInventoryValue(product: ValuationProduct, targetCurrency?: string) {
  const sale = product.salesInvoiceLines?.[0], purchase = product.purchaseInvoiceLines?.[0];
  const source: "SALE" | "PURCHASE" | "CATALOG_COST" = sale ? "SALE" : purchase ? "PURCHASE" : "CATALOG_COST";
  const invoice = sale?.salesInvoice ?? purchase?.purchaseInvoice;
  const line = sale ?? purchase;
  const xml = readInvoiceXml(invoice);
  const exchangeRate = invoice ? exchange(invoice, xml) : null;
  const currency = invoice?.currency ?? product.currency;
  const unitPrice = line ? preciseUnitPrice(line, xml) : new Prisma.Decimal(String(product.baseCost));
  const hasPrice = !!line || !unitPrice.isZero();
  const nativeValue = unitPrice.mul(String(product.stock));
  let value: Prisma.Decimal | null = nativeValue;
  if (hasPrice && !nativeValue.isZero() && targetCurrency && targetCurrency !== currency) {
    value = targetCurrency === "MXN" && exchangeRate && exchangeRate > 0 ? nativeValue.mul(exchangeRate) : null;
  }
  return { source, currency, unitPrice, folio: invoice?.folio ?? null, exchangeRate, hasPrice, nativeValue, value };
}

export function valueInventoryProduct(product: ValuationProduct, targetCurrency?: string) {
  const { unitPrice, nativeValue, value, ...row } = calculateInventoryValue(product, targetCurrency);
  return { ...row, unitPrice: unitPrice.toNumber(), nativeValue: nativeValue.toNumber(), value: value?.toNumber() ?? null };
}

export function summarizeInventoryValuation(products: ValuationProduct[], targetCurrency?: string) {
  const native = new Map<string, Prisma.Decimal>();
  const sources = { SALE: 0, PURCHASE: 0, CATALOG_COST: 0 };
  let value = new Prisma.Decimal(0), missingPrice = 0, missingConversion = 0, valuedProducts = 0, negativeStock = 0;
  for (const product of products) {
    const row = calculateInventoryValue(product, targetCurrency);
    native.set(row.currency, (native.get(row.currency) ?? new Prisma.Decimal(0)).plus(row.nativeValue));
    sources[row.source]++;
    const stock = Number(product.stock);
    if (stock === 0) continue;
    if (stock < 0) negativeStock++;
    if (!row.hasPrice) missingPrice++;
    else if (row.value === null) missingConversion++;
    else {
      valuedProducts++;
      value = value.plus(row.value);
    }
  }
  return { method: INVENTORY_VALUATION_METHOD, currency: targetCurrency ?? null, total: targetCurrency ? value.toDecimalPlaces(2).toNumber() : null, nativeTotals: [...native].map(([currency, total]) => ({ currency, total: total.toDecimalPlaces(2).toNumber() })), missingPrice, missingConversion, valuedProducts, isPartial: missingPrice + missingConversion > 0, negativeStock, sources };
}
