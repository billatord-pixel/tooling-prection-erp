import { RecordStatus } from "@prisma/client";
import { z } from "zod";

const optionalText = z.preprocess(
  value => typeof value === "string" && value.trim() === "" ? undefined : value,
  z.string().trim().optional(),
);
const optionalTaxId = z.preprocess(
  value => typeof value === "string" && value.trim() === "" ? undefined : value,
  z.string().trim().toUpperCase().regex(/^(?:[A-ZÑ&]{3,4}\d{6}[A-Z0-9]{3})$/, "RFC inválido.").optional(),
);
const optionalEmail = z.preprocess(
  value => typeof value === "string" && value.trim() === "" ? undefined : value,
  z.string().trim().email("Correo electrónico inválido.").optional(),
);

export const partySchema = z.object({
  kind: z.enum(["CUSTOMER", "SUPPLIER"]),
  taxId: optionalTaxId,
  legalName: z.string().trim().min(1, "La razón social es obligatoria."),
  tradeName: optionalText,
  email: optionalEmail,
  phone: optionalText,
  contactName: optionalText,
  address: optionalText,
  city: optionalText,
  state: optionalText,
  country: z.string().trim().default("México"),
  postalCode: z.preprocess(
    value => typeof value === "string" && value.trim() === "" ? undefined : value,
    z.string().trim().regex(/^\d{5}$/, "El código postal debe tener 5 dígitos.").optional(),
  ),
  commercialTerms: optionalText,
});

export const customerEditSchema = partySchema.omit({ kind: true }).extend({ kind: z.literal("CUSTOMER").optional() });
export const statusSchema = z.object({ status: z.nativeEnum(RecordStatus) }).strict();
