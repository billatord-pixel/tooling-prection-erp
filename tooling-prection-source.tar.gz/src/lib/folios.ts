import { DocumentType } from "@prisma/client";
import { db } from "@/lib/db";

export async function nextFolio(type: DocumentType) {
  const sequence = await db.sequence.upsert({
    where: { type },
    create: { type, prefix: { QUOTE: "COT", PURCHASE_ORDER: "OC", PURCHASE_INVOICE: "FC", SALES_INVOICE: "FV", DELIVERY: "REM", REPORT: "REP" }[type], nextValue: 2 },
    update: { nextValue: { increment: 1 } },
  });
  return `${sequence.prefix}-${String(sequence.nextValue - 1).padStart(6, "0")}`;
}
