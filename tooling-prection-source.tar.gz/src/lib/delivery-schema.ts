import { z } from "zod";

export const deliverySchema = z.object({
  quoteId: z.string().optional().nullable(), customerId: z.string().min(1), issueDate: z.string().optional(),
  warehouse: z.string().trim().min(1).max(160).default("Almacén principal"), sellerName: z.string().trim().max(160).optional(),
  shippingMethod: z.string().trim().max(120).optional(), currency: z.enum(["MXN", "USD", "EUR"]).default("MXN"),
  exchangeRate: z.coerce.number().positive().default(1), taxRate: z.coerce.number().min(0).max(100).default(16),
  carrier: z.string().trim().max(160).optional(), trackingNumber: z.string().trim().max(160).optional(),
  shippingAddress: z.string().trim().max(1200).optional(), notes: z.string().optional(),
  lines: z.array(z.object({ productId: z.string().min(1), description: z.string().trim().min(1).max(600), quantity: z.coerce.number().positive(), listPrice: z.coerce.number().min(0), discount: z.coerce.number().min(0).max(100).default(0), lot: z.string().trim().max(100).optional(), note: z.string().trim().max(600).optional() })).min(1).max(100),
});
export type DeliveryInput = z.infer<typeof deliverySchema>;
export const deliveryDate = (value?: string) => value ? new Date(`${value.slice(0, 10)}T12:00:00.000Z`) : new Date();
export const roundMoney = (value: number) => Math.round((value + Number.EPSILON) * 100) / 100;
export function deliveryTotals(input: DeliveryInput) {
  const lines = input.lines.map(line => { const listPrice = roundMoney(line.listPrice), unitPrice = roundMoney(listPrice * (1 - line.discount / 100)); return { ...line, listPrice, unitPrice, amount: roundMoney(unitPrice * line.quantity) }; });
  const subtotal = roundMoney(lines.reduce((sum, line) => sum + line.listPrice * line.quantity, 0));
  const discount = roundMoney(lines.reduce((sum, line) => sum + line.listPrice * line.quantity * line.discount / 100, 0));
  const tax = roundMoney((subtotal - discount) * input.taxRate / 100);
  return { lines, subtotal, discount, tax, total: roundMoney(subtotal - discount + tax) };
}
