import { afterEach, describe, expect, it, vi } from "vitest";
import { getBanxicoInventoryRate, readBanxicoFix } from "./banxico-fix";

const column = (...values: string[]) => `<td><table>${values.map(value => `<tr><td class="renglonPar">${value}</td></tr>`).join("")}</table></td>`;
const html = `<table>
  <tr><td class="titulos_simpletablaSF">Fecha</td><td>Determinaci&oacute;n</td><td>Publicaci&oacute;n<br>DOF</td><td>Para solventar<br>obligaciones</td></tr>
  <tr>
    ${column("06/11/2026", "05/11/2026", "04/11/2026", "03/11/2026")}
    ${column("18.9000", "N/E", "18.6285", "18.7592")}
    ${column("18.7147", "18.6285", "18.7592", "18.6000")}
    ${column("18.6285", "18.7592", "18.6000", "18.7000")}
  </tr>
</table>`;

afterEach(() => vi.unstubAllGlobals());

describe("FIX de Banxico para el inventario", () => {
  it("lee la columna de determinación y conserva la alineación cuando el día no tiene FIX", () => {
    expect(readBanxicoFix(html, "2026-10-22", "2026-11-05")).toEqual({ date: "2026-11-04", rate: "18.6285" });
    expect(readBanxicoFix(html.replace("N/E", "18.7147"), "2026-10-22", "2026-11-05")).toEqual({ date: "2026-11-05", rate: "18.7147" });
  });

  it("descarta páginas inesperadas, datos fuera del rango o columnas incompletas", () => {
    expect(readBanxicoFix("<html>Error</html>", "2026-10-22", "2026-11-05")).toBeNull();
    expect(readBanxicoFix(html, "2026-11-05", "2026-11-05")).toBeNull();
    expect(readBanxicoFix(html.replace('<tr><td class="renglonPar">N/E</td></tr>', ""), "2026-10-22", "2026-11-05")).toBeNull();
  });

  it("consulta con fecha de Ciudad de México y enlaza la fecha realmente aplicada", async () => {
    const fetcher = vi.fn().mockResolvedValue(new Response(html));
    vi.stubGlobal("fetch", fetcher);
    const result = await getBanxicoInventoryRate(new Date("2026-11-06T02:00:00Z"));
    expect(result).toMatchObject({ requestedDate: "2026-11-05", quote: { date: "2026-11-04", rate: "18.6285" } });
    expect(new URL(fetcher.mock.calls[0][0]).searchParams.get("fechaFinal")).toBe("05/11/2026");
    expect(new URL(result.quote!.sourceUrl).searchParams.get("fechaFinal")).toBe("04/11/2026");
  });

  it("permite continuar con el importe en USD si el banco no responde", async () => {
    vi.stubGlobal("fetch", vi.fn().mockRejectedValue(new Error("timeout")));
    await expect(getBanxicoInventoryRate(new Date("2026-11-05T19:00:00Z"))).resolves.toEqual({ requestedDate: "2026-11-05", quote: null });
  });
});
