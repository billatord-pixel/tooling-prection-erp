import { describe,it,expect } from "vitest";
import { createInvoiceReportPdf } from "./invoice-report-pdf";
import { readCustomerOrderPdf } from "./customer-order-pdf-reader";
describe("reportes de facturas con moneda explícita",()=>{
  it.each(["sales","purchases"] as const)("%s muestra MXN y USD sin hojas vacías",async kind=>{
    const bytes=await createInvoiceReportPdf({kind,currency:"MXN",title:"Reporte de prueba",period:"Octubre 2026",invoices:[{issueDate:new Date("2026-10-01T12:00:00Z"),folio:"F-MXN",counterparty:"Empresa ejemplo",currency:"MXN",reportTotal:100,status:"PAID",lineCount:1},{issueDate:new Date("2026-10-02T12:00:00Z"),folio:"F-USD",counterparty:"Empresa ejemplo",currency:"USD",reportTotal:1800,status:"PENDING",lineCount:2}]});
    expect((bytes.toString("latin1").match(/\/Type\s*\/Page\b/g)||[]).length).toBe(1);
    const text=await readCustomerOrderPdf(bytes);
    expect(text).toContain("MXN 100.00");expect(text).toContain("MXN 1,800.00");expect(text).toContain("USD");expect(text).toContain("MXN");
  });
});
