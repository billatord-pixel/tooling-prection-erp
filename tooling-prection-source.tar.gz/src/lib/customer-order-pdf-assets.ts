import { PDFDocument, StandardFonts, rgb, type PDFFont, type PDFPage, type PDFImage } from "pdf-lib";
import fontkit from "@pdf-lib/fontkit";
import { readFile } from "node:fs/promises";
import { join } from "node:path";
export const pdfBrand = {ink:rgb(.14,.20,.28), muted:rgb(.32,.42,.51), skyTint:rgb(.94,.97,.99), paper:rgb(.97,.99,1), border:rgb(.83,.90,.95)};
export function wrapOperationalPdfText(value:unknown,font:PDFFont,size:number,width:number) {
  const text=String(value ?? "").replace(/[\u2010-\u2015]/g,"-").replace(/[\r\n]+/g," ");
  const lines:string[]=[]; let current="";
  for (const word of text.split(/\s+/).filter(Boolean)) {
    if (current && font.widthOfTextAtSize(current+" "+word,size)>width) {lines.push(current);current="";}
    // Break long identifiers without dropping text.
    for (const char of word) {
      if (current && font.widthOfTextAtSize(current+char,size)>width) {lines.push(current);current="";}
      current+=char;
    }
    current+=" ";
  }
  if (current.trim()) lines.push(current.trim());
  return lines.length?lines:["-"];
}
export async function loadOperationalPdfAssets(pdf:PDFDocument,logoBytes?:Uint8Array,content?:unknown) {
  let regular=await pdf.embedFont(StandardFonts.Helvetica),bold=await pdf.embedFont(StandardFonts.HelveticaBold);
  const supported=new Set(regular.getCharacterSet());
  if([...JSON.stringify(content||"")].some(c=>!supported.has(c.codePointAt(0)!))) {
    pdf.registerFontkit(fontkit);
    regular=await pdf.embedFont(await readFile(join(process.cwd(),"public/fonts/ToolingUnicode-Regular.ttf")));
    bold=await pdf.embedFont(await readFile(join(process.cwd(),"public/fonts/ToolingUnicode-Bold.ttf")));
  }
  let logo:PDFImage|undefined;
  if (logoBytes) {try {logo=await pdf.embedJpg(logoBytes);}catch {logo=await pdf.embedPng(logoBytes);}}
  return {regular,bold,logo};
}
export function drawBrandedPdfHeader(page:PDFPage,input:{margin:number;height:number;regular:PDFFont;bold:PDFFont;logo?:PDFImage;companyName:string;metadata:string;section:string;folio:string}) {
  const w=page.getWidth(),h=page.getHeight();
  page.drawRectangle({x:0,y:h-7,width:w*.68,height:7,color:rgb(.086,.231,.357)});
  page.drawRectangle({x:w*.68,y:h-7,width:w*.22,height:7,color:rgb(.027,.373,.663)});
  page.drawRectangle({x:w*.90,y:h-7,width:w*.1,height:7,color:rgb(.357,.737,.898)});
  if(input.logo) page.drawImage(input.logo,{x:input.margin,y:h-70,width:52,height:52});
  page.drawText(input.companyName,{x:input.margin+66,y:h-37,size:17,font:input.bold,color:pdfBrand.ink});
  page.drawText(input.metadata,{x:input.margin+66,y:h-52,size:8,font:input.regular,color:pdfBrand.muted});
  page.drawText(input.section,{x:w-245,y:h-34,size:10,font:input.bold,color:rgb(.027,.373,.663)});
  page.drawText(input.folio,{x:w-245,y:h-50,size:9,font:input.regular,color:pdfBrand.muted});
}
