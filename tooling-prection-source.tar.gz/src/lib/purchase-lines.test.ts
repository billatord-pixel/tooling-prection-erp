import { describe, expect, it } from "vitest";
import { aggregateInvoiceLines, allocateInvoiceReceipt } from "./purchase-lines";

describe("aggregateInvoiceLines", () => {
  it("combines duplicate invoice product lines with decimal precision", () => {
    const result = aggregateInvoiceLines([
      { productId: "p1", quantity: "0.1" },
      { productId: "p1", quantity: "0.2" },
      { productId: "p2", quantity: "4" },
      { productId: null, quantity: "8" },
    ]);

    expect(result.map(({ productId, quantity }) => [productId, quantity.toString()])).toEqual([
      ["p1", "0.3"],
      ["p2", "4"],
    ]);
  });
});

describe("allocateInvoiceReceipt", () => {
  it("applies partial receipts across duplicate order lines and caps at the ordered quantity", () => {
    const allocations = allocateInvoiceReceipt(
      [
        { id: "l1", productId: "p1", quantity: "2", receivedQuantity: "0.5" },
        { id: "l2", productId: "p1", quantity: "4", receivedQuantity: "0" },
        { id: "l3", productId: "p2", quantity: "3", receivedQuantity: "1" },
      ],
      [
        { productId: "p1", quantity: "2.25" },
        { productId: "p1", quantity: "5" },
        { productId: "p2", quantity: "20" },
        { productId: "unmatched", quantity: "9" },
      ],
    );

    expect(allocations.map(({ orderLineId, quantity }) => [orderLineId, quantity.toString()])).toEqual([
      ["l1", "1.5"],
      ["l2", "4"],
      ["l3", "2"],
    ]);
  });
});
