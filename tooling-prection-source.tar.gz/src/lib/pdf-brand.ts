/** Shared Tooling Prection PDF palette, sampled from the approved quotation design. */
export const TOOLING_PDF = {
  blue: "#075FA9",
  navy: "#163B5B",
  ink: "#243447",
  muted: "#536A82",
  pale: "#F0F6FC",
  row: "#F5F9FD",
  border: "#D5E5F2",
  cyan: "#5BBCE5",
} as const;

/** Three-part top rail gives every operational export a recognizable brand signature. */
export function drawToolingPdfRail(doc: PDFKit.PDFDocument) {
  const w = doc.page.width;
  doc.rect(0, 0, w * 0.68, 7).fill(TOOLING_PDF.navy);
  doc.rect(w * 0.68, 0, w * 0.22, 7).fill(TOOLING_PDF.blue);
  doc.rect(w * 0.9, 0, w * 0.1, 7).fill(TOOLING_PDF.cyan);
}
