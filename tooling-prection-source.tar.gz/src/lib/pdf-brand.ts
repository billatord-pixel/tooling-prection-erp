/** Shared Tooling Prection PDF palette, sampled from the approved quotation design. */
export const TOOLING_PDF = {
  blue: "#075FA9",
  navy: "#163B5B",
  ink: "#243447",
  muted: "#536A82",
  pale: "#F0F6FC",
  row: "#F5F9FD",
  border: "#D5E5F2",
  cyan: "#5BBCE5",
} as const;

export const TOOLING_CONTACT_EMAIL = "tooling.prection@yahoo.com";

/** Three-part top rail gives every operational export a recognizable brand signature. */
export function drawToolingPdfRail(doc: PDFKit.PDFDocument) {
  const w = doc.page.width;
  doc.rect(0, 0, w * 0.68, 7).fill(TOOLING_PDF.navy);
  doc.rect(w * 0.68, 0, w * 0.22, 7).fill(TOOLING_PDF.blue);
  doc.rect(w * 0.9, 0, w * 0.1, 7).fill(TOOLING_PDF.cyan);
}

/** Width-less, positioned text never invokes PDFKit's flow pagination. */
export function drawToolingPdfFooter(doc: PDFKit.PDFDocument, label: string, page: number, count: number, left = 42, right = doc.page.width - 42) {
  const y = doc.page.height - 40;
  doc.moveTo(left, y - 9).lineTo(right, y - 9).lineWidth(.5).strokeColor(TOOLING_PDF.border).stroke();
  doc.font("Helvetica").fontSize(7).fillColor(TOOLING_PDF.muted);
  doc.text(label, left, y, { lineBreak: false });
  const text = `Página ${page} de ${count}`;
  doc.text(text, right - doc.widthOfString(text), y, { lineBreak: false });
}
