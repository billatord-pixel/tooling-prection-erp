import { afterAll, beforeAll, describe, expect, it, vi } from "vitest";
import { randomUUID } from "node:crypto";
const user = vi.hoisted(() => ({ id: "", role: "ADMIN" }));
vi.mock("@/lib/auth", () => ({ currentSession: async () => user }));
import { db } from "./db";
import { parseCfdi } from "./cfdi";
import { processPurchaseInvoice, saveSalesInvoice, processSalesInvoice } from "./invoices";
import { POST as createOrder } from "@/app/api/purchase-orders/route";
import { GET as purchasePdf } from "@/app/api/purchase-orders/[id]/pdf/route";
import { PATCH as resolveInventoryReview } from "@/app/api/inventory/review/route";
import { POST as postSale } from "@/app/api/invoices/sales/route";
import { POST as postPurchase } from "@/app/api/invoices/purchase/route";
const enabled = process.env.TP_INVENTORY_TEST_URL === "postgresql://postgres@127.0.0.1:54987/postgres" && process.env.DATABASE_URL === process.env.TP_INVENTORY_TEST_URL;
describe.skipIf(!enabled)("flujo real sobre restauración aislada; nunca producción", () => {
  beforeAll(async () => { const admin = await db.user.findFirstOrThrow({ where: { role: "ADMIN" } }); user.id = admin.id; });
  afterAll(async () => { await db.$disconnect(); });
  it("pedido → recepción → venta, sin entradas ni salidas duplicadas", async () => {
    const code = `QA-${randomUUID()}`;
    const product = await db.product.create({ data: { technicalCode: code, description: "Herramienta de prueba aislada", currency: "USD", baseCost: 15, salePrice: 20 } });
    const supplier = await db.party.create({ data: { kind: "SUPPLIER", legalName: `Proveedor ${code}`, currency: "USD" } });
    const response = await createOrder(new Request("http://localhost/api/purchase-orders", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ supplierId: supplier.id, currency: "USD", lines: [{ productId: product.id, quantity: 7, unitPrice: 15 }] }) }));
    const order = await response.json();
    expect(response.status, JSON.stringify(order)).toBe(201);
    let stored = await db.product.findUniqueOrThrow({ where: { id: product.id } });
    expect(Number(stored.stock)).toBe(0); expect(Number(stored.onOrder)).toBe(7);
    const pdf = await purchasePdf(new Request("http://localhost/pdf"), { params: Promise.resolve({ id: order.id }) });
    const bytes = Buffer.from(await pdf.arrayBuffer());
    expect((bytes.toString("latin1").match(/\/Type\s*\/Page\b/g) || []).length).toBe(1);
    const xml = (quantity: number, price: number, issuer: string, receiver: string, folio: string) => `<cfdi:Comprobante xmlns:cfdi="http://www.sat.gob.mx/cfd/4" xmlns:tfd="http://www.sat.gob.mx/TimbreFiscalDigital" Serie="QA" Folio="${folio}" Fecha="2026-10-14T12:00:00" Moneda="USD" TipoCambio="18" SubTotal="${quantity * price}" Total="${quantity * price * 1.16}"><cfdi:Emisor Rfc="AAA010101AAA" Nombre="${issuer}"/><cfdi:Receptor Rfc="BBB010101BBB" Nombre="${receiver}"/><cfdi:Conceptos><cfdi:Concepto NoIdentificacion="${code}" Descripcion="Herramienta de prueba aislada" ClaveUnidad="H87" Cantidad="${quantity}" ValorUnitario="${price}" Importe="${quantity * price}"/></cfdi:Conceptos><cfdi:Impuestos TotalImpuestosTrasladados="${quantity * price * .16}"/><cfdi:Complemento><tfd:TimbreFiscalDigital UUID="${randomUUID()}"/></cfdi:Complemento></cfdi:Comprobante>`;
    const purchaseXml = xml(10, 15, supplier.legalName, "Tooling Prection", randomUUID());
    const purchaseRequest = () => new Request("http://localhost/api/invoices/purchase", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ xml: purchaseXml, supplierId: supplier.id, purchaseOrderId: order.id, productIds: [product.id] }),
    });
    const purchaseResponse = await postPurchase(purchaseRequest());
    const invoice = await purchaseResponse.json();
    expect(purchaseResponse.status, JSON.stringify(invoice)).toBe(201);
    expect(invoice.processedAt).toBeTruthy();
    stored = await db.product.findUniqueOrThrow({ where: { id: product.id } });
    expect(Number(stored.stock)).toBe(10); expect(Number(stored.onOrder)).toBe(0);
    expect((await db.purchaseOrder.findUniqueOrThrow({ where: { id: order.id } })).status).toBe("DELIVERED");
    expect((await postPurchase(purchaseRequest())).status).toBe(400);
    await processPurchaseInvoice(invoice.id);
    const competingProduct = await db.product.create({
      data: { technicalCode: `${code}-OTRO`, description: "Descripción distinta del proveedor", stock: 21 },
    });
    const saleXml = xml(4, 20, "Tooling Prection", `Cliente ${code}`, randomUUID())
      .replace('Descripcion="Herramienta de prueba aislada"', 'Descripcion="Descripción distinta del proveedor"');
    const saleRequest = () => {
      const body = new FormData();
      body.set("xml", new File([saleXml], "prueba.xml", { type: "application/xml" }));
      return new Request("http://localhost/api/invoices/sales", { method: "POST", body });
    };
    const saleResponse = await postSale(saleRequest());
    const sale = await saleResponse.json();
    expect(saleResponse.status, JSON.stringify(sale)).toBe(201);
    expect(sale.processedAt).toBeTruthy();
    stored = await db.product.findUniqueOrThrow({ where: { id: product.id } });
    expect(Number(stored.stock)).toBe(6);
    expect((await postSale(saleRequest())).status).toBe(400);
    await processSalesInvoice(sale.id);
    expect(await db.inventoryMovement.count({ where: { productId: product.id } })).toBe(2);
    expect(Number((await db.product.findUniqueOrThrow({ where: { id: competingProduct.id } })).stock)).toBe(21);
    const newCode = `${code}-NUEVO`;
    const newXml = xml(2, 20, "Tooling Prection", `Cliente ${code}`, randomUUID())
      .replace(`NoIdentificacion="${code}"`, `NoIdentificacion="${newCode}"`);
    await saveSalesInvoice(parseCfdi(newXml), newXml);
    expect(Number((await db.product.findUniqueOrThrow({ where: { technicalCode: newCode } })).stock)).toBe(-2);
    expect(Number((await db.product.findUniqueOrThrow({ where: { id: product.id } })).stock)).toBe(6);
  }, 30000);

  it("corrige una partida con existencia negativa conservando el saldo y el historial", async () => {
    const code = `QA-${randomUUID()}`;
    const product = await db.product.create({
      data: { technicalCode: code, description: "Descripción anterior", stock: -11, onOrder: 3, baseCost: 5 },
    });
    const item = await db.inventoryReviewItem.create({
      data: { sourceBatch: code, sourcePage: 1, sourceLine: 1, originalName: "Partida original", reportedStock: 20, reason: "codigo_no_explicito_o_ambiguo" },
    });
    const correctedCode = `${code}-OK`;
    const response = await resolveInventoryReview(new Request("http://localhost/api/inventory/review", {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: item.id, code: correctedCode, currentCode: code, description: "Descripción corregida" }),
    }));
    expect(response.status, await response.clone().text()).toBe(200);
    expect(await response.json()).toMatchObject({ productId: product.id, resolvedCode: correctedCode });
    const stored = await db.product.findUniqueOrThrow({ where: { id: product.id } });
    expect(stored.description).toBe("Descripción corregida");
    expect([Number(stored.stock), Number(stored.onOrder), Number(stored.baseCost)]).toEqual([-11, 3, 5]);
    expect(await db.inventoryMovement.count({ where: { productId: product.id } })).toBe(0);
  });
});
