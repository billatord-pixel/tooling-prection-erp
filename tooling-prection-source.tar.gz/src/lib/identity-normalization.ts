export function normalizeMatch(value: string) {
  return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\./g, "").replace(/[^\p{L}\p{N}]+/gu, " ").trim().replace(/\s+/g, " ").toLocaleUpperCase("es-MX");
}

export function normalizeTaxId(value?: string) {
  return value?.trim().toLocaleUpperCase("es-MX").replace(/[^A-ZÑ&0-9]/g, "") || "";
}
