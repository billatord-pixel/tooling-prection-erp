import { Prisma } from "@prisma/client";

export function aggregateInvoiceLines(
  lines: Array<{ productId: string | null; quantity: Prisma.Decimal | number | string }>,
) {
  const quantities = new Map<string, Prisma.Decimal>();
  for (const line of lines) {
    if (!line.productId) continue;
    quantities.set(
      line.productId,
      (quantities.get(line.productId) ?? new Prisma.Decimal(0)).plus(line.quantity),
    );
  }
  return [...quantities].map(([productId, quantity]) => ({ productId, quantity }));
}

export function allocateInvoiceReceipt(
  orderLines: Array<{ id: string; productId: string; quantity: Prisma.Decimal | number | string; receivedQuantity: Prisma.Decimal | number | string }>,
  invoiceLines: Array<{ productId: string | null; quantity: Prisma.Decimal | number | string }>,
) {
  const invoiceByProduct = new Map<string, Prisma.Decimal>();
  for (const line of invoiceLines) {
    if (!line.productId) continue;
    invoiceByProduct.set(line.productId, (invoiceByProduct.get(line.productId) ?? new Prisma.Decimal(0)).plus(line.quantity));
  }
  const allocations: Array<{ orderLineId: string; productId: string; quantity: Prisma.Decimal }> = [];
  for (const line of orderLines) {
    const invoiced = invoiceByProduct.get(line.productId) ?? new Prisma.Decimal(0);
    const outstanding = Prisma.Decimal.max(0, new Prisma.Decimal(line.quantity).minus(line.receivedQuantity));
    const received = Prisma.Decimal.min(outstanding, invoiced);
    if (received.gt(0)) {
      invoiceByProduct.set(line.productId, invoiced.minus(received));
      allocations.push({ orderLineId: line.id, productId: line.productId, quantity: received });
    }
  }
  return allocations;
}
