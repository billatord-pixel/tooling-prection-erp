import { NextResponse } from "next/server";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";

export async function GET(request: Request) {
  const session = await currentSession(); if (!session || session.role !== "ADMIN") return NextResponse.json({ error: "Sólo un administrador puede consultar la auditoría." }, { status: 403 });
  const limit = Math.min(Math.max(Number(new URL(request.url).searchParams.get("limit") ?? 100), 1), 250);
  const events = await db.auditEvent.findMany({ take: limit, orderBy: { createdAt: "desc" }, include: { user: { select: { name: true, email: true } } } });
  return NextResponse.json(events);
}
