import { readFile } from "node:fs/promises";
import path from "node:path";
import PDFDocument from "pdfkit";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
const BLUE = "#0759A5";
const NAVY = "#133454";
const INK = "#243447";
const MUTED = "#64748B";
const format = (amount: number, currency: string) => new Intl.NumberFormat("es-MX", { style: "currency", currency }).format(amount);
const date = (value: Date | null) => value ? new Intl.DateTimeFormat("es-MX", { day: "2-digit", month: "short", year: "numeric", timeZone: "America/Mexico_City" }).format(value) : "—";

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await currentSession();
  if (!session) return new Response("No autorizado", { status: 401 });
  const { id } = await params;
  const quote = await db.quote.findUnique({ where: { id }, include: { customer: true, lines: { include: { product: true } } } });
  if (!quote) return new Response("Cotización no encontrada", { status: 404 });
  const company = await db.companySettings.findFirst({ orderBy: { createdAt: "asc" } });
  const doc = new PDFDocument({ size: "LETTER", margins: { top: 42, left: 42, right: 42, bottom: 48 }, bufferPages: true, info: { Title: `Cotización ${quote.folio}`, Author: company?.tradeName ?? "Tooling Prection" } });
  const buffers: Buffer[] = [];
  doc.on("data", chunk => buffers.push(Buffer.from(chunk)));
  const complete = new Promise<Buffer>(resolve => doc.on("end", () => resolve(Buffer.concat(buffers))));
  const width = doc.page.width - 84;
  const right = 42 + width;
  let y = 42;
  const logoPath = company?.logoUrl ? path.join(process.cwd(), "public", company.logoUrl.replace(/^\/+/, "")) : path.join(process.cwd(), "public/brand/tooling-prection-logo.jpg");
  try { doc.image(await readFile(logoPath), 42, y, { fit: [152, 48] }); } catch { /* el documento conserva identidad tipográfica si falta el logo */ }
  doc.font("Helvetica-Bold").fontSize(17).fillColor(NAVY).text(company?.tradeName || "Tooling Prection", 212, y + 2, { width: 190 });
  doc.font("Helvetica").fontSize(8.5).fillColor(MUTED);
  const businessLines = [company?.legalName, company?.address, [company?.postalCode, company?.city, company?.state].filter(Boolean).join(", "), [company?.phone, company?.email].filter(Boolean).join("  ·  "), company?.taxId ? `RFC ${company.taxId}` : ""].filter(Boolean);
  doc.text(businessLines.join("\n"), 212, y + 24, { width: 195, lineGap: 2 });
  doc.roundedRect(421, y, 149, 72, 8).fill("#F2F7FC");
  doc.font("Helvetica-Bold").fontSize(8).fillColor(BLUE).text("COTIZACIÓN", 434, y + 10);
  doc.font("Helvetica-Bold").fontSize(16).fillColor(NAVY).text(quote.folio, 434, y + 24, { width: 124 });
  doc.font("Helvetica").fontSize(8).fillColor(MUTED).text(`Emisión: ${date(quote.issueDate)}\nVigencia: ${date(quote.validUntil)}`, 434, y + 47, { width: 125, lineGap: 2 });
  y += 96;
  doc.moveTo(42, y).lineTo(right, y).lineWidth(2).strokeColor(BLUE).stroke();
  y += 14;

  const cardY = y;
  doc.roundedRect(42, cardY, width, 83, 8).lineWidth(1).strokeColor("#D7E5F2").stroke();
  doc.font("Helvetica-Bold").fontSize(8).fillColor(BLUE).text("CLIENTE", 55, cardY + 10);
  doc.font("Helvetica-Bold").fontSize(11).fillColor(INK).text(quote.customer?.legalName || quote.recipientName || "Cliente", 55, cardY + 24, { width: 290 });
  doc.font("Helvetica").fontSize(8.5).fillColor(MUTED);
  const clientLine = [quote.customer?.taxId ? `RFC ${quote.customer.taxId}` : "", quote.customer?.address, [quote.customer?.postalCode, quote.customer?.city, quote.customer?.state].filter(Boolean).join(", "), quote.customer?.phone, quote.customer?.email].filter(Boolean).join("  ·  ");
  doc.text(clientLine || "", 55, cardY + 42, { width: 330, lineGap: 2 });
  doc.font("Helvetica-Bold").fillColor(BLUE).text("ATENCIÓN", 405, cardY + 10);
  doc.font("Helvetica").fontSize(9).fillColor(INK).text(quote.attention || quote.contactName || quote.customer?.contactName || "—", 405, cardY + 24, { width: 150 });
  doc.fontSize(8).fillColor(MUTED).text(`Vendedor: ${quote.sellerName || "—"}\nEnvío: ${quote.shippingMethod || "—"}`, 405, cardY + 43, { width: 150, lineGap: 2 });
  y = cardY + 98;
  const tableX = 42;
  const columns = [tableX, tableX + 37, tableX + 126, tableX + 331, tableX + 385, tableX + 430, tableX + 485, right];
  const headings = ["#", "Código", "Descripción", "Entrega", "Cant.", "P. unitario", "Importe"];
  const drawTableHead = () => {
    doc.roundedRect(tableX, y, width, 25, 4).fill(BLUE);
    doc.font("Helvetica-Bold").fontSize(7.5).fillColor("#FFFFFF");
    headings.forEach((heading, index) => doc.text(heading, columns[index] + 5, y + 8, { width: columns[index + 1] - columns[index] - 9, align: index > 3 ? "right" : "left", lineBreak: false }));
    y += 30;
  };
  drawTableHead();
  quote.lines.forEach((line, index) => {
    const descriptionHeight = doc.font("Helvetica").fontSize(8.5).heightOfString(line.description, { width: columns[3] - columns[2] - 10 });
    const rowHeight = Math.max(31, descriptionHeight + 12);
    if (y + rowHeight > doc.page.height - 118) { doc.addPage(); y = 42; drawTableHead(); }
    if (index % 2 === 1) doc.rect(tableX, y - 2, width, rowHeight).fill("#F5F9FD");
    doc.font("Helvetica").fontSize(8.5).fillColor(INK);
    const values = [String(index + 1), line.productCode || line.product?.technicalCode || "—", line.description, line.leadTime || "—", Number(line.quantity).toLocaleString("es-MX"), format(Number(line.unitPrice), quote.currency), format(Number(line.amount), quote.currency)];
    values.forEach((value, column) => doc.text(value, columns[column] + 5, y + 5, { width: columns[column + 1] - columns[column] - 9, align: column > 3 ? "right" : "left", height: rowHeight - 8, ellipsis: true }));
    y += rowHeight;
    doc.moveTo(tableX, y).lineTo(right, y).lineWidth(.5).strokeColor("#E3EAF1").stroke();
  });

  const totalY = Math.max(y + 20, doc.page.height - 190);
  if (totalY + 120 > doc.page.height - 50) { doc.addPage(); y = 42; }
  const finalY = Math.max(y + 16, totalY > doc.page.height - 50 ? 42 : totalY);
  const notesWidth = 276;
  doc.font("Helvetica-Bold").fontSize(8).fillColor(BLUE).text("OBSERVACIONES", 42, finalY);
  doc.font("Helvetica").fontSize(8.5).fillColor(INK).text(quote.notes || quote.paymentTerms || "Gracias por la oportunidad de cotizar.", 42, finalY + 15, { width: notesWidth, height: 94, ellipsis: true, lineGap: 3 });
  doc.font("Helvetica").fontSize(9).fillColor(MUTED);
  const totalX = 367;
  const drawTotal = (label: string, amount: number, atY: number, bold = false, color = INK) => {
    doc.font(bold ? "Helvetica-Bold" : "Helvetica").fontSize(bold ? 12 : 9).fillColor(color).text(label, totalX, atY, { width: 95 });
    doc.text(format(amount, quote.currency), totalX + 97, atY, { width: 106, align: "right" });
  };
  drawTotal("Subtotal", Number(quote.subtotal) + Number(quote.discount), finalY);
  drawTotal("Descuento", Number(quote.discount), finalY + 19);
  drawTotal(`IVA (${(Number(quote.taxRate) * 100).toLocaleString("es-MX")}%)`, Number(quote.tax), finalY + 38);
  doc.roundedRect(totalX - 8, finalY + 58, width - (totalX - tableX) + 8, 31, 5).fill(NAVY);
  drawTotal("TOTAL", Number(quote.total), finalY + 67, true, "#FFFFFF");
  doc.font("Helvetica").fontSize(8).fillColor(MUTED).text(`Moneda: ${quote.currency}   ·   Tipo de cambio: ${Number(quote.exchangeRate).toLocaleString("es-MX", { maximumFractionDigits: 6 })}   ·   Pago: ${quote.paymentTerms || "A convenir"}`, 42, finalY + 110, { width });

  const range = doc.bufferedPageRange();
  for (let page = range.start; page < range.start + range.count; page++) {
    doc.switchToPage(page);
    const footerY = doc.page.height - 34;
    doc.moveTo(42, footerY - 7).lineTo(right, footerY - 7).lineWidth(.6).strokeColor("#D7E5F2").stroke();
    doc.font("Helvetica").fontSize(7.5).fillColor(MUTED).text("Propuesta comercial · Tooling Prection", 42, footerY, { width: 300 });
    doc.text(`${page + 1} / ${range.count}`, right - 72, footerY, { width: 72, align: "right" });
  }
  doc.end();
  const buffer = await complete;
  const download = new URL(request.url).searchParams.get("download") === "1";
  return new Response(new Uint8Array(buffer), { headers: { "Content-Type": "application/pdf", "Content-Disposition": `${download ? "attachment" : "inline"}; filename="${quote.folio}.pdf"`, "Cache-Control": "private, no-store" } });
}
