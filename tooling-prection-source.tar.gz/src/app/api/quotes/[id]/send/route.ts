import { NextResponse } from "next/server";
import { currentSession } from "@/lib/auth";
import { audit } from "@/lib/audit";
import { db } from "@/lib/db";
import { can } from "@/lib/permissions";

export async function POST(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await currentSession();
  if (!session || !can(session.role, "update")) return NextResponse.json({ error: "Sin permiso" }, { status: 403 });
  const { id } = await params;
  const before = await db.quote.findUnique({ where: { id } });
  if (!before) return NextResponse.json({ error: "No se encontró la cotización." }, { status: 404 });
  const quote = await db.quote.update({ where: { id }, data: { sentAt: new Date() } });
  await audit({ userId: session.id, action: "MARK_SENT", entity: "Quote", entityId: id, before: before as never, after: quote as never });
  return NextResponse.json(quote);
}
