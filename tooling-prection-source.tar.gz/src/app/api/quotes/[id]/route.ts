import { NextResponse } from "next/server";
import { currentSession } from "@/lib/auth";
import { audit } from "@/lib/audit";
import { db } from "@/lib/db";
import { can } from "@/lib/permissions";
import { calculateLines, quoteSchema } from "@/lib/quote-schema";

type Context = { params: Promise<{ id: string }> };
const include = { customer: true, lines: { include: { product: true } }, deliveries: { select: { id: true, folio: true } } } as const;

export async function GET(_request: Request, { params }: Context) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  const { id } = await params;
  const quote = await db.quote.findUnique({ where: { id }, include });
  return quote ? NextResponse.json(quote) : NextResponse.json({ error: "No se encontró la cotización." }, { status: 404 });
}

export async function PATCH(request: Request, { params }: Context) {
  const session = await currentSession();
  if (!session || !can(session.role, "update")) return NextResponse.json({ error: "Sin permiso" }, { status: 403 });
  const { id } = await params;
  try {
    const input = quoteSchema.parse(await request.json());
    const existing = await db.quote.findUnique({ where: { id } });
    if (!existing || existing.status === "ARCHIVED") return NextResponse.json({ error: "La cotización no está disponible para edición." }, { status: 404 });
    const totals = await calculateLines(input);
    const quote = await db.$transaction(async tx => {
      await tx.quoteLine.deleteMany({ where: { quoteId: id } });
      return tx.quote.update({ where: { id }, data: {
        customerId: input.customerId || null, recipientName: input.customerId ? null : input.attention?.trim() || null,
        contactName: input.contactName?.trim() || null, attention: input.attention?.trim() || null,
        issueDate: input.issueDate ? new Date(input.issueDate) : existing.issueDate,
        validUntil: input.validUntil ? new Date(input.validUntil) : null, sellerName: input.sellerName?.trim() || null,
        shippingMethod: input.shippingMethod?.trim() || null, currency: input.currency,
        exchangeRate: input.exchangeRate, taxRate: input.taxRate / 100, paymentTerms: input.paymentTerms?.trim() || null,
        notes: input.notes?.trim() || null, subtotal: totals.subtotal, discount: totals.discount,
        tax: totals.tax, total: totals.total, lines: { create: totals.lines },
      }, include });
    });
    await audit({ userId: session.id, action: "UPDATE", entity: "Quote", entityId: id, before: existing as never, after: quote as never });
    return NextResponse.json(quote);
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "No fue posible actualizar la cotización." }, { status: 400 });
  }
}

export async function DELETE(_request: Request, { params }: Context) {
  const session = await currentSession();
  if (!session || !can(session.role, "admin")) return NextResponse.json({ error: "Solo administración puede eliminar cotizaciones." }, { status: 403 });
  const { id } = await params;
  const quote = await db.quote.findUnique({ where: { id }, include: { deliveries: { select: { id: true } } } });
  if (!quote) return NextResponse.json({ error: "No se encontró la cotización." }, { status: 404 });
  if (quote.deliveries.length) return NextResponse.json({ error: "No se puede eliminar: ya tiene una remisión vinculada." }, { status: 409 });
  await db.quote.delete({ where: { id } });
  await audit({ userId: session.id, action: "DELETE", entity: "Quote", entityId: id, before: quote as never });
  return NextResponse.json({ ok: true });
}
