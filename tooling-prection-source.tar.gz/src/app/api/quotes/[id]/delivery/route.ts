import { NextResponse } from "next/server";
import { DocumentType } from "@prisma/client";
import { currentSession } from "@/lib/auth";
import { audit } from "@/lib/audit";
import { db } from "@/lib/db";
import { nextFolio } from "@/lib/folios";
import { can } from "@/lib/permissions";

const money = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;

export async function POST(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await currentSession();
  if (!session || !can(session.role, "create")) return NextResponse.json({ error: "Sin permiso" }, { status: 403 });
  const { id } = await params;
  const quote = await db.quote.findUnique({ where: { id }, include: { lines: true, deliveries: true } });
  if (!quote) return NextResponse.json({ error: "No se encontró la cotización." }, { status: 404 });
  if (quote.deliveries.length) return NextResponse.json({ error: `Esta cotización ya tiene la remisión ${quote.deliveries[0].folio}.` }, { status: 409 });
  if (!quote.lines.length || quote.lines.some(line => !line.productId)) return NextResponse.json({ error: "Vincula todas las partidas a productos activos antes de crear la remisión." }, { status: 400 });
  const products = await db.product.findMany({ where: { id: { in: quote.lines.map(line => line.productId!) }, status: "ACTIVE" } });
  if (products.length !== quote.lines.length) return NextResponse.json({ error: "Una partida pertenece a un producto inactivo. Reactívalo para continuar." }, { status: 400 });
  const rate = Number(quote.exchangeRate);
  const lines = quote.lines.map(line => ({ productId: line.productId!, description: line.description, quantity: Number(line.quantity), unitPrice: money(Number(line.unitPrice) * rate), amount: money(Number(line.amount) * rate) }));
  const subtotal = money(lines.reduce((sum, line) => sum + line.amount, 0));
  const tax = money(subtotal * Number(quote.taxRate));
  try {
    const delivery = await db.delivery.create({ data: {
      folio: await nextFolio(DocumentType.DELIVERY), customerId: quote.customerId, quoteId: quote.id,
      notes: `Generada desde la cotización ${quote.folio}${quote.notes ? `\n${quote.notes}` : ""}`,
      subtotal, tax, total: money(subtotal + tax), lines: { create: lines },
    }, include: { customer: true, lines: { include: { product: true } }, quote: true } });
    await audit({ userId: session.id, action: "CREATE_FROM_QUOTE", entity: "Delivery", entityId: delivery.id, after: delivery as never });
    return NextResponse.json(delivery, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "No fue posible crear la remisión." }, { status: 400 });
  }
}
