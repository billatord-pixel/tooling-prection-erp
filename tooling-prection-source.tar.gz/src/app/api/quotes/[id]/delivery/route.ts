import { NextResponse } from "next/server";
import { DeliveryStatus, DocumentType } from "@prisma/client";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { nextFolio } from "@/lib/folios";
import { can } from "@/lib/permissions";

const money = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;

export async function POST(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await currentSession();
  if (!session || !can(session.role, "create")) return NextResponse.json({ error: "Sin permiso" }, { status: 403 });
  const { id } = await params;
  const quote = await db.quote.findUnique({ where: { id }, include: { lines: true, deliveries: { select: { id: true, folio: true, status: true } } } });
  if (!quote) return NextResponse.json({ error: "No se encontró la cotización." }, { status: 404 });
  const activeDelivery = quote.deliveries.find(delivery => delivery.status !== DeliveryStatus.CANCELLED);
  if (activeDelivery) return NextResponse.json({ error: `Esta cotización ya tiene la remisión ${activeDelivery.folio}.` }, { status: 409 });
  if (!quote.customerId) return NextResponse.json({ error: "Asigna un cliente a la cotización antes de generar su remisión." }, { status: 400 });
  if (!quote.lines.length || quote.lines.some(line => !line.productId)) return NextResponse.json({ error: "Vincula todas las partidas a productos activos antes de crear la remisión." }, { status: 400 });
  const productIds = [...new Set(quote.lines.map(line => line.productId!))];
  const products = await db.product.findMany({ where: { id: { in: productIds }, status: "ACTIVE" } });
  if (products.length !== productIds.length) return NextResponse.json({ error: "Una partida pertenece a un producto inactivo. Reactívalo para continuar." }, { status: 400 });
  const lines = quote.lines.map(line => ({ productId: line.productId!, description: line.description, quantity: Number(line.quantity), listPrice: Number(line.listPrice ?? line.unitPrice), discount: Number(line.discount), unitPrice: Number(line.unitPrice), amount: Number(line.amount), lot: null, note: null }));
  const subtotal = money(lines.reduce((sum, line) => sum + line.listPrice * line.quantity, 0));
  const discount = money(subtotal - lines.reduce((sum, line) => sum + line.amount, 0));
  const tax = money((subtotal - discount) * Number(quote.taxRate));
  try {
    const delivery = await db.$transaction(async tx => {
      const created = await tx.delivery.create({ data: {
      folio: await nextFolio(DocumentType.DELIVERY), customerId: quote.customerId, quoteId: quote.id,
      issueDate: new Date(), warehouse: "Almacén principal", sellerName: quote.sellerName, shippingMethod: quote.shippingMethod,
      currency: quote.currency, exchangeRate: quote.exchangeRate, taxRate: quote.taxRate, notes: `Generada desde la cotización ${quote.folio}${quote.notes ? `\n${quote.notes}` : ""}`,
      subtotal, discount, tax, total: money(subtotal - discount + tax), lines: { create: lines },
    }, include: { customer: true, lines: { include: { product: true } }, quote: true } });
      await tx.auditEvent.create({ data: { userId: session.id, action: "CREATE_FROM_QUOTE", entity: "Delivery", entityId: created.id, after: { folio: created.folio, quoteId: quote.id, total: created.total } } });
      return created;
    });
    return NextResponse.json(delivery, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "No fue posible crear la remisión." }, { status: 400 });
  }
}
