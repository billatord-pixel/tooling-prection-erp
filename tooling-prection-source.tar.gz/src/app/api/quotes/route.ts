import { NextResponse } from "next/server";
import { audit } from "@/lib/audit";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { nextFolio } from "@/lib/folios";
import { can } from "@/lib/permissions";
import { calculateLines, quoteSchema } from "@/lib/quote-schema";

export const runtime = "nodejs";

export async function GET() {
  const session = await currentSession();
  if (!session) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  const quotes = await db.quote.findMany({ orderBy: [{ createdAt: "desc" }, { id: "desc" }], include: { customer: true, lines: true } });
  return NextResponse.json(quotes);
}

export async function POST(request: Request) {
  const session = await currentSession();
  if (!session || !can(session.role, "create")) return NextResponse.json({ error: "Sin permiso" }, { status: 403 });
  try {
    const input = quoteSchema.parse(await request.json());
    const totals = await calculateLines(input);
    const quote = await db.quote.create({ data: {
      folio: await nextFolio("QUOTE"), customerId: input.customerId || null,
      recipientName: input.customerId ? undefined : input.attention?.trim() || undefined,
      contactName: input.contactName?.trim() || null, attention: input.attention?.trim() || null,
      issueDate: input.issueDate ? new Date(input.issueDate) : new Date(), validUntil: input.validUntil ? new Date(input.validUntil) : null,
      sellerName: input.sellerName?.trim() || null, shippingMethod: input.shippingMethod?.trim() || null,
      currency: input.currency, exchangeRate: input.exchangeRate, taxRate: input.taxRate / 100,
      paymentTerms: input.paymentTerms?.trim() || null, notes: input.notes?.trim() || null,
      subtotal: totals.subtotal, discount: totals.discount, tax: totals.tax, total: totals.total,
      lines: { create: totals.lines },
    }, include: { customer: true, lines: { include: { product: true } } } });
    await audit({ userId: session.id, action: "CREATE", entity: "Quote", entityId: quote.id, after: quote as never });
    return NextResponse.json(quote, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "No fue posible guardar la cotización." }, { status: 400 });
  }
}
