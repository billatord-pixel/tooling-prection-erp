import { NextResponse } from "next/server";
import { z } from "zod";
import { audit } from "@/lib/audit";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { nextFolio } from "@/lib/folios";
import { can } from "@/lib/permissions";

const line = z.object({ productId: z.string().optional(), description: z.string().trim().min(1), quantity: z.coerce.number().positive(), unitPrice: z.coerce.number().min(0), discount: z.coerce.number().min(0).max(100).default(0) });
const schema = z.object({ customerId: z.string().optional(), recipientName: z.string().trim().optional(), validUntil: z.string().optional(), deliveryTime: z.string().optional(), notes: z.string().optional(), lines: z.array(line).min(1) });

export async function GET() { const session = await currentSession(); if (!session) return NextResponse.json({ error: "No autorizado" }, { status: 401 }); return NextResponse.json(await db.quote.findMany({ orderBy: { issueDate: "desc" }, include: { customer: true, lines: true } })); }
export async function POST(request: Request) { const session = await currentSession(); if (!session || !can(session.role, "create")) return NextResponse.json({ error: "Sin permiso" }, { status: 403 }); try { const input = schema.parse(await request.json()); const lines = input.lines.map(item => ({ ...item, amount: item.quantity * item.unitPrice * (1 - item.discount / 100) })); const subtotal = lines.reduce((sum, item) => sum + item.amount, 0); const tax = subtotal * .16; const quote = await db.quote.create({ data: { folio: await nextFolio("QUOTE"), customerId: input.customerId, recipientName: input.recipientName, validUntil: input.validUntil ? new Date(input.validUntil) : undefined, deliveryTime: input.deliveryTime, notes: input.notes, subtotal, tax, total: subtotal + tax, lines: { create: lines } }, include: { customer: true, lines: true } }); await audit({ userId: session.id, action: "CREATE", entity: "Quote", entityId: quote.id, after: quote as unknown as never }); return NextResponse.json(quote, { status: 201 }); } catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "No fue posible guardar la cotización." }, { status: 400 }); } }
