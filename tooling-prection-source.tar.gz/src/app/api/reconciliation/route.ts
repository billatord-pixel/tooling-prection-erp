import { NextResponse } from "next/server";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { can } from "@/lib/permissions";

const norm = (s: string) => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]/g, "");
export async function GET() {
  if (!await currentSession()) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  const pairs = await db.productReconciliation.findMany({ orderBy: [{ status: "asc" }, { similarity: "desc" }, { createdAt: "desc" }], include: { productA: { include: { brand: true, category: true } }, productB: { include: { brand: true, category: true } } }, take: 500 });
  
  return NextResponse.json({ pairs: pairs.map(p => ({ ...p, reasons: Array.isArray(p.reasons) ? p.reasons : [] })) });
}
export async function POST() {
  const session = await currentSession(); if (!session || !can(session.role, "update")) return NextResponse.json({ error: "Sin permiso" }, { status: 403 });
  const products = await db.product.findMany({ where: { status: "ACTIVE" }, select: { id: true, technicalCode: true, description: true }, orderBy: { createdAt: "asc" }, take: 3000 });
  const existing = await db.productReconciliation.findMany({ select: { productAId: true, productBId: true } });
  const seen = new Set(existing.map(p => [p.productAId, p.productBId].sort().join(":"))); const create: { productAId: string; productBId: string; similarity: number; reasons: string[] }[] = [];
  outer: for (let i = 0; i < products.length; i++) for (let j = i + 1; j < products.length; j++) {
    const a = products[i], b = products[j], codeA = norm(a.technicalCode), codeB = norm(b.technicalCode), descA = norm(a.description), descB = norm(b.description);
    const codeMatch = codeA === codeB || codeA.includes(codeB) || codeB.includes(codeA);
    const descMatch = descA === descB || (Math.min(descA.length, descB.length) > 12 && (descA.includes(descB) || descB.includes(descA)));
    if (!codeMatch && !descMatch) continue;
    const key = [a.id, b.id].sort().join(":"); if (seen.has(key)) continue;
    create.push({ productAId: a.id, productBId: b.id, similarity: codeMatch && descMatch ? 99 : codeMatch ? 92 : 82, reasons: [codeMatch ? "Código coincidente/similar" : "", descMatch ? "Descripción coincidente/similar" : ""].filter(Boolean) }); seen.add(key);
    if (create.length >= 500) break outer;
  }
  let created = 0;
  for (const pair of create) { try { await db.$transaction(async tx => { const row = await tx.productReconciliation.create({ data: { ...pair, similarity: pair.similarity, reasons: pair.reasons } }); await tx.auditEvent.create({ data: { userId: session.id, action: "SUGGEST", entity: "ProductReconciliation", entityId: row.id, after: { ...pair, status: "SUGGESTED" } } }); }); created++; } catch { /* duplicate suggestions may be generated concurrently; continue with the rest */ } }
  return NextResponse.json({ created, scanned: products.length });
}
