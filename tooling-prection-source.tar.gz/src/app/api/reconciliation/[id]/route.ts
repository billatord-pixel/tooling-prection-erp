import { NextResponse } from "next/server";
import { z } from "zod";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { can } from "@/lib/permissions";
const schema = z.object({ status: z.enum(["CONFIRMED", "REJECTED"]), officialProductId: z.string().optional() });
export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await currentSession(); if (!session || !can(session.role, "update")) return NextResponse.json({ error: "Sin permiso" }, { status: 403 });
  try {
    const { id } = await params, input = schema.parse(await request.json());
    const current = await db.productReconciliation.findUnique({ where: { id } }); if (!current) return NextResponse.json({ error: "La revisión no existe." }, { status: 404 });
    if (current.status !== "SUGGESTED") return NextResponse.json({ error: "Solo se pueden decidir sugerencias pendientes." }, { status: 409 });
    if (input.status === "CONFIRMED" && input.officialProductId !== current.productAId && input.officialProductId !== current.productBId) return NextResponse.json({ error: "Selecciona uno de los productos de la comparación." }, { status: 400 });
    const updated = await db.$transaction(async tx => {
      const result = await tx.productReconciliation.update({ where: { id }, data: { status: input.status, officialProductId: input.status === "CONFIRMED" ? input.officialProductId : null, impact: { action: "decision-only", note: "Sin fusión ni modificación de productos, existencias o documentos" } } });
      await tx.auditEvent.create({ data: { userId: session.id, action: input.status, entity: "ProductReconciliation", entityId: id, before: { status: current.status }, after: { status: result.status, officialProductId: result.officialProductId } } });
      return result;
    });
    return NextResponse.json(updated);
  } catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "No fue posible guardar la decisión." }, { status: 400 }); }
}
