import { Prisma } from "@prisma/client";
import { NextResponse } from "next/server";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { can } from "@/lib/permissions";
import { customerEditSchema, statusSchema } from "@/lib/party-validation";

type RouteContext = { params: Promise<{ id: string }> };

export async function PATCH(request: Request, context: RouteContext) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  const { id } = await context.params;

  let input: unknown;
  try { input = await request.json(); } catch { return NextResponse.json({ error: "Solicitud inválida." }, { status: 400 }); }
  const statusUpdate = statusSchema.safeParse(input);
  if (statusUpdate.success && !can(session.role, "archive")) return NextResponse.json({ error: "Sin permiso para archivar o restaurar clientes." }, { status: 403 });
  if (!statusUpdate.success && !can(session.role, "update")) return NextResponse.json({ error: "Sin permiso para editar clientes." }, { status: 403 });

  const before = await db.party.findUnique({ where: { id } });
  if (!before || before.kind !== "CUSTOMER") return NextResponse.json({ error: "Cliente no encontrado." }, { status: 404 });

  const parsed = statusUpdate.success ? statusUpdate : customerEditSchema.safeParse(input);
  if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Revisa los datos ingresados." }, { status: 400 });

  try {
    const after = await db.party.update({ where: { id }, data: parsed.data });
    await db.auditEvent.create({ data: {
      userId: session.id,
      action: statusUpdate.success ? (statusUpdate.data.status === "ARCHIVED" ? "ARCHIVE" : "RESTORE") : "UPDATE",
      entity: "Party",
      entityId: id,
      before: before as unknown as Prisma.InputJsonValue,
      after: after as unknown as Prisma.InputJsonValue,
    } });
    return NextResponse.json(after);
  } catch (error) {
    if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === "P2002") {
      return NextResponse.json({ error: "Ya existe un cliente con ese RFC." }, { status: 409 });
    }
    return NextResponse.json({ error: "No fue posible actualizar el cliente." }, { status: 400 });
  }
}

export async function DELETE(_request: Request, context: RouteContext) {
  const session = await currentSession();
  if (!session || !can(session.role, "admin")) return NextResponse.json({ error: "Solo administración puede eliminar clientes permanentemente." }, { status: 403 });
  const { id } = await context.params;
  const party = await db.party.findUnique({ where: { id } });
  if (!party || party.kind !== "CUSTOMER") return NextResponse.json({ error: "Cliente no encontrado." }, { status: 404 });

  const [orders, purchaseInvoices, salesInvoices, quotes, deliveries, suppliedProducts] = await Promise.all([
    db.purchaseOrder.count({ where: { supplierId: id } }),
    db.purchaseInvoice.count({ where: { supplierId: id } }),
    db.salesInvoice.count({ where: { customerId: id } }),
    db.quote.count({ where: { customerId: id } }),
    db.delivery.count({ where: { customerId: id } }),
    db.product.count({ where: { mainSupplierId: id } }),
  ]);
  if (orders + purchaseInvoices + salesInvoices + quotes + deliveries + suppliedProducts > 0) {
    return NextResponse.json({ error: "Este cliente tiene documentos o movimientos vinculados. Archívalo para conservar la integridad de la información." }, { status: 409 });
  }

  try {
    await db.$transaction(async tx => {
      await tx.auditEvent.create({ data: {
        userId: session.id,
        action: "DELETE",
        entity: "Party",
        entityId: id,
        before: party as unknown as Prisma.InputJsonValue,
      } });
      await tx.party.delete({ where: { id } });
    });
    return NextResponse.json({ success: true });
  } catch (error) {
    if (error instanceof Prisma.PrismaClientKnownRequestError && (error.code === "P2003" || error.code === "P2014")) {
      return NextResponse.json({ error: "No se puede eliminar porque hay información vinculada. Archívalo para conservar el historial." }, { status: 409 });
    }
    return NextResponse.json({ error: "No fue posible eliminar el cliente." }, { status: 400 });
  }
}
