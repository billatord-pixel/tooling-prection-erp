import { Prisma } from "@prisma/client";
import { NextResponse } from "next/server";
import { audit } from "@/lib/audit";
import { currentSession } from "@/lib/auth";
import { createCustomer, ensureCustomerCodes } from "@/lib/customer-codes";
import { db } from "@/lib/db";
import { can } from "@/lib/permissions";
import { partySchema } from "@/lib/party-validation";

export async function GET(request: Request) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ error: "No autorizado" }, { status: 401 });

  const params = new URL(request.url).searchParams;
  const kind = params.get("kind");
  const status = params.get("status") === "ARCHIVED" ? "ARCHIVED" : "ACTIVE";
  if (kind === "CUSTOMER") await ensureCustomerCodes();

  const parties = await db.party.findMany({
    where: { ...(kind ? { kind } : {}), status },
    orderBy: [{ createdAt: "asc" }, { id: "asc" }],
  });
  return NextResponse.json(parties);
}

export async function POST(request: Request) {
  const session = await currentSession();
  if (!session || !can(session.role, "create")) return NextResponse.json({ error: "Sin permiso" }, { status: 403 });

  const parsed = partySchema.safeParse(await request.json());
  if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Revisa los datos ingresados." }, { status: 400 });

  try {
    const party = parsed.data.kind === "CUSTOMER"
      ? await createCustomer(parsed.data)
      : await db.party.create({ data: parsed.data });
    await audit({ userId: session.id, action: "CREATE", entity: "Party", entityId: party.id, after: party as unknown as Prisma.InputJsonValue });
    return NextResponse.json(party, { status: 201 });
  } catch (error) {
    if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === "P2002") {
      return NextResponse.json({ error: "Ya existe un cliente o proveedor con ese RFC." }, { status: 409 });
    }
    return NextResponse.json({ error: "No fue posible guardar el registro. Revisa los datos e inténtalo de nuevo." }, { status: 400 });
  }
}
