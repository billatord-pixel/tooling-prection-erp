import { NextResponse } from "next/server";
import { z } from "zod";
import { audit } from "@/lib/audit";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { can } from "@/lib/permissions";
const schema = z.object({ kind: z.enum(["CUSTOMER", "SUPPLIER"]), taxId: z.string().trim().optional(), legalName: z.string().trim().min(1), tradeName: z.string().optional(), email: z.string().email().optional(), phone: z.string().optional(), contactName: z.string().optional(), address: z.string().optional(), city: z.string().optional(), state: z.string().optional(), country: z.string().default("México"), postalCode: z.string().optional(), commercialTerms: z.string().optional() });
export async function GET(request: Request) { const session = await currentSession(); if (!session) return NextResponse.json({ error: "No autorizado" }, { status: 401 }); const kind = new URL(request.url).searchParams.get("kind"); return NextResponse.json(await db.party.findMany({ where: { ...(kind ? { kind } : {}), status: "ACTIVE" }, orderBy: { legalName: "asc" } })); }
export async function POST(request: Request) { const session = await currentSession(); if (!session || !can(session.role, "create")) return NextResponse.json({ error: "Sin permiso" }, { status: 403 }); try { const party = await db.party.create({ data: schema.parse(await request.json()) }); await audit({ userId: session.id, action: "CREATE", entity: "Party", entityId: party.id, after: party as unknown as never }); return NextResponse.json(party, { status: 201 }); } catch { return NextResponse.json({ error: "Ya existe una entidad del mismo tipo con ese RFC, o los datos son inválidos." }, { status: 400 }); } }
