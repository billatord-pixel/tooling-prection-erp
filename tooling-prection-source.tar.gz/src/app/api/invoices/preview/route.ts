import { NextResponse } from "next/server";
import { z } from "zod";
import { currentSession } from "@/lib/auth";
import { parseCfdi } from "@/lib/cfdi";
import { previewInvoice } from "@/lib/invoices";
const schema = z.object({ kind: z.enum(["purchase", "sales"]), xml: z.string().min(1) });
export async function POST(request: Request) { if (!await currentSession()) return NextResponse.json({ error: "No autorizado" }, { status: 401 }); try { const { kind, xml } = schema.parse(await request.json()); return NextResponse.json(await previewInvoice(kind, parseCfdi(xml))); } catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "No se pudo procesar el XML." }, { status: 400 }); } }
