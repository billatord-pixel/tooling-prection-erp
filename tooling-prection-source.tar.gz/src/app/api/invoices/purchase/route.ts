import { NextResponse } from "next/server";
import { z } from "zod";
import { currentSession } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { parseCfdi } from "@/lib/cfdi";
import { savePurchaseInvoice } from "@/lib/invoices";
const schema = z.object({ xml: z.string().min(1), supplierId: z.string(), purchaseOrderId: z.string().optional(), productIds: z.array(z.string()).optional() });
export async function POST(request: Request) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  if (!can(session.role, "create")) return NextResponse.json({ error: "Sin permiso para registrar facturas." }, { status: 403 });
  try {
    const input = schema.parse(await request.json());
    return NextResponse.json(await savePurchaseInvoice(parseCfdi(input.xml), input.xml, input.supplierId, input.purchaseOrderId, input.productIds), { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "No se pudo guardar la factura." }, { status: 400 });
  }
}
