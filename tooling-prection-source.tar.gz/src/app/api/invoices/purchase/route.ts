import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { currentSession } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { parseCfdi } from "@/lib/cfdi";
import { savePurchaseInvoice } from "@/lib/invoices";
const schema = z.object({ xml: z.string().min(1), supplierId: z.string(), purchaseOrderId: z.string().optional(), productIds: z.array(z.string()).optional(), pdf: z.string().optional(), pdfName: z.string().optional() });
export async function GET(request: Request) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  const q = new URL(request.url).searchParams.get("q")?.trim() ?? "";
  const status = new URL(request.url).searchParams.get("status");
  return NextResponse.json(await db.purchaseInvoice.findMany({ where: { ...(status === "PAID" || status === "PENDING" ? { status } : {}), ...(q ? { OR: [{ folio: { contains: q, mode: "insensitive" } }, { uuid: { contains: q, mode: "insensitive" } }, { supplier: { legalName: { contains: q, mode: "insensitive" } } }] } : {}) }, orderBy: [{ issueDate: "desc" }, { createdAt: "desc" }], include: { supplier: true, purchaseOrder: { select: { folio: true } }, lines: true } }));
}
export async function POST(request: Request) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  if (!can(session.role, "create")) return NextResponse.json({ error: "Sin permiso para registrar facturas." }, { status: 403 });
  try {
    const input = schema.parse(await request.json());
    const attachments = input.pdf ? [{ fileName: input.pdfName || "factura.pdf", contentType: "application/pdf", data: Buffer.from(input.pdf, "base64") }] : [];
    if (attachments.some(file => file.data.length > 20 * 1024 * 1024)) return NextResponse.json({ error: "El PDF no puede exceder 20 MB." }, { status: 413 });
    return NextResponse.json(await savePurchaseInvoice(parseCfdi(input.xml), input.xml, input.supplierId, input.purchaseOrderId, input.productIds, attachments), { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "No se pudo guardar la factura." }, { status: 400 });
  }
}
