import { NextResponse } from "next/server";
import { currentSession } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { db } from "@/lib/db";
import { audit } from "@/lib/audit";

export async function GET(_: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!await currentSession()) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  const invoice = await db.purchaseInvoice.findUnique({ where: { id: (await params).id }, include: { supplier: true, purchaseOrder: { select: { id: true, folio: true } }, lines: { include: { product: true } }, attachments: { select: { id: true, fileName: true, contentType: true, fileSize: true, createdAt: true } } } });
  return invoice ? NextResponse.json(invoice) : NextResponse.json({ error: "Factura no encontrada." }, { status: 404 });
}

export async function PATCH(_: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await currentSession();
  if (!session || !can(session.role, "process")) return NextResponse.json({ error: "Sin permiso" }, { status: 403 });
  const { id } = await params;
  const before = await db.purchaseInvoice.findUnique({ where: { id } });
  if (!before) return NextResponse.json({ error: "Factura no encontrada." }, { status: 404 });
  if (before.status === "CANCELLED") return NextResponse.json({ error: "No se puede cambiar el estado de una factura cancelada." }, { status: 409 });
  const invoice = await db.purchaseInvoice.update({ where: { id }, data: { status: before.status === "PAID" ? "PENDING" : "PAID" } });
  await audit({ userId: session.id, action: "UPDATE", entity: "PurchaseInvoice", entityId: id, before: before as unknown as never, after: invoice as unknown as never });
  return NextResponse.json(invoice);
}
