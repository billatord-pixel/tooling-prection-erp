import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export async function GET(request: Request, { params }: { params: Promise<{ id: string; attachmentId: string }> }) {
  if (!await currentSession()) return new Response("No autorizado", { status: 401 });
  const { id, attachmentId } = await params;
  let fileName: string, contentType: string, data: Uint8Array;
  if (attachmentId === "xml") {
    const invoice = await db.purchaseInvoice.findUnique({ where: { id }, select: { folio: true, rawXml: true } });
    if (!invoice?.rawXml) return new Response("XML no encontrado", { status: 404 });
    fileName = `${invoice.folio}.xml`; contentType = "application/xml"; data = new TextEncoder().encode(invoice.rawXml);
  } else {
    const file = await db.purchaseInvoiceAttachment.findFirst({ where: { id: attachmentId, purchaseInvoiceId: id } });
    if (!file) return new Response("Archivo no encontrado", { status: 404 });
    fileName = file.fileName; contentType = file.contentType; data = file.data;
  }
  const inline = new URL(request.url).searchParams.get("inline") === "1";
  const safeName = fileName.replace(/[\r\n"\\]/g, "_");
  const body = data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength) as ArrayBuffer;
  return new Response(body, { headers: { "Content-Type": contentType, "Content-Disposition": `${inline ? "inline" : "attachment"}; filename="${safeName}"; filename*=UTF-8''${encodeURIComponent(fileName)}`, "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff" } });
}
