import { NextResponse } from "next/server";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { parseCfdi } from "@/lib/cfdi";
import { normalizeTaxId } from "@/lib/identity-normalization";
import { saveSalesInvoice } from "@/lib/invoices";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const session = await currentSession();
  if (!session || session.role !== "ADMIN") return NextResponse.json({ error: "Solo un administrador puede importar facturas históricas." }, { status: 403 });
  try {
    const form = await request.formData();
    const xmlFile = form.get("xml");
    const pdfFile = form.get("pdf");
    if (!(xmlFile instanceof File) || !xmlFile.size || !(pdfFile instanceof File) || !pdfFile.size) throw new Error("Cada CFDI histórico requiere XML y PDF.");
    if (xmlFile.size > 20 * 1024 * 1024 || pdfFile.size > 20 * 1024 * 1024) throw new Error("Cada archivo debe pesar menos de 20 MB.");
    if (!pdfFile.name.toLowerCase().endsWith(".pdf")) throw new Error("El archivo visual debe ser PDF.");
    const xml = await xmlFile.text();
    const cfdi = parseCfdi(xml);
    if (!cfdi.uuid || !cfdi.concepts.length) throw new Error("El XML no contiene una factura de ingreso con UUID y partidas.");
    if (normalizeTaxId(cfdi.issuer.rfc) !== "TPR090119AKA") throw new Error("El RFC emisor del XML no corresponde a Tooling Prection.");
    const pdfData = Buffer.from(await pdfFile.arrayBuffer());
    if (pdfData.subarray(0, 5).toString("ascii") !== "%PDF-") throw new Error("El archivo seleccionado no es un PDF válido.");
    const duplicate = await db.salesInvoice.findUnique({ where: { uuid: cfdi.uuid }, select: { id: true, folio: true } });
    if (duplicate) return NextResponse.json({ skipped: true, folio: duplicate.folio, reason: "El UUID ya existe en el sistema." });
    const codesRaw = form.get("productCodes");
    const productCodes = codesRaw ? JSON.parse(String(codesRaw)) as Array<string | null> : [];
    if (!Array.isArray(productCodes) || productCodes.length > cfdi.concepts.length || productCodes.some(code => code !== null && (typeof code !== "string" || code.length > 100))) throw new Error("La asignación de claves de producto no es válida.");
    const invoice = await saveSalesInvoice(
      cfdi,
      xml,
      undefined,
      [
        { fileName: xmlFile.name, contentType: "application/xml", fileSize: xmlFile.size, data: Buffer.from(await xmlFile.arrayBuffer()) },
        { fileName: pdfFile.name, contentType: "application/pdf", fileSize: pdfFile.size, data: pdfData },
      ],
      [],
      { historical: true, productCodes: productCodes.map(code => code || "") },
    );
    return NextResponse.json({ id: invoice.id, folio: invoice.folio, uuid: invoice.uuid, skipped: false }, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "No se pudo importar el CFDI histórico." }, { status: 400 });
  }
}
