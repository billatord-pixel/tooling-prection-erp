import { NextResponse } from "next/server";
import { z } from "zod";
import { currentSession } from "@/lib/auth";
import { parseCfdi } from "@/lib/cfdi";
import { saveSalesInvoice } from "@/lib/invoices";
import { db } from "@/lib/db";
import { InvoiceStatus } from "@prisma/client";
import { can } from "@/lib/permissions";
const schema = z.object({ xml: z.string().min(1), customerId: z.string() });
export async function GET(request: Request) {
  if (!await currentSession()) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  const params = new URL(request.url).searchParams;
  const q = params.get("q")?.trim() || "";
  const status = params.get("status") || "ALL";
  if (status !== "ALL" && status !== "PENDING" && status !== "PAID") return NextResponse.json({ error: "Filtro no válido." }, { status: 400 });
  const invoices = await db.salesInvoice.findMany({
    where: { ...(status === "ALL" ? {} : { status: status as InvoiceStatus }), ...(q ? { OR: [{ folio: { contains: q, mode: "insensitive" as const } }, { uuid: { contains: q, mode: "insensitive" as const } }, { customer: { legalName: { contains: q, mode: "insensitive" as const } } }] } : {}) },
    orderBy: [{ issueDate: "desc" }, { createdAt: "desc" }], include: { customer: true, _count: { select: { lines: true } } },
  });
  return NextResponse.json(invoices.map(invoice => ({ id: invoice.id, folio: invoice.folio, uuid: invoice.uuid, customer: invoice.customer.legalName, issueDate: invoice.issueDate, status: invoice.status, items: invoice._count.lines, currency: invoice.currency, total: Number(invoice.total), balance: invoice.status === "PENDING" ? Number(invoice.total) : 0 })));
}

export async function POST(request: Request) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  if (!can(session.role, "create")) return NextResponse.json({ error: "Sin permiso para registrar facturas." }, { status: 403 });
  try {
    const contentType = request.headers.get("content-type") || "";
    if (contentType.includes("multipart/form-data")) {
      const form = await request.formData();
      const xmlFile = form.get("xml"); const pdfFile = form.get("pdf");
      const customerId = String(form.get("customerId") || "");
      if (!(xmlFile instanceof File) || xmlFile.size === 0) throw new Error("Adjunta el XML CFDI.");
      if (xmlFile.size > 20 * 1024 * 1024) throw new Error("El XML no puede superar 20 MB.");
      if (pdfFile && (!(pdfFile instanceof File) || pdfFile.size > 20 * 1024 * 1024 || (pdfFile.size > 0 && pdfFile.type !== "application/pdf" && !pdfFile.name.toLowerCase().endsWith(".pdf")))) throw new Error("Adjunta un PDF válido de hasta 20 MB.");
      const xml = await xmlFile.text();
      const attachments = [{ fileName: xmlFile.name, contentType: "application/xml", fileSize: xmlFile.size, data: Buffer.from(await xmlFile.arrayBuffer()) }];
      if (pdfFile instanceof File && pdfFile.size > 0) {
        const pdfData = Buffer.from(await pdfFile.arrayBuffer());
        if (pdfData.subarray(0, 5).toString("ascii") !== "%PDF-") throw new Error("El archivo seleccionado no contiene un PDF válido.");
        attachments.push({ fileName: pdfFile.name, contentType: "application/pdf", fileSize: pdfFile.size, data: pdfData });
      }
      const invoice = await saveSalesInvoice(parseCfdi(xml), xml, customerId, attachments);
      return NextResponse.json(invoice, { status: 201 });
    }
    const input = schema.parse(await request.json());
    return NextResponse.json(await saveSalesInvoice(parseCfdi(input.xml), input.xml, input.customerId), { status: 201 });
  } catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "No se pudo guardar la factura." }, { status: 400 }); }
}
