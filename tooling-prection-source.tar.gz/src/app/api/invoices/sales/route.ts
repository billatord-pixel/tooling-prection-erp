import { NextResponse } from "next/server";
import { z } from "zod";
import { currentSession } from "@/lib/auth";
import { parseCfdi } from "@/lib/cfdi";
import { saveSalesInvoice } from "@/lib/invoices";
const schema = z.object({ xml: z.string().min(1), customerId: z.string() });
export async function POST(request: Request) { if (!await currentSession()) return NextResponse.json({ error: "No autorizado" }, { status: 401 }); try { const input = schema.parse(await request.json()); return NextResponse.json(await saveSalesInvoice(parseCfdi(input.xml), input.xml, input.customerId), { status: 201 }); } catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "No se pudo guardar la factura." }, { status: 400 }); } }
