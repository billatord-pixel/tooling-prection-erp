import { readFile } from "node:fs/promises";
import path from "node:path";
import PDFDocument from "pdfkit";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { TOOLING_CONTACT_EMAIL, TOOLING_PDF, drawToolingPdfRail } from "@/lib/pdf-brand";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
const { blue: BLUE, navy: NAVY, ink: INK, muted: MUTED } = TOOLING_PDF;
const money = (amount: number, currency: string) => new Intl.NumberFormat("es-MX", { style: "currency", currency }).format(amount);
const date = (value: Date) => new Intl.DateTimeFormat("es-MX", { day: "2-digit", month: "2-digit", year: "numeric", timeZone: "America/Mexico_City" }).format(value);

export async function GET() {
  if (!await currentSession()) return new Response("No autorizado", { status: 401 });
  const [invoices, company] = await Promise.all([
    db.salesInvoice.findMany({ where: { status: "PENDING" }, orderBy: [{ issueDate: "asc" }, { createdAt: "asc" }], include: { customer: true, _count: { select: { lines: true } } } }),
    db.companySettings.findFirst({ orderBy: { createdAt: "asc" } }),
  ]);
  const doc = new PDFDocument({ size: "LETTER", margins: { top: 38, left: 40, right: 40, bottom: 48 }, bufferPages: true, info: { Title: "Cuentas por cobrar - Tooling Prection", Author: company?.tradeName || "Tooling Prection" } });
  const chunks: Buffer[] = []; doc.on("data", chunk => chunks.push(Buffer.from(chunk)));
  const complete = new Promise<Buffer>(resolve => doc.on("end", () => resolve(Buffer.concat(chunks))));
  const left = 40, right = doc.page.width - 40, width = right - left;
  const balances = new Map<string, number>();
  for (const invoice of invoices) balances.set(invoice.currency, (balances.get(invoice.currency) || 0) + Number(invoice.total));
  const totalText = balances.size ? [...balances.entries()].map(([currency, amount]) => money(amount, currency)).join("   ·   ") : money(0, company?.currency || "MXN");
  let pageNumber = 0;
  // Load the brand mark before drawing the pages.
  let awaitLogo: Buffer | null = null;
  try { awaitLogo = await readFile(path.join(process.cwd(), "public/brand/tooling-prection-logo.jpg")); } catch { awaitLogo = null; }
  const startPage = () => {
    pageNumber++;
    drawToolingPdfRail(doc);
    if (awaitLogo && pageNumber === 1) try { doc.image(awaitLogo, left, 22, { fit: [60, 40] }); } catch { /* logo is optional */ }
    const titleX = awaitLogo && pageNumber === 1 ? left + 72 : left;
    doc.font("Helvetica-Bold").fontSize(13).fillColor(NAVY).text(company?.tradeName || "Tooling Prection", titleX, 26, { width: 315 });
    const info = [company?.taxId ? `RFC ${company.taxId}` : "", [company?.phone, TOOLING_CONTACT_EMAIL].filter(Boolean).join("  ·  ")].filter(Boolean).join("   |   ");
    doc.font("Helvetica").fontSize(7.5).fillColor(MUTED).text(info || "Reporte de cartera", titleX, 44, { width: 355 });
    doc.font("Helvetica-Bold").fontSize(9).fillColor(BLUE).text("VENTAS", right - 110, 25, { width: 110, align: "right" });
    doc.font("Helvetica-Bold").fontSize(13).fillColor(INK).text("CUENTAS POR COBRAR", right - 210, 39, { width: 210, align: "right" });
    if (pageNumber === 1) {
      doc.font("Helvetica-Bold").fontSize(19).fillColor(INK).text("Facturas pendientes de pago", left, 92, { width });
      doc.font("Helvetica").fontSize(8).fillColor(MUTED).text(`Reporte general  ·  Generado ${date(new Date())}  ·  ${invoices.length} factura${invoices.length === 1 ? "" : "s"}  ·  Saldo total ${totalText}`, left, 119, { width });
    }
    const y = pageNumber === 1 ? 146 : 82;
    const xs = [left, left + 53, left + 109, left + 269, left + 309, left + 344, left + 408, left + 472, right];
    doc.roundedRect(left, y, width, 23, 3).fill("#E8F4FC");
    doc.font("Helvetica-Bold").fontSize(6.8).fillColor(NAVY);
    ["FECHA", "FOLIO", "CLIENTE", "MONEDA", "PARTIDAS", "TOTAL", "SALDO", "ESTADO"].forEach((label, i) => doc.text(label, xs[i] + 3, y + 8, { width: xs[i + 1] - xs[i] - 6, lineBreak: false }));
    return { y: y + 27, xs };
  };
  let { y, xs } = startPage();
  const row = (invoice: typeof invoices[number], index: number) => {
    const nameHeight = doc.font("Helvetica").fontSize(7.2).heightOfString(invoice.customer.legalName, { width: xs[3] - xs[2] - 9 });
    const h = Math.max(22, nameHeight + 9);
    if (y + h > doc.page.height - 60) { doc.addPage(); ({ y, xs } = startPage()); }
    if (index % 2 === 1) doc.rect(left, y - 2, width, h).fill("#F6FAFE");
    const values = [date(invoice.issueDate), invoice.folio, invoice.customer.legalName, invoice.currency, String(invoice._count.lines), money(Number(invoice.total), invoice.currency), money(Number(invoice.total), invoice.currency), "PENDIENTE"];
    values.forEach((value, i) => doc.font(i === 1 ? "Helvetica-Bold" : "Helvetica").fontSize(6.7).fillColor(INK).text(value, xs[i] + 3, y + 4, { width: xs[i + 1] - xs[i] - 6, height: h - 4, ellipsis: true, align: i > 3 && i < 7 ? "right" : "left" }));
    y += h; doc.moveTo(left, y).lineTo(right, y).lineWidth(.4).strokeColor("#D9E7F3").stroke();
  };
  if (invoices.length) invoices.forEach(row);
  else doc.font("Helvetica").fontSize(9).fillColor(MUTED).text("No hay facturas pendientes de pago.", left + 5, y + 14, { width: width - 10, align: "center" });
  const range = doc.bufferedPageRange();
  for (let page = range.start; page < range.start + range.count; page++) {
    doc.switchToPage(page); const fy = doc.page.height - 35;
    doc.moveTo(left, fy - 8).lineTo(right, fy - 8).lineWidth(.5).strokeColor("#D9E7F3").stroke();
    doc.font("Helvetica").fontSize(7).fillColor(MUTED).text("Cuentas por cobrar · Tooling Prection", left, fy, { width: 300 });
    doc.text(`Página ${page + 1} de ${range.count}`, right - 100, fy, { width: 100, align: "right" });
  }
  doc.end(); const buffer = await complete;
  return new Response(new Uint8Array(buffer), { headers: { "Content-Type": "application/pdf", "Content-Disposition": "attachment; filename=cuentas-por-cobrar-tooling-prection.pdf", "Cache-Control": "private, no-store" } });
}
