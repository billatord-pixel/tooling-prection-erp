import { NextResponse } from "next/server";
import { currentSession } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { processSalesInvoice } from "@/lib/invoices";
export async function POST(_: Request, { params }: { params: Promise<{ id: string }> }) { const session = await currentSession(); if (!session || !can(session.role, "process")) return NextResponse.json({ error: "Sin permiso" }, { status: 403 }); try { return NextResponse.json(await processSalesInvoice((await params).id)); } catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "No se pudo procesar." }, { status: 400 }); } }
