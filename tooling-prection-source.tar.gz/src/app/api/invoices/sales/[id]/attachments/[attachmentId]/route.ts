import { NextResponse } from "next/server";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";

export const runtime = "nodejs";
export async function GET(_: Request, { params }: { params: Promise<{ id: string; attachmentId: string }> }) {
  if (!await currentSession()) return new Response("No autorizado", { status: 401 });
  const { id, attachmentId } = await params;
  const file = await db.salesInvoiceAttachment.findFirst({ where: { id: attachmentId, salesInvoiceId: id } });
  if (!file) return NextResponse.json({ error: "Archivo no encontrado." }, { status: 404 });
  const safeName = file.fileName.replace(/[\r\n"\\]/g, "_");
  return new Response(new Uint8Array(file.data), { headers: { "Content-Type": file.contentType, "Content-Length": String(file.fileSize), "Content-Disposition": `attachment; filename="${safeName}"; filename*=UTF-8''${encodeURIComponent(file.fileName)}`, "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff" } });
}
