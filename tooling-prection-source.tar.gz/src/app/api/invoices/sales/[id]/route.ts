import { InvoiceStatus } from "@prisma/client";
import { NextResponse } from "next/server";
import { z } from "zod";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { can } from "@/lib/permissions";
import { audit } from "@/lib/audit";

const updateSchema = z.object({
  status: z.nativeEnum(InvoiceStatus).optional(),
  customerId: z.string().min(1).optional(),
  issueDate: z.string().datetime().optional(),
  paymentForm: z.string().max(100).nullable().optional(),
  paymentMethod: z.string().max(100).nullable().optional(),
  lines: z.array(z.object({ id: z.string(), description: z.string().trim().min(1).max(500) })).optional(),
}).strict();

export async function GET(_: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!await currentSession()) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  const invoice = await db.salesInvoice.findUnique({ where: { id: (await params).id }, include: { customer: true, lines: { include: { product: true } }, attachments: { select: { id: true, fileName: true, contentType: true, fileSize: true, createdAt: true } } } });
  if (!invoice) return NextResponse.json({ error: "Factura no encontrada." }, { status: 404 });
  return NextResponse.json({ ...invoice, balance: invoice.status === "PENDING" ? Number(invoice.total) : 0 });
}

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  if (!can(session.role, "update")) return NextResponse.json({ error: "Sin permiso para modificar facturas." }, { status: 403 });
  try {
    const id = (await params).id;
    const input = updateSchema.parse(await request.json());
    const invoice = await db.salesInvoice.findUnique({ where: { id }, include: { lines: true } });
    if (!invoice) return NextResponse.json({ error: "Factura no encontrada." }, { status: 404 });
    if (input.status === "DRAFT") return NextResponse.json({ error: "No se puede cambiar una factura a borrador." }, { status: 400 });
    if (input.lines?.some(line => !invoice.lines.some(existing => existing.id === line.id))) return NextResponse.json({ error: "Las partidas no corresponden a esta factura." }, { status: 400 });
    const updated = await db.$transaction(async tx => {
      if (input.lines) for (const line of input.lines) await tx.salesInvoiceLine.update({ where: { id: line.id }, data: { description: line.description } });
      return tx.salesInvoice.update({ where: { id }, data: { status: input.status, customerId: input.customerId, issueDate: input.issueDate ? new Date(input.issueDate) : undefined, paymentForm: input.paymentForm, paymentMethod: input.paymentMethod }, include: { customer: true, lines: true, attachments: { select: { id: true, fileName: true, contentType: true, fileSize: true, createdAt: true } } } });
    });
    await audit({ userId: session.id, action: input.status ? "UPDATE_STATUS" : "UPDATE", entity: "SalesInvoice", entityId: updated.id, before: invoice as unknown as import("@prisma/client").Prisma.InputJsonValue, after: updated as unknown as import("@prisma/client").Prisma.InputJsonValue });
    return NextResponse.json(updated);
  } catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "No se pudo actualizar la factura." }, { status: 400 }); }
}
