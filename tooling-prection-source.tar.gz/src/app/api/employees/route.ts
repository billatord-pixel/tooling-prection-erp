import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { Role } from "@prisma/client";
import { z } from "zod";
import { audit } from "@/lib/audit";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";

const inputSchema = z.object({ name: z.string().trim().min(2).max(120), position: z.string().trim().min(2).max(120), phone: z.string().trim().max(40).optional(), email: z.string().trim().email().max(250).optional().or(z.literal("")), isSeller: z.boolean().default(false), userId: z.string().nullable().optional(), access: z.object({ email: z.string().trim().email().max(250), password: z.string().min(12).max(128), role: z.nativeEnum(Role) }).optional() });
const admin = async () => { const session = await currentSession(); return session?.role === "ADMIN" ? session : null; };

export async function GET(request: Request) {
  const session = await currentSession(); if (!session) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  const params = new URL(request.url).searchParams;
  if (params.get("view") === "sellers") return NextResponse.json(await db.employee.findMany({ where: { status: "ACTIVE", isSeller: true }, select: { id: true, name: true }, orderBy: { name: "asc" } }));
  if (session.role !== "ADMIN") return NextResponse.json({ error: "Sólo administradores pueden consultar el directorio completo." }, { status: 403 });
  const status = params.get("status") === "archived" ? "ARCHIVED" : "ACTIVE";
  return NextResponse.json(await db.employee.findMany({ where: { status }, include: { user: { select: { id: true, name: true, email: true, isActive: true } } }, orderBy: [{ createdAt: "asc" }, { name: "asc" }] }));
}

export async function POST(request: Request) {
  const session = await admin(); if (!session) return NextResponse.json({ error: "Sólo administradores pueden registrar empleados." }, { status: 403 });
  try {
    const input = inputSchema.parse(await request.json());
    if (input.access && input.userId) return NextResponse.json({ error: "Elige una cuenta existente o crea una nueva, no ambas." }, { status: 400 });
    if (input.userId && !await db.user.findUnique({ where: { id: input.userId } })) return NextResponse.json({ error: "La cuenta vinculada no existe." }, { status: 400 });
    const employee = await db.$transaction(async tx => {
      const user = input.access ? await tx.user.create({ data: { name: input.name, email: input.access.email.toLowerCase(), passwordHash: await bcrypt.hash(input.access.password, 12), role: input.access.role }, select: { id: true } }) : null;
      return tx.employee.create({ data: { name: input.name, position: input.position, email: input.email || null, phone: input.phone || null, isSeller: input.isSeller, userId: user?.id || input.userId || null }, include: { user: { select: { id: true, name: true, email: true, isActive: true } } } });
    });
    if (employee.user) await audit({ userId: session.id, action: "CREATE", entity: "User", entityId: employee.user.id, after: { id: employee.user.id, name: employee.user.name, email: employee.user.email, role: input.access?.role, isActive: employee.user.isActive } as never });
    await audit({ userId: session.id, action: "CREATE", entity: "Employee", entityId: employee.id, after: employee as never });
    return NextResponse.json(employee, { status: 201 });
  } catch (error) { return NextResponse.json({ error: error instanceof Error && error.message.includes("Unique constraint") ? "La cuenta ya está vinculada a otro empleado." : "No fue posible guardar el empleado." }, { status: 400 }); }
}

export async function PATCH(request: Request) {
  const session = await admin(); if (!session) return NextResponse.json({ error: "Sólo administradores pueden actualizar empleados." }, { status: 403 });
  try {
    const body = await request.json(); const id = z.string().min(1).parse(body.id);
    if (body.status !== undefined) {
      const status = z.enum(["ACTIVE", "ARCHIVED"]).parse(body.status); const before = await db.employee.findUnique({ where: { id } });
      if (!before) return NextResponse.json({ error: "No se encontró el empleado." }, { status: 404 });
      const employee = await db.employee.update({ where: { id }, data: { status } });
      await audit({ userId: session.id, action: status === "ARCHIVED" ? "ARCHIVE" : "RESTORE", entity: "Employee", entityId: id, before: before as never, after: employee as never });
      return NextResponse.json(employee);
    }
    const input = inputSchema.omit({ access: true }).partial().parse(body); const before = await db.employee.findUnique({ where: { id } });
    if (!before) return NextResponse.json({ error: "No se encontró el empleado." }, { status: 404 });
    const employee = await db.employee.update({ where: { id }, data: { ...input, email: input.email || null, phone: input.phone || null, userId: input.userId || null } });
    await audit({ userId: session.id, action: "UPDATE", entity: "Employee", entityId: id, before: before as never, after: employee as never });
    return NextResponse.json(employee);
  } catch { return NextResponse.json({ error: "Los datos del empleado no son válidos o su cuenta ya está vinculada." }, { status: 400 }); }
}
