import { NextResponse } from "next/server";
import { z } from "zod";
import { audit } from "@/lib/audit";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";

const inputSchema = z.object({ name: z.string().trim().min(2).max(120), position: z.string().trim().min(2).max(120), phone: z.string().trim().max(40).optional(), email: z.string().trim().email().max(250).optional().or(z.literal("")), isSeller: z.boolean().default(false), userId: z.string().nullable().optional() });
const admin = async () => { const session = await currentSession(); return session?.role === "ADMIN" ? session : null; };

export async function GET(request: Request) {
  if (!await admin()) return NextResponse.json({ error: "Sólo administradores pueden consultar el directorio de empleados." }, { status: 403 });
  const status = new URL(request.url).searchParams.get("status") === "archived" ? "ARCHIVED" : "ACTIVE";
  return NextResponse.json(await db.employee.findMany({ where: { status }, include: { user: { select: { id: true, name: true, email: true, isActive: true } } }, orderBy: [{ createdAt: "asc" }, { name: "asc" }] }));
}

export async function POST(request: Request) {
  const session = await admin(); if (!session) return NextResponse.json({ error: "Sólo administradores pueden registrar empleados." }, { status: 403 });
  try {
    const input = inputSchema.parse(await request.json());
    if (input.userId && !await db.user.findUnique({ where: { id: input.userId } })) return NextResponse.json({ error: "La cuenta vinculada no existe." }, { status: 400 });
    const employee = await db.employee.create({ data: { ...input, email: input.email || null, phone: input.phone || null, userId: input.userId || null }, include: { user: { select: { id: true, name: true, email: true, isActive: true } } } });
    await audit({ userId: session.id, action: "CREATE", entity: "Employee", entityId: employee.id, after: employee as never });
    return NextResponse.json(employee, { status: 201 });
  } catch (error) { return NextResponse.json({ error: error instanceof Error && error.message.includes("Unique constraint") ? "La cuenta ya está vinculada a otro empleado." : "No fue posible guardar el empleado." }, { status: 400 }); }
}

export async function PATCH(request: Request) {
  const session = await admin(); if (!session) return NextResponse.json({ error: "Sólo administradores pueden actualizar empleados." }, { status: 403 });
  try {
    const body = await request.json(); const id = z.string().min(1).parse(body.id);
    if (body.status !== undefined) {
      const status = z.enum(["ACTIVE", "ARCHIVED"]).parse(body.status); const before = await db.employee.findUnique({ where: { id } });
      if (!before) return NextResponse.json({ error: "No se encontró el empleado." }, { status: 404 });
      const employee = await db.employee.update({ where: { id }, data: { status } });
      await audit({ userId: session.id, action: status === "ARCHIVED" ? "ARCHIVE" : "RESTORE", entity: "Employee", entityId: id, before: before as never, after: employee as never });
      return NextResponse.json(employee);
    }
    const input = inputSchema.partial().parse(body); const before = await db.employee.findUnique({ where: { id } });
    if (!before) return NextResponse.json({ error: "No se encontró el empleado." }, { status: 404 });
    const employee = await db.employee.update({ where: { id }, data: { ...input, email: input.email || null, phone: input.phone || null, userId: input.userId || null } });
    await audit({ userId: session.id, action: "UPDATE", entity: "Employee", entityId: id, before: before as never, after: employee as never });
    return NextResponse.json(employee);
  } catch { return NextResponse.json({ error: "Los datos del empleado no son válidos o su cuenta ya está vinculada." }, { status: 400 }); }
}
