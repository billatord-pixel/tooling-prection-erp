import { NextResponse } from "next/server";
import { DocumentType } from "@prisma/client";
import { z } from "zod";
import { audit } from "@/lib/audit";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { nextFolio } from "@/lib/folios";
import { can } from "@/lib/permissions";

const schema = z.object({ customerId: z.string().optional(), notes: z.string().optional(), lines: z.array(z.object({ productId: z.string(), quantity: z.coerce.number().positive(), unitPrice: z.coerce.number().min(0) })).min(1) });
export async function GET() { const session = await currentSession(); if (!session) return NextResponse.json({ error: "No autorizado" }, { status: 401 }); return NextResponse.json(await db.delivery.findMany({ orderBy: { issueDate: "desc" }, include: { customer: true, lines: { include: { product: true } } } })); }
export async function POST(request: Request) { const session = await currentSession(); if (!session || !can(session.role, "create")) return NextResponse.json({ error: "Sin permiso" }, { status: 403 }); try { const input = schema.parse(await request.json()); const products = await db.product.findMany({ where: { id: { in: input.lines.map(line => line.productId) }, status: "ACTIVE" } }); if (products.length !== input.lines.length) return NextResponse.json({ error: "Una o más partidas no corresponden a productos activos." }, { status: 400 }); const lines = input.lines.map(line => ({ ...line, description: products.find(product => product.id === line.productId)!.description, amount: line.quantity * line.unitPrice })); const subtotal = lines.reduce((sum, line) => sum + line.amount, 0); const tax = subtotal * .16; const delivery = await db.delivery.create({ data: { folio: await nextFolio(DocumentType.DELIVERY), customerId: input.customerId, notes: input.notes, subtotal, tax, total: subtotal + tax, lines: { create: lines } }, include: { customer: true, lines: { include: { product: true } } } }); await audit({ userId: session.id, action: "CREATE", entity: "Delivery", entityId: delivery.id, after: delivery as unknown as never }); return NextResponse.json(delivery, { status: 201 }); } catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "No fue posible crear la remisión." }, { status: 400 }); } }
