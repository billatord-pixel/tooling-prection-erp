import { DeliveryStatus, DocumentType } from "@prisma/client";
import { NextResponse } from "next/server";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { deliveryDate, deliverySchema, deliveryTotals } from "@/lib/delivery-schema";
import { nextFolio } from "@/lib/folios";
import { can } from "@/lib/permissions";

export async function GET(request: Request) {
  if (!await currentSession()) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  const search = new URL(request.url).searchParams.get("q")?.trim();
  const deliveries = await db.delivery.findMany({ where: search ? { OR: [{ folio: { contains: search, mode: "insensitive" } }, { customer: { legalName: { contains: search, mode: "insensitive" } } }] } : undefined, orderBy: [{ issueDate: "desc" }, { createdAt: "desc" }], include: { customer: true, lines: { include: { product: true } }, quote: { select: { folio: true } }, _count: { select: { lines: true } } } });
  return NextResponse.json(deliveries.map(delivery => ({ ...delivery, status: delivery.status === DeliveryStatus.CANCELLED ? "CANCELLED" : delivery.processedAt ? "DELIVERED" : delivery.status })));
}

export async function POST(request: Request) {
  const session = await currentSession(); if (!session || !can(session.role, "create")) return NextResponse.json({ error: "Sin permiso" }, { status: 403 });
  try {
    const input = deliverySchema.parse(await request.json());
    const uniqueProductIds = [...new Set(input.lines.map(line => line.productId))];
    const [customer, quote, products] = await Promise.all([
      db.party.findFirst({ where: { id: input.customerId, kind: "CUSTOMER", status: "ACTIVE" } }),
      input.quoteId ? db.quote.findUnique({ where: { id: input.quoteId }, select: { id: true, customerId: true, folio: true } }) : null,
      db.product.findMany({ where: { id: { in: uniqueProductIds }, status: "ACTIVE" } }),
    ]);
    if (!customer) return NextResponse.json({ error: "Selecciona un cliente activo." }, { status: 400 });
    if (input.quoteId && (!quote || quote.customerId !== customer.id)) return NextResponse.json({ error: "La cotización debe corresponder al cliente seleccionado." }, { status: 400 });
    if (products.length !== uniqueProductIds.length) return NextResponse.json({ error: "Una o más partidas no corresponden a productos activos." }, { status: 400 });
    const calculated = deliveryTotals(input);
    const lines = calculated.lines;
    const delivery = await db.$transaction(async tx => {
      const created = await tx.delivery.create({ data: { folio: await nextFolio(DocumentType.DELIVERY), customerId: customer.id, quoteId: quote?.id || null, issueDate: deliveryDate(input.issueDate), warehouse: input.warehouse, sellerName: input.sellerName || null, shippingMethod: input.shippingMethod || null, currency: input.currency, exchangeRate: input.exchangeRate, taxRate: input.taxRate / 100, carrier: input.carrier || null, trackingNumber: input.trackingNumber || null, shippingAddress: input.shippingAddress || null, notes: input.notes || null, status: DeliveryStatus.DRAFT, ...calculated, lines: { create: lines } }, include: { customer: true, quote: { select: { folio: true } }, lines: { include: { product: true } } } });
      await tx.auditEvent.create({ data: { userId: session.id, action: "CREATE", entity: "Delivery", entityId: created.id, after: { folio: created.folio, customerId: created.customerId, quoteId: created.quoteId, status: created.status, total: created.total } } });
      return created;
    });
    return NextResponse.json(delivery, { status: 201 });
  } catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "No fue posible crear la remisión." }, { status: 400 }); }
}
