import { readFile } from "node:fs/promises";
import path from "node:path";
import PDFDocument from "pdfkit";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { TOOLING_CONTACT_EMAIL, TOOLING_PDF, drawToolingPdfRail } from "@/lib/pdf-brand";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
const { blue: BLUE, navy: NAVY, ink: INK, muted: MUTED, pale: PALE, row: ROW, border: BORDER } = TOOLING_PDF;
const money = (amount: number, currency: string) => new Intl.NumberFormat("es-MX", { style: "currency", currency }).format(amount);
const date = (value: Date) => new Intl.DateTimeFormat("es-MX", { day: "2-digit", month: "2-digit", year: "numeric", timeZone: "America/Mexico_City" }).format(value);
const statusLabel = (status: string) => status === "CANCELLED" ? "CANCELADA" : status === "DELIVERED" ? "ENTREGADA" : "BORRADOR";

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!await currentSession()) return new Response("No autorizado", { status: 401 });
  const { id } = await params;
  const [delivery, company] = await Promise.all([
    db.delivery.findUnique({ where: { id }, include: { customer: true, quote: { select: { folio: true } }, lines: { include: { product: true } } } }),
    db.companySettings.findFirst({ orderBy: { createdAt: "asc" } }),
  ]);
  if (!delivery) return new Response("Remisión no encontrada", { status: 404 });
  const doc = new PDFDocument({ size: "LETTER", margins: { top: 38, left: 42, right: 42, bottom: 48 }, bufferPages: true, info: { Title: `Remisión ${delivery.folio}`, Author: company?.tradeName || "Tooling Prection" } });
  const chunks: Buffer[] = []; doc.on("data", chunk => chunks.push(Buffer.from(chunk)));
  const complete = new Promise<Buffer>(resolve => doc.on("end", () => resolve(Buffer.concat(chunks))));
  const left = 42, right = doc.page.width - 42, width = right - left;
  const logoPath = company?.logoUrl ? path.join(process.cwd(), "public", company.logoUrl.replace(/^\/+/, "")) : path.join(process.cwd(), "public/brand/tooling-prection-logo.jpg");
  let logo: Buffer | null = null; try { logo = await readFile(logoPath); } catch { /* the company wordmark remains readable */ }
  let y = 0;
  const pageHeader = () => {
    drawToolingPdfRail(doc);
    if (logo) try { doc.image(logo, left, 20, { fit: [68, 50] }); } catch { /* optional logo */ }
    const companyX = logo ? left + 80 : left;
    doc.font("Helvetica-Bold").fontSize(16).fillColor(NAVY).text(company?.tradeName || "Tooling Prection", companyX, 23, { width: 260 });
    const companyDetails = [company?.legalName, company?.taxId ? `RFC ${company.taxId}` : "", [company?.phone, TOOLING_CONTACT_EMAIL].filter(Boolean).join("  ·  ")].filter(Boolean).join("\n");
    doc.font("Helvetica").fontSize(7.5).fillColor(MUTED).text(companyDetails || "ERP · Entrega de producto", companyX, 44, { width: 275, lineGap: 2 });
    doc.roundedRect(right - 184, 20, 184, 61, 8).fill(PALE);
    doc.font("Helvetica-Bold").fontSize(8).fillColor(BLUE).text("REMISIÓN", right - 170, 29, { width: 156, align: "right" });
    doc.font("Helvetica-Bold").fontSize(15).fillColor(NAVY).text(delivery.folio, right - 170, 43, { width: 156, align: "right" });
    doc.font("Helvetica").fontSize(8).fillColor(MUTED).text(`${date(delivery.issueDate)}  ·  ${statusLabel(delivery.status === "DELIVERED" || delivery.processedAt ? "DELIVERED" : delivery.status)}`, right - 170, 64, { width: 156, align: "right" });
    y = 100;
  };
  pageHeader();
  doc.moveTo(left, y).lineTo(right, y).lineWidth(1.6).strokeColor(BLUE).stroke(); y += 12;
  const customer = delivery.customer;
  const customerLines = [customer?.tradeName && customer.tradeName !== customer.legalName ? customer.tradeName : "", customer?.taxId ? `RFC ${customer.taxId}` : "", delivery.shippingAddress || customer?.address, [customer?.postalCode, customer?.city, customer?.state].filter(Boolean).join(", "), customer?.phone, customer?.email, customer?.contactName ? `Contacto: ${customer.contactName}` : ""].filter(Boolean);
  const headerInfo = [
    ["CLIENTE", customer?.legalName || "Cliente", customerLines.join("\n") || ""],
    ["ENTREGA", delivery.warehouse, [`Vendedor: ${delivery.sellerName || "—"}`, `Envío: ${delivery.shippingMethod || "—"}`, delivery.carrier ? `Transportista: ${delivery.carrier}` : "", delivery.trackingNumber ? `Guía: ${delivery.trackingNumber}` : "", delivery.quote?.folio ? `Cotización: ${delivery.quote.folio}` : ""].filter(Boolean).join("\n")],
  ] as const;
  const cardY = y, cardW = (width - 12) / 2, cardH = 110;
  headerInfo.forEach(([label, title, details], index) => {
    const x = left + index * (cardW + 12); doc.roundedRect(x, cardY, cardW, cardH, 8).lineWidth(.8).strokeColor(BORDER).stroke();
    doc.font("Helvetica-Bold").fontSize(7.5).fillColor(BLUE).text(label, x + 12, cardY + 10);
    doc.font("Helvetica-Bold").fontSize(10).fillColor(INK).text(title, x + 12, cardY + 23, { width: cardW - 24, height: 28, ellipsis: true });
    doc.font("Helvetica").fontSize(7.4).fillColor(MUTED).text(details || "—", x + 12, cardY + 49, { width: cardW - 24, height: cardH - 55, ellipsis: true, lineGap: 2 });
  });
  y += cardH + 16;
  const xs = [left, left + 29, left + 115, left + 302, left + 348, left + 393, left + 462, right];
  const headings = ["#", "CÓDIGO", "DESCRIPCIÓN", "CANT.", "UNIDAD", "PRECIO UNIT.", "IMPORTE"];
  const tableHead = () => { doc.roundedRect(left, y, width, 24, 4).fill(PALE); doc.font("Helvetica-Bold").fontSize(7).fillColor(NAVY); headings.forEach((h,i)=>doc.text(h, xs[i]+4, y+8, { width: xs[i+1]-xs[i]-8, align: i>2 ? "right" : "left", lineBreak: false })); y += 28; };
  tableHead();
  for (const [index, line] of delivery.lines.entries()) {
    const description = [line.description, Number(line.discount) ? `Descuento ${Number(line.discount).toLocaleString("es-MX")} %` : "", line.lot ? `Lote: ${line.lot}` : "", line.note || ""].filter(Boolean).join("\n");
    const h = Math.max(30, doc.font("Helvetica").fontSize(8).heightOfString(description, { width: xs[3]-xs[2]-10 }) + 12);
    if (y + h > doc.page.height - 174) { doc.addPage(); pageHeader(); tableHead(); }
    if (index % 2) doc.rect(left, y-2, width, h).fill(ROW);
    const vals = [String(index+1), line.product.technicalCode, description, Number(line.quantity).toLocaleString("es-MX"), line.product.unit, money(Number(line.unitPrice), delivery.currency), money(Number(line.amount), delivery.currency)];
    vals.forEach((value,i)=>doc.font(i===1?"Helvetica-Bold":"Helvetica").fontSize(7.8).fillColor(INK).text(value, xs[i]+4, y+5, { width: xs[i+1]-xs[i]-8, height: h-7, align: i>2?"right":"left", ellipsis: true }));
    y += h; doc.moveTo(left,y).lineTo(right,y).lineWidth(.35).strokeColor(BORDER).stroke();
  }
  const notesHeight = Math.min(100, Math.max(42, doc.fontSize(8).heightOfString(delivery.notes || "—", { width: 255 }) + 20));
  if (y + notesHeight + 140 > doc.page.height - 92) { doc.addPage(); pageHeader(); }
  y += 15;
  doc.font("Helvetica-Bold").fontSize(7.5).fillColor(BLUE).text("OBSERVACIONES", left, y);
  doc.font("Helvetica").fontSize(8).fillColor(INK).text(delivery.notes || "—", left, y+13, { width: 260, height: notesHeight, ellipsis: true, lineGap: 2 });
  const totalX = right - 205, totals = [["Subtotal", Number(delivery.subtotal)], ["Descuento", Number(delivery.discount)], [`IVA ${(Number(delivery.taxRate)*100).toLocaleString("es-MX")}%`, Number(delivery.tax)]] as const;
  totals.forEach(([label,value],i)=>{ const ty=y+i*19; doc.font("Helvetica").fontSize(8.5).fillColor(MUTED).text(label,totalX,ty,{width:100}); doc.text(money(value,delivery.currency),totalX+100,ty,{width:105,align:"right"}); });
  doc.roundedRect(totalX-6,y+57,211,29,5).fill(NAVY); doc.font("Helvetica-Bold").fontSize(11).fillColor("#FFFFFF").text("TOTAL",totalX+4,y+66,{width:80}); doc.text(money(Number(delivery.total),delivery.currency),totalX+82,y+66,{width:112,align:"right"});
  y += Math.max(notesHeight, 91) + 24;
  const signY = Math.min(y + 25, doc.page.height - 118);
  [[left,"Entregó"],[left+width/2+15,"Recibió de conformidad"]].forEach(([x,label])=>{ doc.moveTo(Number(x),signY).lineTo(Number(x)+width/2-20,signY).lineWidth(.7).strokeColor(MUTED).stroke(); doc.font("Helvetica").fontSize(8).fillColor(MUTED).text(String(label),Number(x),signY+8,{width:width/2-20,align:"center"}); });
  const range = doc.bufferedPageRange();
  for (let page = range.start; page < range.start + range.count; page++) { doc.switchToPage(page); const fy=doc.page.height-55; doc.moveTo(left,fy-8).lineTo(right,fy-8).lineWidth(.5).strokeColor(BORDER).stroke(); doc.font("Helvetica").fontSize(7).fillColor(MUTED).text("Documento de entrega · Tooling Prection",left,fy,{width:300,lineBreak:false}); doc.text(`Página ${page+1} de ${range.count}`,right-90,fy,{width:90,align:"right",lineBreak:false}); }
  doc.end(); const buffer=await complete, download=new URL(request.url).searchParams.get("download")==="1";
  return new Response(new Uint8Array(buffer), { headers: { "Content-Type":"application/pdf", "Content-Disposition":`${download?"attachment":"inline"}; filename="${delivery.folio}.pdf"`, "Cache-Control":"private, no-store" } });
}
