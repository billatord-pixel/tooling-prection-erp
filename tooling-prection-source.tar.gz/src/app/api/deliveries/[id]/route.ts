import { DeliveryStatus, DocumentType, InventoryMovementType, Prisma } from "@prisma/client";
import { NextResponse } from "next/server";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { deliveryDate, deliverySchema, deliveryTotals } from "@/lib/delivery-schema";
import { applyMovementInTransaction } from "@/lib/inventory";
import { can } from "@/lib/permissions";

type Context = { params: Promise<{ id: string }> };
const include = { customer: true, quote: { select: { id: true, folio: true } }, lines: { include: { product: true } }, attachments: { select: { id: true, fileName: true, contentType: true, fileSize: true, createdAt: true } } } as const;

export async function GET(_: Request, { params }: Context) {
  if (!await currentSession()) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  const { id } = await params;
  const delivery = await db.delivery.findUnique({ where: { id }, include });
  return delivery ? NextResponse.json({ ...delivery, status: delivery.status === DeliveryStatus.CANCELLED ? "CANCELLED" : delivery.processedAt ? "DELIVERED" : delivery.status }) : NextResponse.json({ error: "No se encontró la remisión." }, { status: 404 });
}

export async function PATCH(request: Request, { params }: Context) {
  const session = await currentSession(); if (!session || !can(session.role, "update")) return NextResponse.json({ error: "Sin permiso" }, { status: 403 });
  const { id } = await params;
  let body: unknown;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "Solicitud inválida." }, { status: 400 }); }
  if (body && typeof body === "object" && "action" in body && body.action === "cancel") {
    if (!can(session.role, "process")) return NextResponse.json({ error: "Sin permiso para cancelar remisiones." }, { status: 403 });
    try {
      const result = await db.$transaction(async tx => {
        const delivery = await tx.delivery.findUniqueOrThrow({ where: { id }, include: { movements: true } });
        if (delivery.status === DeliveryStatus.CANCELLED) return delivery;
        if (delivery.status === DeliveryStatus.DELIVERED || delivery.processedAt) {
          for (const movement of delivery.movements.filter(item => item.type === InventoryMovementType.DELIVERY)) {
            const exists = await tx.inventoryMovement.findUnique({ where: { reversalOfId: movement.id } });
            if (!exists) await applyMovementInTransaction(tx, { productId: movement.productId, type: InventoryMovementType.REVERSAL, quantity: new Prisma.Decimal(movement.quantity).negated(), sourceType: DocumentType.DELIVERY, sourceId: delivery.id, deliveryId: delivery.id, reversalOfId: movement.id, notes: `Cancelación de remisión ${delivery.folio}` });
          }
        }
        const updated = await tx.delivery.update({ where: { id }, data: { status: DeliveryStatus.CANCELLED } });
        await tx.auditEvent.create({ data: { userId: session.id, action: "CANCEL", entity: "Delivery", entityId: id, before: { status: delivery.status }, after: { status: updated.status, inventoryReversed: Boolean(delivery.processedAt || delivery.status === DeliveryStatus.DELIVERED) } } });
        return updated;
      }, { isolationLevel: "Serializable" });
      return NextResponse.json(result);
    } catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "No se pudo cancelar la remisión." }, { status: 400 }); }
  }
  try {
    const input = deliverySchema.parse(body);
    const existing = await db.delivery.findUnique({ where: { id }, include: { lines: true } });
    if (!existing || existing.status !== DeliveryStatus.DRAFT || existing.processedAt) return NextResponse.json({ error: "Solo se pueden editar remisiones en borrador." }, { status: 409 });
    const uniqueIds = [...new Set(input.lines.map(line => line.productId))];
    const [customer, quote, products] = await Promise.all([
      db.party.findFirst({ where: { id: input.customerId, kind: "CUSTOMER", status: "ACTIVE" } }),
      input.quoteId ? db.quote.findUnique({ where: { id: input.quoteId }, select: { id: true, customerId: true } }) : null,
      db.product.findMany({ where: { id: { in: uniqueIds }, status: "ACTIVE" }, select: { id: true } }),
    ]);
    if (!customer) return NextResponse.json({ error: "Selecciona un cliente activo." }, { status: 400 });
    if (input.quoteId && (!quote || quote.customerId !== customer.id)) return NextResponse.json({ error: "La cotización debe corresponder al cliente seleccionado." }, { status: 400 });
    if (products.length !== uniqueIds.length) return NextResponse.json({ error: "Una o más partidas no corresponden a productos activos." }, { status: 400 });
    const totals = deliveryTotals(input);
    const updated = await db.$transaction(async tx => {
      await tx.deliveryLine.deleteMany({ where: { deliveryId: id } });
      const result = await tx.delivery.update({ where: { id }, data: { quoteId: input.quoteId || null, customerId: customer.id, issueDate: deliveryDate(input.issueDate), warehouse: input.warehouse, sellerName: input.sellerName || null, shippingMethod: input.shippingMethod || null, currency: input.currency, exchangeRate: input.exchangeRate, taxRate: input.taxRate / 100, carrier: input.carrier || null, trackingNumber: input.trackingNumber || null, shippingAddress: input.shippingAddress || null, notes: input.notes || null, subtotal: totals.subtotal, discount: totals.discount, tax: totals.tax, total: totals.total, lines: { create: totals.lines } }, include });
      await tx.auditEvent.create({ data: { userId: session.id, action: "UPDATE", entity: "Delivery", entityId: id, before: { status: existing.status, total: existing.total }, after: { status: result.status, total: result.total } } });
      return result;
    });
    return NextResponse.json(updated);
  } catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "No se pudo actualizar la remisión." }, { status: 400 }); }
}
