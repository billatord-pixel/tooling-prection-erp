import { NextResponse } from "next/server";
import { DocumentType, InventoryMovementType } from "@prisma/client";
import { audit } from "@/lib/audit";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { applyMovement } from "@/lib/inventory";
import { can } from "@/lib/permissions";

export async function POST(_: Request, { params }: { params: Promise<{ id: string }> }) { const session = await currentSession(); if (!session || !can(session.role, "process")) return NextResponse.json({ error: "Sin permiso" }, { status: 403 }); try { const id = (await params).id; const delivery = await db.delivery.findUniqueOrThrow({ where: { id }, include: { lines: true } }); if (delivery.processedAt) return NextResponse.json(delivery); for (const line of delivery.lines) await applyMovement({ productId: line.productId, type: InventoryMovementType.DELIVERY, quantity: -Number(line.quantity), sourceType: DocumentType.DELIVERY, sourceId: delivery.id, deliveryId: delivery.id }); const result = await db.delivery.update({ where: { id }, data: { processedAt: new Date() } }); await audit({ userId: session.id, action: "PROCESS", entity: "Delivery", entityId: id }); return NextResponse.json(result); } catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "No se pudo procesar la salida." }, { status: 400 }); } }
