import { NextResponse } from "next/server";
import { DocumentType, InventoryMovementType } from "@prisma/client";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { applyMovementInTransaction } from "@/lib/inventory";
import { can } from "@/lib/permissions";
import { aggregateDeliveryLines } from "@/lib/delivery-lines";

export async function POST(_: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await currentSession();
  if (!session || !can(session.role, "process")) return NextResponse.json({ error: "Sin permiso" }, { status: 403 });
  try {
    const id = (await params).id;
    const result = await db.$transaction(async tx => {
      const delivery = await tx.delivery.findUniqueOrThrow({ where: { id }, include: { lines: true } });
      if (delivery.processedAt) return delivery;
      for (const { productId, quantity } of aggregateDeliveryLines(delivery.lines)) {
        await applyMovementInTransaction(tx, { productId, type: InventoryMovementType.DELIVERY, quantity: -quantity.toNumber(), sourceType: DocumentType.DELIVERY, sourceId: delivery.id, deliveryId: delivery.id });
      }
      const updated = await tx.delivery.update({ where: { id }, data: { processedAt: new Date() } });
      await tx.auditEvent.create({ data: { userId: session.id, action: "PROCESS", entity: "Delivery", entityId: id } });
      return updated;
    }, { isolationLevel: "Serializable" });
    return NextResponse.json(result);
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "No se pudo procesar la salida." }, { status: 400 });
  }
}
