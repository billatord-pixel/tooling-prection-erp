import { DeliveryStatus } from "@prisma/client";
import { NextResponse } from "next/server";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { can } from "@/lib/permissions";
type Context = { params: Promise<{ id: string }> };
const MAX_BYTES = 20 * 1024 * 1024;
export async function POST(request: Request, { params }: Context) {
  const session = await currentSession(); if (!session || !can(session.role, "update")) return NextResponse.json({ error: "Sin permiso" }, { status: 403 });
  try {
    const { id } = await params, form = await request.formData(), file = form.get("file");
    if (!(file instanceof File)) return NextResponse.json({ error: "Selecciona un archivo XML o PDF." }, { status: 400 });
    if (!file.size || file.size > MAX_BYTES) return NextResponse.json({ error: "El archivo debe pesar entre 1 byte y 20 MB." }, { status: 413 });
    const ext = file.name.split(".").pop()?.toLowerCase();
    if (ext !== "xml" && ext !== "pdf") return NextResponse.json({ error: "Solo se permiten archivos XML o PDF." }, { status: 415 });
    const delivery = await db.delivery.findUnique({ where: { id }, select: { id: true, folio: true, status: true } });
    if (!delivery || delivery.status === DeliveryStatus.CANCELLED) return NextResponse.json({ error: "La remisión no está disponible." }, { status: 404 });
    const fileName = file.name.split(/[\\/]/).pop()?.replace(/[\u0000-\u001f]/g, "").slice(0, 180) || `documento.${ext}`;
    const contentType = ext === "pdf" ? "application/pdf" : "application/xml";
    const bytes = Buffer.from(await file.arrayBuffer());
    const attachment = await db.$transaction(async tx => {
      const created = await tx.deliveryAttachment.create({ data: { deliveryId: id, fileName, contentType, fileSize: bytes.length, data: bytes } });
      await tx.auditEvent.create({ data: { userId: session.id, action: "ATTACH", entity: "Delivery", entityId: id, after: { attachmentId: created.id, fileName, contentType, fileSize: bytes.length } } });
      return created;
    });
    return NextResponse.json({ id: attachment.id, fileName: attachment.fileName, contentType, fileSize: attachment.fileSize, createdAt: attachment.createdAt }, { status: 201 });
  } catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "No se pudo adjuntar el archivo." }, { status: 400 }); }
}
