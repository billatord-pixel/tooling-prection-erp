import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
type Context = { params: Promise<{ id: string; attachmentId: string }> };
export async function GET(_: Request, { params }: Context) {
  if (!await currentSession()) return new Response("No autorizado", { status: 401 });
  const { id, attachmentId } = await params;
  const file = await db.deliveryAttachment.findFirst({ where: { id: attachmentId, deliveryId: id } });
  if (!file) return new Response("Archivo no encontrado", { status: 404 });
  const safeName = file.fileName.replace(/[\r\n"\\]/g, "_");
  return new Response(new Uint8Array(file.data), { headers: { "Content-Type": file.contentType, "Content-Disposition": `attachment; filename="${safeName}"`, "Content-Length": String(file.fileSize), "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff" } });
}
