import { NextResponse } from "next/server";
import { z } from "zod";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { can } from "@/lib/permissions";
const rowSchema = z.object({ technicalcode: z.string().trim().min(1).max(100), description: z.string().trim().min(1).max(500), fiscaldescription: z.string().trim().max(500).optional(), unit: z.string().trim().max(20).optional(), basecost: z.string().optional(), saleprice: z.string().optional(), brand: z.string().trim().max(100).optional(), category: z.string().trim().max(100).optional() });
const amount = (v?: string) => { if (!v) return 0; const n = Number(v.replace(/[$\s,]/g, "")); if (!Number.isFinite(n) || n < 0) throw new Error("Costo/precio debe ser un número no negativo."); return n; };
export async function POST(request: Request) {
  const session = await currentSession(); if (!session || !can(session.role, "create")) return NextResponse.json({ error: "Sin permiso" }, { status: 403 });
  try {
    const body = z.object({ rows: z.array(z.record(z.string(), z.string())).min(1).max(500) }).parse(await request.json());
    const seen = new Set<string>(), errors: string[] = []; let created = 0, skipped = 0;
    for (let i = 0; i < body.rows.length; i++) {
      const line = i + 2;
      try {
        const row = rowSchema.parse(body.rows[i]), code = row.technicalcode.trim();
        if (seen.has(code.toLowerCase())) { errors.push(`Fila ${line}: código repetido dentro del archivo (${code}).`); skipped++; continue; } seen.add(code.toLowerCase());
        if (await db.product.findUnique({ where: { technicalCode: code }, select: { id: true } })) { errors.push(`Fila ${line}: ${code} ya existe; no se sobrescribió.`); skipped++; continue; }
        const baseCost = amount(row.basecost), salePrice = amount(row.saleprice);
        await db.$transaction(async tx => {
          const product = await tx.product.create({ data: { technicalCode: code, description: row.description, fiscalDescription: row.fiscaldescription || null, unit: row.unit || "PZA", baseCost, salePrice, margin: salePrice ? (salePrice - baseCost) / salePrice : 0, ...(row.brand ? { brand: { connectOrCreate: { where: { name: row.brand }, create: { name: row.brand } } } } : {}), ...(row.category ? { category: { connectOrCreate: { where: { name: row.category }, create: { name: row.category } } } } : {}) } });
          await tx.auditEvent.create({ data: { userId: session.id, action: "IMPORT_CREATE", entity: "Product", entityId: product.id, after: { technicalCode: code, description: row.description } } });
        }); created++;
      } catch (error) { errors.push(`Fila ${line}: ${error instanceof Error ? error.message : "datos inválidos"}`); skipped++; }
    }
    return NextResponse.json({ created, skipped, errors });
  } catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "Archivo de importación inválido." }, { status: 400 }); }
}
