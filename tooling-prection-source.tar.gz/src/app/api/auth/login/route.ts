import bcrypt from "bcryptjs";
import { NextResponse } from "next/server";
import { z } from "zod";
import { audit } from "@/lib/audit";
import { db } from "@/lib/db";
import { setSession } from "@/lib/auth";

const schema = z.object({ email: z.string().email(), password: z.string().min(1) });
export async function POST(request: Request) { try { const input = schema.parse(await request.json()); const user = await db.user.findUnique({ where: { email: input.email } }); if (!user || !user.isActive || !(await bcrypt.compare(input.password, user.passwordHash))) { if (user) await audit({ userId: user.id, action: "LOGIN_FAILED", entity: "User", entityId: user.id }); return NextResponse.json({ error: "Correo o contraseña inválidos." }, { status: 401 }); } await db.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } }); await setSession({ id: user.id, email: user.email, name: user.name, role: user.role }); await audit({ userId: user.id, action: "LOGIN", entity: "User", entityId: user.id }); return NextResponse.json({ ok: true }); } catch { return NextResponse.json({ error: "Datos de acceso inválidos." }, { status: 400 }); } }
