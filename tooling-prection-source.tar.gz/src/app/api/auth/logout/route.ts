import { NextResponse } from "next/server";
import { clearSession, currentSession } from "@/lib/auth";
import { audit } from "@/lib/audit";
export async function POST() { const session = await currentSession(); if (session) await audit({ userId: session.id, action: "LOGOUT", entity: "User", entityId: session.id }); await clearSession(); return NextResponse.json({ ok: true }); }
