import { formatMoney } from "@/lib/money-format";
import type { Prisma } from "@prisma/client";
import { inventoryValuationInclude, summarizeInventoryValuation } from "@/lib/inventory-valuation";
import { loadPhysicalInventoryValuation, physicalInventoryByProduct } from "@/lib/physical-inventory-valuation";
import { readFile } from "node:fs/promises";
import path from "node:path";
import PDFDocument from "pdfkit";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { TOOLING_CONTACT_EMAIL, TOOLING_PDF, drawToolingPdfRail, drawToolingPdfFooter } from "@/lib/pdf-brand";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
const { blue: BLUE, navy: NAVY, ink: INK, muted: MUTED } = TOOLING_PDF;
const date = (value: Date) => new Intl.DateTimeFormat("es-MX", { day: "2-digit", month: "2-digit", year: "numeric", timeZone: "America/Mexico_City" }).format(value);
const money = formatMoney;
const pdfText = (value: string) => value.normalize("NFKD").replace(/\p{M}/gu, "").replace(/[^\x20-\x7E]/g, " ").replace(/\s+/g, " ").trim();

export async function GET(request: Request) {
  if (!await currentSession()) return new Response("No autorizado", { status: 401 });
  const params = new URL(request.url).searchParams;
  const requested = params.get("status") || "ACTIVE";
  if (!["ACTIVE", "ARCHIVED", "ALL"].includes(requested)) return new Response("Filtro no válido", { status: 400 });
  const physical = await loadPhysicalInventoryValuation();
  const query = {
    where: requested === "ALL" ? {} : { status: requested as "ACTIVE" | "ARCHIVED" },
    orderBy: [{ technicalCode: "asc" }, { id: "asc" }],
    include: { brand: true, category: true, mainSupplier: true },
  } satisfies Prisma.ProductFindManyArgs;
  const [{ products, valuation }, company] = await Promise.all([
    physical
      ? db.product.findMany(query).then(products => ({ products, valuation: null }))
      : db.product.findMany({ ...query, include: { ...query.include, ...inventoryValuationInclude } })
          .then(products => ({ products, valuation: summarizeInventoryValuation(products) })),
    db.companySettings.findFirst({ orderBy: { createdAt: "asc" } }),
  ]);
  const sumStock = products.reduce((sum, product) => sum + Number(product.stock), 0);
  const sumOnOrder = products.reduce((sum, product) => sum + Number(product.onOrder), 0);
  const byProduct = physical ? physicalInventoryByProduct(physical.lines) : null;
  const inventoryValueText = valuation?.nativeTotals.map(row => money(row.total, row.currency)).join(" · ") || money(0, "USD");
  const doc = new PDFDocument({ size: "LETTER", layout: "landscape", margins: { top: 38, left: 40, right: 40, bottom: 48 }, bufferPages: true, info: { Title: "Resumen de productos - Tooling Prection", Author: company?.tradeName || "Tooling Prection" } });
  const chunks: Buffer[] = [];
  doc.on("data", chunk => chunks.push(Buffer.from(chunk)));
  const complete = new Promise<Buffer>(resolve => doc.on("end", () => resolve(Buffer.concat(chunks))));
  const left = 40, right = doc.page.width - 40, width = right - left;
  let logo: Buffer | null = null;
  try { logo = await readFile(path.join(process.cwd(), "public/brand/tooling-prection-logo.jpg")); } catch { logo = null; }
  let pageNumber = 0;
  const startPage = () => {
    pageNumber++;
    drawToolingPdfRail(doc);
    if (logo && pageNumber === 1) try { doc.image(logo, left, 22, { fit: [60, 40] }); } catch { /* logo is optional */ }
    const titleX = logo && pageNumber === 1 ? left + 72 : left;
    doc.font("Helvetica-Bold").fontSize(13).fillColor(NAVY).text(pdfText(company?.tradeName || "Tooling Prection"), titleX, 26, { width: 315 });
    const companyInfo = pdfText([company?.taxId ? `RFC ${company.taxId}` : "", [company?.phone, TOOLING_CONTACT_EMAIL].filter(Boolean).join(" | ")].filter(Boolean).join("   |   "));
    doc.font("Helvetica").fontSize(7.5).fillColor(MUTED).text(companyInfo || "Catálogo técnico", titleX, 44, { width: 350 });
    doc.font("Helvetica-Bold").fontSize(9).fillColor(BLUE).text("PRODUCTOS", right - 110, 25, { width: 110, align: "right" });
    doc.font("Helvetica-Bold").fontSize(13).fillColor(INK).text("RESUMEN DE PRODUCTOS", right - 220, 39, { width: 220, align: "right" });
    if (pageNumber === 1) {
      doc.font("Helvetica-Bold").fontSize(19).fillColor(INK).text("Catálogo e inventario", left, 91, { width });
      const statusLabel = requested === "ACTIVE" ? "Productos activos" : requested === "ARCHIVED" ? "Productos archivados" : "Todos los productos";
      doc.font("Helvetica").fontSize(8).fillColor(MUTED).text(`${statusLabel}  ·  Generado ${date(new Date())}  ·  ${products.length} registros  ·  Stock ${sumStock.toLocaleString("es-MX")}  ·  En pedido ${sumOnOrder.toLocaleString("es-MX")}`, left, 118, { width });
      doc.text(physical
        ? `Valor del corte general (${physical.summary.title}): ${money(physical.summary.total, physical.summary.currency)}`
        : `Valor venta facturada / compra, por moneda: ${inventoryValueText}`, left, 132, { width });
    }
    const y = pageNumber === 1 ? 160 : 82;
    const xs = [left, left + 100, left + 305, left + 435, left + 490, left + 550, left + 635, right];
    doc.roundedRect(left, y, width, 23, 3).fill("#E8F4FC");
    doc.font("Helvetica-Bold").fontSize(6.8).fillColor(NAVY);
    ["CÓDIGO", "DESCRIPCIÓN", "MARCA / CATEGORÍA", physical ? "STOCK ACTUAL" : "STOCK", "EN PEDIDO", ...(physical ? ["PRECIO PDF", "VALOR PDF"] : ["COSTO", "PRECIO"])].forEach((label, index) => doc.text(label, xs[index] + 3, y + 8, { width: xs[index + 1] - xs[index] - 6, lineBreak: false, align: index >= 3 ? "right" : "left" }));
    return { y: y + 27, xs };
  };
  let { y, xs } = startPage();
  products.forEach((product, index) => {
    const desc = pdfText(product.description);
    const category = pdfText([product.brand?.name, product.category?.name].filter(Boolean).join(" / ") || "Sin clasificar");
    const descHeight = doc.font("Helvetica").fontSize(7.1).heightOfString(desc, { width: xs[2] - xs[1] - 10 });
    const metadataHeight = doc.font("Helvetica").fontSize(6.4).heightOfString(category, { width: xs[3] - xs[2] - 10 });
    const h = Math.max(24, descHeight + 9, metadataHeight + 9);
    if (y + h > doc.page.height - 68) { doc.addPage(); ({ y, xs } = startPage()); }
    if (index % 2 === 1) doc.rect(left, y - 2, width, h).fill("#F6FAFE");
    const reference = byProduct?.get(product.id);
    const prices = physical ? [
      reference?.unitPrices.length === 1 ? money(reference.unitPrices[0], physical.summary.currency) : reference?.unitPrices.length ? "Varios precios" : "—",
      reference ? money(reference.amount, physical.summary.currency) : "—",
    ] : [money(Number(product.baseCost), product.currency), money(Number(product.salePrice), product.currency)];
    const values = [pdfText(product.technicalCode), desc, category, Number(product.stock).toLocaleString("en-US"), Number(product.onOrder).toLocaleString("en-US"), ...prices];
    values.forEach((value, column) => doc.font(column === 0 ? "Helvetica-Bold" : "Helvetica").fontSize(column === 2 ? 6.4 : 7.1).fillColor(INK).text(value, xs[column] + 4, y + 4, { width: xs[column + 1] - xs[column] - 8, height: h - 5, ellipsis: true, align: column >= 3 ? "right" : "left" }));
    y += h;
    doc.moveTo(left, y).lineTo(right, y).lineWidth(.4).strokeColor("#D9E7F3").stroke();
  });
  if (!products.length) doc.font("Helvetica").fontSize(9).fillColor(MUTED).text("No hay productos en este filtro.", left + 5, y + 14, { width: width - 10, align: "center" });
  const range = doc.bufferedPageRange();
  for (let page = range.start; page < range.start + range.count; page++) {
    doc.switchToPage(page);
    drawToolingPdfFooter(doc, "Resumen de productos · Tooling Prection", page + 1, range.count, left, right);
  }
  doc.end();
  const buffer = await complete;
  return new Response(new Uint8Array(buffer), { headers: { "Content-Type": "application/pdf", "Content-Disposition": `attachment; filename=resumen-productos-tooling-prection-${requested.toLowerCase()}.pdf`, "Cache-Control": "private, no-store" } });
}
