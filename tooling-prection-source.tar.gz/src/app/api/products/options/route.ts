import { NextResponse } from "next/server";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";

export async function GET() {
  if (!await currentSession()) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  const [brands, categories, suppliers] = await Promise.all([
    db.brand.findMany({ where: { status: "ACTIVE" }, orderBy: { name: "asc" }, select: { id: true, name: true } }),
    db.category.findMany({ where: { status: "ACTIVE" }, orderBy: { name: "asc" }, select: { id: true, name: true } }),
    db.party.findMany({ where: { kind: "SUPPLIER", status: "ACTIVE" }, orderBy: { legalName: "asc" }, select: { id: true, legalName: true } }),
  ]);
  return NextResponse.json({ brands, categories, suppliers });
}
