import { Prisma, RecordStatus } from "@prisma/client";
import { NextResponse } from "next/server";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { can } from "@/lib/permissions";
import { productSchema } from "@/lib/product-validation";

type Context = { params: Promise<{ id: string }> };
const relations = { brand: true, category: true, mainSupplier: true } as const;

export async function GET(_request: Request, { params }: Context) {
  if (!await currentSession()) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  const { id } = await params;
  const product = await db.product.findUnique({
    where: { id }, include: {
      ...relations,
      inventoryMovements: { orderBy: { createdAt: "desc" }, take: 30 },
      purchaseLines: { orderBy: { purchaseOrder: { issueDate: "desc" } }, take: 30, include: { purchaseOrder: { include: { supplier: true } } } },
      purchaseInvoiceLines: { orderBy: { purchaseInvoice: { issueDate: "desc" } }, take: 30, include: { purchaseInvoice: { include: { supplier: true } } } },
      salesInvoiceLines: { orderBy: { salesInvoice: { issueDate: "desc" } }, take: 30, include: { salesInvoice: { include: { customer: true } } } },
      quoteLines: { orderBy: { quote: { issueDate: "desc" } }, take: 20, include: { quote: { include: { customer: true } } } },
      deliveryLines: { orderBy: { delivery: { issueDate: "desc" } }, take: 20, include: { delivery: { include: { customer: true } } } },
      reconciliationLeft: { orderBy: { updatedAt: "desc" }, take: 30, include: { productB: { include: relations } } },
      reconciliationRight: { orderBy: { updatedAt: "desc" }, take: 30, include: { productA: { include: relations } } },
    },
  });
  if (!product) return NextResponse.json({ error: "Producto no encontrado." }, { status: 404 });
  return NextResponse.json(product);
}

export async function PATCH(request: Request, { params }: Context) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  const { id } = await params;
  const before = await db.product.findUnique({ where: { id } });
  if (!before) return NextResponse.json({ error: "Producto no encontrado." }, { status: 404 });
  let input: unknown;
  try { input = await request.json(); } catch { return NextResponse.json({ error: "Solicitud inválida." }, { status: 400 }); }
  const statusUpdate = zStatus(input);
  if (statusUpdate && !can(session.role, "archive")) return NextResponse.json({ error: "Sin permiso para archivar o restaurar productos." }, { status: 403 });
  if (!statusUpdate && !can(session.role, "update")) return NextResponse.json({ error: "Sin permiso para editar productos." }, { status: 403 });
  let data: { status: RecordStatus } | (ReturnType<typeof productSchema.parse> & { margin: number });
  if (statusUpdate) data = statusUpdate;
  else {
    const submitted = typeof input === "object" && input ? input as Record<string, unknown> : {};
    const parsed = productSchema.safeParse({ ...submitted, currency: submitted.currency ?? before.currency });
    if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Revisa los datos del producto." }, { status: 400 });
    data = { ...parsed.data, margin: parsed.data.salePrice ? (parsed.data.salePrice - parsed.data.baseCost) / parsed.data.salePrice : 0 };
  }
  try {
    const after = await db.product.update({ where: { id }, data, include: relations });
    await db.auditEvent.create({ data: { userId: session.id, action: statusUpdate ? statusUpdate.status === "ARCHIVED" ? "ARCHIVE" : "RESTORE" : "UPDATE", entity: "Product", entityId: id, before: before as unknown as Prisma.InputJsonValue, after: after as unknown as Prisma.InputJsonValue } });
    return NextResponse.json(after);
  } catch (error) {
    if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === "P2002") return NextResponse.json({ error: "El código técnico ya está asignado a otro producto." }, { status: 409 });
    return NextResponse.json({ error: "No fue posible actualizar el producto." }, { status: 400 });
  }
}

function zStatus(input: unknown): { status: RecordStatus } | null {
  if (!input || typeof input !== "object" || !("status" in input)) return null;
  const status = (input as { status?: unknown }).status;
  return status === "ACTIVE" || status === "ARCHIVED" ? { status } : null;
}
