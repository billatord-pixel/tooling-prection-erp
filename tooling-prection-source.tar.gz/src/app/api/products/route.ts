import { NextResponse } from "next/server";
import { z } from "zod";
import { audit } from "@/lib/audit";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { can } from "@/lib/permissions";

const schema = z.object({ technicalCode: z.string().trim().min(1), description: z.string().trim().min(1), fiscalDescription: z.string().optional(), unit: z.string().default("PZA"), baseCost: z.coerce.number().min(0).default(0), salePrice: z.coerce.number().min(0).default(0), brandId: z.string().optional(), categoryId: z.string().optional(), mainSupplierId: z.string().optional(), leadTimeDays: z.coerce.number().int().min(0).optional() });
export async function GET() { const session = await currentSession(); if (!session) return NextResponse.json({ error: "No autorizado" }, { status: 401 }); return NextResponse.json(await db.product.findMany({ where: { status: "ACTIVE" }, orderBy: { createdAt: "desc" }, include: { brand: true, category: true, mainSupplier: true } })); }
export async function POST(request: Request) { const session = await currentSession(); if (!session || !can(session.role, "create")) return NextResponse.json({ error: "Sin permiso" }, { status: 403 }); try { const input = schema.parse(await request.json()); const product = await db.product.create({ data: { ...input, margin: input.salePrice ? (input.salePrice - input.baseCost) / input.salePrice : 0 } }); await audit({ userId: session.id, action: "CREATE", entity: "Product", entityId: product.id, after: product as unknown as never }); return NextResponse.json(product, { status: 201 }); } catch (error) { const message = error instanceof Error && error.message.includes("Unique constraint") ? "El código técnico ya existe." : "No fue posible crear el producto."; return NextResponse.json({ error: message }, { status: 400 }); } }
