import { NextResponse } from "next/server";
import { RecordStatus } from "@prisma/client";
import { audit } from "@/lib/audit";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { can } from "@/lib/permissions";
import { productSchema } from "@/lib/product-validation";

const relations = { brand: true, category: true, mainSupplier: true } as const;

export async function GET(request: Request) {
  const session = await currentSession();
  if (!session) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  const params = new URL(request.url).searchParams;
  const requested = params.get("status") || "ACTIVE";
  if (!["ACTIVE", "ARCHIVED", "ALL"].includes(requested)) return NextResponse.json({ error: "Filtro de estado no válido." }, { status: 400 });
  const q = params.get("q")?.trim() || "";
  const products = await db.product.findMany({
    where: { ...(requested === "ALL" ? {} : { status: requested as RecordStatus }), ...(q ? { OR: [{ technicalCode: { contains: q, mode: "insensitive" } }, { description: { contains: q, mode: "insensitive" } }, { fiscalDescription: { contains: q, mode: "insensitive" } }] } : {}) },
    orderBy: [{ createdAt: "desc" }, { id: "desc" }], include: relations,
  });
  return NextResponse.json(products);
}

export async function POST(request: Request) {
  const session = await currentSession();
  if (!session || !can(session.role, "create")) return NextResponse.json({ error: "Sin permiso" }, { status: 403 });
  try {
    const input = productSchema.parse(await request.json());
    const product = await db.product.create({ data: { ...input, margin: input.salePrice ? (input.salePrice - input.baseCost) / input.salePrice : 0 }, include: relations });
    await audit({ userId: session.id, action: "CREATE", entity: "Product", entityId: product.id, after: product as unknown as never });
    return NextResponse.json(product, { status: 201 });
  } catch (error) {
    const message = error instanceof Error && error.message.includes("Unique constraint") ? "El código técnico ya existe." : error instanceof Error ? error.message : "No fue posible crear el producto.";
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
