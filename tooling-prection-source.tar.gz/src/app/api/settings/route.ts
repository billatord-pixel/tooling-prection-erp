import { NextResponse } from "next/server";
import { z } from "zod";
import { audit } from "@/lib/audit";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";

const COMPANY_ID = "tooling-prection-company";
const schema = z.object({ legalName: z.string().trim().min(2), tradeName: z.string().trim().min(2), taxId: z.string().trim().optional(), email: z.string().trim().email().optional().or(z.literal("")), phone: z.string().trim().optional(), address: z.string().trim().optional(), city: z.string().trim().optional(), state: z.string().trim().optional(), postalCode: z.string().trim().optional(), paymentTerms: z.string().trim().optional(), commercialTerms: z.string().trim().optional(), legalText: z.string().trim().optional(), taxRate: z.coerce.number().min(0).max(1).default(.16), currency: z.enum(["MXN", "USD", "EUR"]).default("MXN"), timezone: z.string().trim().min(1).default("America/Mexico_City"), bankDetails: z.string().trim().optional() });

export async function GET() {
  const session = await currentSession(); if (!session) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  const settings = await db.companySettings.findUnique({ where: { id: COMPANY_ID } });
  const result = settings ?? { id: COMPANY_ID, legalName: "Tooling Prection", tradeName: "Tooling Prection", taxRate: .16, currency: "MXN", timezone: "America/Mexico_City", bankDetails: null };
  const bankDetails = session.role === "ADMIN" ? typeof result.bankDetails === "string" ? result.bankDetails : result.bankDetails ? JSON.stringify(result.bankDetails, null, 2) : "" : "";
  return NextResponse.json({ ...result, bankDetails });
}

export async function PUT(request: Request) {
  const session = await currentSession(); if (!session || session.role !== "ADMIN") return NextResponse.json({ error: "Sólo un administrador puede cambiar la configuración." }, { status: 403 });
  try {
    const parsed = schema.parse(await request.json()); const { bankDetails, ...input } = parsed; const before = await db.companySettings.findUnique({ where: { id: COMPANY_ID } });
    const settings = await db.companySettings.upsert({ where: { id: COMPANY_ID }, update: { ...input, bankDetails: bankDetails ? { notes: bankDetails } : undefined }, create: { id: COMPANY_ID, ...input, bankDetails: bankDetails ? { notes: bankDetails } : undefined, logoUrl: "/brand/tooling-prection-logo.jpg" } });
    await audit({ userId: session.id, action: "UPDATE", entity: "CompanySettings", entityId: settings.id, before: before as never, after: settings as never });
    return NextResponse.json(settings);
  } catch { return NextResponse.json({ error: "Revisa los datos de empresa e inténtalo de nuevo." }, { status: 400 }); }
}
