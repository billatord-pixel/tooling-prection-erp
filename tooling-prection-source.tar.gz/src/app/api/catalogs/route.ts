import { NextResponse } from "next/server";
import { z } from "zod";
import { audit } from "@/lib/audit";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";

const typeSchema = z.enum(["brands", "categories"]);
const createSchema = z.object({ type: typeSchema, name: z.string().trim().min(2).max(100) });

export async function GET(request: Request) {
  const session = await currentSession(); if (!session) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  const parsed = typeSchema.safeParse(new URL(request.url).searchParams.get("type"));
  if (!parsed.success) return NextResponse.json({ error: "Tipo de catálogo inválido." }, { status: 400 });
  const rows = parsed.data === "brands" ? await db.brand.findMany({ where: { status: "ACTIVE" }, orderBy: { name: "asc" } }) : await db.category.findMany({ where: { status: "ACTIVE" }, orderBy: { name: "asc" } });
  return NextResponse.json(rows);
}

export async function POST(request: Request) {
  const session = await currentSession(); if (!session || session.role !== "ADMIN") return NextResponse.json({ error: "Sólo un administrador puede administrar este catálogo." }, { status: 403 });
  try {
    const input = createSchema.parse(await request.json());
    const item = input.type === "brands" ? await db.brand.create({ data: { name: input.name } }) : await db.category.create({ data: { name: input.name } });
    await audit({ userId: session.id, action: "CREATE", entity: input.type === "brands" ? "Brand" : "Category", entityId: item.id, after: item as never });
    return NextResponse.json(item, { status: 201 });
  } catch (error) {
    const duplicate = error instanceof Error && error.message.includes("Unique constraint");
    return NextResponse.json({ error: duplicate ? "Ese nombre ya existe." : "No fue posible guardar el catálogo." }, { status: 400 });
  }
}
