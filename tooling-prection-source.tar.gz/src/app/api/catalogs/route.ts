import { NextResponse } from "next/server";
import { z } from "zod";
import { audit } from "@/lib/audit";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";

const typeSchema = z.enum(["brands", "categories"]);
const createSchema = z.object({ type: typeSchema, name: z.string().trim().min(2).max(100) });
const updateSchema = z.object({ type: typeSchema, id: z.string().min(1), name: z.string().trim().min(2).max(100).optional(), status: z.enum(["ACTIVE", "ARCHIVED"]).optional() }).refine(value => value.name || value.status, "Indica qué dato deseas cambiar.");

export async function GET(request: Request) {
  const session = await currentSession(); if (!session) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  const parsed = typeSchema.safeParse(new URL(request.url).searchParams.get("type"));
  if (!parsed.success) return NextResponse.json({ error: "Tipo de catálogo inválido." }, { status: 400 });
  const status = new URL(request.url).searchParams.get("status") === "archived" ? "ARCHIVED" : "ACTIVE";
  const rows = parsed.data === "brands" ? await db.brand.findMany({ where: { status }, orderBy: { name: "asc" }, include: { _count: { select: { products: true } } } }) : await db.category.findMany({ where: { status }, orderBy: { name: "asc" }, include: { _count: { select: { products: true } } } });
  return NextResponse.json(rows);
}

export async function PATCH(request: Request) {
  const session = await currentSession(); if (!session || session.role !== "ADMIN") return NextResponse.json({ error: "Sólo un administrador puede administrar este catálogo." }, { status: 403 });
  try {
    const input = updateSchema.parse(await request.json());
    const before = input.type === "brands" ? await db.brand.findUnique({ where: { id: input.id } }) : await db.category.findUnique({ where: { id: input.id } });
    if (!before) return NextResponse.json({ error: "No se encontró el registro." }, { status: 404 });
    const data = { ...(input.name ? { name: input.name } : {}), ...(input.status ? { status: input.status } : {}) };
    const item = input.type === "brands" ? await db.brand.update({ where: { id: input.id }, data }) : await db.category.update({ where: { id: input.id }, data });
    await audit({ userId: session.id, action: input.status ? (input.status === "ARCHIVED" ? "ARCHIVE" : "RESTORE") : "UPDATE", entity: input.type === "brands" ? "Brand" : "Category", entityId: item.id, before: before as never, after: item as never });
    return NextResponse.json(item);
  } catch (error) {
    const duplicate = error instanceof Error && error.message.includes("Unique constraint");
    return NextResponse.json({ error: duplicate ? "Ese nombre ya existe." : error instanceof z.ZodError ? "Los datos del catálogo no son válidos." : "No fue posible actualizar el catálogo." }, { status: 400 });
  }
}

export async function POST(request: Request) {
  const session = await currentSession(); if (!session || session.role !== "ADMIN") return NextResponse.json({ error: "Sólo un administrador puede administrar este catálogo." }, { status: 403 });
  try {
    const input = createSchema.parse(await request.json());
    const item = input.type === "brands" ? await db.brand.create({ data: { name: input.name } }) : await db.category.create({ data: { name: input.name } });
    await audit({ userId: session.id, action: "CREATE", entity: input.type === "brands" ? "Brand" : "Category", entityId: item.id, after: item as never });
    return NextResponse.json(item, { status: 201 });
  } catch (error) {
    const duplicate = error instanceof Error && error.message.includes("Unique constraint");
    return NextResponse.json({ error: duplicate ? "Ese nombre ya existe." : "No fue posible guardar el catálogo." }, { status: 400 });
  }
}
