import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
export const dynamic = "force-dynamic";
export async function GET() {
  const session = await currentSession();
  if (!session) return Response.json({ error: "No autorizado" }, { status: 401 });
  if (session.role !== "ADMIN") return Response.json({ error: "Solo administración puede revisar respaldos." }, { status: 403 });
  const latest = await db.auditEvent.findFirst({ where: { entity: "DatabaseBackup" }, orderBy: { createdAt: "desc" }, select: { createdAt: true, action: true, after: true } });
  return Response.json({ schedule: "Diariamente a las 14:00 (Ciudad de México)", destination: "OneDrive · Tooling Prection - Respaldos", requiresComputer: true, latest }, { headers: { "Cache-Control": "private, no-store" } });
}
