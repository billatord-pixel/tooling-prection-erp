import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
export const dynamic = "force-dynamic";
export const runtime = "nodejs";
export async function GET() {
  const session = await currentSession();
  if (!session) return new Response("No autorizado", { status: 401 });
  if (session.role !== "ADMIN") return new Response("Solo administradores", { status: 403 });
  const [companySettings, parties, partyCodeSequences, brands, categories, products, purchaseOrders, purchaseInvoices, salesInvoices, quotes, deliveries, inventoryMovements, productReconciliations, sequences, auditEvents, users] = await Promise.all([
    db.companySettings.findMany(), db.party.findMany(), db.partyCodeSequence.findMany(), db.brand.findMany(), db.category.findMany(), db.product.findMany(),
    db.purchaseOrder.findMany({ include: { lines: true } }), db.purchaseInvoice.findMany({ include: { lines: true } }),
    db.salesInvoice.findMany({ include: { lines: true, attachments: true } }), db.quote.findMany({ include: { lines: true } }),
    db.delivery.findMany({ include: { lines: true } }), db.inventoryMovement.findMany(), db.productReconciliation.findMany(),
    db.sequence.findMany(), db.auditEvent.findMany(), db.user.findMany({ select: { id: true, name: true, email: true, role: true, isActive: true, lastLoginAt: true, createdAt: true, updatedAt: true } }),
  ]);
  const backupSalesInvoices = salesInvoices.map(({ attachments, ...invoice }) => ({ ...invoice, attachments: attachments.map(({ data, ...attachment }) => ({ ...attachment, dataBase64: Buffer.from(data).toString("base64") })) }));
  const snapshot = { format: "tooling-prection-logical-export-v1", generatedAt: new Date().toISOString(), generatedBy: session.email, warning: "Exportación lógica JSON; no es un dump SQL ni restaurable directamente. Se excluyen hashes de contraseña y tokens de recuperación. Configure backups PostgreSQL nativos en Railway.", data: { companySettings, parties, partyCodeSequences, brands, categories, products, purchaseOrders, purchaseInvoices, salesInvoices: backupSalesInvoices, quotes, deliveries, inventoryMovements, productReconciliations, sequences, auditEvents, users } };
  const body = JSON.stringify(snapshot, null, 2);
  const filename = `tooling-prection-export-${new Date().toISOString().slice(0, 10)}.json`;
  return new Response(body, { headers: { "Content-Type": "application/json; charset=utf-8", "Content-Disposition": `attachment; filename=${filename}`, "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff" } });
}
