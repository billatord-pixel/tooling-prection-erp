import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
export const dynamic = "force-dynamic";
export const runtime = "nodejs";
export async function GET() {
  const session = await currentSession();
  if (!session) return new Response("No autorizado", { status: 401 });
  if (session.role !== "ADMIN") return new Response("Solo administradores", { status: 403 });
  const [companySettings, parties, partyCodeSequences, brands, categories, products, purchaseOrders, purchaseInvoices, salesInvoices, quotes, deliveries, inventoryMovements, productReconciliations, sequences, auditEvents, users, employees, shippingMethods] = await Promise.all([
    db.companySettings.findMany(), db.party.findMany(), db.partyCodeSequence.findMany(), db.brand.findMany(), db.category.findMany(), db.product.findMany(),
    db.purchaseOrder.findMany({ include: { lines: true } }), db.purchaseInvoice.findMany({ include: { lines: true, attachments: true } }),
    db.salesInvoice.findMany({ include: { lines: true, attachments: true } }), db.quote.findMany({ include: { lines: true } }),
    db.delivery.findMany({ include: { lines: true, attachments: true } }), db.inventoryMovement.findMany(), db.productReconciliation.findMany(),
    db.sequence.findMany(), db.auditEvent.findMany(), db.user.findMany({ select: { id: true, name: true, email: true, role: true, isActive: true, lastLoginAt: true, createdAt: true, updatedAt: true } }),
    db.employee.findMany(), db.shippingMethod.findMany(),
  ]);
  const backupSalesInvoices = salesInvoices.map(({ attachments, ...invoice }) => ({ ...invoice, attachments: attachments.map(({ data, ...attachment }) => ({ ...attachment, dataBase64: Buffer.from(data).toString("base64") })) }));
  const backupPurchaseInvoices = purchaseInvoices.map(({ attachments, ...invoice }) => ({ ...invoice, attachments: attachments.map(({ data, ...attachment }) => ({ ...attachment, dataBase64: Buffer.from(data).toString("base64") })) }));
  const backupDeliveries = deliveries.map(({ attachments, ...delivery }) => ({ ...delivery, attachments: attachments.map(({ data, ...attachment }) => ({ ...attachment, dataBase64: Buffer.from(data).toString("base64") })) }));
  const snapshot = { format: "tooling-prection-logical-export-v2", generatedAt: new Date().toISOString(), generatedBy: session.email, warning: "Exportación lógica JSON para consulta y resguardo. Incluye los XML y adjuntos guardados en la base, empleados y modos de envío. Se excluyen hashes de contraseña y tokens de recuperación; para restaurar el sistema completo utilice el respaldo PostgreSQL cifrado.", data: { companySettings, parties, partyCodeSequences, brands, categories, products, purchaseOrders, purchaseInvoices: backupPurchaseInvoices, salesInvoices: backupSalesInvoices, quotes, deliveries: backupDeliveries, inventoryMovements, productReconciliations, sequences, auditEvents, users, employees, shippingMethods } };
  const customerOrders = await db.customerOrder.findMany({include:{items:{include:{allocations:true,deliveries:true}},invoiceLinks:true,attachments:true}});
  const expandedSnapshot = {...snapshot,format:"tooling-prection-logical-export-v3",data:{...snapshot.data,customerOrders:customerOrders.map(({attachments,...order})=>({...order,attachments:attachments.map(({data,...attachment})=>({...attachment,dataBase64:Buffer.from(data).toString("base64")}))}))}};
  const body = JSON.stringify(expandedSnapshot, null, 2);
  const filename = `tooling-prection-export-${new Date().toISOString().slice(0, 10)}.json`;
  return new Response(body, { headers: { "Content-Type": "application/json; charset=utf-8", "Content-Disposition": `attachment; filename=${filename}`, "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff" } });
}
