import { NextResponse } from "next/server";
import { readFile } from "node:fs/promises";
import { join } from "node:path";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { getMonthlySoldProducts } from "@/lib/monthly-sold-products-query";
import { monthlyInvoiceRange } from "@/lib/monthly-sold-products";
import { createMonthlySoldProductsPdf } from "@/lib/monthly-sold-products-pdf";
import { mexicoToday } from "@/lib/customer-order-calendar";
export const runtime="nodejs";
export const dynamic="force-dynamic";
export async function GET(request:Request){
  if(!await currentSession())return NextResponse.json({error:"No autorizado"},{status:401});
  const params=new URL(request.url).searchParams,month=params.get("month")||mexicoToday().slice(0,7),format=params.get("format")||"json";
  const endMonth=params.get("endMonth")??month;
  try{monthlyInvoiceRange(month,endMonth);}catch(error){return NextResponse.json({error:(error as Error).message},{status:400});}
  if(!["json","pdf"].includes(format))return NextResponse.json({error:"Formato no válido."},{status:400});
  const report=await getMonthlySoldProducts(month,endMonth);
  if(format==="json")return NextResponse.json(report,{headers:{"Cache-Control":"private, no-store"}});
  const company=await db.companySettings.findFirst({select:{tradeName:true,taxId:true,email:true}});
  const logo=await readFile(join(process.cwd(),"public/brand/tooling-prection-logo.jpg")).catch(()=>undefined);
  const bytes=await createMonthlySoldProductsPdf(report,company||{tradeName:"Tooling Prection"},logo);
  const period=month===endMonth?month:`${month}-al-${endMonth}`;
  return new Response(new Uint8Array(bytes),{headers:{"Content-Type":"application/pdf","Content-Disposition":'attachment; filename="productos-vendidos-tooling-prection-'+period+'.pdf"',"Cache-Control":"private, no-store","X-Content-Type-Options":"nosniff"}});
}
