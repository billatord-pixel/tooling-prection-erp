import { beforeEach, describe, expect, it, vi } from "vitest";

const { salesFindMany, purchaseFindMany } = vi.hoisted(() => ({ salesFindMany: vi.fn(), purchaseFindMany: vi.fn() }));

vi.mock("@/lib/auth", () => ({ currentSession: vi.fn().mockResolvedValue({ id: "qa-admin", role: "ADMIN" }) }));
vi.mock("@/lib/db", () => ({ db: {
  salesInvoice: { findMany: salesFindMany },
  purchaseInvoice: { findMany: purchaseFindMany },
  companySettings: { findFirst: vi.fn().mockResolvedValue(null) },
} }));

import { GET } from "./route";

describe("sales and purchase report PDFs", () => {
  beforeEach(() => { salesFindMany.mockResolvedValue([]); purchaseFindMany.mockResolvedValue([]); });

  it.each(["sales", "purchases"] as const)("creates an empty %s report PDF", async kind => {
    const response = await GET(new Request(`http://localhost/api/reports/invoices/${kind}?currency=MXN&from=2026-10-01&to=2026-10-03`), { params: Promise.resolve({ kind }) });
    expect(response.status).toBe(200);
    expect(response.headers.get("Content-Type")).toBe("application/pdf");
    const label = kind === "sales" ? "ventas" : "compras";
    expect(response.headers.get("Content-Disposition")).toContain(`reporte-${label}-tooling-prection-2026-10-01-al-2026-10-03.pdf`);
    const bytes = Buffer.from(await response.arrayBuffer());
    expect(bytes.subarray(0, 5).toString()).toBe("%PDF-");
    expect(bytes.length).toBeGreaterThan(1000);
  });

  it("rejects an invalid date range", async () => {
    const response = await GET(new Request("http://localhost/api/reports/invoices/sales?from=2026-02-30&to=2026-03-01"), { params: Promise.resolve({ kind: "sales" }) });
    expect(response.status).toBe(400);
  });
});
