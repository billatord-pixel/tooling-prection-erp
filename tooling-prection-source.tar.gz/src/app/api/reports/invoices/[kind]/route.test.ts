import { beforeEach, describe, expect, it, vi } from "vitest";

const { salesFindMany, purchaseFindMany } = vi.hoisted(() => ({ salesFindMany: vi.fn(), purchaseFindMany: vi.fn() }));

vi.mock("@/lib/auth", () => ({ currentSession: vi.fn().mockResolvedValue({ id: "qa-admin", role: "ADMIN" }) }));
vi.mock("@/lib/db", () => ({ db: {
  salesInvoice: { findMany: salesFindMany },
  purchaseInvoice: { findMany: purchaseFindMany },
  companySettings: { findFirst: vi.fn().mockResolvedValue(null) },
} }));

import { GET } from "./route";
import { createInvoiceReportPdf } from "@/lib/invoice-report-pdf";

const pageCount = (bytes: Buffer) => (bytes.toString("latin1").match(/\/Type\s*\/Page\b/g) || []).length;

describe("sales and purchase report PDFs", () => {
  beforeEach(() => { vi.clearAllMocks(); salesFindMany.mockResolvedValue([]); purchaseFindMany.mockResolvedValue([]); });

  it.each(["sales", "purchases"] as const)("creates an empty %s report PDF", async kind => {
    const response = await GET(new Request(`http://localhost/api/reports/invoices/${kind}?currency=MXN&from=2026-10-01&to=2026-10-03`), { params: Promise.resolve({ kind }) });
    expect(response.status).toBe(200);
    expect(response.headers.get("Content-Type")).toBe("application/pdf");
    const label = kind === "sales" ? "ventas" : "compras";
    expect(response.headers.get("Content-Disposition")).toContain(`reporte-${label}-tooling-prection-2026-10-01-al-2026-10-03.pdf`);
    const bytes = Buffer.from(await response.arrayBuffer());
    expect(bytes.subarray(0, 5).toString()).toBe("%PDF-");
    expect(bytes.length).toBeGreaterThan(1000);
    expect(pageCount(bytes)).toBe(1);
  });

  it.each(["sales", "purchases"] as const)("includes cancelled invoices and applies the exact date range to %s", async kind => {
    const rows = ["PAID", "PENDING", "CANCELLED"].map((status, index) => ({ issueDate: new Date("2026-10-09T12:00:00Z"), folio: `F-${index + 1}`, customer: { legalName: "Cliente de prueba" }, supplier: { legalName: "Proveedor de prueba" }, currency: "MXN", exchangeRate: 1, rawXml: null, total: 100, status, _count: { lines: 2 } }));
    const query = kind === "sales" ? salesFindMany : purchaseFindMany;
    query.mockResolvedValue(rows);
    const response = await GET(new Request(`http://localhost/api/reports/invoices/${kind}?currency=MXN&from=2026-10-01&to=2026-10-09`), { params: Promise.resolve({ kind }) });
    expect(response.status).toBe(200);
    expect(query.mock.calls[0][0].where).toEqual({ issueDate: { gte: new Date("2026-10-01T00:00:00.000Z"), lte: new Date("2026-10-09T23:59:59.999Z") } });
    expect(pageCount(Buffer.from(await response.arrayBuffer()))).toBe(1);
  });

  it.each(["sales", "purchases"] as const)("paginates 70 %s invoices into four populated pages without footer-only pages", async kind => {
    const invoices = Array.from({ length: 70 }, (_, index) => ({ issueDate: new Date("2026-10-09T12:00:00Z"), folio: `F-${index + 1}`, counterparty: `Cliente ${index + 1}`, currency: "MXN", reportTotal: 100, status: "PENDING", lineCount: 1 }));
    const bytes = await createInvoiceReportPdf({ kind, currency: "MXN", title: "Reporte de prueba", period: "Octubre de 2026", invoices });
    expect(pageCount(bytes)).toBe(4);
  });

  it("rejects an invalid date range", async () => {
    const response = await GET(new Request("http://localhost/api/reports/invoices/sales?from=2026-02-30&to=2026-03-01"), { params: Promise.resolve({ kind: "sales" }) });
    expect(response.status).toBe(400);
  });
});
