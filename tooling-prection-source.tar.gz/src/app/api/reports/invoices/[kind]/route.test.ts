import { beforeEach, describe, expect, it, vi } from "vitest";

const { salesFindMany, purchaseFindMany, salesRates, session } = vi.hoisted(() => ({ salesFindMany: vi.fn(), purchaseFindMany: vi.fn(), salesRates: vi.fn(), session: vi.fn() }));

vi.mock("@/lib/auth", () => ({ currentSession: session }));
vi.mock("@/lib/banxico-fix", () => ({ getBanxicoSalesRates: salesRates }));
vi.mock("@/lib/db", () => ({ db: {
  salesInvoice: { findMany: salesFindMany },
  purchaseInvoice: { findMany: purchaseFindMany },
  companySettings: { findFirst: vi.fn().mockResolvedValue(null) },
} }));

import { GET } from "./route";
import { createInvoiceReportPdf } from "@/lib/invoice-report-pdf";
import { readCustomerOrderPdf } from "@/lib/customer-order-pdf-reader";

const pageCount = (bytes: Buffer) => (bytes.toString("latin1").match(/\/Type\s*\/Page\b/g) || []).length;

describe("sales and purchase report PDFs", () => {
  beforeEach(() => { vi.clearAllMocks(); session.mockResolvedValue({role:"ADMIN"}); salesFindMany.mockResolvedValue([]); purchaseFindMany.mockResolvedValue([]); });

  it.each(["sales", "purchases"] as const)("creates an empty %s report PDF", async kind => {
    const response = await GET(new Request(`http://localhost/api/reports/invoices/${kind}?currency=MXN&from=2026-10-01&to=2026-10-03`), { params: Promise.resolve({ kind }) });
    expect(response.status).toBe(200);
    expect(response.headers.get("Content-Type")).toBe("application/pdf");
    const label = kind === "sales" ? "ventas" : "compras";
    expect(response.headers.get("Content-Disposition")).toContain(`reporte-${label}-tooling-prection-2026-10-01-al-2026-10-03.pdf`);
    const bytes = Buffer.from(await response.arrayBuffer());
    expect(bytes.subarray(0, 5).toString()).toBe("%PDF-");
    expect(bytes.length).toBeGreaterThan(1000);
    expect(pageCount(bytes)).toBe(1);
  });

  it.each(["sales", "purchases"] as const)("includes cancelled invoices and applies the exact date range to %s", async kind => {
    const rows = ["PAID", "PENDING", "CANCELLED"].map((status, index) => ({ issueDate: new Date("2026-10-09T12:00:00Z"), folio: `F-${index + 1}`, customer: { legalName: "Cliente de prueba" }, supplier: { legalName: "Proveedor de prueba" }, currency: "MXN", exchangeRate: 1, rawXml: null, total: 100, status, _count: { lines: 2 } }));
    const query = kind === "sales" ? salesFindMany : purchaseFindMany;
    query.mockResolvedValue(rows);
    const response = await GET(new Request(`http://localhost/api/reports/invoices/${kind}?currency=MXN&from=2026-10-01&to=2026-10-09`), { params: Promise.resolve({ kind }) });
    expect(response.status).toBe(200);
    expect(query.mock.calls[0][0].where).toEqual({ issueDate: { gte: new Date("2026-10-01T00:00:00.000Z"), lte: new Date("2026-10-09T23:59:59.999Z") } });
    expect(pageCount(Buffer.from(await response.arrayBuffer()))).toBe(kind === "sales" ? 2 : 1);
  });

  it("converts each USD line by its fiscal day, retains native MXN and marks missing rates", async () => {
    session.mockResolvedValue({role:"SALES"});
    const rows = [
      ["F-USD-1","2026-10-09","USD","Herramienta uno",12.25],
      ["F-USD-2","2026-10-10","USD","Herramienta dos",12.25],
      ["F-MXN","2026-10-10","MXN","Herramienta local",38.75],
      ["F-USD-3","2026-10-11","USD","Herramienta sin FIX",100],
    ] as const;
    salesFindMany.mockResolvedValue(rows.map(([folio,day,currency,description,amount])=>({
      folio, issueDate:new Date(day), currency, exchangeRate:20, total:amount,
      rawXml:null, status:"PENDING", customer:{legalName:"Cliente prueba"}, _count:{lines:1},
      lines:[{description,quantity:2,amount,product:{technicalCode:"EDP 12345"}}],
    })));
    salesRates.mockResolvedValue(new Map([
      ["2026-10-09",{date:"2026-10-09",rate:"18.0000"}],
      ["2026-10-10",{date:"2026-10-08",rate:"19.0000"}],
    ]));
    const response=await GET(new Request("http://localhost/api/reports/invoices/sales?currency=MXN"),{params:Promise.resolve({kind:"sales"})});
    expect(response.status).toBe(200);
    expect(salesRates).toHaveBeenCalledWith(["2026-10-09","2026-10-10","2026-10-11"]);
    const text=await readCustomerOrderPdf(Buffer.from(await response.arrayBuffer()));
    expect(text).toContain("Detalle de partidas");
    expect(text).toContain("FIX 19.0000");
    expect(text).toContain("08/10/2026");
    for(const value of ["MXN 220.50","MXN 232.75","MXN 38.75","Sin conversión","Herramienta sin FIX"]) expect(text).toContain(value);
    expect(text).not.toContain("MXN 245.00");
  });

  it.each(["sales", "purchases"] as const)("paginates 70 %s invoices into four populated pages without footer-only pages", async kind => {
    const invoices = Array.from({ length: 70 }, (_, index) => ({ issueDate: new Date("2026-10-09T12:00:00Z"), folio: `F-${index + 1}`, counterparty: `Cliente ${index + 1}`, currency: "MXN", reportTotal: 100, status: "PENDING", lineCount: 1 }));
    const bytes = await createInvoiceReportPdf({ kind, currency: "MXN", title: "Reporte de prueba", period: "Octubre de 2026", invoices });
    expect(pageCount(bytes)).toBe(4);
  });

  it("rejects an invalid date range", async () => {
    const response = await GET(new Request("http://localhost/api/reports/invoices/sales?from=2026-02-30&to=2026-03-01"), { params: Promise.resolve({ kind: "sales" }) });
    expect(response.status).toBe(400);
  });
});
