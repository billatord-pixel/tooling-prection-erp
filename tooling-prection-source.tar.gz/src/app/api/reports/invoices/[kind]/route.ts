import { readFile } from "node:fs/promises";
import path from "node:path";
import PDFDocument from "pdfkit";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { parseCfdi } from "@/lib/cfdi";
import { TOOLING_CONTACT_EMAIL, TOOLING_PDF, drawToolingPdfRail } from "@/lib/pdf-brand";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type ReportInvoice = {
  issueDate: Date;
  folio: string;
  counterparty: string;
  currency: string;
  exchangeRate: unknown;
  rawXml: string | null;
  total: unknown;
  status: string;
  lineCount: number;
};

const currencies = ["MXN", "USD", "EUR"] as const;
const money = (value: number, currency: string) => new Intl.NumberFormat("es-MX", { style: "currency", currency, maximumFractionDigits: 2 }).format(value);
const dateLabel = (value: Date) => new Intl.DateTimeFormat("es-MX", { day: "2-digit", month: "short", year: "numeric", timeZone: "UTC" }).format(value).replaceAll(".", "");

function invoiceRate(invoice: ReportInvoice) {
  if (invoice.currency === "MXN") return 1;
  const stored = Number(invoice.exchangeRate || 0);
  if (stored > 0) return stored;
  if (!invoice.rawXml) return null;
  try { return parseCfdi(invoice.rawXml).exchangeRate || null; } catch { return null; }
}

function statusLabel(status: string) {
  if (status === "PAID") return "Pagada";
  if (status === "PENDING") return "Pendiente";
  return status === "CANCELLED" ? "Cancelada" : status;
}

export async function GET(request: Request, { params }: { params: Promise<{ kind: string }> }) {
  const session = await currentSession();
  if (!session) return new Response("No autorizado", { status: 401 });
  if (session.role !== "ADMIN") return new Response("Los reportes están disponibles solo para administradores.", { status: 403 });

  const { kind } = await params;
  if (kind !== "sales" && kind !== "purchases") return new Response("Tipo de reporte no válido.", { status: 404 });

  const search = new URL(request.url).searchParams;
  const currency = search.get("currency") || "MXN";
  const from = search.get("from") || undefined;
  const to = search.get("to") || undefined;
  if (!currencies.includes(currency as typeof currencies[number])) return new Response("Moneda no válida.", { status: 400 });
  const isValidDate = (value?: string) => {
    if (!value || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return !value;
    const date = new Date(`${value}T00:00:00.000Z`);
    return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value;
  };
  if (!isValidDate(from) || !isValidDate(to) || (from && to && from > to)) return new Response("El periodo seleccionado no es válido.", { status: 400 });
  const dateRange = from || to ? { gte: from ? new Date(`${from}T00:00:00.000Z`) : undefined, lte: to ? new Date(`${to}T23:59:59.999Z`) : undefined } : undefined;
  const where = { status: { not: "CANCELLED" as const }, ...(currency === "MXN" ? {} : { currency }), ...(dateRange ? { issueDate: dateRange } : {}) };

  let invoices: ReportInvoice[];
  if (kind === "sales") {
    const rows = await db.salesInvoice.findMany({ where, orderBy: [{ issueDate: "asc" }, { createdAt: "asc" }], include: { customer: { select: { legalName: true } }, _count: { select: { lines: true } } } });
    invoices = rows.map(row => ({ issueDate: row.issueDate, folio: row.folio, counterparty: row.customer.legalName, currency: row.currency, exchangeRate: row.exchangeRate, rawXml: row.rawXml, total: row.total, status: row.status, lineCount: row._count.lines }));
  } else {
    const rows = await db.purchaseInvoice.findMany({ where, orderBy: [{ issueDate: "asc" }, { createdAt: "asc" }], include: { supplier: { select: { legalName: true } }, _count: { select: { lines: true } } } });
    invoices = rows.map(row => ({ issueDate: row.issueDate, folio: row.folio, counterparty: row.supplier.legalName, currency: row.currency, exchangeRate: row.exchangeRate, rawXml: row.rawXml, total: row.total, status: row.status, lineCount: row._count.lines }));
  }

  const converted = invoices.map(invoice => {
    const total = Number(invoice.total);
    if (invoice.currency === currency) return { ...invoice, reportTotal: total };
    if (currency !== "MXN") return { ...invoice, reportTotal: null };
    const rate = invoiceRate(invoice);
    return { ...invoice, reportTotal: rate && rate > 0 ? Number((total * rate).toFixed(2)) : null };
  });
  const missingConversions = converted.filter(invoice => invoice.reportTotal === null).length;
  const total = converted.reduce((sum, invoice) => sum + (invoice.reportTotal ?? 0), 0);
  const title = kind === "sales" ? "ventas" : "compras";
  const label = kind === "sales" ? "VENTAS" : "COMPRAS";
  const period = from && to ? `${dateLabel(new Date(`${from}T12:00:00.000Z`))} al ${dateLabel(new Date(`${to}T12:00:00.000Z`))}` : from ? `Desde ${dateLabel(new Date(`${from}T12:00:00.000Z`))}` : to ? `Hasta ${dateLabel(new Date(`${to}T12:00:00.000Z`))}` : "Todos los periodos";
  const monthYear = from && to && from.slice(0, 7) === to.slice(0, 7)
    ? new Intl.DateTimeFormat("es-MX", { month: "long", year: "numeric", timeZone: "UTC" }).format(new Date(`${from}T12:00:00.000Z`))
    : "";
  const reportTitle = `Reporte de ${title}${monthYear ? ` · ${monthYear}` : ""}`;
  const company = await db.companySettings.findFirst({ orderBy: { createdAt: "asc" } });
  const doc = new PDFDocument({ size: "LETTER", margins: { top: 40, left: 34, right: 34, bottom: 42 }, bufferPages: true, info: { Title: reportTitle, Author: company?.tradeName || "Tooling Prection" } });
  const chunks: Buffer[] = [];
  doc.on("data", chunk => chunks.push(Buffer.from(chunk)));
  const done = new Promise<Buffer>(resolve => doc.on("end", () => resolve(Buffer.concat(chunks))));
  const left = 34, right = doc.page.width - 34, width = right - left;
  const logo = company?.logoUrl ? path.join(process.cwd(), "public", company.logoUrl.replace(/^\/+/, "")) : path.join(process.cwd(), "public/brand/tooling-prection-logo.jpg");
  let logoBytes: Buffer | undefined;
  try { logoBytes = await readFile(logo); } catch { /* The report remains legible without a logo file. */ }

  const heading = () => {
    drawToolingPdfRail(doc);
    if (logoBytes) doc.image(logoBytes, left, 20, { fit: [44, 38] });
    doc.font("Helvetica-Bold").fontSize(17).fillColor(TOOLING_PDF.navy).text(company?.tradeName || "Tooling Prection", left + 54, 23, { width: 240 });
    doc.font("Helvetica").fontSize(7.5).fillColor(TOOLING_PDF.muted).text([company?.taxId ? `RFC ${company.taxId}` : "", TOOLING_CONTACT_EMAIL].filter(Boolean).join(" | ") || "ERP OPERATIVO", left + 54, 45, { width: 300 });
    doc.font("Helvetica-Bold").fontSize(8).fillColor(TOOLING_PDF.blue).text(label, right - 150, 23, { width: 150, align: "right" });
    doc.font("Helvetica-Bold").fontSize(7.5).fillColor(TOOLING_PDF.muted).text("REPORTE DE OPERACIÓN", right - 170, 40, { width: 170, align: "right" });
    doc.moveTo(left, 70).lineTo(right, 70).lineWidth(1.4).strokeColor(TOOLING_PDF.blue).stroke();
    doc.font("Helvetica-Bold").fontSize(16).fillColor(TOOLING_PDF.navy).text(reportTitle, left, 86, { width });
    doc.font("Helvetica").fontSize(8.5).fillColor(TOOLING_PDF.muted).text(`${period}  ·  ${converted.length} factura${converted.length === 1 ? "" : "s"}  ·  Total ${currency} ${money(total, currency)}${missingConversions ? `  ·  ${missingConversions} sin tipo de cambio` : ""}`, left, 111, { width });
    return 143;
  };
  const footer = (page: number, pages: number) => {
    const y = doc.page.height - 32;
    doc.moveTo(left, y - 9).lineTo(right, y - 9).lineWidth(.5).strokeColor(TOOLING_PDF.border).stroke();
    doc.font("Helvetica").fontSize(6.5).fillColor(TOOLING_PDF.muted).text(`Tooling Prection ERP  ·  Reporte de ${title}  ·  Uso interno`, left, y, { width: width * .52 });
    doc.text(`Generado ${new Intl.DateTimeFormat("es-MX", { dateStyle: "medium", timeStyle: "short" }).format(new Date())}`, left + width * .53, y, { width: width * .29, align: "center" });
    doc.text(`Página ${page} de ${pages}`, right - 58, y, { width: 58, align: "right" });
  };

  let y = heading();
  const headers = ["FECHA", "FOLIO", kind === "sales" ? "CLIENTE" : "PROVEEDOR", "MONEDA", "PARTIDAS", `TOTAL ${currency}`, "ESTADO"];
  const columnWidths = [58, 70, 148, 49, 48, 91, 80];
  const tableHeader = () => {
    doc.rect(left, y, width, 20).fill(TOOLING_PDF.pale);
    let x = left;
    headers.forEach((header, index) => {
      doc.font("Helvetica-Bold").fontSize(7).fillColor(TOOLING_PDF.blue).text(header, x + 5, y + 6, { width: columnWidths[index] - 10, ellipsis: true, align: index >= 4 ? "right" : "left" });
      x += columnWidths[index];
    });
    y += 20;
  };
  tableHeader();
  converted.forEach((invoice, index) => {
    const cells = [dateLabel(invoice.issueDate), invoice.folio, invoice.counterparty, invoice.currency, String(invoice.lineCount), invoice.reportTotal === null ? "Sin conversión" : money(invoice.reportTotal, currency), statusLabel(invoice.status)];
    doc.font("Helvetica").fontSize(7.2);
    const rowHeight = Math.max(22, ...cells.map((value, column) => doc.heightOfString(value, { width: columnWidths[column] - 10, lineGap: 1 }) + 8));
    if (y + rowHeight > doc.page.height - 49) { doc.addPage(); drawToolingPdfRail(doc); y = 42; tableHeader(); }
    if (index % 2 === 1) doc.rect(left, y, width, rowHeight).fill(TOOLING_PDF.row);
    let x = left;
    cells.forEach((value, column) => {
      doc.font(column === 1 ? "Helvetica-Bold" : "Helvetica").fontSize(7.2).fillColor(column === 6 && invoice.status === "PENDING" ? TOOLING_PDF.blue : TOOLING_PDF.ink);
      doc.text(value, x + 5, y + 4, { width: columnWidths[column] - 10, height: rowHeight - 6, ellipsis: true, align: column >= 4 ? "right" : "left" });
      x += columnWidths[column];
    });
    y += rowHeight;
    doc.moveTo(left, y).lineTo(right, y).lineWidth(.35).strokeColor(TOOLING_PDF.border).stroke();
  });
  if (!converted.length) {
    doc.font("Helvetica").fontSize(9).fillColor(TOOLING_PDF.muted).text("No hay facturas en el periodo seleccionado.", left + 8, y + 16, { width: width - 16, align: "center" });
  }
  const pages = doc.bufferedPageRange();
  for (let index = 0; index < pages.count; index++) { doc.switchToPage(pages.start + index); footer(index + 1, pages.count); }
  doc.end();
  const bytes = await done;
  const fileName = `reporte-${title}-tooling-prection${from ? `-${from}` : ""}${to ? `-al-${to}` : ""}.pdf`;
  return new Response(new Uint8Array(bytes), { headers: { "Content-Type": "application/pdf", "Content-Disposition": `inline; filename="${fileName}"`, "Cache-Control": "private, no-store" } });
}
