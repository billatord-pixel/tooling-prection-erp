import { readFile } from "node:fs/promises";
import path from "node:path";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { parseCfdi } from "@/lib/cfdi";
import { createInvoiceReportPdf } from "@/lib/invoice-report-pdf";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type ReportInvoice = {
  issueDate: Date;
  folio: string;
  counterparty: string;
  currency: string;
  exchangeRate: unknown;
  rawXml: string | null;
  total: unknown;
  status: string;
  lineCount: number;
};

const currencies = ["MXN", "USD", "EUR"] as const;
const dateLabel = (value: Date) => new Intl.DateTimeFormat("es-MX", { day: "2-digit", month: "short", year: "numeric", timeZone: "UTC" }).format(value).replaceAll(".", "");

function invoiceRate(invoice: ReportInvoice) {
  if (invoice.currency === "MXN") return 1;
  const stored = Number(invoice.exchangeRate || 0);
  if (stored > 0) return stored;
  if (!invoice.rawXml) return null;
  try { return parseCfdi(invoice.rawXml).exchangeRate || null; } catch { return null; }
}

export async function GET(request: Request, { params }: { params: Promise<{ kind: string }> }) {
  const session = await currentSession();
  if (!session) return new Response("No autorizado", { status: 401 });
  if (session.role !== "ADMIN") return new Response("Los reportes están disponibles solo para administradores.", { status: 403 });

  const { kind } = await params;
  if (kind !== "sales" && kind !== "purchases") return new Response("Tipo de reporte no válido.", { status: 404 });

  const search = new URL(request.url).searchParams;
  const currency = search.get("currency") || "MXN";
  const from = search.get("from") || undefined;
  const to = search.get("to") || undefined;
  if (!currencies.includes(currency as typeof currencies[number])) return new Response("Moneda no válida.", { status: 400 });
  const isValidDate = (value?: string) => {
    if (!value || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return !value;
    const date = new Date(`${value}T00:00:00.000Z`);
    return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value;
  };
  if (!isValidDate(from) || !isValidDate(to) || (from && to && from > to)) return new Response("El periodo seleccionado no es válido.", { status: 400 });
  const dateRange = from || to ? { gte: from ? new Date(`${from}T00:00:00.000Z`) : undefined, lte: to ? new Date(`${to}T23:59:59.999Z`) : undefined } : undefined;
  const where = { ...(currency === "MXN" ? {} : { currency }), ...(dateRange ? { issueDate: dateRange } : {}) };

  let invoices: ReportInvoice[];
  if (kind === "sales") {
    const rows = await db.salesInvoice.findMany({ where, orderBy: [{ issueDate: "asc" }, { createdAt: "asc" }], include: { customer: { select: { legalName: true } }, _count: { select: { lines: true } } } });
    invoices = rows.map(row => ({ issueDate: row.issueDate, folio: row.folio, counterparty: row.customer.legalName, currency: row.currency, exchangeRate: row.exchangeRate, rawXml: row.rawXml, total: row.total, status: row.status, lineCount: row._count.lines }));
  } else {
    const rows = await db.purchaseInvoice.findMany({ where, orderBy: [{ issueDate: "asc" }, { createdAt: "asc" }], include: { supplier: { select: { legalName: true } }, _count: { select: { lines: true } } } });
    invoices = rows.map(row => ({ issueDate: row.issueDate, folio: row.folio, counterparty: row.supplier.legalName, currency: row.currency, exchangeRate: row.exchangeRate, rawXml: row.rawXml, total: row.total, status: row.status, lineCount: row._count.lines }));
  }

  const converted = invoices.map(invoice => {
    const total = Number(invoice.total);
    if (invoice.currency === currency) return { ...invoice, reportTotal: total };
    if (currency !== "MXN") return { ...invoice, reportTotal: null };
    const rate = invoiceRate(invoice);
    return { ...invoice, reportTotal: rate && rate > 0 ? Number((total * rate).toFixed(2)) : null };
  });
  const title = kind === "sales" ? "ventas" : "compras";
  const period = from && to ? `${dateLabel(new Date(`${from}T12:00:00.000Z`))} al ${dateLabel(new Date(`${to}T12:00:00.000Z`))}` : from ? `Desde ${dateLabel(new Date(`${from}T12:00:00.000Z`))}` : to ? `Hasta ${dateLabel(new Date(`${to}T12:00:00.000Z`))}` : "Todos los periodos";
  const monthYear = from && to && from.slice(0, 7) === to.slice(0, 7)
    ? new Intl.DateTimeFormat("es-MX", { month: "long", year: "numeric", timeZone: "UTC" }).format(new Date(`${from}T12:00:00.000Z`))
    : "";
  const reportTitle = `Reporte de ${title}${monthYear ? ` · ${monthYear}` : ""}`;
  const company = await db.companySettings.findFirst({ orderBy: { createdAt: "asc" } });
  const logo = company?.logoUrl ? path.join(process.cwd(), "public", company.logoUrl.replace(/^\/+/, "")) : path.join(process.cwd(), "public/brand/tooling-prection-logo.jpg");
  let logoBytes: Buffer | undefined;
  try { logoBytes = await readFile(logo); } catch { /* The report remains legible without a logo file. */ }

  const bytes = await createInvoiceReportPdf({ kind, currency, title: reportTitle, period, invoices: converted, companyName: company?.tradeName || "Tooling Prection", taxId: company?.taxId || undefined, logo: logoBytes });
  const fileName = `reporte-${title}-tooling-prection${from ? `-${from}` : ""}${to ? `-al-${to}` : ""}.pdf`;
  return new Response(new Uint8Array(bytes), { headers: { "Content-Type": "application/pdf", "Content-Disposition": `inline; filename="${fileName}"`, "Cache-Control": "private, no-store" } });
}
