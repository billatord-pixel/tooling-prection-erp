import { describe, expect, it, vi } from "vitest";

vi.mock("@/lib/auth", () => ({ currentSession: vi.fn().mockResolvedValue({ id: "qa-user" }) }));
vi.mock("@/lib/db", () => ({ db: { companySettings: { findFirst: vi.fn().mockResolvedValue(null) } } }));
vi.mock("@/app/api/reports/route", () => ({
  GET: vi.fn().mockResolvedValue(new Response(JSON.stringify({
    currency: "USD", products: 0, stockValue: 0, lowStock: 0,
    sales: [], nativeSales: [], purchases: [], receivables: [], payables: [], pendingReceive: [],
    movements: 0, openOrders: 0, monthly: [], recentMonths: [], topClients: [],
    topSuppliers: [], topProducts: [], criticalProducts: [], pendingLines: [],
  }), { headers: { "Content-Type": "application/json" } })),
}));

import { GET } from "./route";

describe("report PDF", () => {
  it("generates a valid PDF even when the operation has no records", async () => {
    const response = await GET(new Request("http://localhost/api/reports/pdf?currency=USD"));
    expect(response.status).toBe(200);
    expect(response.headers.get("Content-Type")).toBe("application/pdf");
    const bytes = Buffer.from(await response.arrayBuffer());
    expect(bytes.subarray(0, 5).toString()).toBe("%PDF-");
    expect(bytes.length).toBeGreaterThan(1000);
  });
});
