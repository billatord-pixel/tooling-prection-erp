import { NextResponse } from "next/server";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
export const dynamic = "force-dynamic";
export async function GET(request: Request) {
  if (!await currentSession()) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  const [products, sales, purchases, receivable, payable, movements] = await Promise.all([
    db.product.aggregate({ where: { status: "ACTIVE" }, _count: { id: true }, _sum: { stock: true } }),
    db.salesInvoice.groupBy({ by: ["currency"], where: { status: { not: "CANCELLED" } }, _count: { id: true }, _sum: { total: true } }),
    db.purchaseInvoice.groupBy({ by: ["currency"], where: { status: { not: "CANCELLED" } }, _count: { id: true }, _sum: { total: true } }),
    db.salesInvoice.groupBy({ by: ["currency"], where: { status: "PENDING" }, _sum: { total: true } }),
    db.purchaseInvoice.groupBy({ by: ["currency"], where: { status: "PENDING" }, _sum: { total: true } }),
    db.inventoryMovement.count(),
  ]);
  const stock = await db.product.findMany({ where: { status: "ACTIVE" }, select: { stock: true, baseCost: true } });
  const report = { products: products._count.id, stockValue: stock.reduce((sum, p) => sum + Number(p.stock) * Number(p.baseCost), 0), sales: sales.map(x => ({ currency: x.currency, count: x._count.id, total: Number(x._sum.total || 0) })), purchases: purchases.map(x => ({ currency: x.currency, count: x._count.id, total: Number(x._sum.total || 0) })), receivables: receivable.map(x => ({ currency: x.currency, total: Number(x._sum.total || 0) })), payables: payable.map(x => ({ currency: x.currency, total: Number(x._sum.total || 0) })), movements };
  if (new URL(request.url).searchParams.get("format") === "csv") {
    const lines = [["Indicador", "Moneda", "Valor"], ["Productos activos", "", String(report.products)], ["Valor inventario a costo", "MXN", report.stockValue.toFixed(2)], ...report.sales.map(x => ["Ventas acumuladas", x.currency, x.total.toFixed(2)]), ...report.purchases.map(x => ["Compras acumuladas", x.currency, x.total.toFixed(2)]), ...report.receivables.map(x => ["Cuentas por cobrar", x.currency, x.total.toFixed(2)]), ...report.payables.map(x => ["Cuentas por pagar", x.currency, x.total.toFixed(2)]), ["Movimientos inventario", "", String(report.movements)]];
    const csv = "\uFEFF" + lines.map(row => row.map(v => `"${v.replaceAll('"', '""')}"`).join(",")).join("\r\n");
    return new Response(csv, { headers: { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": "attachment; filename=reporte-operativo-tooling-prection.csv", "Cache-Control": "private, no-store" } });
  }
  return NextResponse.json(report, { headers: { "Cache-Control": "private, no-store" } });
}
