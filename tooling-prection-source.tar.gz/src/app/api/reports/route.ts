import { NextResponse } from "next/server";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
export const dynamic = "force-dynamic";
export async function GET(request: Request) {
  if (!await currentSession()) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  const params = new URL(request.url).searchParams;
  const from = params.get("from"), to = params.get("to");
  const currency = params.get("currency");
  const currencyFilter = currency && ["MXN","USD","EUR"].includes(currency) ? { currency } : {};
  const dateRange = from || to ? { gte: from ? new Date(`${from}T00:00:00.000Z`) : undefined, lte: to ? new Date(`${to}T23:59:59.999Z`) : undefined } : undefined;
  if ((from && Number.isNaN(Date.parse(from))) || (to && Number.isNaN(Date.parse(to)))) return NextResponse.json({ error: "El periodo seleccionado no es válido." }, { status: 400 });
  const [products, sales, purchases, receivable, payable, movements] = await Promise.all([
    db.product.aggregate({ where: { status: "ACTIVE" }, _count: { id: true }, _sum: { stock: true } }),
    db.salesInvoice.groupBy({ by: ["currency"], where: { ...currencyFilter, status: { not: "CANCELLED" }, ...(dateRange ? { issueDate: dateRange } : {}) }, _count: { id: true }, _sum: { total: true } }),
    db.purchaseInvoice.groupBy({ by: ["currency"], where: { ...currencyFilter, status: { not: "CANCELLED" }, ...(dateRange ? { issueDate: dateRange } : {}) }, _count: { id: true }, _sum: { total: true } }),
    db.salesInvoice.groupBy({ by: ["currency"], where: { ...currencyFilter, status: "PENDING", ...(dateRange ? { issueDate: dateRange } : {}) }, _sum: { total: true } }),
    db.purchaseInvoice.groupBy({ by: ["currency"], where: { ...currencyFilter, status: "PENDING", ...(dateRange ? { issueDate: dateRange } : {}) }, _sum: { total: true } }),
    db.inventoryMovement.count({ where: dateRange ? { createdAt: dateRange } : {} }),
  ]);
  const [salesRows, purchaseRows, openOrders] = await Promise.all([
    db.salesInvoice.findMany({ where: { ...currencyFilter, status: { not: "CANCELLED" }, ...(dateRange ? { issueDate: dateRange } : {}) }, select: { issueDate: true, total: true, currency: true } }),
    db.purchaseInvoice.findMany({ where: { ...currencyFilter, status: { not: "CANCELLED" }, ...(dateRange ? { issueDate: dateRange } : {}) }, select: { issueDate: true, total: true, currency: true } }),
    db.purchaseOrder.count({ where: { status: "PENDING" } }),
  ]);
  const monthlyMap = new Map<string, { sales: Record<string, number>; purchases: Record<string, number> }>();
  for (const row of salesRows) { const key = `${row.issueDate.getUTCFullYear()}-${String(row.issueDate.getUTCMonth()+1).padStart(2,"0")}`; const month = monthlyMap.get(key) || { sales: {}, purchases: {} }; month.sales[row.currency] = (month.sales[row.currency] || 0) + Number(row.total); monthlyMap.set(key, month); }
  for (const row of purchaseRows) { const key = `${row.issueDate.getUTCFullYear()}-${String(row.issueDate.getUTCMonth()+1).padStart(2,"0")}`; const month = monthlyMap.get(key) || { sales: {}, purchases: {} }; month.purchases[row.currency] = (month.purchases[row.currency] || 0) + Number(row.total); monthlyMap.set(key, month); }
  const stock = await db.product.findMany({ where: { status: "ACTIVE" }, select: { stock: true, baseCost: true } });
  const report = { products: products._count.id, stockValue: stock.reduce((sum, p) => sum + Number(p.stock) * Number(p.baseCost), 0), sales: sales.map(x => ({ currency: x.currency, count: x._count.id, total: Number(x._sum.total || 0) })), purchases: purchases.map(x => ({ currency: x.currency, count: x._count.id, total: Number(x._sum.total || 0) })), receivables: receivable.map(x => ({ currency: x.currency, total: Number(x._sum.total || 0) })), payables: payable.map(x => ({ currency: x.currency, total: Number(x._sum.total || 0) })), movements, openOrders, monthly: [...monthlyMap.entries()].sort(([a],[b])=>a.localeCompare(b)).slice(-12).map(([month,value])=>({month,sales:value.sales,purchases:value.purchases})) };
  if (new URL(request.url).searchParams.get("format") === "csv") {
    const lines = [["Indicador", "Moneda", "Valor"], ["Productos activos", "", String(report.products)], ["Valor inventario a costo", "MXN", report.stockValue.toFixed(2)], ...report.sales.map(x => ["Ventas acumuladas", x.currency, x.total.toFixed(2)]), ...report.purchases.map(x => ["Compras acumuladas", x.currency, x.total.toFixed(2)]), ...report.receivables.map(x => ["Cuentas por cobrar", x.currency, x.total.toFixed(2)]), ...report.payables.map(x => ["Cuentas por pagar", x.currency, x.total.toFixed(2)]), ["Movimientos inventario", "", String(report.movements)]];
    const csv = "\uFEFF" + lines.map(row => row.map(v => `"${v.replaceAll('"', '""')}"`).join(",")).join("\r\n");
    return new Response(csv, { headers: { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": "attachment; filename=reporte-operativo-tooling-prection.csv", "Cache-Control": "private, no-store" } });
  }
  return NextResponse.json(report, { headers: { "Cache-Control": "private, no-store" } });
}
