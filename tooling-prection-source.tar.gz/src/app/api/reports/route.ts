import { NextResponse } from "next/server";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { convertAmount } from "@/lib/currency";
import { parseCfdi } from "@/lib/cfdi";

export const dynamic = "force-dynamic";
const currencies = ["MXN", "USD", "EUR"] as const;
const monthKey = (date: Date) => `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, "0")}`;

function invoiceExchangeRate(invoice: { currency: string; exchangeRate: unknown; rawXml: string | null }) {
  if (invoice.currency === "MXN") return 1;
  const stored = Number(invoice.exchangeRate || 0);
  if (stored > 0) return stored;
  if (!invoice.rawXml) return null;
  try { return parseCfdi(invoice.rawXml).exchangeRate; } catch { return null; }
}

function convertForReport(amount: number, from: string, to: string, mxnPerUnit: number | null) {
  if (from === to) return amount;
  if (to === "MXN" && mxnPerUnit && mxnPerUnit > 0) return Number((amount * mxnPerUnit).toFixed(2));
  return null;
}

function totalByCurrency(rows: Array<{ currency: string; total: number }>) {
  const totals = new Map<string, { currency: string; count: number; total: number }>();
  for (const row of rows) { const value = totals.get(row.currency) ?? { currency: row.currency, count: 0, total: 0 }; value.count++; value.total += row.total; totals.set(row.currency, value); }
  return [...totals.values()].sort((a, b) => a.currency.localeCompare(b.currency));
}

export async function GET(request: Request) {
  if (!await currentSession()) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  const params = new URL(request.url).searchParams; const from = params.get("from"), to = params.get("to"), requestedCurrency = params.get("currency");
  const currency = requestedCurrency || "MXN";
  if (!currencies.includes(currency as typeof currencies[number])) return NextResponse.json({ error: "Moneda no válida." }, { status: 400 });
  if ((from && Number.isNaN(Date.parse(from))) || (to && Number.isNaN(Date.parse(to)))) return NextResponse.json({ error: "El periodo seleccionado no es válido." }, { status: 400 });
  const dateRange = from || to ? { gte: from ? new Date(`${from}T00:00:00.000Z`) : undefined, lte: to ? new Date(`${to}T23:59:59.999Z`) : undefined } : undefined;
  // MXN es la vista consolidada: se incluyen todas las monedas y cada CFDI extranjero usa su propio TipoCambio.
  // USD/EUR conservan su vista nativa para evitar convertir MXN con una tasa ajena a la fecha de esa factura.
  const currencyFilter = currency === "MXN" ? {} : { currency };
  const invoiceFilter = { status: { not: "CANCELLED" as const }, ...currencyFilter, ...(dateRange ? { issueDate: dateRange } : {}) };
  const [products, salesRows, purchaseRows, critical, openOrders, movements] = await Promise.all([
    db.product.findMany({ where: { status: "ACTIVE" }, select: { stock: true, minimumStock: true, baseCost: true, currency: true } }),
    db.salesInvoice.findMany({ where: invoiceFilter, include: { customer: { select: { legalName: true } }, lines: { include: { product: { select: { technicalCode: true, description: true, baseCost: true, currency: true } } } } }, orderBy: { issueDate: "asc" } }),
    db.purchaseInvoice.findMany({ where: invoiceFilter, include: { supplier: { select: { legalName: true } }, lines: true }, orderBy: { issueDate: "asc" } }),
    db.product.findMany({ where: { status: "ACTIVE", minimumStock: { gt: 0 } }, include: { mainSupplier: { select: { legalName: true } } }, orderBy: { stock: "asc" } }),
    db.purchaseOrder.findMany({ where: { status: "PENDING" }, include: { supplier: { select: { legalName: true } }, lines: { include: { product: { select: { technicalCode: true, description: true, unit: true } } } } }, orderBy: { issueDate: "asc" } }),
    db.inventoryMovement.count({ where: dateRange ? { createdAt: dateRange } : {} }),
  ]);
  const monthly = new Map<string, { sales: Record<string, number>; purchases: Record<string, number>; profit: Record<string, number>; margin: Record<string, number>; emptyInvoices: number }>();
  const clients = new Map<string, { count: number; total: number }>(); const vendors = new Map<string, { count: number; total: number }>(); const productsSold = new Map<string, { code: string; description: string; quantity: number; sales: number; profit: number }>();
  const salesTotals: Array<{ currency: string; total: number }> = []; const purchaseTotals: Array<{ currency: string; total: number }> = [];
  const nativeSales: Array<{ currency: string; count: number; total: number }> = [];
  const nativeSalesMap = new Map<string, { currency: string; count: number; total: number }>();
  const usdInvoices = salesRows.filter(invoice => invoice.currency === "USD").map(invoice => {
    const exchangeRate = invoiceExchangeRate(invoice); const amountMxn = exchangeRate ? Number((Number(invoice.total) * exchangeRate).toFixed(2)) : null;
    return { id: invoice.id, folio: invoice.folio, uuid: invoice.uuid, customer: invoice.customer.legalName, issueDate: invoice.issueDate, status: invoice.status, totalUsd: Number(invoice.total), exchangeRate, totalMxn: amountMxn };
  }).sort((a, b) => new Date(b.issueDate).getTime() - new Date(a.issueDate).getTime());
  let missingSalesConversion = 0; let missingPurchaseConversion = 0;
  for (const invoice of salesRows) {
    const rate = invoiceExchangeRate(invoice); const amount = convertForReport(Number(invoice.total), invoice.currency, currency, rate);
    if (amount === null) { missingSalesConversion++; continue; }
    salesTotals.push({ currency, total: amount });
    const native = nativeSalesMap.get(invoice.currency) ?? { currency: invoice.currency, count: 0, total: 0 }; native.count++; native.total += Number(invoice.total); nativeSalesMap.set(invoice.currency, native);
    const key = monthKey(invoice.issueDate); const m = monthly.get(key) ?? { sales: {}, purchases: {}, profit: {}, margin: {}, emptyInvoices: 0 };
    m.sales[currency] = (m.sales[currency] || 0) + amount; if (!invoice.lines.length) m.emptyInvoices++;
    const client = clients.get(invoice.customer.legalName) ?? { count: 0, total: 0 }; client.count++; client.total += amount; clients.set(invoice.customer.legalName, client);
    for (const line of invoice.lines) { const code = line.product?.technicalCode || "Sin código"; const description = line.product?.description || line.description; const row = productsSold.get(code) ?? { code, description, quantity: 0, sales: 0, profit: 0 }; const cost = line.product ? convertAmount(Number(line.product.baseCost), line.product.currency, invoice.currency, rate || 0) : null; const nativeProfit = cost === null ? 0 : Number(line.amount) - cost * Number(line.quantity); const profit = convertForReport(nativeProfit, invoice.currency, currency, rate) ?? 0; const lineSales = convertForReport(Number(line.amount), invoice.currency, currency, rate) ?? 0; row.quantity += Number(line.quantity); row.sales += lineSales; row.profit += profit; productsSold.set(code, row); m.profit[currency] = (m.profit[currency] || 0) + profit; }
    monthly.set(key, m);
  }
  const pendingSales: Array<{ currency: string; total: number }> = []; const pendingPurchases: Array<{ currency: string; total: number }> = [];
  for (const invoice of purchaseRows) { const rate = invoiceExchangeRate(invoice); const amount = convertForReport(Number(invoice.total), invoice.currency, currency, rate); if (amount === null) { missingPurchaseConversion++; continue; } purchaseTotals.push({ currency, total: amount }); if (invoice.status === "PENDING") pendingPurchases.push({ currency, total: amount }); const key = monthKey(invoice.issueDate); const m = monthly.get(key) ?? { sales: {}, purchases: {}, profit: {}, margin: {}, emptyInvoices: 0 }; m.purchases[currency] = (m.purchases[currency] || 0) + amount; const vendor = vendors.get(invoice.supplier.legalName) ?? { count: 0, total: 0 }; vendor.count++; vendor.total += amount; vendors.set(invoice.supplier.legalName, vendor); monthly.set(key, m); }
  for (const invoice of salesRows) if (invoice.status === "PENDING") { const rate = invoiceExchangeRate(invoice); const amount = convertForReport(Number(invoice.total), invoice.currency, currency, rate); if (amount !== null) pendingSales.push({ currency, total: amount }); }
  nativeSales.push(...nativeSalesMap.values());
  for (const m of monthly.values()) m.margin[currency] = m.sales[currency] ? (m.profit[currency] || 0) / m.sales[currency] * 100 : 0;
  const report = {
    from, to, currency, products: products.length,
    stockValue: products.filter(product => product.currency === currency).reduce((sum, product) => sum + Number(product.stock) * Number(product.baseCost), 0),
    lowStock: critical.filter(product => Number(product.stock) <= Number(product.minimumStock)).length,
    sales: totalByCurrency(salesTotals), purchases: totalByCurrency(purchaseTotals), nativeSales, usdInvoices,
    missingSalesConversion, missingPurchaseConversion,
    receivables: totalByCurrency(pendingSales), payables: totalByCurrency(pendingPurchases), movements,
    openOrders: openOrders.length,
    pendingReceive: [...openOrders.reduce((totals, order) => { const snapshot = order.snapshot && typeof order.snapshot === "object" && !Array.isArray(order.snapshot) ? order.snapshot as Record<string, unknown> : {}; const orderCurrency = typeof snapshot.currency === "string" ? snapshot.currency : "USD"; const exchangeRate = Number(snapshot.exchangeRate || 0); const nativeAmount = order.lines.reduce((sum, line) => sum + Math.max(0, Number(line.quantity) - Number(line.receivedQuantity)) * Number(line.unitPrice), 0); const amount = convertForReport(nativeAmount, orderCurrency, currency, orderCurrency === "MXN" ? 1 : exchangeRate || null); if (amount !== null) totals.set(currency, (totals.get(currency) || 0) + amount); return totals; }, new Map<string, number>())].map(([currency, total]) => ({ currency, total })),
    monthly: [...monthly.entries()].sort(([a], [b]) => a.localeCompare(b)).slice(-12).map(([month, value]) => ({ month, ...value })),
    recentMonths: [...monthly.entries()].sort(([a], [b]) => a.localeCompare(b)).slice(-6).map(([month, value]) => ({ month, ...value })),
    topClients: [...clients.entries()].map(([name, value]) => ({ name, ...value })).sort((a, b) => b.total - a.total).slice(0, 10),
    topSuppliers: [...vendors.entries()].map(([name, value]) => ({ name, ...value })).sort((a, b) => b.total - a.total).slice(0, 10),
    topProducts: [...productsSold.values()].sort((a, b) => b.sales - a.sales).slice(0, 10),
    criticalProducts: critical.filter(product => Number(product.stock) <= Number(product.minimumStock)).map(product => ({ code: product.technicalCode, description: product.description, supplier: product.mainSupplier?.legalName || "—", stock: Number(product.stock), onOrder: Number(product.onOrder), minimum: Number(product.minimumStock) })).slice(0, 30),
    pendingLines: openOrders.flatMap(order => order.lines.map(line => ({ folio: order.folio, supplier: order.supplier.legalName, code: line.product.technicalCode, description: line.description, pending: Math.max(0, Number(line.quantity) - Number(line.receivedQuantity)), unit: line.product.unit }))).filter(line => line.pending > 0).slice(0, 30),
  };
  if (params.get("format") === "usd-invoices-csv") { const lines = [["Folio", "UUID", "Cliente", "Fecha", "Estado", "Total USD", "Tipo de cambio MXN por USD", "Total convertido MXN"], ...usdInvoices.map(row => [row.folio, row.uuid || "", row.customer, new Date(row.issueDate).toISOString().slice(0, 10), row.status, row.totalUsd.toFixed(2), row.exchangeRate?.toFixed(6) || "", row.totalMxn?.toFixed(2) || "SIN TIPO DE CAMBIO"])]; const csv = "\uFEFF" + lines.map(row => row.map(value => `"${String(value).replaceAll('"', '""')}"`).join(",")).join("\r\n"); return new Response(csv, { headers: { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": "attachment; filename=relacion-facturas-usd-tooling-prection.csv", "Cache-Control": "private, no-store" } }); }
  if (params.get("format") === "csv") { const lines = [["Indicador", "Moneda", "Valor"], ["Productos activos", "", String(report.products)], ["Valor inventario a costo", currency, report.stockValue.toFixed(2)], ["Productos bajo mínimo", "", String(report.lowStock)], ...report.nativeSales.map(row => ["Ventas por moneda original", row.currency, row.total.toFixed(2)]), ...report.sales.map(row => ["Ventas convertidas al reporte", row.currency, row.total.toFixed(2)]), ...report.purchases.map(row => ["Compras convertidas al reporte", row.currency, row.total.toFixed(2)]), ...report.receivables.map(row => ["Cuentas por cobrar convertidas", row.currency, row.total.toFixed(2)]), ...report.payables.map(row => ["Cuentas por pagar convertidas", row.currency, row.total.toFixed(2)]), ["Movimientos de inventario", "", String(report.movements)], ["Facturas sin tipo de cambio", "", String(report.missingSalesConversion)]]; const csv = "\uFEFF" + lines.map(row => row.map(value => `"${String(value).replaceAll('"', '""')}"`).join(",")).join("\r\n"); const fileName = currency === "MXN" ? "reporte-operativo-tooling-prection-mxn.csv" : currency === "USD" ? "reporte-operativo-tooling-prection-usd.csv" : "reporte-operativo-tooling-prection-eur.csv"; return new Response(csv, { headers: { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": `attachment; filename=${fileName}`, "Cache-Control": "private, no-store" } }); }
  return NextResponse.json(report, { headers: { "Cache-Control": "private, no-store" } });
}
