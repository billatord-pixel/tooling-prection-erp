import { NextResponse } from "next/server";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";
const currencies = ["MXN", "USD", "EUR"] as const;
const monthKey = (date: Date) => `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, "0")}`;

export async function GET(request: Request) {
  if (!await currentSession()) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  const params = new URL(request.url).searchParams; const from = params.get("from"), to = params.get("to"), currency = params.get("currency");
  if ((from && Number.isNaN(Date.parse(from))) || (to && Number.isNaN(Date.parse(to)))) return NextResponse.json({ error: "El periodo seleccionado no es válido." }, { status: 400 });
  const dateRange = from || to ? { gte: from ? new Date(`${from}T00:00:00.000Z`) : undefined, lte: to ? new Date(`${to}T23:59:59.999Z`) : undefined } : undefined;
  const currencyFilter = currency && currencies.includes(currency as typeof currencies[number]) ? { currency } : {};
  const invoiceFilter = { status: { not: "CANCELLED" as const }, ...currencyFilter, ...(dateRange ? { issueDate: dateRange } : {}) };
  const [products, sales, purchases, receivables, payables, salesRows, purchaseRows, critical, openOrders, movements] = await Promise.all([
    db.product.findMany({ where: { status: "ACTIVE" }, select: { stock: true, minimumStock: true, baseCost: true } }),
    db.salesInvoice.groupBy({ by: ["currency"], where: invoiceFilter, _count: { id: true }, _sum: { total: true } }),
    db.purchaseInvoice.groupBy({ by: ["currency"], where: invoiceFilter, _count: { id: true }, _sum: { total: true } }),
    db.salesInvoice.groupBy({ by: ["currency"], where: { ...currencyFilter, status: "PENDING", ...(dateRange ? { issueDate: dateRange } : {}) }, _sum: { total: true } }),
    db.purchaseInvoice.groupBy({ by: ["currency"], where: { ...currencyFilter, status: "PENDING", ...(dateRange ? { issueDate: dateRange } : {}) }, _sum: { total: true } }),
    db.salesInvoice.findMany({ where: invoiceFilter, include: { customer: { select: { legalName: true } }, lines: { include: { product: { select: { technicalCode: true, description: true, baseCost: true } } } } }, orderBy: { issueDate: "asc" } }),
    db.purchaseInvoice.findMany({ where: invoiceFilter, include: { supplier: { select: { legalName: true } }, lines: true }, orderBy: { issueDate: "asc" } }),
    db.product.findMany({ where: { status: "ACTIVE", minimumStock: { gt: 0 } }, include: { mainSupplier: { select: { legalName: true } } }, orderBy: { stock: "asc" } }),
    db.purchaseOrder.findMany({ where: { status: "PENDING" }, include: { supplier: { select: { legalName: true } }, lines: { include: { product: { select: { technicalCode: true, description: true, unit: true } } } } }, orderBy: { issueDate: "asc" } }),
    db.inventoryMovement.count({ where: dateRange ? { createdAt: dateRange } : {} }),
  ]);
  const monthly = new Map<string, { sales: Record<string, number>; purchases: Record<string, number>; profit: Record<string, number>; margin: Record<string, number>; emptyInvoices: number }>();
  const clients = new Map<string, { count: number; total: number }>(); const vendors = new Map<string, { count: number; total: number }>(); const productsSold = new Map<string, { code: string; description: string; quantity: number; sales: number; profit: number }>();
  for (const invoice of salesRows) {
    const key = monthKey(invoice.issueDate); const m = monthly.get(key) ?? { sales: {}, purchases: {}, profit: {}, margin: {}, emptyInvoices: 0 };
    m.sales[invoice.currency] = (m.sales[invoice.currency] || 0) + Number(invoice.total); if (!invoice.lines.length) m.emptyInvoices++;
    const client = clients.get(invoice.customer.legalName) ?? { count: 0, total: 0 }; client.count++; client.total += Number(invoice.total); clients.set(invoice.customer.legalName, client);
    for (const line of invoice.lines) { const code = line.product?.technicalCode || "Sin código"; const description = line.product?.description || line.description; const row = productsSold.get(`${invoice.currency}|${code}`) ?? { code, description, quantity: 0, sales: 0, profit: 0 }; row.quantity += Number(line.quantity); row.sales += Number(line.amount); row.profit += Number(line.amount) - Number(line.product?.baseCost || 0) * Number(line.quantity); productsSold.set(`${invoice.currency}|${code}`, row); m.profit[invoice.currency] = (m.profit[invoice.currency] || 0) + Number(line.amount) - Number(line.product?.baseCost || 0) * Number(line.quantity); }
    monthly.set(key, m);
  }
  for (const invoice of purchaseRows) { const key = monthKey(invoice.issueDate); const m = monthly.get(key) ?? { sales: {}, purchases: {}, profit: {}, margin: {}, emptyInvoices: 0 }; m.purchases[invoice.currency] = (m.purchases[invoice.currency] || 0) + Number(invoice.total); const vendor = vendors.get(invoice.supplier.legalName) ?? { count: 0, total: 0 }; vendor.count++; vendor.total += Number(invoice.total); vendors.set(invoice.supplier.legalName, vendor); monthly.set(key, m); }
  for (const m of monthly.values()) for (const cur of currencies) m.margin[cur] = m.sales[cur] ? (m.profit[cur] || 0) / m.sales[cur] * 100 : 0;
  const currencyTotals = (rows: typeof sales) => rows.map(row => ({ currency: row.currency, count: row._count.id, total: Number(row._sum.total || 0) }));
  const report = {
    from, to, currency: currency || "MXN", products: products.length,
    stockValue: products.reduce((sum, product) => sum + Number(product.stock) * Number(product.baseCost), 0),
    lowStock: critical.filter(product => Number(product.stock) <= Number(product.minimumStock)).length,
    sales: currencyTotals(sales), purchases: currencyTotals(purchases),
    receivables: receivables.map(row => ({ currency: row.currency, total: Number(row._sum.total || 0) })), payables: payables.map(row => ({ currency: row.currency, total: Number(row._sum.total || 0) })), movements,
    openOrders: openOrders.length,
    pendingReceive: [...openOrders.reduce((totals, order) => { const orderCurrency = typeof order.snapshot === "object" && order.snapshot && "currency" in order.snapshot && typeof order.snapshot.currency === "string" ? order.snapshot.currency : "MXN"; const amount = order.lines.reduce((sum, line) => sum + Math.max(0, Number(line.quantity) - Number(line.receivedQuantity)) * Number(line.unitPrice), 0); totals.set(orderCurrency, (totals.get(orderCurrency) || 0) + amount); return totals; }, new Map<string, number>())].map(([currency, total]) => ({ currency, total })),
    monthly: [...monthly.entries()].sort(([a], [b]) => a.localeCompare(b)).slice(-12).map(([month, value]) => ({ month, ...value })),
    recentMonths: [...monthly.entries()].sort(([a], [b]) => a.localeCompare(b)).slice(-6).map(([month, value]) => ({ month, ...value })),
    topClients: [...clients.entries()].map(([name, value]) => ({ name, ...value })).sort((a, b) => b.total - a.total).slice(0, 10),
    topSuppliers: [...vendors.entries()].map(([name, value]) => ({ name, ...value })).sort((a, b) => b.total - a.total).slice(0, 10),
    topProducts: [...productsSold.values()].sort((a, b) => b.sales - a.sales).slice(0, 10),
    criticalProducts: critical.filter(product => Number(product.stock) <= Number(product.minimumStock)).map(product => ({ code: product.technicalCode, description: product.description, supplier: product.mainSupplier?.legalName || "—", stock: Number(product.stock), onOrder: Number(product.onOrder), minimum: Number(product.minimumStock) })).slice(0, 30),
    pendingLines: openOrders.flatMap(order => order.lines.map(line => ({ folio: order.folio, supplier: order.supplier.legalName, code: line.product.technicalCode, description: line.description, pending: Math.max(0, Number(line.quantity) - Number(line.receivedQuantity)), unit: line.product.unit }))).filter(line => line.pending > 0).slice(0, 30),
  };
  if (params.get("format") === "csv") { const lines = [["Indicador", "Moneda", "Valor"], ["Productos activos", "", String(report.products)], ["Valor inventario a costo", "MXN", report.stockValue.toFixed(2)], ["Productos bajo mínimo", "", String(report.lowStock)], ...report.sales.map(row => ["Ventas del periodo", row.currency, row.total.toFixed(2)]), ...report.purchases.map(row => ["Compras del periodo", row.currency, row.total.toFixed(2)]), ...report.receivables.map(row => ["Cuentas por cobrar", row.currency, row.total.toFixed(2)]), ...report.payables.map(row => ["Cuentas por pagar", row.currency, row.total.toFixed(2)]), ["Movimientos de inventario", "", String(report.movements)]]; const csv = "\uFEFF" + lines.map(row => row.map(value => `"${String(value).replaceAll('"', '""')}"`).join(",")).join("\r\n"); return new Response(csv, { headers: { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": "attachment; filename=reporte-operativo-tooling-prection.csv", "Cache-Control": "private, no-store" } }); }
  return NextResponse.json(report, { headers: { "Cache-Control": "private, no-store" } });
}
