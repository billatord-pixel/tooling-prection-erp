import { readFile } from "node:fs/promises";
import path from "node:path";
import { InvoiceStatus, Prisma } from "@prisma/client";
import { getBanxicoSalesRates } from "@/lib/banxico-fix";
import { parseCfdi } from "@/lib/cfdi";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { createFFacturasPdf } from "@/lib/f-facturas-pdf";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const session = await currentSession();
  if (!session) return new Response("No autorizado", { status: 401 });
  if (!["ADMIN", "SALES"].includes(session.role)) return new Response("Sin permiso", { status: 403 });
  const search = new URL(request.url).searchParams;
  const from = search.get("from"), to = search.get("to"), status = search.get("status") || "ALL";
  const validDate = (v: string | null) => !v || (/^\d{4}-\d{2}-\d{2}$/.test(v) && Number.isFinite(Date.parse(v)) && new Date(v).toISOString().slice(0,10) === v);
  if (!validDate(from) || !validDate(to) || (from && to && from > to)) return new Response("Periodo no válido", { status: 400 });
  const labels: Record<string,string> = { ALL: "Todas", PAID: "Pagadas", PENDING: "Pendientes de pago", CANCELLED: "Canceladas" };
  if (!Object.hasOwn(labels,status)) return new Response("Estado no válido", { status: 400 });
  const invoices = await db.salesInvoice.findMany({
    where: {
      ...(status !== "ALL" ? {status: status as InvoiceStatus} : {}),
      ...(from || to ? {issueDate: {gte: from ? new Date(`${from}T00:00:00.000Z`) : undefined, lte: to ? new Date(`${to}T23:59:59.999Z`) : undefined}} : {}),
    },
    select: {folio:true,total:true,currency:true,issueDate:true,exchangeRate:true,rawXml:true},
    orderBy: {folio:"asc"},
  });
  const day = (date:Date) => date.toISOString().slice(0,10);
  const dates = invoices.filter(row=>row.currency === "USD").map(row=>day(row.issueDate));
  const rates = dates.length ? await getBanxicoSalesRates(dates) : new Map();
  const converted = invoices.map(invoice=>{
    let rate: string | number | undefined = invoice.currency === "MXN" ? 1 : invoice.currency === "USD" ? rates.get(day(invoice.issueDate))?.rate : Number(invoice.exchangeRate || 0) || undefined;
    if (!rate && invoice.currency !== "USD" && invoice.rawXml) {
      try { rate = parseCfdi(invoice.rawXml).exchangeRate || undefined; } catch { /* Keep unavailable conversions explicit. */ }
    }
    return {...invoice, mxnTotal: rate ? new Prisma.Decimal(String(invoice.total)).mul(rate).toDecimalPlaces(2).toNumber() : null};
  });
  const company = await db.companySettings.findFirst({orderBy:{createdAt:"asc"}});
  let logo: Buffer | undefined;
  try { logo = await readFile(path.join(process.cwd(),"public",company?.logoUrl?.replace(/^\/+/,"") || "brand/tooling-prection-logo.jpg")); } catch { /* Optional branding asset. */ }
  const dateLabel = (v:string) => new Intl.DateTimeFormat("es-MX",{dateStyle:"medium",timeZone:"UTC"}).format(new Date(v));
  const period = from && to ? `${dateLabel(from)} al ${dateLabel(to)}` : from ? `Desde ${dateLabel(from)}` : to ? `Hasta ${dateLabel(to)}` : "Todos los periodos";
  const bytes = await createFFacturasPdf({invoices:converted,period,statusLabel:labels[status],companyName:company?.tradeName || "Tooling Prection",logo});
  return new Response(new Uint8Array(bytes), {headers:{"Content-Type":"application/pdf","Content-Disposition":`inline; filename="F-Facturas${from ? "-"+from : ""}${to ? "-al-"+to : ""}.pdf"`,"Cache-Control":"private, no-store"}});
}
