import { beforeEach,describe,it,expect,vi } from "vitest";
const {session,findMany,rates}=vi.hoisted(()=>({session:vi.fn(),findMany:vi.fn(),rates:vi.fn()}));
vi.mock("@/lib/banxico-fix",()=>({getBanxicoSalesRates:rates}));
vi.mock("@/lib/auth",()=>({currentSession:session}));
vi.mock("@/lib/db",()=>({db:{salesInvoice:{findMany},companySettings:{findFirst:vi.fn().mockResolvedValue(null)}}}));
import { GET } from "./route";
import { readCustomerOrderPdf } from "@/lib/customer-order-pdf-reader";
describe("F-Facturas access and filters",()=>{
 beforeEach(()=>{vi.clearAllMocks();session.mockResolvedValue({role:"ADMIN"});findMany.mockResolvedValue([]);});
 it("requires an authorized session",async()=>{session.mockResolvedValue(null);expect((await GET(new Request("http://localhost/api/reports/f-facturas"))).status).toBe(401);expect(findMany).not.toHaveBeenCalled();});
 it.each(["from=2026-02-30","from=2026-11-02&to=2026-11-01","status=INVALID"])("rejects invalid filters %s",async(query)=>{expect((await GET(new Request(`http://localhost/api/reports/f-facturas?${query}`))).status).toBe(400);expect(findMany).not.toHaveBeenCalled();});
 it("allows sellers to print, filters paid invoices and retains both currencies",async()=>{
  session.mockResolvedValue({role:"SALES"});
  const response=await GET(new Request("http://localhost/api/reports/f-facturas?status=PAID&from=2026-06-01&to=2026-10-31"));
  expect(response.status).toBe(200);
  expect(response.headers.get("Content-Type")).toBe("application/pdf");
  expect(findMany.mock.calls[0][0].where).toEqual({status:"PAID",issueDate:{gte:new Date("2026-06-01T00:00:00.000Z"),lte:new Date("2026-10-31T23:59:59.999Z")}});
 });
 it("uses fiscal-day Banxico FIX, keeps native MXN and never substitutes XML rates for missing USD FIX",async()=>{
  findMany.mockResolvedValue([
   {folio:"F-1001",total:"100.50",currency:"USD",issueDate:new Date("2026-10-09T12:00:00Z"),exchangeRate:99,rawXml:null},
   {folio:"F-1002",total:"100.50",currency:"USD",issueDate:new Date("2026-10-10T12:00:00Z"),exchangeRate:99,rawXml:null},
   {folio:"F-1003",total:"1250",currency:"MXN",issueDate:new Date("2026-10-10T12:00:00Z"),exchangeRate:99,rawXml:null},
   {folio:"F-1004",total:"150",currency:"USD",issueDate:new Date("2026-10-11T12:00:00Z"),exchangeRate:99,rawXml:null},
  ]);
  rates.mockResolvedValue(new Map([["2026-10-09",{date:"2026-10-09",rate:"18.0000"}],["2026-10-10",{date:"2026-10-09",rate:"18.0000"}]]));
  const response=await GET(new Request("http://localhost/api/reports/f-facturas"));
  const text=await readCustomerOrderPdf(Buffer.from(await response.arrayBuffer()));
  expect(rates).toHaveBeenCalledWith(["2026-10-09","2026-10-10","2026-10-11"]);
  expect(text).toMatch(/F-1001\s+USD 100.50\s+MXN 1,809.00/);
  expect(text).toMatch(/F-1002\s+USD 100.50\s+MXN 1,809.00/);
  expect(text).toMatch(/F-1003\s+-\s+MXN 1,250.00/);
  expect(text).toMatch(/F-1004\s+USD 150.00\s+Sin conversión/);
 });
});
