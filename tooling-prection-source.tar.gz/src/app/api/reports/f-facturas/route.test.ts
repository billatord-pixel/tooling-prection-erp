import { beforeEach,describe,it,expect,vi } from "vitest";
const {session,findMany}=vi.hoisted(()=>({session:vi.fn(),findMany:vi.fn()}));
vi.mock("@/lib/auth",()=>({currentSession:session}));
vi.mock("@/lib/db",()=>({db:{salesInvoice:{findMany},companySettings:{findFirst:vi.fn().mockResolvedValue(null)}}}));
import { GET } from "./route";
describe("F-Facturas access and filters",()=>{
 beforeEach(()=>{vi.clearAllMocks();session.mockResolvedValue({role:"ADMIN"});findMany.mockResolvedValue([]);});
 it("requires an authorized session",async()=>{session.mockResolvedValue(null);expect((await GET(new Request("http://localhost/api/reports/f-facturas"))).status).toBe(401);expect(findMany).not.toHaveBeenCalled();});
 it.each(["from=2026-02-30","from=2026-11-02&to=2026-11-01","status=INVALID"])("rejects invalid filters %s",async(query)=>{expect((await GET(new Request(`http://localhost/api/reports/f-facturas?${query}`))).status).toBe(400);expect(findMany).not.toHaveBeenCalled();});
 it("allows sellers to print, filters paid invoices and retains both currencies",async()=>{
  session.mockResolvedValue({role:"SALES"});
  const response=await GET(new Request("http://localhost/api/reports/f-facturas?status=PAID&from=2026-06-01&to=2026-10-31"));
  expect(response.status).toBe(200);
  expect(response.headers.get("Content-Type")).toBe("application/pdf");
  expect(findMany.mock.calls[0][0].where).toEqual({status:"PAID",issueDate:{gte:new Date("2026-06-01T00:00:00.000Z"),lte:new Date("2026-10-31T23:59:59.999Z")}});
 });
});
