import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({ getFix: vi.fn(), getPhysical: vi.fn() }));
vi.mock("@/lib/auth", () => ({ currentSession: async () => ({ role: "ADMIN" }) }));
vi.mock("@/lib/banxico-fix", () => ({ getBanxicoInventoryRate: mocks.getFix }));
vi.mock("@/lib/physical-inventory-valuation", () => ({ loadPhysicalInventoryValuation: mocks.getPhysical }));
vi.mock("@/lib/db", () => ({ db: {
  product: { count: async () => 1, findMany: async () => [] },
  salesInvoice: { findMany: async () => [{
    id: "invoice", folio: "F-1", currency: "USD", total: 100, status: "PENDING", exchangeRate: 17,
    customer: { legalName: "Cliente" }, issueDate: new Date("2026-10-15"), lines: [],
  }] },
  purchaseInvoice: { findMany: async () => [] },
  purchaseOrder: { findMany: async () => [] },
  inventoryMovement: { count: async () => 0 },
} }));

import { GET } from "./route";

const url = (query: string) => new Request(`http://localhost/api/reports?${query}`);
const quote = { date: "2026-11-05", rate: "18.7147", sourceUrl: "https://www.banxico.org.mx/tipcamb/tipCamIHAction.do" };

beforeEach(() => {
  vi.clearAllMocks();
  mocks.getPhysical.mockResolvedValue({ summary: { currency: "USD", title: "Inventario físico", lines: 2837, total: 379935.98, calculatedTotal: 379935.98, roundingAdjustment: 0 } });
  mocks.getFix.mockResolvedValue({ requestedDate: "2026-11-05", quote });
});

describe("conversión del corte de inventario", () => {
  it("convierte el inventario en MXN sin aplicar el FIX diario a las facturas", async () => {
    const report = await (await GET(url("currency=MXN&from=2026-10-01&to=2026-10-31"))).json();
    expect(report).toMatchObject({
      stockValue: 7110387.88,
      stockCurrency: "MXN",
      stockExchangeRate: { requestedDate: "2026-11-05", quote },
      physicalInventory: { currency: "USD", total: 379935.98 },
      sales: [{ currency: "MXN", total: 1700 }],
    });
  });

  it.each(["currency=USD", "currency=EUR", "currency=MXN&format=usd-invoices-csv"])("evita consultar Banxico para %s", async query => {
    const response = await GET(url(query));
    expect(response.ok).toBe(true);
    if (!query.includes("format")) expect(await response.json()).toMatchObject({ stockValue: 379935.98, stockCurrency: "USD", stockExchangeRate: null });
    expect(mocks.getFix).not.toHaveBeenCalled();
  });

  it("etiqueta el importe original en USD si la conversión no está disponible", async () => {
    mocks.getFix.mockResolvedValue({ requestedDate: "2026-11-05", quote: null });
    expect(await (await GET(url("currency=MXN"))).json()).toMatchObject({
      stockValue: 379935.98, stockCurrency: "USD", stockExchangeRate: { quote: null },
    });
  });

  it("exporta el importe convertido, la tasa y su fecha en el CSV", async () => {
    const csv = await (await GET(url("currency=MXN&format=csv"))).text();
    expect(csv).toContain('"Valor del inventario al corte","MXN","7110387.88"');
    expect(csv).toContain('"Existencias por precio unitario","USD","379935.98"');
    expect(csv).toContain('"Tipo de cambio FIX Banxico","MXN por USD","18.7147"');
    expect(csv).toContain('"Fecha del FIX","","2026-11-05"');
  });
});
