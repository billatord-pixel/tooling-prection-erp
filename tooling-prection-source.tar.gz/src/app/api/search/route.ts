import { NextResponse } from "next/server";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";

export async function GET(request: Request) {
  if (!await currentSession()) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  const query = new URL(request.url).searchParams.get("q")?.trim() ?? "";
  if (query.length < 2) return NextResponse.json({ results: [] });
  if (query.length > 100) return NextResponse.json({ error: "La búsqueda es demasiado larga." }, { status: 400 });
  const text = { contains: query, mode: "insensitive" as const };

  const [products, parties, quotes, salesInvoices, purchaseInvoices, orders, deliveries] = await Promise.all([
    db.product.findMany({ where: { status: "ACTIVE", OR: [{ technicalCode: text }, { description: text }] }, orderBy: { updatedAt: "desc" }, take: 5, select: { id: true, technicalCode: true, description: true, updatedAt: true } }),
    db.party.findMany({ where: { status: "ACTIVE", OR: [{ legalName: text }, { tradeName: text }, { taxId: text }, { contactName: text }] }, orderBy: { updatedAt: "desc" }, take: 5, select: { id: true, kind: true, legalName: true, tradeName: true, taxId: true, updatedAt: true } }),
    db.quote.findMany({ where: { OR: [{ folio: text }, { customer: { legalName: text } }, { customer: { tradeName: text } }] }, orderBy: { createdAt: "desc" }, take: 5, select: { id: true, folio: true, issueDate: true, createdAt: true, customer: { select: { legalName: true, tradeName: true } } } }),
    db.salesInvoice.findMany({ where: { OR: [{ folio: text }, { uuid: text }, { customer: { legalName: text } }] }, orderBy: { issueDate: "desc" }, take: 5, select: { id: true, folio: true, uuid: true, issueDate: true, customer: { select: { legalName: true } } } }),
    db.purchaseInvoice.findMany({ where: { OR: [{ folio: text }, { uuid: text }, { supplier: { legalName: text } }] }, orderBy: { issueDate: "desc" }, take: 5, select: { id: true, folio: true, uuid: true, issueDate: true, supplier: { select: { legalName: true } } } }),
    db.purchaseOrder.findMany({ where: { OR: [{ folio: text }, { supplier: { legalName: text } }] }, orderBy: { issueDate: "desc" }, take: 5, select: { id: true, folio: true, issueDate: true, supplier: { select: { legalName: true } } } }),
    db.delivery.findMany({ where: { OR: [{ folio: text }, { customer: { legalName: text } }] }, orderBy: { issueDate: "desc" }, take: 5, select: { id: true, folio: true, issueDate: true, customer: { select: { legalName: true } } } }),
  ]);

  const results = [
    ...products.map(item => ({ id: item.id, type: "Producto", title: item.technicalCode, subtitle: item.description, href: "/productos", date: item.updatedAt })),
    ...parties.map(item => ({ id: item.id, type: item.kind === "CUSTOMER" ? "Cliente" : "Proveedor", title: item.tradeName || item.legalName, subtitle: [item.taxId, item.legalName].filter(Boolean).join(" · "), href: item.kind === "CUSTOMER" ? "/clientes" : "/proveedores", date: item.updatedAt })),
    ...quotes.map(item => ({ id: item.id, type: "Cotización", title: item.folio, subtitle: item.customer?.tradeName || item.customer?.legalName || "Sin cliente", href: `/cotizaciones/${item.id}`, date: item.createdAt })),
    ...salesInvoices.map(item => ({ id: item.id, type: "Factura de venta", title: item.folio, subtitle: [item.customer.legalName, item.uuid].filter(Boolean).join(" · "), href: `/facturas-venta/${item.id}`, date: item.issueDate })),
    ...purchaseInvoices.map(item => ({ id: item.id, type: "Factura de compra", title: item.folio, subtitle: [item.supplier.legalName, item.uuid].filter(Boolean).join(" · "), href: "/facturas-compra", date: item.issueDate })),
    ...orders.map(item => ({ id: item.id, type: "Pedido de compra", title: item.folio, subtitle: item.supplier.legalName, href: "/pedidos-compra", date: item.issueDate })),
    ...deliveries.map(item => ({ id: item.id, type: "Remisión", title: item.folio, subtitle: item.customer?.legalName || "Sin cliente", href: "/remisiones", date: item.issueDate })),
  ].sort((a, b) => b.date.getTime() - a.date.getTime()).slice(0, 30);

  return NextResponse.json({ results: results.map(({ date, ...item }) => ({ ...item, date: date.toISOString() })) });
}
