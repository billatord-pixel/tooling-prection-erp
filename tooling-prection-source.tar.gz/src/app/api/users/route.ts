import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { Role } from "@prisma/client";
import { z } from "zod";
import { audit } from "@/lib/audit";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";

const schema = z.object({ name: z.string().trim().min(2).max(120), email: z.string().trim().email().max(250), password: z.string().min(12).max(128), role: z.nativeEnum(Role) });
const adminOnly = async () => { const session = await currentSession(); return session?.role === "ADMIN" ? session : null; };

export async function GET() {
  const session = await adminOnly(); if (!session) return NextResponse.json({ error: "Sólo un administrador puede ver usuarios." }, { status: 403 });
  return NextResponse.json(await db.user.findMany({ select: { id: true, name: true, email: true, role: true, isActive: true, lastLoginAt: true, createdAt: true }, orderBy: { name: "asc" } }));
}

export async function POST(request: Request) {
  const session = await adminOnly(); if (!session) return NextResponse.json({ error: "Sólo un administrador puede crear usuarios." }, { status: 403 });
  try {
    const input = schema.parse(await request.json()); const email = input.email.toLowerCase();
    const user = await db.user.create({ data: { name: input.name, email, passwordHash: await bcrypt.hash(input.password, 12), role: input.role }, select: { id: true, name: true, email: true, role: true, isActive: true, createdAt: true } });
    await audit({ userId: session.id, action: "CREATE", entity: "User", entityId: user.id, after: user as never });
    return NextResponse.json(user, { status: 201 });
  } catch (error) {
    const duplicate = error instanceof Error && error.message.includes("Unique constraint");
    return NextResponse.json({ error: duplicate ? "Ya existe un usuario con ese correo." : "No fue posible crear el usuario." }, { status: 400 });
  }
}
