import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { Role } from "@prisma/client";
import { z } from "zod";
import { audit } from "@/lib/audit";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";

const schema = z.object({ name: z.string().trim().min(2).max(120), email: z.string().trim().email().max(250), password: z.string().min(12).max(128), role: z.nativeEnum(Role) });
const adminOnly = async () => { const session = await currentSession(); return session?.role === "ADMIN" ? session : null; };

export async function GET(request: Request) {
  const session = await adminOnly(); if (!session) return NextResponse.json({ error: "Sólo un administrador puede ver usuarios." }, { status: 403 });
  const status = new URL(request.url).searchParams.get("status");
  return NextResponse.json(await db.user.findMany({ where: status === "active" ? { isActive: true } : status === "inactive" ? { isActive: false } : {}, select: { id: true, name: true, email: true, role: true, isActive: true, lastLoginAt: true, createdAt: true }, orderBy: { name: "asc" } }));
}

const updateSchema = z.object({ id: z.string().min(1), name: z.string().trim().min(2).max(120).optional(), email: z.string().trim().email().max(250).optional(), role: z.nativeEnum(Role).optional(), password: z.string().min(12).max(128).optional(), isActive: z.boolean().optional() }).refine(value => Object.keys(value).some(key => key !== "id"), "Sin cambios");

export async function PATCH(request: Request) {
  const session = await adminOnly(); if (!session) return NextResponse.json({ error: "Sólo un administrador puede actualizar usuarios." }, { status: 403 });
  try {
    const input = updateSchema.parse(await request.json()); const before = await db.user.findUnique({ where: { id: input.id } });
    if (!before) return NextResponse.json({ error: "No se encontró el usuario." }, { status: 404 });
    if (input.isActive === false && input.id === session.id) return NextResponse.json({ error: "No puedes desactivar tu propia cuenta." }, { status: 409 });
    if (input.isActive === false && before.role === "ADMIN" && await db.user.count({ where: { role: "ADMIN", isActive: true } }) <= 1) return NextResponse.json({ error: "Debe permanecer al menos un administrador activo." }, { status: 409 });
    const user = await db.user.update({ where: { id: input.id }, data: { ...(input.name ? { name: input.name } : {}), ...(input.email ? { email: input.email.toLowerCase() } : {}), ...(input.role ? { role: input.role } : {}), ...(input.password ? { passwordHash: await bcrypt.hash(input.password, 12) } : {}), ...(input.isActive !== undefined ? { isActive: input.isActive } : {}) }, select: { id: true, name: true, email: true, role: true, isActive: true, lastLoginAt: true, createdAt: true } });
    await audit({ userId: session.id, action: input.isActive === undefined ? "UPDATE" : input.isActive ? "ACTIVATE" : "DEACTIVATE", entity: "User", entityId: user.id, before: before as never, after: user as never });
    return NextResponse.json(user);
  } catch (error) { return NextResponse.json({ error: error instanceof Error && error.message.includes("Unique constraint") ? "Ya existe un usuario con ese correo." : "Los datos del usuario no son válidos." }, { status: 400 }); }
}

export async function POST(request: Request) {
  const session = await adminOnly(); if (!session) return NextResponse.json({ error: "Sólo un administrador puede crear usuarios." }, { status: 403 });
  try {
    const input = schema.parse(await request.json()); const email = input.email.toLowerCase();
    const user = await db.user.create({ data: { name: input.name, email, passwordHash: await bcrypt.hash(input.password, 12), role: input.role }, select: { id: true, name: true, email: true, role: true, isActive: true, createdAt: true } });
    await audit({ userId: session.id, action: "CREATE", entity: "User", entityId: user.id, after: user as never });
    return NextResponse.json(user, { status: 201 });
  } catch (error) {
    const duplicate = error instanceof Error && error.message.includes("Unique constraint");
    return NextResponse.json({ error: duplicate ? "Ya existe un usuario con ese correo." : "No fue posible crear el usuario." }, { status: 400 });
  }
}
