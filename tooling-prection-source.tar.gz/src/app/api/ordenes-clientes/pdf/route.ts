import { readFile } from "node:fs/promises";
import { join } from "node:path";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { listCustomerOrders, parseCustomerOrderFilters } from "@/lib/customer-order-query";
import { customerOrderInclude } from "@/lib/customer-order-service";
import { matchesCustomerDeadline, itemProgress, dateOnly } from "@/lib/customer-orders";
import { buildCustomerOrdersPendingPdf, type CustomerPendingReportRow } from "@/lib/customer-orders-pdf";
export const runtime="nodejs";
export async function GET(request:Request) {
  if(!await currentSession()) return new Response("No autorizado",{status:401});
  const params=new URL(request.url).searchParams, id=params.get("id");
  const filters=parseCustomerOrderFilters(Object.fromEntries(params));
  const individual=id ? await db.customerOrder.findUnique({where:{id},include:customerOrderInclude}):null;
  if(id && !individual) return new Response("Orden no encontrada",{status:404});
  const orders=individual ? [individual]:await listCustomerOrders(filters);
  const rows:CustomerPendingReportRow[]=[];
  for(const order of orders) for(const item of order.items) {
    if(order.status==="CANCELLED") continue;
    const progress=itemProgress(item);
    if(progress.pending<=0 || (!id && !matchesCustomerDeadline(item,order.dueDate,filters))) continue;
    rows.push({orderId:order.id,lineNumber:item.lineNumber,customer:order.customer.legalName,folio:order.folio,description:item.description,quantity:progress.pending,unit:item.unit,dueDate:item.dueDate?dateOnly(item.dueDate):order.dueDate?dateOnly(order.dueDate):null,suppliers:item.allocations.filter(a=>!["CANCELLED","ARCHIVED"].includes(a.purchaseOrderLine.purchaseOrder.status)).map(a=>a.purchaseOrderLine.purchaseOrder.folio+" ("+a.quantity+" "+item.unit+")").join("; "),notes:[order.deadlineText,item.notesText].filter(Boolean).join(" | ")});
  }
  const company=await db.companySettings.findFirst();
  const bytes=await buildCustomerOrdersPendingPdf({company:company || {legalName:"Tooling Prection",tradeName:"Tooling Prection"},rows,filterLabel:id?"Todas las partidas pendientes de esta orden":filters.state || "Pendientes",logoBytes:await readFile(join(process.cwd(),"public/brand/tooling-prection-logo.jpg"))});
  return new Response(new Uint8Array(bytes),{headers:{"Content-Type":"application/pdf","Content-Disposition":'inline; filename="tooling-ordenes-clientes.pdf"',"Cache-Control":"private, no-store"}});
}
