import { NextResponse } from "next/server";
import { createHash } from "node:crypto";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { canCustomerOrder } from "@/lib/customer-order-access";
import { listCustomerOrders, parseCustomerOrderFilters } from "@/lib/customer-order-query";
import { saveCustomerOrder, customerOrderInclude, recordCustomerDelivery, allocateCustomerMaterial, linkCustomerInvoice, unlinkCustomerInvoice, removeCustomerTracking, changeCustomerOrderState, lockCustomerTracking } from "@/lib/customer-order-service";
import { orderProgress } from "@/lib/customer-orders";

export async function GET(request: Request) {
  const session = await currentSession();
  if (!session) return NextResponse.json({error:"No autorizado"}, {status:401});
  const params = new URL(request.url).searchParams;
  const id = params.get("id");
  if (id) {
    const order = await db.customerOrder.findUnique({where:{id}, include:{...customerOrderInclude, attachments:{select:{id:true,fileName:true,createdAt:true}},}});
    if (!order) return NextResponse.json({error:"Orden no encontrada"}, {status:404});
    // No supplier costs or financial data returned by this context endpoint.
    const safe = sanitizeOrder(order);
    const history = await db.auditEvent.findMany({where:{entity:"CustomerOrder",entityId:id},orderBy:{createdAt:"desc"},take:50,select:{action:true,after:true,createdAt:true,user:{select:{name:true}}}});
    return NextResponse.json({...safe, progress:orderProgress(order),history});
  }
  const rows = await listCustomerOrders(parseCustomerOrderFilters(Object.fromEntries(params)));
  const page = Math.max(1,Math.floor(Number(params.get("page")) || 1));
  const start = (page-1)*25;
  return NextResponse.json({rows:rows.slice(start,start+25).map(sanitizeOrder), total:rows.length, page, canWrite:canCustomerOrder(session.role,"create")});
}
type Order = Awaited<ReturnType<typeof listCustomerOrders>>[number] | (NonNullable<Awaited<ReturnType<typeof db.customerOrder.findUnique>>> & {items: import("@/lib/customer-orders").TrackingItem[]});
function sanitizeOrder(order: Order) {
  // Explicit projection prevents exposure of suppliers' prices, totals and bank data.
  const raw = order as Awaited<ReturnType<typeof listCustomerOrders>>[number];
  return {...raw, companySnapshot:undefined, items:raw.items.map(item=>({...item, allocations:item.allocations.map(a=>({id:a.id,quantity:a.quantity,purchaseOrderLineId:a.purchaseOrderLineId,purchaseOrderLine:{id:a.purchaseOrderLine.id,description:a.purchaseOrderLine.description,purchaseOrder:{id:a.purchaseOrderLine.purchaseOrder.id,folio:a.purchaseOrderLine.purchaseOrder.folio,status:a.purchaseOrderLine.purchaseOrder.status,supplier:{legalName:a.purchaseOrderLine.purchaseOrder.supplier.legalName}}}}))}))};
}
export async function POST(request: Request) {
  const session = await currentSession();
  if (!session) return NextResponse.json({error:"No autorizado"},{status:401});
  if (!canCustomerOrder(session.role,"create")) return NextResponse.json({error:"Solo lectura: sin permiso para esta operación."},{status:403});
  try {
    const form = await request.formData();
    const operation = String(form.get("operation") || "save");
    const permission = ["delivery","invoice","void-delivery","unlink-invoice"].includes(operation) ? "deliver" : ["allocation","unlink-allocation"].includes(operation) ? "link" : form.get("id") ? "update" : "create";
    if (!canCustomerOrder(session.role, permission)) return NextResponse.json({error:"Solo lectura: sin permiso para esta operación."},{status:403});
    const id = String(form.get("id") || "");
    const result = await db.$transaction(async tx=>{
      await lockCustomerTracking(tx);
      if (operation === "save") {
        const pdf = form.get("pdf");
        let bytes: Buffer | undefined, checksum: string | undefined;
        if (pdf instanceof File && pdf.size) {
          if (pdf.size > 20*1024*1024 || pdf.type !== "application/pdf") throw new Error("Adjunta un PDF de máximo 20 MB.");
          bytes = Buffer.from(await pdf.arrayBuffer());
          if (!bytes.subarray(0,5).equals(Buffer.from("%PDF-"))) throw new Error("El archivo no es un PDF válido.");
          checksum = createHash("sha256").update(bytes).digest("hex");
          const duplicate = await tx.customerOrderAttachment.findUnique({where:{checksum}});
          if (duplicate && duplicate.orderId !== id) throw new Error("Este PDF ya está registrado, incluso si su orden está archivada.");
          if (form.get("reviewed") !== "true") throw new Error("Confirma que revisaste los datos contra el original.");
          if (id && await tx.customerOrderAttachment.count({where:{orderId:id}}) && form.get("replaceConfirmed") !== "true") throw new Error("Confirma el reemplazo del PDF. El original anterior permanecerá en el historial.");
        }
        const saved = await saveCustomerOrder(tx, JSON.parse(String(form.get("data") || "{}")),session.id,id || undefined,String(form.get("expectedAt") || "") || undefined);
        if (bytes && checksum && pdf instanceof File) {
          await tx.customerOrderAttachment.upsert({where:{checksum},create:{orderId:saved.id,fileName:pdf.name.slice(0,255),checksum,data:Uint8Array.from(bytes)},update:{}});
          await tx.customerOrder.update({where:{id:saved.id},data:{sourceChecksum:checksum}});
        }
        return {id:saved.id};
      }
      const input = JSON.parse(String(form.get("data") || "{}"));
      if (!input.deliveryLineId) delete input.deliveryLineId;
      if (!input.invoiceLinkId) delete input.invoiceLinkId;
      if (!id) throw new Error("Falta la orden.");
      const owned = await tx.customerOrder.findUnique({where:{id},include:{items:{select:{id:true}}}});
      if (!owned) throw new Error("Orden no encontrada.");
      if (input.orderItemId && !owned.items.some(x=>x.id===input.orderItemId)) throw new Error("La partida no pertenece a esta orden.");
      if (operation === "delivery") await recordCustomerDelivery(tx,input,session.id);
      else if (operation === "allocation") await allocateCustomerMaterial(tx,input.orderItemId,input.purchaseOrderLineId,input.quantity,session.id);
      else if (operation === "invoice") await linkCustomerInvoice(tx,id,input.folio,input.markDelivered === true,session.id);
      else if (operation === "unlink-invoice") await unlinkCustomerInvoice(tx,id,input.linkId,input.reason,session.id);
      else if (["unlink-allocation","void-delivery"].includes(operation)) {
        const row = operation === "unlink-allocation" ? await tx.customerOrderAllocation.findUnique({where:{id:input.linkId},include:{orderItem:true}}) : await tx.customerOrderDelivery.findUnique({where:{id:input.linkId},include:{orderItem:true}});
        if (!row || row.orderItem.orderId !== id) throw new Error("La referencia no pertenece a esta orden.");
        await removeCustomerTracking(tx,input.linkId,operation === "unlink-allocation" ? "allocation" : "delivery",input.reason,session.id);
      } else if (["cancel","reactivate","archive","restore"].includes(operation)) await changeCustomerOrderState(tx,id,operation as "cancel"|"reactivate"|"archive"|"restore",session.id);
      else throw new Error("Operación desconocida.");
      return {id};
    },{timeout:30000});
    return NextResponse.json(result);
  } catch(error) { return NextResponse.json({error:error instanceof Error ? error.message:"No se pudo guardar."},{status:400}); }
}
