import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
export async function GET(request:Request) {
  if (!await currentSession()) return new Response("No autorizado",{status:401});
  const id=new URL(request.url).searchParams.get("id") || "";
  const file=await db.customerOrderAttachment.findUnique({where:{id}});
  if (!file) return new Response("No encontrado",{status:404});
  return new Response(new Uint8Array(file.data),{headers:{"Content-Type":"application/pdf","Content-Disposition":'inline; filename="orden-cliente.pdf"',"Cache-Control":"private, no-store","X-Content-Type-Options":"nosniff"}});
}
