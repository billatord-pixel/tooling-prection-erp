import { NextResponse } from "next/server";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
export async function GET(request:Request) {
  if (!await currentSession()) return NextResponse.json({error:"No autorizado"},{status:401});
  const customerId=new URL(request.url).searchParams.get("customerId") || "";
  const [customers, products, purchases, deliveries]=await Promise.all([
    db.party.findMany({where:{kind:"CUSTOMER",status:"ACTIVE"},select:{id:true,legalName:true,contactName:true,address:true},orderBy:{legalName:"asc"}}),
    db.product.findMany({where:{status:"ACTIVE"},select:{id:true,technicalCode:true,description:true,unit:true},orderBy:{technicalCode:"asc"}}),
    db.purchaseOrderLine.findMany({where:{purchaseOrder:{status:{notIn:["CANCELLED","ARCHIVED"]}}},select:{id:true,description:true,quantity:true,product:{select:{unit:true}},purchaseOrder:{select:{folio:true,status:true,supplier:{select:{legalName:true}}}}}}),
    customerId ? db.deliveryLine.findMany({where:{delivery:{customerId,status:"DELIVERED"}},select:{id:true,description:true,quantity:true,product:{select:{unit:true}},delivery:{select:{folio:true}}}}) : [],
  ]);
  return NextResponse.json({customers,products,purchases,deliveries});
}
