import { NextResponse } from "next/server";
import { currentSession } from "@/lib/auth";
import { canCustomerOrder } from "@/lib/customer-order-access";
import { readCustomerOrderPdf } from "@/lib/customer-order-pdf-reader";
import { parseCustomerOrderText } from "@/lib/customer-order-import";
export const runtime = "nodejs";
export async function POST(request:Request) {
  const session=await currentSession();
  if (!session) return NextResponse.json({error:"No autorizado"},{status:401});
  if (!canCustomerOrder(session.role,"create")) return NextResponse.json({error:"Sin permiso"},{status:403});
  const file=(await request.formData()).get("pdf");
  if (!(file instanceof File) || file.size > 20*1024*1024 || !file.size) return NextResponse.json({error:"Adjunta un PDF de máximo 20 MB."},{status:400});
  try {
    const bytes=new Uint8Array(await file.arrayBuffer());
    if (Buffer.from(bytes.subarray(0,5)).toString() !== "%PDF-") throw Error("PDF inválido");
    return NextResponse.json(parseCustomerOrderText(await readCustomerOrderPdf(bytes)));
  } catch {
    return NextResponse.json({items:[],warnings:["No fue posible leer este PDF. Continúa manualmente y conserva el original; no se requiere OCR."]});
  }
}
