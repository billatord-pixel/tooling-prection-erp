import { NextResponse } from "next/server";
import { DocumentType, InventoryMovementType } from "@prisma/client";
import { z } from "zod";
import { audit } from "@/lib/audit";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { applyMovement } from "@/lib/inventory";
import { can } from "@/lib/permissions";

const schema = z.object({ productId: z.string(), quantity: z.coerce.number().refine(value => value !== 0, "El ajuste no puede ser cero."), notes: z.string().trim().min(3) });
export async function GET() {
  const session = await currentSession(); if (!session) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  const [products, latest] = await Promise.all([
    db.product.findMany({ where: { status: "ACTIVE" }, orderBy: { description: "asc" }, include: { inventoryMovements: { orderBy: { createdAt: "desc" }, take: 1 } } }),
    db.inventoryMovement.findMany({ orderBy: { createdAt: "desc" }, take: 30, include: { product: { select: { technicalCode: true } } } }),
  ]);
  const movements = latest.map(({ product, ...movement }) => ({ ...movement, productCode: product.technicalCode }));
  return NextResponse.json({ products, movements });
}
export async function POST(request: Request) { const session = await currentSession(); if (!session || !can(session.role, "process")) return NextResponse.json({ error: "Sin permiso" }, { status: 403 }); try { const input = schema.parse(await request.json()); const sourceId = `ADJ-${crypto.randomUUID()}`; const movement = await applyMovement({ productId: input.productId, type: InventoryMovementType.ADJUSTMENT, quantity: input.quantity, sourceType: DocumentType.REPORT, sourceId, notes: input.notes }); await audit({ userId: session.id, action: "ADJUST", entity: "Inventory", entityId: movement.id, after: movement as unknown as never }); return NextResponse.json(movement, { status: 201 }); } catch (error) { return NextResponse.json({ error: error instanceof Error ? error.message : "No se pudo registrar el ajuste." }, { status: 400 }); } }
