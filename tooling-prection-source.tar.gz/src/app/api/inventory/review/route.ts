import { NextResponse } from "next/server";
import { Prisma } from "@prisma/client";
import { z } from "zod";
import { currentSession } from "@/lib/auth";
import { db } from "@/lib/db";
import { productCodeCandidates } from "@/lib/product-code";

const inputSchema = z.object({
  id: z.string().min(1),
  code: z.string().trim().min(1, "Escribe el código de la herramienta.").max(100),
  description: z.string().trim().min(1, "Escribe la descripción.").max(2000),
  currentCode: z.string().trim().max(100).optional(),
});

export async function GET() {
  if ((await currentSession())?.role !== "ADMIN") {
    return NextResponse.json({ error: "Sin permiso" }, { status: 403 });
  }
  const items = await db.inventoryReviewItem.findMany({
    orderBy: [{ sourceBatch: "desc" }, { sourceLine: "asc" }],
  });
  return NextResponse.json(items, { headers: { "Cache-Control": "private, no-store" } });
}

export async function PATCH(request: Request) {
  const session = await currentSession();
  if (session?.role !== "ADMIN") {
    return NextResponse.json({ error: "Sin permiso" }, { status: 403 });
  }
  try {
    const input = inputSchema.parse(await request.json());
    const item = await db.$transaction(async tx => {
      const original = await tx.inventoryReviewItem.findUnique({ where: { id: input.id } });
      if (!original) throw new Error("La partida ya no está disponible.");
      if (original.resolvedAt) throw new Error("La partida ya se guardó. Actualiza la lista.");

      const [exactCode, ...aliases] = productCodeCandidates(input.code);
      const exactMatches = await tx.product.findMany({
        where: { technicalCode: { equals: exactCode, mode: "insensitive" } },
        take: 2,
      });
      if (exactMatches.length > 1) throw new Error("Hay varios registros con ese código. Corrige sus códigos en Productos.");
      let product = exactMatches[0];
      if (input.currentCode) {
        const current = await tx.product.findMany({
          where: { technicalCode: { equals: input.currentCode, mode: "insensitive" } },
          take: 2,
        });
        if (current.length !== 1) throw new Error("El código actual debe identificar un solo producto.");
        if (product && product.id !== current[0].id) throw new Error("El código nuevo pertenece a otro producto.");
        product = current[0];
      }
      if (!exactMatches.length && aliases.length) {
        const equivalent = await tx.product.findMany({
          where: { OR: aliases.map(code => ({ technicalCode: { equals: code, mode: "insensitive" } })) },
          take: 2,
        });
        if (equivalent.length > 1) throw new Error("Hay varios códigos equivalentes. Revisa sus fichas en Productos.");
        if (product && equivalent[0] && equivalent[0].id !== product.id) {
          throw new Error("El código nuevo equivale al código de otro producto.");
        }
        product = product || equivalent[0];
      }

      const data = { technicalCode: input.code, description: input.description };
      const saved = product
        ? await tx.product.update({ where: { id: product.id }, data })
        : await tx.product.create({ data });
      const resolved = await tx.inventoryReviewItem.update({
        where: { id: original.id },
        data: {
          resolvedCode: saved.technicalCode,
          resolvedDescription: saved.description,
          productId: saved.id,
          resolvedAt: new Date(),
        },
      });
      await tx.auditEvent.create({
        data: {
          userId: session.id,
          action: "RESOLVE",
          entity: "InventoryReviewItem",
          entityId: original.id,
          before: {
            code: product?.technicalCode ?? null,
            description: product?.description ?? null,
          },
          after: { ...data, productId: saved.id, stock: saved.stock.toString() },
        },
      });
      return resolved;
    }, { isolationLevel: Prisma.TransactionIsolationLevel.Serializable });
    return NextResponse.json(item);
  } catch (error) {
    if (error instanceof Prisma.PrismaClientKnownRequestError && ["P2002", "P2034"].includes(error.code)) {
      return NextResponse.json({ error: "El código o la partida cambió durante el guardado. Actualiza y vuelve a intentarlo." }, { status: 409 });
    }
    return NextResponse.json({
      error: error instanceof z.ZodError ? error.issues[0].message
        : error instanceof Error ? error.message : "No se pudo guardar la partida.",
    }, { status: 400 });
  }
}
