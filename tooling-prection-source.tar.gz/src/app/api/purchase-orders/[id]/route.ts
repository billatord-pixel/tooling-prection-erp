import { NextResponse } from "next/server";
import { currentSession } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { db } from "@/lib/db";
import { audit } from "@/lib/audit";

export async function GET(_: Request, { params }: { params: Promise<{ id: string }> }) {
  if (!await currentSession()) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  const order = await db.purchaseOrder.findUnique({ where: { id: (await params).id }, include: { supplier: true, lines: { include: { product: true } }, purchaseInvoices: { select: { id: true, folio: true, status: true, total: true } } } });
  return order ? NextResponse.json(order) : NextResponse.json({ error: "Pedido no encontrado." }, { status: 404 });
}

export async function PATCH(_: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await currentSession();
  if (!session || !can(session.role, "update")) return NextResponse.json({ error: "Sin permiso" }, { status: 403 });
  const { id } = await params; const before = await db.purchaseOrder.findUnique({ where: { id } });
  if (!before) return NextResponse.json({ error: "Pedido no encontrado." }, { status: 404 });
  if (before.status === "DELIVERED") return NextResponse.json({ error: "Un pedido recibido no se puede cancelar desde esta pantalla." }, { status: 409 });
  const order = await db.$transaction(async tx => {
    const current = await tx.purchaseOrder.findUniqueOrThrow({ where: { id }, include: { lines: true } });
    for (const line of current.lines) {
      const outstanding = line.quantity.minus(line.receivedQuantity);
      if (outstanding.gt(0)) {
        const product = await tx.product.findUniqueOrThrow({ where: { id: line.productId } });
        await tx.product.update({ where: { id: line.productId }, data: { onOrder: product.onOrder.gte(outstanding) ? { decrement: outstanding } : { set: 0 } } });
      }
    }
    return tx.purchaseOrder.update({ where: { id }, data: { status: "CANCELLED" } });
  });
  await audit({ userId: session.id, action: "UPDATE", entity: "PurchaseOrder", entityId: id, before: before as unknown as never, after: order as unknown as never });
  return NextResponse.json(order);
}

export async function DELETE(_: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await currentSession();
  if (!session || !can(session.role, "admin")) return NextResponse.json({ error: "Solo un administrador puede eliminar pedidos." }, { status: 403 });
  const { id } = await params;
  const order = await db.purchaseOrder.findUnique({ where: { id }, include: { purchaseInvoices: true, lines: true } });
  if (!order) return NextResponse.json({ error: "Pedido no encontrado." }, { status: 404 });
  if (order.purchaseInvoices.length || order.lines.some(line => Number(line.receivedQuantity) > 0)) return NextResponse.json({ error: "No se puede eliminar: conserva el pedido y cancélalo porque tiene recepción o facturas vinculadas." }, { status: 409 });
  await db.$transaction(async tx => {
    for (const line of order.lines) await tx.product.update({ where: { id: line.productId }, data: { onOrder: { decrement: line.quantity } } });
    await tx.purchaseOrder.delete({ where: { id } });
  });
  await audit({ userId: session.id, action: "DELETE", entity: "PurchaseOrder", entityId: id, before: order as unknown as never });
  return NextResponse.json({ ok: true });
}
