import { notFound } from "next/navigation";
import { currentSession } from "@/lib/auth";
import { InventoryReviewWorkspace } from "@/components/inventory-review-workspace";

export default async function InventoryReviewPage() {
  if ((await currentSession())?.role !== "ADMIN") notFound();
  return <InventoryReviewWorkspace/>;
}
