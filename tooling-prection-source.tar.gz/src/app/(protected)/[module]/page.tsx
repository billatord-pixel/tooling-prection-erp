import { notFound } from "next/navigation";
import "./module.css";
import { CatalogWorkspace } from "@/components/catalog-workspace";
import { InvoiceImportWorkspace } from "@/components/invoice-import-workspace";
import { OperationsWorkspace } from "@/components/operations-workspace";
import { AdminWorkspace } from "@/components/admin-workspace";
import { AuditWorkspace } from "@/components/audit-workspace";
import { currentSession } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { SalesInvoicesWorkspace } from "@/components/sales-invoices-workspace";
import { GlobalSearchWorkspace } from "@/components/global-search-workspace";
import { PendingModulesWorkspace } from "@/components/pending-modules-workspace";
import { DeliveriesListWorkspace } from "@/components/deliveries-workspace";
import { ProductsWorkspace } from "@/components/products-workspace";

const modules: Record<string, { eyebrow: string; title: string; description: string; action: string; placeholder: string; tabs?: string[] }> = {
  productos: { eyebrow: "CATÁLOGO TÉCNICO", title: "Productos", description: "Herramientas, costos, precios y disponibilidad.", action: "Registrar producto", placeholder: "WNMG432, CNMG 120408, descripción…", tabs: ["Activos", "Archivados"] },
  clientes: { eyebrow: "COMERCIAL", title: "Clientes", description: "Datos fiscales, condiciones comerciales e historial.", action: "Registrar cliente", placeholder: "RFC, razón social o contacto…", tabs: ["Activos", "Archivados"] },
  proveedores: { eyebrow: "COMPRAS", title: "Proveedores", description: "RFC, condiciones y vínculo fiscal con facturas.", action: "Registrar proveedor", placeholder: "RFC o proveedor…", tabs: ["Activos", "Archivados"] },
  inventario: { eyebrow: "PRODUCTOS", title: "Inventario", description: "Entradas, salidas, ajustes reversibles y documentos origen.", action: "Registrar ajuste", placeholder: "Producto, código o documento…", tabs: ["Existencias", "Movimientos"] },
  conciliacion: { eyebrow: "PRODUCTOS", title: "Conciliación de productos", description: "Revisa equivalencias antes de confirmar cualquier fusión.", action: "Analizar productos", placeholder: "Buscar productos similares…", tabs: ["Sugerencias", "Confirmadas", "Rechazadas"] },
  "revision-tecnica": { eyebrow: "PRODUCTOS", title: "Revisión técnica", description: "Compara atributos de herramientas antes de decidir equivalencias.", action: "Nueva revisión", placeholder: "Código técnico o descripción…" },
  cotizaciones: { eyebrow: "COMERCIAL", title: "Cotizaciones", description: "Propuestas, seguimiento e historial de precios.", action: "Nueva cotización", placeholder: "Folio o cliente…" },
  remisiones: { eyebrow: "COMERCIAL", title: "Remisiones", description: "Entregas relacionadas y salida controlada de inventario.", action: "Nueva remisión", placeholder: "Folio, cliente o producto…" },
  "facturas-venta": { eyebrow: "COMERCIAL", title: "Facturas de venta", description: "Importa CFDI XML, relaciona el cliente y procesa la salida de inventario.", action: "Importar XML", placeholder: "UUID, folio o cliente…" },
  "pedidos-compra": { eyebrow: "COMPRAS", title: "Pedidos de compra", description: "Solicitudes, partidas, fechas y recepción mediante factura de compra.", action: "Nuevo pedido", placeholder: "Folio o proveedor…" },
  "facturas-compra": { eyebrow: "COMPRAS", title: "Facturas de compra", description: "Importa CFDI XML, vincula proveedor y confirma la entrada de inventario.", action: "Importar XML", placeholder: "UUID, folio o proveedor…" },
  categorias: { eyebrow: "PRODUCTOS", title: "Categorías", description: "Clasificación homogénea del catálogo técnico.", action: "Nueva categoría", placeholder: "Buscar categoría…" },
  marcas: { eyebrow: "PRODUCTOS", title: "Marcas", description: "Marcas autorizadas y fabricantes del catálogo.", action: "Nueva marca", placeholder: "Buscar marca…" },
  usuarios: { eyebrow: "ADMINISTRACIÓN", title: "Usuarios", description: "Accesos, roles y permisos por módulo.", action: "Nuevo usuario", placeholder: "Nombre o correo…", tabs: ["Activos", "Inactivos"] },
  importaciones: { eyebrow: "ADMINISTRACIÓN", title: "Importaciones", description: "Carga controlada de documentos fiscales y archivos operativos.", action: "Nueva importación", placeholder: "Documento, UUID o fecha…" },
  respaldos: { eyebrow: "ADMINISTRACIÓN", title: "Respaldos", description: "Backups independientes y pruebas de restauración documentadas.", action: "Crear respaldo", placeholder: "Fecha o resultado de restauración…" },
  buscar: { eyebrow: "BÚSQUEDA GLOBAL", title: "Búsqueda", description: "Consulta productos, documentos y contactos desde un solo lugar.", action: "Buscar", placeholder: "Producto, folio, RFC o cliente…" },
  reportes: { eyebrow: "CONTROL", title: "Reportes", description: "Ventas, compras, cobranza, pagos e inventario por periodo.", action: "Generar reporte", placeholder: "Buscar reporte…" },
  auditoria: { eyebrow: "CONTROL", title: "Auditoría", description: "Cambios críticos, documentos, usuarios y trazabilidad operativa.", action: "Exportar auditoría", placeholder: "Usuario, entidad o acción…" },
  configuracion: { eyebrow: "ADMINISTRACIÓN", title: "Configuración", description: "Empresa, RFC, logo, datos de PDF, impuestos y condiciones.", action: "Guardar cambios", placeholder: "Buscar configuración…" },
};

export default async function ModulePage({ params }: { params: Promise<{ module: string }> }) {
  const { module } = await params;
  const session = await currentSession();
  if (module === "productos") return <ProductsWorkspace canCreate={!!session && can(session.role, "create")} canArchive={!!session && can(session.role, "archive")}/>;
  if (module === "clientes") return <CatalogWorkspace kind="customers" canEdit={!!session && can(session.role, "update")} canArchive={!!session && can(session.role, "archive")} canDelete={!!session && can(session.role, "admin")}/>;
  if (module === "proveedores") return <CatalogWorkspace kind="suppliers"/>;
  if (module === "pedidos-compra") return <OperationsWorkspace kind="purchase-orders"/>;
  if (module === "remisiones") return <DeliveriesListWorkspace/>;
  if (module === "inventario") return <OperationsWorkspace kind="inventory"/>;
  if (module === "marcas") return <AdminWorkspace mode="brands"/>;
  if (module === "categorias") return <AdminWorkspace mode="categories"/>;
  if (module === "usuarios") return <AdminWorkspace mode="users"/>;
  if (module === "configuracion") return <AdminWorkspace mode="settings"/>;
  if (module === "auditoria") return <AuditWorkspace/>;
  if (module === "facturas-compra") return <InvoiceImportWorkspace kind="purchase"/>;
  if (module === "facturas-venta") return <SalesInvoicesWorkspace view="list"/>;
  if (module === "buscar") return <GlobalSearchWorkspace/>;
  if (["conciliacion", "revision-tecnica", "importaciones", "respaldos", "reportes"].includes(module)) return <PendingModulesWorkspace module={module} role={session?.role || "READONLY"}/>;
  const item = modules[module];
  if (!item) notFound();
  return <section className="content"><div className="title-row"><div><span className="module-eyebrow">{item.eyebrow}</span><h1>{item.title}</h1><p>{item.description}</p></div><button className="primary page-action">{item.action}</button></div><div className="module-tools"><input aria-label={`Buscar en ${item.title}`} placeholder={item.placeholder}/>{item.tabs && <div className="module-tabs">{item.tabs.map((tab, index) => <button key={tab} className={index === 0 ? "selected" : ""}>{tab}</button>)}</div>}</div><section className="panel"><div className="panel-head"><h2>Sin registros</h2><span className="record-count">0 resultados</span></div><div className="empty">Este módulo está listo para operar con información nueva de Tooling Prection. No se importó información de Gerat Tool.</div></section></section>;
}
