import { Suspense } from "react";
import { redirect } from "next/navigation";
import { currentSession } from "@/lib/auth";
import { CustomerOrdersWorkspace } from "@/components/customer-orders-workspace";
export default async function Page({params}:{params:Promise<{id:string}>}){const session=await currentSession();if(session?.role!=="ADMIN")redirect("/ordenes-clientes");return <Suspense><CustomerOrdersWorkspace id={(await params).id} mode="edit" canWrite/></Suspense>;}
