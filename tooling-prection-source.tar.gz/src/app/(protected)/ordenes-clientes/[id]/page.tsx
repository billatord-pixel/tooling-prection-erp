import { Suspense } from "react";
import { currentSession } from "@/lib/auth";
import { CustomerOrdersWorkspace } from "@/components/customer-orders-workspace";
export default async function Page({params}:{params:Promise<{id:string}>}){const session=await currentSession();return <Suspense><CustomerOrdersWorkspace id={(await params).id} mode="detail" canWrite={session?.role==="ADMIN"}/></Suspense>;}
