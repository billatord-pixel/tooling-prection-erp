import { Suspense } from "react";
import { currentSession } from "@/lib/auth";
import { CustomerOrdersWorkspace } from "@/components/customer-orders-workspace";
export default async function Page(){const session=await currentSession();return <Suspense fallback={<p>Cargando órdenes…</p>}><CustomerOrdersWorkspace canWrite={session?.role==="ADMIN"}/></Suspense>;}
