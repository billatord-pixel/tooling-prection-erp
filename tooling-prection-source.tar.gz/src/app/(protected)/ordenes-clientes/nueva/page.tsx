import { Suspense } from "react";
import { redirect } from "next/navigation";
import { currentSession } from "@/lib/auth";
import { CustomerOrdersWorkspace } from "@/components/customer-orders-workspace";
export default async function Page(){const session=await currentSession();if(session?.role!=="ADMIN")redirect("/ordenes-clientes");return <Suspense><CustomerOrdersWorkspace mode="new" canWrite/></Suspense>;}
