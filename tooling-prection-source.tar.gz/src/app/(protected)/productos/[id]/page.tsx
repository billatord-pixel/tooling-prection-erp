import { currentSession } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { ProductDetailWorkspace } from "@/components/products-workspace";

export default async function ProductPage({ params }: { params: Promise<{ id: string }> }) {
  const [{ id }, session] = await Promise.all([params, currentSession()]);
  return <ProductDetailWorkspace productId={id} canUpdate={!!session && can(session.role, "update")} canArchive={!!session && can(session.role, "archive")} canManageCatalogs={session?.role === "ADMIN"}/>;
}
