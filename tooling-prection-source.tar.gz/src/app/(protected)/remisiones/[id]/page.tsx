import { DeliveryDetailWorkspace } from "@/components/deliveries-workspace";
export default async function DeliveryPage({ params }: { params: Promise<{ id: string }> }) { return <DeliveryDetailWorkspace deliveryId={(await params).id}/>; }
