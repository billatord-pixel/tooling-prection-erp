import { DeliveryFormWorkspace } from "@/components/deliveries-workspace";
export default async function EditDeliveryPage({ params }: { params: Promise<{ id: string }> }) { return <DeliveryFormWorkspace deliveryId={(await params).id}/>; }
