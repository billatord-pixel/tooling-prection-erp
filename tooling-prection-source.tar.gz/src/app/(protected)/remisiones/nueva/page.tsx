import { DeliveryFormWorkspace } from "@/components/deliveries-workspace";
export default function NewDeliveryPage() { return <DeliveryFormWorkspace/>; }
