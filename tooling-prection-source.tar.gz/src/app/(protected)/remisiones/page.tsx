import { DeliveriesListWorkspace } from "@/components/deliveries-workspace";
export default function RemissionsPage() { return <DeliveriesListWorkspace/>; }
