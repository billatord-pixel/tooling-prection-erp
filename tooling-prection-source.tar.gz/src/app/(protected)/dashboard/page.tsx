import { db } from "@/lib/db";
import Link from "next/link";

export const dynamic = "force-dynamic";

const mxn = new Intl.NumberFormat("es-MX", { style: "currency", currency: "MXN" });

export default async function DashboardPage() {
  const [products, pendingOrders, pendingSales, stock] = await Promise.all([db.product.count({ where: { status: "ACTIVE" } }), db.purchaseOrder.count({ where: { status: "PENDING" } }), db.salesInvoice.aggregate({ where: { status: "PENDING" }, _sum: { total: true } }), db.product.aggregate({ _sum: { stock: true } })]);
  const invoices = await db.salesInvoice.findMany({ take: 6, orderBy: { issueDate: "desc" }, include: { customer: true } });
  return <section className="content"><div className="title-row"><div><h1>Dashboard</h1><p>Operación de Tooling Prection · Inicio independiente octubre 2026</p></div></div><div className="cards"><div className="card"><label>Productos activos</label><strong>{products}</strong><small>Catálogo independiente</small></div><div className="card"><label>Pedidos pendientes</label><strong>{pendingOrders}</strong><small>Requieren seguimiento</small></div><div className="card"><label>Por cobrar</label><strong>{mxn.format(Number(pendingSales._sum.total ?? 0))}</strong><small>Facturas de venta pendientes</small></div><div className="card"><label>Existencia total</label><strong>{Number(stock._sum.stock ?? 0).toLocaleString("es-MX")}</strong><small>Unidades en inventario</small></div></div><section className="panel"><div className="panel-head"><h2>Facturas de venta recientes</h2><Link href="/facturas-venta">Ver todas</Link></div><div className="table-wrap"><table className="table"><thead><tr><th>Folio</th><th>Cliente</th><th>Fecha</th><th>Total</th><th>Estado</th></tr></thead><tbody>{invoices.length ? invoices.map(invoice => <tr key={invoice.id}><td>{invoice.folio}</td><td>{invoice.customer.legalName}</td><td>{invoice.issueDate.toLocaleDateString("es-MX")}</td><td>{mxn.format(Number(invoice.total))}</td><td><span className={`status ${invoice.status.toLowerCase()}`}>{invoice.status === "PAID" ? "Pagada" : invoice.status === "CANCELLED" ? "Cancelada" : "Pendiente"}</span></td></tr>) : <tr><td colSpan={5} className="empty">Aún no hay facturas de venta. El sistema inicia sin información histórica.</td></tr>}</tbody></table></div></section></section>;
}
