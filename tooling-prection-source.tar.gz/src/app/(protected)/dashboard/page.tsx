import { db } from "@/lib/db";
import Link from "next/link";
import "./dashboard.css";

export const dynamic = "force-dynamic";

const money = (amount: number, currency: string) =>
  new Intl.NumberFormat("es-MX", { style: "currency", currency }).format(amount);

export default async function DashboardPage() {
  const [products, pendingOrders, pendingSales, stock, invoices] = await Promise.all([
    db.product.count({ where: { status: "ACTIVE" } }),
    db.purchaseOrder.count({ where: { status: "PENDING" } }),
    db.salesInvoice.groupBy({ by: ["currency"], where: { status: "PENDING" }, _sum: { total: true } }),
    db.product.aggregate({ _sum: { stock: true } }),
    db.salesInvoice.findMany({ take: 6, orderBy: [{ issueDate: "desc" }, { createdAt: "desc" }], include: { customer: true } }),
  ]);
  const receivables = pendingSales.length
    ? pendingSales.map(row => money(Number(row._sum.total ?? 0), row.currency)).join(" · ")
    : money(0, "USD");

  return <section className="content dashboard-content">
    <div className="title-row"><div><span className="module-eyebrow">RESUMEN OPERATIVO</span><h1>Dashboard</h1><p>Estado actual de la operación comercial de Tooling Prection.</p></div><Link className="secondary" href="/reportes">Ver reportes completos</Link></div>
    <div className="cards">
      <div className="card"><label>Productos activos</label><strong>{products.toLocaleString("es-MX")}</strong><small>Catálogo de Tooling Prection</small></div>
      <div className="card"><label>Pedidos pendientes</label><strong>{pendingOrders.toLocaleString("es-MX")}</strong><small>Esperando recepción de factura</small></div>
      <div className="card"><label>Por cobrar</label><strong>{receivables}</strong><small>Facturas de venta pendientes · por moneda</small></div>
      <div className="card"><label>Existencia total</label><strong>{Number(stock._sum.stock ?? 0).toLocaleString("es-MX", { maximumFractionDigits: 3 })}</strong><small>Unidades registradas en inventario</small></div>
    </div>
    <section className="panel"><div className="panel-head"><div><h2>Facturas de venta recientes</h2><span className="record-count">Hasta 6 registros · más recientes primero</span></div><Link href="/facturas-venta">Ver todas</Link></div><div className="table-wrap"><table className="table dashboard-invoices-table"><thead><tr><th>Folio</th><th>Cliente</th><th>Fecha</th><th>Total</th><th>Estado</th></tr></thead><tbody>{invoices.length ? invoices.map(invoice => <tr key={invoice.id}><td><Link href={`/facturas-venta/${invoice.id}`}>{invoice.folio}</Link></td><td>{invoice.customer.legalName}</td><td>{invoice.issueDate.toLocaleDateString("es-MX")}</td><td>{money(Number(invoice.total), invoice.currency)}</td><td><span className={`status ${invoice.status.toLowerCase()}`}>{invoice.status === "PAID" ? "Pagada" : invoice.status === "CANCELLED" ? "Cancelada" : "Pendiente"}</span></td></tr>) : <tr><td colSpan={5} className="empty">Aún no hay facturas de venta. El sistema inicia sin información histórica.</td></tr>}</tbody></table></div></section>
  </section>;
}
