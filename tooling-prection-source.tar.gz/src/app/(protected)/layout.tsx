import { redirect } from "next/navigation";
import { AppShell } from "@/components/app-shell";
import { currentSession } from "@/lib/auth";

export default async function ProtectedLayout({ children }: { children: React.ReactNode }) {
  const session = await currentSession(); if (!session) redirect("/login"); return <AppShell user={session}>{children}</AppShell>;
}
