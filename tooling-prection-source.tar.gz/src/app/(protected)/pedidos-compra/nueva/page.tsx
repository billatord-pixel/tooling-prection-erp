import { OperationsWorkspace } from "@/components/operations-workspace";
export default function NewPurchaseOrderPage(){return <OperationsWorkspace kind="purchase-orders" initialOpen/>;}
