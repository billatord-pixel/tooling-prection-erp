import { PurchaseOrderDetail } from "@/components/purchase-order-detail";
export default async function PurchaseOrderPage({params}:{params:Promise<{id:string}>}){return <PurchaseOrderDetail id={(await params).id}/>;}
