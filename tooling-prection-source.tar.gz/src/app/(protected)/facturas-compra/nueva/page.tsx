import { PurchaseInvoicesWorkspace } from "@/components/purchase-invoices-workspace";
export default function NewPurchaseInvoicePage(){return <PurchaseInvoicesWorkspace mode="new"/>;}
