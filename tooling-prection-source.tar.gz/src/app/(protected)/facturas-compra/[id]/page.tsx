import { PurchaseInvoicesWorkspace } from "@/components/purchase-invoices-workspace";
export default async function PurchaseInvoicePage({params}:{params:Promise<{id:string}>}){return <PurchaseInvoicesWorkspace mode="detail" id={(await params).id}/>;}
