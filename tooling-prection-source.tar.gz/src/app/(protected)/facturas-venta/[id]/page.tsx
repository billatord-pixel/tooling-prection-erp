import { SalesInvoicesWorkspace } from "@/components/sales-invoices-workspace";

export default async function SalesInvoiceDetailPage({ params }: { params: Promise<{ id: string }> }) { return <SalesInvoicesWorkspace view="detail" invoiceId={(await params).id}/>; }
