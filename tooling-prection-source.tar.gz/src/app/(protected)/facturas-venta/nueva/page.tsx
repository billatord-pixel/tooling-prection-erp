import { SalesInvoicesWorkspace } from "@/components/sales-invoices-workspace";

export default function NewSalesInvoicePage() { return <SalesInvoicesWorkspace view="new"/>; }
