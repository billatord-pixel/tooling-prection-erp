import { QuoteDetailWorkspace } from "@/components/quote-workspace";

export default async function QuoteDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <QuoteDetailWorkspace quoteId={id}/>;
}
