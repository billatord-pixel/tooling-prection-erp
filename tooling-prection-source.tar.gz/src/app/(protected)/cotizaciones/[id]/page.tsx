import { QuoteDetailWorkspace } from "@/components/quote-workspace";
import { currentSession } from "@/lib/auth";

export default async function QuoteDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const session = await currentSession();
  return <QuoteDetailWorkspace quoteId={id} canManage={session?.role === "ADMIN"}/>;
}
