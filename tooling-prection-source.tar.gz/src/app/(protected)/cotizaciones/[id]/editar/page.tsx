import { QuoteFormWorkspace } from "@/components/quote-workspace";

export default async function EditQuotePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <QuoteFormWorkspace quoteId={id}/>;
}
