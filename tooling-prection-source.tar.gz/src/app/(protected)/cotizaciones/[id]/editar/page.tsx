import { QuoteFormWorkspace } from "@/components/quote-workspace";
import { currentSession } from "@/lib/auth";
import { notFound } from "next/navigation";

export default async function EditQuotePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const session = await currentSession();
  if (session?.role !== "ADMIN") notFound();
  return <QuoteFormWorkspace quoteId={id}/>;
}
