import { QuoteWorkspace } from "@/components/quote-workspace";
import { currentSession } from "@/lib/auth";

export default async function QuotesPage() { const session = await currentSession(); return <QuoteWorkspace canCreate={session?.role === "ADMIN" || session?.role === "SALES"}/>; }
