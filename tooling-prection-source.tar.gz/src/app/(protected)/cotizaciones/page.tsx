import { QuoteWorkspace } from "@/components/quote-workspace";

export default function QuotesPage() { return <QuoteWorkspace/>; }
