import { QuoteFormWorkspace } from "@/components/quote-workspace";
import { currentSession } from "@/lib/auth";

export default async function NewQuotePage() {
  const session = await currentSession();
  return <QuoteFormWorkspace defaultSeller={session?.name ?? ""} canManageCatalog={session?.role === "ADMIN"}/>;
}
