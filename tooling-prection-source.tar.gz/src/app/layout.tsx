import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = { title: "Tooling Prection ERP", description: "Operación independiente de Tooling Prection" };

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="es"><body>{children}</body></html>;
}
