# Tooling Prection ERP

ERP independiente para Tooling Prection. No contiene conexiones, secretos, usuarios, archivos ni datos históricos de Gerat Tool.

## Puesta en marcha local

1. Copia `.env.example` a `.env` y define valores nuevos e independientes.
2. Crea una base PostgreSQL nueva y apunta `DATABASE_URL` a ella.
3. Ejecuta `pnpm db:generate`, `pnpm db:migrate --name init` y `pnpm db:seed`.
4. Arranca con `pnpm dev`.

La semilla únicamente registra identidad corporativa, logotipo y marcas oficiales. Define `INITIAL_ADMIN_EMAIL` e `INITIAL_ADMIN_PASSWORD` antes de correrla para crear el primer administrador.

## Railway

1. Crea el proyecto **tooling-prection-erp** en Railway, separado de Gerat Tool.
2. Agrega un PostgreSQL nuevo llamado **tooling-prection-postgres** y un servicio web **tooling-prection-web** desde este repositorio.
3. Define variables nuevas desde `.env.example`, incluidos `AUTH_SECRET`, credenciales SMTP y almacenamiento de archivos propio.
4. El primer despliegue ejecuta `pnpm db:bootstrap`: crea el esquema vacío propio y registra la identidad, marcas y administrador inicial. No carga XML, PDF ni datos comerciales. Los siguientes arranques repiten la semilla de forma idempotente.
5. Activa backup diario del PostgreSQL, conserva una prueba de restauración y configura alertas de `/api/health`, logins fallidos y respuestas HTTP 5xx.

No conectes ningún volumen, bucket, dominio, base, backup ni variable existente de Gerat Tool.

## Matriz de permisos

| Rol | Alcance |
| --- | --- |
| Administrador | Todos los módulos, usuarios, configuración, auditoría y respaldos. |
| Compras | Proveedores, productos, pedidos y facturas de compra. |
| Ventas | Clientes, productos de consulta, cotizaciones, remisiones y facturas de venta. |
| Inventario | Productos, existencias, movimientos, remisiones y conciliación. |
| Consulta | Lectura de módulos autorizados, sin cambios. |
